<?php
    session_start();   
	require_once 'core/require.php'; 
	require_once 'Model/connexion.php';
     if (!isset($_SESSION['user'])) {
    session_unset();
    session_destroy();
    header('location: index.php');    
    }
    $etb->ShowEtb();
    $etb->CkLE();
    $etb->ckexneE();
    $nbclasses=$class->NombreClasses();
?>

<!DOCTYPE html>
<html>
	<head>
	 <?php Config::head(); ?>
		<title>Ndalère Tools|Login</title>
	</head>

<body class="fix-header">
     <!-- #header -->
    <?php Head::SimpleHead(); ?>  
        <!-- Page Content -->
        <!-- ============================================================== -->
        <div id="page-wrapper">
            <div class="container-fluid">
            

                <!-- ============================================================== -->
                <!-- table -->
                <!-- ============================================================== -->
                <div class="row">
                    <div class="col-md-12 col-lg-12 col-sm-12">
                        <div class="white-box">
                            <div class="col-md-3 col-sm-4 col-xs-6 pull-right">
                                <select class="form-control pull-right row b-none">
                                    <option><a href=""></a></option>
                                    <option>April 2017</option>
                                    <option>May 2017</option>
                                    <option>June 2017</option>
                                    <option>July 2017</option>
                                </select>
                            </div>
                            <h3 class="box-title">Toutes les classes > ( <?php  echo $nbclasses; ?> ) <button type="button" class="btn btn-primary ml-2" data-toggle="modal" data-target="#addclasse" data-whatever="@mdo">Ajouter une classe</button></h3>
                            <div class="table-responsive table-sm">
                                <table class="table">
                                    <thead>
                                        <tr>
                                            <th>#</th>
                                            <th>NOM</th>
                                            <th>NIVEAU</th>
                                            <th>MODIFIER</th>
                                            <th>SUPPRIMER</th>
                                        </tr>
                                    </thead>
                                    <tbody class="table-hover">
                                       <!--  <tr>
                                            <td>1</td>
                                            <td class="txt-oflo">Elite admin</td>
                                            <td>SALE</td>
                                            <td class="txt-oflo">
                                                <a href="" class="waves-effect"><i class="fa fa-user fa-edit" aria-hidden="true"></i></a></td>
                                            <td><span class="text-success">$24</span></td>
                                        </tr> -->
                                        <?php  $class-> ShowAllClasses(); ?>
                                        
                            
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- ============================================================== -->
                <!-- Gestion des Classes -->

                 <div class="row">
       

                    <div class="modal fade" id="addclasse" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                      <div class="modal-dialog" role="document">
                        <div class="modal-content">
                          <div class="modal-header">
                            <h5 class="modal-title" id="exampleModalLabel">Ajouter une classe</h5>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                              <span aria-hidden="true">&times;</span>
                            </button>
                          </div>
                          <div class="modal-body">
                           <form action="Controler/classes/addclasse.php" method="post" >
                                <div class="form-row">
                                    <div class="form-group col-4 ">
                                        <label for="inputEmail4">Nom de la classe: </label>
                                        <input type="text" class="form-control" id="nom_class" name="nom_class"  maxlength="10"   required>
                                    </div>
                                    <div class="form-group col-4 ">
                                        <label for="inputState">Niveau</label>
                                         <select id="inputState" class="form-control" name="niveau" required>
                                            <option >Choisir...</option>
                                            <option value="1">6EME / F1 / 1E_AN</option>
                                            <option value="2">5EME / F2 / 2E_AN</option>
                                            <option value="3">4EME / F3 / 3E_AN</option>
                                            <option value="4">3EME / F4 / 4E_AN</option>
                                            <option value="5">2NDE / F5 </option>
                                            <option value="6">1ERE / L6 </option>
                                            <option value="7">TLE / U6 </option>
                                        
                                        </select>
                                    </div>

                                    <div class="form-group col-4  ">
                                            <label for="inputState">Session</label>
                                            <select id="inputState" class="form-control" name="session"  required="true" required>
                                                <option >Choisir...</option>
                                                <option value="SFG">SF E.Général</option>
                                                <option value="SAG">SA E.Général</option>
                                                <option value="SFT">SF E.Technique</option>
                                                <option value="SAT">SA E.Technique</option>
                                            </select>
                                    </div>
                                       <button type="submit" class="btn btn-primary">Enrégistrer</button>
                                </form>
                                </div>
  
                                </div>
                                <div class="modal-footer">
                                    
                                 
                                <button type="button" class="btn btn-secondary" data-dismiss="modal">Annuler</button>
                          </div>
                        </div>
                      </div>
                </div>
        </div>
                
            </div>
           
        <?php 
            Footers::TDfoot();
        ?>
        </div>
        <!-- ============================================================== -->
        <!-- End Page Content -->
        <!-- ============================================================== -->
    </div>


		<?php 
		 	Config::scriptJs();
		?>
        <script type="text/javascript">
            $('#exampleModal').on('show.bs.modal', function (event) {
  var button = $(event.relatedTarget) // Button that triggered the modal
  var recipient = button.data('whatever') // Extract info from data-* attributes
  // If necessary, you could initiate an AJAX request here (and then do the updating in a callback).
  // Update the modal's content. We'll use jQuery here, but you could use a data binding library or other methods instead.
  var modal = $(this)
  modal.find('.modal-title').text('New message to ' + recipient)
  modal.find('.modal-body input').val(recipient)
})
        </script>
	</body>
</html>