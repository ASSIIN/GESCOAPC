<?php
session_start();
ini_set('display_errors', 0);
error_reporting(0);

require_once '../../Model/connexion.php';
require_once '../../core/require.php'; 

$bdd = $GLOBALS['bdd'];

if (isset($_POST['nom_std']) && !empty($_POST['nom_std'])) {
    
    $classe_std = htmlspecialchars($_POST['classe_std']);
    $nom_std = mb_strtoupper(trim(preg_replace('/\s+/', ' ', htmlspecialchars($_POST['nom_std']))), 'UTF-8');
    $cni_std = !empty($_POST['cni_std']) ? mb_strtoupper(trim(preg_replace('/\s+/', ' ', htmlspecialchars($_POST['cni_std']))), 'UTF-8') : '';
    $date_naiss = strval(htmlspecialchars($_POST['date_naiss_std']));
    $sexe_std = htmlspecialchars($_POST['sexe']);
    $lieu_naiss_std = mb_strtoupper(trim(preg_replace('/\s+/', ' ', htmlspecialchars($_POST['lieu_naiss_std']))), 'UTF-8');
    $handicap = htmlspecialchars($_POST['handicap']);

    // Sécurité 1 : Interdiction de duplication sur le matricule national (CNI)
    if (!empty($cni_std) && $std->CkExistingMatricule($cni_std) && strlen($cni_std) == 9) {
        header('location: ../../home.php?exist=ok');
        exit();
    }

    // Sécurité 2 : Génération automatisée et incrémentale du matricule local unique (0001, 0042)
    $lastMat = $std->IncrimValMatr();
    if (!empty($lastMat)) {
        $NumMat = (int)$lastMat + 1;  
    } else {
        $NumMat = 1;
    }
    $code = substr("0000" . $NumMat, -4);

    // Sécurité 3 : Insertion par requête préparée PDO
    $req = $bdd->prepare('INSERT INTO eleves (nom_std, cni_std, date_nais, lieu_nais, sexe_std, mat_std, ref_class, handicap, statut, contenu_std) VALUES(?, ?, ?, ?, ?, ?, ?, ?, "N", "avatar.png")');
    
    if ($req->execute(array($nom_std, $cni_std, $date_naiss, $lieu_naiss_std, $sexe_std, $code, $classe_std, $handicap))) {
        header('location: ../../home.php?cls=' . urlencode($classe_std));
        exit();
    } else {
        echo "Erreur d'insertion dans la base de données locale.";
    }
} else {
    header('location: ../../home.php');
    exit();
}
?>
