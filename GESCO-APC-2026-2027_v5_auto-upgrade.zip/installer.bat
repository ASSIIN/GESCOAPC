@echo off
chcp 65001 >nul
title Installation GESCO-APC 2026-2027

setlocal EnableExtensions EnableDelayedExpansion

echo ============================================================
echo   GESCO-APC 2026-2027 - Installateur automatique
echo ============================================================
echo.

rem ============ 1. Verification de Laragon ============
set "LARAGON_DIR=C:\laragon"
if not exist "%LARAGON_DIR%\laragon.exe" (
    echo.
    echo [ERREUR] Laragon n'est pas detecte sur ce poste.
    echo  - L'application doit etre installee dans  : C:\laragon
    echo  - Site de telechargement                  : https://laragon.org/download
    echo.
    echo Installez Laragon, puis relancez ce fichier.
    pause
    exit /b 1
)
if not exist "%LARAGON_DIR%\www" (
    echo.
    echo [ERREUR] Le dossier C:\laragon\www est introuvable.
    echo Reinstallez Laragon correctement, puis relancez ce fichier.
    pause
    exit /b 1
)
echo [OK] Laragon detecte.
echo.

rem ============ 2. Copie du logiciel dans C:\laragon\www ============
set "TARGET=%LARAGON_DIR%\www\gescoapc"
set "SOURCE=%~dp0"

set "A=%~dp0"
set "B=%TARGET%\"
if /i "%A%"=="%B%" goto deja_en_place

if not exist "%TARGET%" mkdir "%TARGET%"
echo Copie des fichiers vers : %TARGET%
echo (le dossier d'origine n'est pas modifie)
robocopy "%SOURCE%" "%TARGET%" /E /XD .git /NFL /NDL /NJH /NJS /NP /R:1 /W:1
if errorlevel 8 (
    echo.
    echo [ERREUR] Echec de la copie des fichiers.
    pause
    exit /b 1
)
echo [OK] Logiciel installe dans le dossier www de Laragon.
echo.

:deja_en_place

rem ============ 3. Demarrage de Laragon ============
echo Demarrage de Laragon...
if exist "%LARAGON_DIR%\laragon.exe" start "" "%LARAGON_DIR%\laragon.exe"

rem ============ 4. Attente du demarrage de MySQL ============
echo.
echo Dans la fenetre de Laragon, cliquez sur le bouton  Start All
echo (cela demarre MySQL et Apache), puis patientez...
set /a WAIT=0
:wait_mysql
set /a WAIT+=1
netstat -an 2>nul | findstr /C:":3306 " >nul 2>&1
if not errorlevel 1 goto mysql_ok
if %WAIT% GEQ 45 (
    echo.
    echo [Attention] MySQL ne repond pas encore.
    echo Dans Laragon, cliquez sur  Start All  puis appuyez sur une touche.
    pause
    goto mysql_ok
)
timeout /t 2 /nobreak >nul
goto wait_mysql

:mysql_ok
echo [OK] Base de donnees MySQL demarree.
echo.

rem ============ 5. Ouverture de l'application ============
echo Ouverture de GESCO-APC dans le navigateur...
echo La base de donnees est creee automatiquement au premier chargement.
start "" "http://localhost/gescoapc"

echo.
echo ============================================================
echo  Installation terminee !
echo   Identifiant : 1275     Mot de passe : 1275
echo   (a modifier apres la premiere connexion)
echo ============================================================
echo.
pause
exit /b 0