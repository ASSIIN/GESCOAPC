<?php 
	session_start();
	require_once '../Model/connexion.php';
	require_once '../core/require.php'; 

	// Sécurité : connexion obligatoire
	if (!isset($_SESSION['user'])) {
		header('location: ../index.php');
		exit;
	}

	$etb->ShowEtb(); 

	$lgpre_m=strlen((string)($_SESSION['pre_matr'] ?? ''));
    $ref_cls= trim((string)($_POST['refcls'] ?? ''));
	$ref_mat= trim((string)($_POST['refmat'] ?? ''));
	$ref_seq= trim((string)($_POST['refseq'] ?? ''));
	if ($ref_cls==='' || $ref_mat==='' || $ref_seq==='' || empty($_FILES['excel']) || $_FILES['excel']['error']!==UPLOAD_ERR_OK) {
		header('location: ../espace_notes.php');
		exit;
	}
	$bdd = $GLOBALS['bdd'];	
	$note= array();
	$fileName = $_FILES["excel"]["name"];
	$fileExtension = explode('.', $fileName);
		$fileExtension = strtolower(end($fileExtension));
	$exts_ok = array('xls','xlsx','ods','csv');
	// CORRECTION : seuls les formats réellement lus par la bibliothèque sont acceptés
	if (!in_array($fileExtension, $exts_ok)) {
		header('location: ../espace_notes.php?ef');
		exit;
	}
	$newFileName = date("Y.m.d") . " - " . date("h.i.sa") . "." . $fileExtension;

			// CORRECTION : chemin absolu de stockage, dossier créé s'il manque
			$targetDirectory = __DIR__ . '/../uploads/notes/' . $newFileName;
			$dirTarget = dirname($targetDirectory);
			if (!is_dir($dirTarget)) {
				mkdir($dirTarget, 0755, true);
			}
			if (!move_uploaded_file($_FILES['excel']['tmp_name'], $targetDirectory)) {
				header('location: ../espace_notes.php?up');
				exit;
			}

			error_reporting(0);
			ini_set('display_errors', 0);

			// CORRECTION : chemins résolus depuis ce dossier (et non depuis la racine)
			require __DIR__ . '/excelReader/excel_reader2.php';
			require __DIR__ . '/excelReader/SpreadsheetReader.php';
			$reader = new SpreadsheetReader($targetDirectory);
			foreach($reader as $key => $value){
				$mat_std=substr($value[0], $lgpre_m);
				$ref_std=(int)$mat_std;	

				// Ignorer les lignes sans matricule ou sans note
				if ($mat_std==='' || ($value[2]??'')==='') { continue; }

				if ($value[2]!="")
				{
					if ($class->CheckNoteStd_by_MatCls($ref_cls,$ref_mat,$ref_seq,$mat_std)) {
						$coef=$opt->SelectCoef_by_MatCls($ref_cls,$ref_mat);
						$notei=(float)$value[2];
						if ($notei<0) {
						$notei=NULL;
						$ucoef=NULL;
						$note_x_coeff=NULL;
						$bdd = $GLOBALS['bdd'];	
						// SÉCURISÉ : requête préparée anti-injection SQL (WHERE sur valeurs liées)
						$req ='UPDATE table_note_par_mat SET note= ?, coef= ?, note_x_coeff= ? WHERE ref_cls=? AND ref_mat=? AND ref_eval=? AND ref_std=?';

						$rep = $bdd->prepare($req);
						$rep->execute(array($notei,$ucoef,$note_x_coeff,$ref_cls,$ref_mat,$ref_seq,$mat_std));
							
						}
						else{
							// CORRECTION : note plafonnée à 20 (échelle du bulletin)
							$notei=(float)$value[2];
							if ($notei>20) { $notei=20.0; }
							$note_x_coeff=$notei*$coef;
							$note_x_coeff=(string)$note_x_coeff;
							$bdd = $GLOBALS['bdd'];	
							// SÉCURISÉ : requête préparée anti-injection SQL (WHERE sur valeurs liées)
							$req ='UPDATE table_note_par_mat SET note= ?, coef= ?, note_x_coeff= ? WHERE ref_cls=? AND ref_mat=? AND ref_eval=? AND ref_std=?';

							$rep = $bdd->prepare($req);
							$rep->execute(array($notei,$coef,$note_x_coeff,$ref_cls,$ref_mat,$ref_seq,$mat_std));
						}
						}
					else
					{
						
						$coef=$opt->SelectCoef_by_MatCls($ref_cls,$ref_mat);
						$notei=(float)$value[2];
						if ($notei<0) { $notei=0.0; }
						// CORRECTION : note plafonnée à 20 (échelle du bulletin)
						if ($notei>20) { $notei=20.0; }
						$note_x_coeff=$notei*$coef;
						$note_x_coeff=(string)$note_x_coeff;
						$req = "INSERT INTO table_note_par_mat (ref_mat, ref_cls, ref_std, ref_eval, note, coef, note_x_coeff) VALUES(?, ?, ?, ?, ?, ?, ?)" ;

						$rep = $bdd->prepare($req);
						if ($rep->execute(array($ref_mat, $ref_cls, $mat_std, $ref_seq, $notei,$coef,$note_x_coeff ))) {
						}
						else{
							echo "Erreur2";
						}
					}
				}
			}

		if (($_SESSION['user_role']!="admin") and ($_SESSION['user_role']!="cs") and ($_SESSION['user_role']!="pcpl")) 
		{
       			header('location: ../espace_notes.php?cls='.$ref_cls.'&mat='.$ref_mat.'&seq='.$ref_seq.'');    
		}else{
			header('location: ../gestion_notes_by_mat.php?cls='.$ref_cls.'&mat='.$ref_mat.'&seq='.$ref_seq.'');
		}

?>