<?php
session_start();
require_once '../Model/connexion.php';
require_once '../core/require.php';
 if (!isset($_SESSION['user'])) {
    session_unset();
    session_destroy();
    header('location: ../index.php');    
    }
 $etb->ShowEtb();
 if (!isset($_SESSION['listnv']) ) {
	header('location: ../impression.php');
 }
 $refnv=$_SESSION['listnv'];
require('fpdf.php');
$pdf = new FPDF();

class PDF extends FPDF
{
// En-tête
function Header()
{
	 $this->SetY(15);
    // Logo
    $this->Image('../plugins/images/'.$_SESSION['logo_etb'].'',10,6,30);
    // Police Arial gras 15
    $this->SetFont('Arial','B',15);
    // Décalage à droite
    $this->Cell(80);
    // Titre
    $this->Cell(30,10,'Titre',1,0,'C');
    // Saut de ligne
    $this->Ln(20);
}

// Pied de page
function Footer()
{
    // Positionnement à 1,5 cm du bas
    $this->SetY(-15);
    // Police Arial italique 8
    $this->SetFont('Arial','I',8);
    // Numéro de page
    $this->Cell(0,10,'Page '.$this->PageNo().'/{nb}',0,0,'C');
}
}
$pdf->AliasNBPages();
$pdf->AddPage();
//code for print data

		 $bdd = $GLOBALS['bdd'];
			$reponse = $bdd->query('SELECT * FROM eleves where id>=0 order by nom_std asc');

			$i=1;
			$eff=0;
			/*En-tête*/
				$pdf->SetFont('Times','',8);
				$pdf->Image('../plugins/images/'.$_SESSION['logo_etb'].'',90,15,30);
				$pdf->Cell(70,4,'REPUBLIQUE DU CAMEROUN',0,0,'C');
				$pdf->Cell(50,4,'',0,0);
				$pdf->Cell(70,4,'REPUBLIC OF CAMEROON',0,1,'C');

				$pdf->Cell(70,4,'Paix-Travail-Patrie',0,0,'C');
				$pdf->Cell(50,4,'',0,0);
				$pdf->Cell(70,4,'Peace-Work-Fatherland',0,1,'C');

				$pdf->Cell(70,4, utf8_to_cp1252("".$_SESSION['minist_etb_fr'].""),0,0,'C');
				$pdf->Cell(50,4,'',0,0);
				$pdf->Cell(70,4,utf8_to_cp1252(''.$_SESSION['minist_etb_en'].''),0,1,'C');

				$pdf->Cell(70,4,utf8_to_cp1252("".$_SESSION['region_etb_fr'].""),0,0,'C');
				$pdf->Cell(50,4,'',0,0);
				$pdf->Cell(70,4,utf8_to_cp1252(''.$_SESSION['region_etb_en'].''),0,1,'C');

				$pdf->Cell(70,4,utf8_to_cp1252(''.$_SESSION['depart_etb_fr'].''),0,0,'C');
				$pdf->Cell(50,4,'',0,0);
				$pdf->Cell(70,4,utf8_to_cp1252(''.$_SESSION['depart_etb_en'].''),0,1,'C');
				$pdf->SetFont('Times','B',10);
				$pdf->Cell(70,6,utf8_to_cp1252(''.$_SESSION['nom_etb_fr'].''),0,0,'C');
				$pdf->Cell(50,6,'',0,0);
				$pdf->Cell(70,6,utf8_to_cp1252(''.$_SESSION['nom_etb_en'].''),0,1,'C');
				$pdf->SetFont('Times','',8);
				$pdf->Cell(70,5,utf8_to_cp1252(''.$_SESSION['code_pste_etb'].' / '.$_SESSION['tel_etb'].''),0,0,'C');
				$pdf->Cell(50,5,'',0,0);
				$pdf->Cell(70,5,utf8_to_cp1252(''.$_SESSION['code_pste_etb'].'/ '.$_SESSION['tel_etb'].''),0,1,'C');
				$pdf->SetFont('Times','',8);
				$pdf->Cell(70,4,utf8_to_cp1252(''.$_SESSION['email_etb'].''),0,0,'C');
				$pdf->Cell(50,4,'',0,0);
				$pdf->Cell(70,4,utf8_to_cp1252(''.$_SESSION['email_etb'].''),0,1,'C');
					$pdf->Ln();
					$pdf->SetFont('Times','I',12);
					$pdf->Cell(65,5,'',0,0);
					$pdf->Cell(60,5,utf8_to_cp1252(''.$_SESSION['code_im_etb'].''),0,0,'C');
					$pdf->Ln();
					$pdf->Ln();
			/*FIN En-tête*/
			$nomnv=$class->ReturnNomNiveau_by_Ref($refnv);

			//Titre 
				$pdf->SetFont('Times','I',10);
				$pdf->Cell(50,5,'',0,0,'C');
				$pdf->Cell(60,5,'ANNEE SCOLAIRE/SCHOOL ',0,0,'R');
				$pdf->SetFont('Times','B',12);
				$pdf->Cell(40,5,''.$_SESSION['school_year'].'',0,0,'L');
				$pdf->Cell(40,5,'',0,1,'C');
				
					$pdf->SetFont('Times','B',12);
					$pdf->SetFillColor(171,177,186);
					$pdf->SetFillColor(217,245,254);
					$pdf->Cell(20,6,'',0,0,'C');
					$pdf->Cell(150,6,'LISTE PAR NIVEAU / LIST BY LEVEL',1,0,'C',1);
					$pdf->SetFillColor(171,177,186);
					$pdf->Cell(20,6,'',0,1,'C');
					$pdf->Ln();

				//$nbstd=$class->NbrStudentByAll();
				$nbstd=$class->NbrStudentByNv($refnv);
				$nbM=$class->NbrBySexeByNv($refnv,'M');
				$nbF=$class->NbrBySexeByNv($refnv,'F');
				$pdf->Cell(25,5,"",0,0,'L');
				$pdf->Cell(20,5,"NIVEAU:",0,0,'L');
				$pdf->Cell(60,5,utf8_to_cp1252($nomnv),0,0,'L');
				$pdf->Cell(25,5,"Eff: $nbstd",0,0,'C');
				$pdf->Cell(20,5,"M: $nbM",0,0,'C');
				$pdf->Cell(20,5,"F: $nbF",0,0,'C');
				$pdf->Ln();
			
			$pdf->SetFont('Times','B',8);
				$pdf->Ln();
					$pdf->Cell(10,6,utf8_to_cp1252('N°'),1,0);
					$pdf->Cell(20,6, utf8_to_cp1252('N° INSCRIPT'),1,0);
					$pdf->Cell(22,6,'MATRICULE',1,0);
					$pdf->Cell(61,6,utf8_to_cp1252('Noms_et_Prénoms/Full_Name'),1,0);
					$pdf->Cell(10,6,'Sexe',1,0);
					$pdf->Cell(10,6,'Red',1,0);
					$pdf->Cell(22,6,utf8_to_cp1252('Né(e)le/Born'),1,0);
					$pdf->Cell(38,6,'Lieu_de_nais/Place',1,0);
					$pdf->SetFont('Times','B',9);
			 
			while($row = $reponse->fetch(PDO::FETCH_ASSOC)) 
			{
				$nv=$class->ReturnClasseNvByCode($row['ref_class']);
				$Nom=htmlspecialchars($row['nom_std']);
				$Nom=strtoupper($Nom);
				$Nom=substr($Nom, 0,33);
				$Nom = str_replace("&#039;", "'", $Nom);

				$lieu_nais=mb_strtoupper($row['lieu_nais']);
				$lieu_nais=substr($lieu_nais, 0,27);
				$lieu_nais = str_replace("&#039;", "'", $lieu_nais);

				$date_nais_fr= date('d/m/Y ',strtotime($row['date_nais']));
				if ($nv==$refnv) {
					# code...
				
					/*$row['mat_std'];
					$row['nom_prenom_std']
					$row['sexe_std']
					$row['date_nais']
					$row['lieu_nais']*/
					$pdf->SetFont('Arial','',8);
					$pdf->Ln();
						$pdf->Cell(10,5,$i,1,0);
						$pdf->Cell(20,5,utf8_to_cp1252(''.$_SESSION['pre_matr'].''.$row['mat_std'].''),1,0,'C');
					$pdf->Cell(22,5,utf8_to_cp1252(''.$row['cni_std'].''),1,0,'C');
						$pdf->Cell(61,5,utf8_to_cp1252($Nom),1,0);
						$pdf->Cell(10,5,utf8_to_cp1252($row['sexe_std']),1,0,'C');
						$pdf->Cell(10,5,utf8_to_cp1252($row['statut']),1,0,'C');
						$pdf->Cell(22,5,utf8_to_cp1252($date_nais_fr),1,0,'C');
						$pdf->SetFont('Arial','',6);
						$pdf->Cell(38,5,utf8_to_cp1252($lieu_nais),1,0);
						$pdf->SetFont('Arial','',8);
						$i++;
					}	
				}
				 $eff=$i;
				$pdf->SetXY(123,271);
$pdf->Cell(0,3,'Page '.$pdf->PageNo().'/{nb}',0,1,'C');
$pdf->Output(utf8_to_cp1252('Liste_Niveau_'.$refnv.'pdf'),'I');
$pdf->Close();
?>
