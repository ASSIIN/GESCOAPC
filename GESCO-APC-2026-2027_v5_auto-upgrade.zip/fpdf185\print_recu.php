<?php
session_start();
require_once '../Model/connexion.php';
require_once '../core/require.php';
 if (!isset($_SESSION['user'])) {
    session_unset();
    session_destroy();
    // CORRECTION : chemin relatif vers la racine (index.php n'existe pas dans fpdf185/)
    header('location: ../index.php');    
    }
/*if (!isset($_GET['cls']) and !isset($_GET['option']) and !isset($_GET['std']) and !isset($_GET['bul'])) {
	header('location: ../impression.php');
}*/

//Virifions si la classes Existe
       /*$ckcls=$class->CkExistingCode($_GET['cls']);
        if (($_GET['cls']=="") or ($ckcls==false)) {
        header('location: ../impression.php');    
      }*/
$refstd= htmlspecialchars($_GET['std']);
$id_vsm= htmlspecialchars($_GET['id']);

/*$exist_moy=$opt->Ck_ExistMoy_by_Cls($refcls,$refbul);
if ($exist_moy==false) {
	header('location: ../calculs_notes.php');
}*/
$etb->ShowEtb();
$today=date('d-m-Y');
 
/*Récuperation des paramètres de la classe*/
  			$ref_sess="";
			$ref_nv="";

  			$bdd = $GLOBALS['bdd'];
  			$reponse = $bdd->query('SELECT * FROM eleves where mat_std="'.$refstd.'"');
			while (($row = $reponse->fetch(PDO::FETCH_ASSOC))) 
			{
				$refcls=$row['ref_class'];
				$nv=$fin->ReturnClasseNiveauByCode($refcls);
				$sess=$fin->ReturnClasseSessionByCode($refcls);
				$ps=$fin->Return_Ps_Nv($nv,$sess);
				$rdt=$fin->Return_All_rdt_std($refstd);
				$vsm=$fin->Return_All_vsm_std($refstd);
				if ($ps!=0) {
					$reste=$ps-$vsm-$rdt;
					$ps= number_format($ps,0,",",".");
					$rdt= number_format($rdt,0,",",".");
					$vsm= number_format($vsm,0,",",".");
					$reste= number_format($reste,0,",",".");				
				}
				else {
					$ps=0; $rdt=0; $vsm=0; $reste=0;
				}
			}
		/*FIN Récuperation des paramètres de la classe*/
 
$nomcls='';
$nomstd='';
			$titreR='Reçu / Receipt';
		

require('fpdf.php');
$pdf = new FPDF();

class PDF extends FPDF
{
// En-tête
function Header()
{
	 $this->SetY(15);
    // Logo
    $this->Image('../plugins/images/'.$_SESSION['logo_etb'].'',10,6,30);
    // Police Arial gras 15
    $this->SetFont('Arial','B',15);
    // Décalage à droite
    $this->Cell(20);
    // Titre
    $this->Cell(30,10,'Titre',1,0,'C');
    // Saut de ligne
    $this->Ln(20);
}

// Pied de page
function Footer()
{
    // Positionnement à 1,5 cm du bas
    $this->SetY(-15);
    // Police Arial italique 8
    $this->SetFont('Arial','I',6);
    // Numéro de page
    $this->Cell(0,5,'Page '.$this->PageNo().'/{nb}',1,1,'C');
}
}
	$bdd = $GLOBALS['bdd'];
		$reponse0 = $bdd->query('SELECT * FROM eleves where (ref_class="'.$refcls.'" and mat_std="'.$refstd.'") order by nom_std asc');
		$inc=0;
		while($row0 = $reponse0->fetch(PDO::FETCH_ASSOC)) 
		{ 

				$pdf->AddPage('L','a5');

			$refstd=$row0['mat_std'];
			$nomstd=$row0['nom_std'].' '.$row0['mat_std'];

			
			//code for print data

	/*En-tête*/
		$pdf->SetFont('Times','',8);
		$pdf->Image('../plugins/images/'.$_SESSION['logo_etb'].'',95,15,24);
		$pdf->Cell(70,3,'REPUBLIQUE DU CAMEROUN',0,0,'C');
		$pdf->Cell(50,3,'',0,0);
		$pdf->Cell(80,3,'REPUBLIC OF CAMEROON',0,1,'C');

		$pdf->Cell(70,3,'Paix-Travail-Patrie',0,0,'C');
		$pdf->Cell(50,3,'',0,0);
		$pdf->Cell(80,3,'Peace-Work-Fatherland',0,1,'C');

		$pdf->Cell(70,3, utf8_to_cp1252("".$_SESSION['minist_etb_fr'].""),0,0,'C');
		$pdf->Cell(50,3,'',0,0);
		$pdf->Cell(80,3,utf8_to_cp1252(''.$_SESSION['minist_etb_en'].''),0,1,'C');

		$pdf->Cell(70,3,utf8_to_cp1252("".$_SESSION['region_etb_fr'].""),0,0,'C');
		$pdf->Cell(50,3,'',0,0);
		$pdf->Cell(80,3,utf8_to_cp1252(''.$_SESSION['region_etb_en'].''),0,1,'C');

		$pdf->Cell(70,3,utf8_to_cp1252(''.$_SESSION['depart_etb_fr'].''),0,0,'C');
		$pdf->Cell(50,3,'',0,0);
		$pdf->Cell(80,3,utf8_to_cp1252(''.$_SESSION['depart_etb_en'].''),0,1,'C');
		$pdf->SetFont('Times','B',9);
		$pdf->Cell(70,3,utf8_to_cp1252(''.$_SESSION['nom_etb_fr'].''),0,0,'C');
		$pdf->Cell(50,3,'',0,0);
		$pdf->Cell(80,3,utf8_to_cp1252(''.$_SESSION['nom_etb_en'].''),0,1,'C');
		$pdf->SetFont('Times','',7);
		$pdf->Cell(70,3,utf8_to_cp1252(''.$_SESSION['code_pste_etb'].' / '.$_SESSION['tel_etb'].''),0,0,'C');
		$pdf->Cell(50,3,'',0,0);
		$pdf->Cell(80,3,utf8_to_cp1252(''.$_SESSION['code_pste_etb'].'/ '.$_SESSION['tel_etb'].''),0,1,'C');
		$pdf->SetFont('Times','',7);
		$pdf->Cell(70,3,utf8_to_cp1252(''.$_SESSION['email_etb'].''),0,0,'C');
		$pdf->Cell(50,3,'',0,0);
		$pdf->Cell(80,3,utf8_to_cp1252(''.$_SESSION['email_etb'].''),0,1,'C');
			$pdf->Ln();
			$pdf->SetFont('Times','I',8);
			$pdf->Cell(55,5,'',0,0);
			$pdf->Cell(60,5,utf8_to_cp1252(''.$_SESSION['code_im_etb'].''),0,0,'C');
			$pdf->Ln();
	/*FIN En-tête*/
	//Titre 
				$pdf->SetFont('Times','I',10);
				$pdf->Cell(70,5,'',0,0,'C');
				$pdf->Cell(50,5,'ANNEE SCOLAIRE/SCHOOL YEAR ',0,0,'R');
				$pdf->SetFont('Times','B',12);
				$pdf->Cell(70,5,''.$_SESSION['school_year'].'',0,0,'L');
				$pdf->Cell(50,5,'',0,1,'C');
				$pdf->Ln();
	
			$pdf->SetFont('Times','B',12);
			$pdf->SetDrawColor(255,2,2);
			$pdf->SetFillColor(171,177,186);
			$pdf->SetFillColor(69,209,147);
			$pdf->Cell(60,6,'',0,0,'C');
			$pdf->Cell(40,6,utf8_to_cp1252($titreR),1,0,'C',1);
			$pdf->SetTextColor(255,2,2);
			$pdf->SetFont('Times','B',14);
			$pdf->Cell(50,6,utf8_to_cp1252('N° '.$id_vsm.''),0,1,'L');
			$pdf->Ln();
			//les information sur la classe
			$pdf->SetTextColor(0,0,0);
			$class->CkClasseByCode($refcls);
			$nbstd=$class->NbrStudentByClass($refcls);
			$nbM=$class->NbrBySexeByClass($refcls,'M');
			$nbF=$class->NbrBySexeByClass($refcls,'F');
			$nomcls=$_SESSION['nom_class'];
			$niveaucls=$_SESSION['ref_class_niveau'];
			
				//les information de l'eleve
			$std->CkStdByCode_for_Bul($refstd);
			$num=$class->NumStudentByClass($refcls,$refstd);
			
			$nomstd=$_SESSION['nom_std'];
			$matstd=$_SESSION['mat_std'];
			$cnistd=$row0['cni_std'];
			$sexestd=$_SESSION['sexe_std'];
			$naissstd=$_SESSION['date_fr'];
			$lieu_nais=$_SESSION['lieu_nais'];
			$statut=$_SESSION['statut'];

			$pdf->SetFont('Times','',12);
			 $pdf->SetX(7);
			$pdf->Cell(15,5,utf8_to_cp1252('Incript:'),0,0,'L');
			$pdf->SetFont('Times','B',12);
			$pdf->Cell(20,5,utf8_to_cp1252(''.$_SESSION['pre_matr'].''.$matstd.''),1,0,'L');

			$pdf->Cell(15,5,utf8_to_cp1252('Matr:'),0,0,'L');
			$pdf->SetFont('Times','B',12);
			$pdf->Cell(35,5,utf8_to_cp1252(''.$cnistd.''),1,0,'L');
			$pdf->SetFont('Times','',12);
			$pdf->Cell(10,5,utf8_to_cp1252("N°:"),0,0,'L');
			$pdf->SetFont('Times','B',12);
			$pdf->Cell(10,5,utf8_to_cp1252("$num"),1,0,'L');
			$pdf->Ln();
			 // Décalage à droite
		    $pdf->SetX(7);
		    $pdf->SetFont('Times','',11);
		    $pdf->Cell(25,5,"Noms/Name:",0,0,'L');
			$pdf->SetFont('Times','B',11);
			$pdf->Cell(80,5,utf8_to_cp1252("$nomstd"),0,0,'L');
		 	$pdf->Cell(10,5,"",0,0,'L');
		 	$pdf->SetFont('Times','',11);
		 	$pdf->Cell(25,4,"Classe/Class: ",0,0,'L');
		 	$pdf->SetFont('Times','B',11);
		 	$pdf->Cell(30,4,"$nomcls",0,0,'L');
		 	$pdf->SetFont('Times','',11);
		 	$pdf->Cell(10,4,"Code:",0,0,'L');
		 	$pdf->SetFont('Times','B',11);
		 	$pdf->Cell(10,4,"$refcls",0,0,'L');
		 	$pdf->Ln();
			$pdf->SetX(7);
			$pdf->SetFont('Times','',11);
			$pdf->Cell(20,5,"Sexe/Sex:",0,0,'L');
			$pdf->SetFont('Times','B',11);
			$pdf->Cell(15,5,"$sexestd",0,0,'L');
			$pdf->SetFont('Times','',11);
			$pdf->Cell(15,5,"Red: ",0,0,'L');
			$pdf->SetFont('Times','B',11);
			$pdf->Cell(15,5,"$statut",0,0,'L');
			$pdf->Cell(40,5,"",0,0,'L');
			
			$pdf->SetFont('Times','',11);
			$pdf->Cell(50,5,"Pension Classe / School fees: ",0,0,'L');
			$pdf->SetFont('Times','B',13);
			$pdf->Cell(25,5," $ps ",1,0,'C');
			$pdf->SetFont('Times','',11);
			$pdf->Cell(10,5," FCFA",0,0,'L');
			$pdf->Ln();
			// Décalage à droite
		    $pdf->SetX(7);

			$pdf->Cell(30,5,utf8_to_cp1252("Né(e) le/Born on:"),0,0,'L');
			$pdf->SetFont('Times','B',11);
			$pdf->Cell(25,5,utf8_to_cp1252("$naissstd"),0,0,'L');
			$pdf->SetFont('Times','',11);
			$pdf->Cell(10,5,utf8_to_cp1252("A/At:"),0,0,'L');
			$pdf->SetFont('Times','B',11);
			$pdf->Cell(60,5,utf8_to_cp1252("$lieu_nais"),0,0,'L');
			
			$pdf->Ln();
			
						
			$photo = isset($_SESSION['contenu_std']) ? $_SESSION['contenu_std'] : '';
			$photoPath = '../plugins/images/imgstd/'.$photo;
			if ($photo !== '' && is_file($photoPath)) {
				$pdf->Image($photoPath,15,40,20);
			}
			$pdf->SetFont('Times','I',12);
			$pdf->Cell(120,1,'',2,1,'C',);

			 // Décalage à droite


			$bdd = $GLOBALS['bdd'];	

			$last_vsm = 0;
			$last_date = '--';
			$reponse2 = $bdd->query('SELECT * FROM versements where ref_std="'.$row0['mat_std'].'" order by post_on desc limit 1');
			while(($row2 = $reponse2->fetch(PDO::FETCH_ASSOC))) 
			{
				$last_vsm= $row2['prix_vsm'];
				$last_date= date('d/m/Y H:i:s',strtotime($row2['post_on']));
				
			}

			$last_vsm= number_format($last_vsm,0,",",".");
		    


		
		 $pdf->Ln();
		  $pdf->Cell(140,2,"",0,0,'C',0);
             $pdf->Ln();
			// Décalage à droite
		    $pdf->SetX(7);
		    $pdf->Cell(70,8, utf8_to_cp1252("Versement récent/Recent payment:"),0,0,'C',0);
		     $pdf->SetFont('Times','B',12);
		    $pdf->Cell(40,8,"$last_vsm FCFA",1,0,'C',0);
		    $pdf->SetFont('Times','I',12);
		    $pdf->Cell(20,8,"Date:",0,0,'C',0);
		     $pdf->SetFont('Times','B',13);
		    $pdf->Cell(30,8,utf8_to_cp1252($last_date),0,0,'C',0);
		    
		    $pdf->Ln();
		    // Décalage à droite
		    $pdf->SetX(7);
						
			$pdf->Cell(138,2,"",0,0,'C',0);
			$pdf->Ln();
			// Décalage à droite
		    $pdf->SetX(7);
		    $pdf->SetFont('Times','',12);
		    $pdf->SetLineWidth(0.5);
		    $pdf->Cell(20,5,"",0,0,'C',0);
		    $pdf->Cell(50,5,"Versement Total / Paid",1,0,'C',0);
		    $pdf->Cell(40,5,"Remise / Discount",1,0,'C',0);
		    $pdf->Cell(56,5,"Reste / Un pay",1,0,'C',0);
		    $pdf->Cell(20,5,"",0,0,'C',0);

		    $pdf->Ln();
			// Décalage à droite
		    $pdf->SetX(7);

		     $pdf->SetFont('Times','B',12);
		    $pdf->SetLineWidth(0.6);
		    $pdf->Cell(20,10,"",0,0,'C',0);
		    $pdf->Cell(50,10,"$vsm FCFA",1,0,'C',0);
		    $pdf->Cell(40,10,"$rdt FCFA",1,0,'C',0);
		    $pdf->Cell(56,10,"$reste FCFA",1,0,'C',0);
		    $pdf->Cell(20,10,"",0,0,'C',0);
		     $pdf->Ln();
		     $pdf->Ln();
		 
			// Décalage à droite
		    $pdf->SetX(7);
		    $data=date('d/m/Y à H:i:s');
		    $data_cm=date('d/m/Y à H:i:s', strtotime('+1 hour'));
		    
		    $pdf->SetFont('Times','I',9);

		  $pdf->Cell(40,5, utf8_to_cp1252("Imprimé le / Print on the:"),0,0,'L',0);		     
		    $pdf->Cell(15,5, utf8_to_cp1252($data_cm.''),0,0,'L',0);
		     $pdf->Cell(40,5,"",0,0,'C',0);
		    $pdf->SetFont('Times','B',12);
		    $pdf->Cell(70,5,"Le responsable financier/econome",0,0,'R',0);
		   
		    
		    




		}

	

		
				
				

					
		$pdf->Output('Recu_'.$id_vsm.'_'.$nomstd.'.pdf','I');	
?>

