<?php
// Point d'entrée historique : délègue l'export de la base au script principal
// (les pages operationsa.php affluent vers ce contrôleur pour la sauvegarde SQL)
require_once __DIR__ . '/dbdownload.php';