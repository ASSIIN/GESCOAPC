<?php
	session_start();
	require_once '../../Model/connexion.php';
	require_once '../../core/require.php'; 	

	// Sécurité : seuls les rôles admin, pcpl et cs sont autorisés à créer un compte
	if (!isset($_SESSION['user']) || !in_array($_SESSION['user_role'], array('admin', 'pcpl', 'cs'))) {
		header('location: ../../index.php');
		exit;
	}

	$user_civ= isset($_POST['user_civ']) ? htmlspecialchars($_POST['user_civ']) : '';
	$user_role= isset($_POST['user_role']) ? htmlspecialchars($_POST['user_role']) : '';
	$user_dep= isset($_POST['user_dep']) ? htmlspecialchars($_POST['user_dep']) : '';
	$user_name= isset($_POST['user_name']) ? htmlspecialchars($_POST['user_name']) : '';
	$codeswift="";
	/* conversion*/
		$user_name=strtoupper($user_name);
	
  		 
       /* Generation du code (login = mot de passe par défaut, contrôlé anti-doublon)*/
		$password1=str_shuffle('0123456789');
		$pass1=substr($password1,0,10);
		$chaine1=str_shuffle($user_name);
		$pass1.=$chaine1;
		$pass2=substr($pass1,0,4);
		$codeswift.=$pass2;
		$codeswift=strtoupper($codeswift); 
		while ($user->CkExistingUser($codeswift)) {
		 	# code...
		 	$password1=str_shuffle('0123456789');
		$pass1=substr($password1,0,10);
		$chaine1=str_shuffle($user_name);
		$pass1.=$chaine1;
		$pass2=substr($pass1,0,4);
		$codeswift.=$pass2;
		$codeswift=strtoupper($codeswift);
       	
       }
        
    

		if ($codeswift!="") 
	{
		$user->setCivilite($user_civ);
		$user->setUsername($user_name);
		$user->setLogin($codeswift);
		$user->setPass($codeswift);
		
		$user->setRole($user_role);
		$user->setRef_dep($user_dep);
		if ($user->AddUser()) {

			header('location: ../../users.php');
		}
		else{
			echo "error";
		}		
		
	}

		
?>