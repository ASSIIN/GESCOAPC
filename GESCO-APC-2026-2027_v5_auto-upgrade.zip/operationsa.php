<?php
    session_start();   
	require_once 'core/require.php'; 
	require_once 'Model/connexion.php';
     // CORRECTION : garde-fou avec sortie immédiate pour tout utilisateur non autorisé
     if (!isset($_SESSION['user']) || !in_array($_SESSION['user_role'] ?? '', array('admin', 'pcpl', 'sg', 'cs'))) {
    session_unset();
    session_destroy();
    header('location: index.php');    
    exit();
    }
    if (($_SESSION['user_role'] ?? '') == "caisse") {
        header('location: home.php');
        exit();
    }
    if (($_SESSION['user_role'] ?? '') == "ens") {
        header('location: poste_de_saisie.php?trim=t1');
        exit();
    }

    $etb->ShowEtb();
    $etb->CkLE();
    $etb->ckexneE();
?>

<!DOCTYPE html>
<html>
	<head>
	 <?php Config::head(); ?>
		<title>Ndalère Tools|Opérations</title>
	</head>

<body class="fix-header">
     <!-- #header -->
     <?php Head::SimpleHead($_SESSION['user_role']); ?>   
        <!-- Page Content -->
        <!-- ============================================================== -->
        <div id="page-wrapper">
            <div class="container-fluid">

            

                <!--   

    
  
                  $_SESSION['nom_etb_fr'] =$row['nom_etb_fr'];
        $_SESSION['nom_etb_en'] =$row['nom_etb_en'];
        $_SESSION['minist_etb_fr'] =$row['minist_etb_fr'];
        $_SESSION['minist_etb_en'] =$row['minist_etb_en'];
        $_SESSION['region_etb_fr'] =$row['region_etb_fr'];
        $_SESSION['region_etb_en'] =$row['region_etb_en'];
        $_SESSION['depart_etb_fr'] =$row['depart_etb_fr'];
        $_SESSION['depart_etb_en'] =$row['depart_etb_en'];
        $_SESSION['tel_etb'] =$row['tel_etb'];
        $_SESSION['logo_etb'] =$row['logo_etb'];
        $_SESSION['email_etb'] =$row['email_etb'];
        $_SESSION['code_pste_etb'] =$row['code_pste_etb'];
        $_SESSION['civ_respo_etb_fr'] =$row['civ_respo_etb_fr'];
        $_SESSION['civ_respo_etb_en'] =$row['civ_respo_etb_en'];
        $_SESSION['code_im_etb'] =$row['code_im_etb'];
                 -->
                <!-- table -->
                <!-- ============================================================== -->
                <div class="row">
                    <div class="accordion" id="accordionExample">
                      <div class="accordion-item">
                        <h2 class="accordion-header">
                          <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#collapseOne" aria-expanded="false" aria-controls="collapseOne">
                            <h2 class="fw-bolder" >SAUVEGARDER LA BASES DE DONNEES</h2>
                          </button>
                        </h2>
                        <div id="collapseOne" class="accordion-collapse collapse " data-bs-parent="#accordionExample">
                          <div class="accordion-body">
                            <strong><div class="container-fluid">                               
                                <div class="row">
                                   <div class="col-md-4">
                                    <form action="Controler/school/savedb.php" method="GET" >  
                                     <div class="col-md-4">
                                      <label for="exampleInputEmail1" class="form-label">Validation</label><br>
                                
                                      <button type="submit" class="btn btn-primary">Sauvegarder</button>
                                     </div>
                                     </div>
                                  </form>
                                  </div>
                              </div>
                          </div>
                        </div>
                      </div>
                </div>
                <!-- ============================================================== -->
                <!-- Gestion des Classes -->

        </div>
                
            </div>
           
        <?php 
            Footers::TDfoot();
        ?>
        </div>
        <!-- ============================================================== -->
        <!-- End Page Content -->
        <!-- ============================================================== -->
    </div>


		<?php 
		 	Config::scriptJs();
		?>
        <script type="text/javascript">
            $('#exampleModal').on('show.bs.modal', function (event) {
  var button = $(event.relatedTarget) // Button that triggered the modal
  var recipient = button.data('whatever') // Extract info from data-* attributes
  // If necessary, you could initiate an AJAX request here (and then do the updating in a callback).
  // Update the modal's content. We'll use jQuery here, but you could use a data binding library or other methods instead.
  var modal = $(this)
  modal.find('.modal-title').text('New message to ' + recipient)
  modal.find('.modal-body input').val(recipient)
})
        </script>
	</body>
</html>