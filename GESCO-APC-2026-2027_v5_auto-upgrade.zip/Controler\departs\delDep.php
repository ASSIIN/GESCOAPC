<?php 
	session_start();
	require_once '../../Model/connexion.php';
	require_once '../../core/require.php';
	$id = htmlspecialchars($_GET['id']);
	if (isset($id)) 
	{
		if ($dep->delDep($id)) {
			
			header('location: ../../menu_departements.php');
		}
		else{
			echo "Error 1";
		
		}
		
	}
	else{
		echo "Error 2"; 
		
	}
?>