﻿<?php
    session_start();   
  require_once 'core/require.php'; 
  require_once 'Model/connexion.php';
     if (!isset($_SESSION['user'])) {
    session_unset();
    session_destroy();
    header('location: index.php');    
    }
    $admin->ShowAdmin($_SESSION['login']);
    $nbclasses=$class->NombreClasses();
    $etb->ShowEtb();
    $etb->CkLE();
    $etb->ckexneE();

?>

<!DOCTYPE html>
<html>
  <head>
   <?php Config::head_b462(); ?>
    <title>Ndalère Tools|Import Notes</title>
    
  </head>


<body class="fix-header" data-imprimable="1">
     <!-- #header -->
    <?php Head::SimpleHead($_SESSION['user_role']); ?>  
        <!-- Page Content -->
        <!-- ============================================================== -->
        <div id="page-wrapper">
            <div class="container-fluid">

              <div class="row">
                <div class="col-md-10 col-lg-10 col-sm-10">
                  <h3 class="box-title">
                    <a href="gestion_notes_by_mat.php"> <button type="button" class="btn btn-primary btn-sm ml-2 mx-2" style="font-size: 0.8em;">Saisir Notes <i class="fa fa-edit" ></i></button></a>

                    <a href="gestion_import_notes.php"> <button type="button" class="btn btn-primary btn-sm ml-2 mx-2" style="font-size: 0.8em; background-color: #6b6900">Importer <i class="fa fa-file-excel-o"  style="background-color: #1f7246"> </i></button></a>
                   
                   <button type="button" class="btn btn-info btn-sm ml-2 mx-2" data-toggle="modal" data-target="#importstd" data-whatever="@mdo"  style="font-size: 0.8em">Notes Elève<i class="fa  fa-update" aria-hidden="true"></i>
                   </button>

                   <button type="button" class="btn btn-info btn-sm ml-2 mx-2" data-toggle="modal" data-target="#reconN" data-whatever="@mdo"  style="font-size: 0.8em">Reconduire<i class="fa  fa-update" aria-hidden="true"></i>
                   </button>
                </h3>
                   </div>
                <div class="col-md-2 col-sm-2 col-xs-2 pull-right">
                   <div class="dropdown" tabindex="-2">
                      <button class="btn btn-danger btn-sm btn-primarydropdown-toggle" type="button" data-toggle="dropdown" aria-expanded="false" style="font-size: 0.9em;">
                      Model Excel<i class="fa  fa-export" aria-hidden="true"></i>
                      </button>
                      <div class="dropdown-menu">
                         <?php $class->ExportSheetNotes_Ens($_SESSION['login']); ?>
                      </div>
                    </div>
                  </div>
                 </div>        
                <div class="row">
                 <div class="col-md-12 col-lg-12 col-sm-12">
                 <h3 class="fw-bolder text-center" >Importer des notes depuis Excel</h3>  
              <?php  if ( (isset($_GET['cls'])) and (isset($_GET['mat'])) and (isset($_GET['seq'])) ) 
                {
                     echo '   
                   
                  <div class=" my-custom-scrollbar mb-5" style="font-size: 1em; height: 10px ; display:none">';
                  }
                  else{
                   echo '   
                   
                  <div class=" my-custom-scrollbar mb-5" style="font-size: 1em; height: 300px">';

                }
                 ?> 
                
                <div class="accordion col-12 col-md-12" id="accordionExample">
                <?php 
                    $bdd = $GLOBALS['bdd'];
                    $i=0;
                    $nt=0;
                    $reponse = $bdd->query('SELECT distinct(ref_class) as tref_class FROM config_bull where ref_ens="'.$_SESSION['login'].'" ');
                    while($row = $reponse->fetch(PDO::FETCH_ASSOC)) 
                    {
                      $i++;
                      $nom_cls=$class->ShowCls_namebyID($row['tref_class']);
                      echo '

                      <div class="card ">
                        <div class="card-header" id="heading'.$row['tref_class'].'">
                          <h2 class="mb-2">
                            <button class="btn btn-link btn-block text-left" type="button" data-toggle="collapse" data-target="#collapse'.$row['tref_class'].'" aria-expanded="true" aria-controls="collapse'.$row['tref_class'].'"> NOTES ** '.$nom_cls.' ( '.$row['tref_class'].' )</button>
                          </h2>
                        </div>
                        <div id="collapse'.$row['tref_class'].'" class="collapse pb-5" aria-labelledby="heading'.$row['tref_class'].'" data-parent="#accordionExample">
                          <div class="card-body  pb-5" tabindex="-1">
                           <div class="row " style="font-size:0.9em">';
                           $class->ShowMat_Note_and_Eval_Ens_Import($row['tref_class'],$_SESSION['login']);
                      
                       echo '
                          
                              </div>
                            </div>
                            </div>
                          </div>';

                    }
                
               ?> 
                
               </div> 
                                     
              </div>  
              
                   
 <?php  if ( (isset($_GET['cls'])) and (isset($_GET['mat'])) and (isset($_GET['seq'])) ) {
                
                     echo '
                     <div class="row  mb-5">

                 <div class="col-10 col-md-10">
                     <form action="excelReader/insertExelnote.php" method="post" enctype=multipart/form-data >
                    <h4 class="fw-bolder">IMPORTATION DE NOTES</h4>
                   </div>
                     <div class="col-4 col-md-4">   
                          <input class="form-control" type="text" name="refcls" value="'.htmlspecialchars($_GET['cls']).'" hidden="true">
                          <input class="form-control" type="text" name="refmat" value="'.htmlspecialchars($_GET['mat']).'" hidden="true">
                          <input class="form-control" type="text" name="refseq" value="'.htmlspecialchars($_GET['seq']).'" hidden="true">    
                    
                           <label for="formFile" class="form-label">Fichier EXCEL</label>
                          <input class="form-control" type="file" name="excel" id="formFile" accept="">

                        </div>';
          
                         $class->ShowInfosStd_for_Note_by_Mat_Import($_GET['cls'],$_GET['mat'],$_GET['seq']);

                         echo '</div>
                         </div>';
            
                  } ?> 
           
                                  
                  </div>

    </div>
          
         
      <?php 
          Footers::TDfoot();
      ?>
      </div>
      <!-- ============================================================== -->
      <!-- End Page Content -->
      <!-- ============================================================== -->
  </div>


  <?php 
    Config::scriptJ_b462();
  ?>
      <script type="text/javascript">

    //$('.collapse').collapse(''); 
    //$('.dropdown-toggle').dropdown('hide'); 
      </script>

  </body>
</html>

