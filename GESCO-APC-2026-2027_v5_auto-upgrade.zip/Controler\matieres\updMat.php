<?php
	session_start();
	require_once '../../Model/connexion.php';
	require_once '../../core/require.php'; 
	$ref_depart= htmlspecialchars($_POST['ref_dep']);
	$abr_mat= htmlspecialchars($_POST['abr_mat']);
	$nom_mat= htmlspecialchars($_POST['nom_mat']);
	$ref_mat= htmlspecialchars($_POST['ref_mat']);

	if (isset($ref_mat)) 
	{
		$nom_mat=mb_strtoupper($nom_mat);
		$abr_mat=mb_strtoupper($abr_mat);
		$ref_mat=(int)$ref_mat;
		$elt= array('abr_mat' =>$abr_mat , 'nom_mat' =>$nom_mat , 'ref_depart' =>$ref_depart);
		
		foreach ($elt as $key => $value) {
			if ($value!="") {

			$bdd = $GLOBALS['bdd'];	
			$req ='UPDATE  matieres SET '.$key.'= ? where id='.$ref_mat.'';
			$rep = $bdd->prepare($req);
			$rep->execute(array($value));
				
			}
			
		}
		
		header('location: ../../menu_matieres.php');
	}
	else
	{
		header('location: ../../menu_matieres.php?e');
	
	}
	
		
?>