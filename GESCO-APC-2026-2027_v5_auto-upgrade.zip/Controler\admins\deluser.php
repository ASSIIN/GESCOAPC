<?php 
	session_start();
	require_once '../../Model/connexion.php';
	require_once '../../core/require.php';

	// Sécurité : seuls les rôles admin, pcpl et cs sont autorisés à supprimer un compte
	if (!isset($_SESSION['user']) || !in_array($_SESSION['user_role'], array('admin', 'pcpl', 'cs'))) {
		header('location: ../../index.php');
		exit;
	}

	// CORRECTION : vérouillage du paramètre GET en entier strict pour supprimer toute injection SQL
	$id = (int)($_GET['id'] ?? 0);

	// Garde-fou : interdiction de supprimer son propre compte
	if ($id > 0 && isset($_SESSION['user']) && $id === (int)$_SESSION['user']) {
		header('location: ../../users.php?self=1');
		exit;
	}

	if ($id > 0) 
	{

		if ($user->delUser($id)) {
			
			header('location: ../../users.php');
		}
		else{
			echo "Error 1";
		
		}
		
	}
	else{
		echo "Error 2"; 
		
	}
?>