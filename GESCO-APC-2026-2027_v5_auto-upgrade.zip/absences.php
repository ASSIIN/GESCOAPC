<?php
    session_start();
    require_once 'core/require.php';
    require_once 'Model/connexion.php';
    if (!isset($_SESSION['user'])) {
        session_unset();
        session_destroy();
        header('location: index.php');
        exit();
    }

    // Seuls admin, cs et pcpl accèdent à la saisie des absences
    if (($_SESSION['user_role'] != "admin") and ($_SESSION['user_role'] != "cs") and ($_SESSION['user_role'] != "pcpl")) {
        header('location: poste_de_saisie.php?trim=t1');
        exit();
    }

    // Les deux paramètres sont obligatoires
    if ((!isset($_GET['cls'])) || (!isset($_GET['trim']))) {
        header('location: discipline.php');
        exit();
    }
    $etb->ShowEtb();
    $etb->CkLE();
    $etb->ckexneE();
    $admin->ShowAdmin($_SESSION['login']);
    $nbclasses = $class->NombreClasses();

    // ---------- Données de la page ----------
    $bdd      = $GLOBALS['bdd'];
    $cls      = trim((string)$_GET['cls']);
    $trim     = trim((string)$_GET['trim']);
    $nom_cls  = $class->ShowCls_namebyID($cls);
    $pre_matr = isset($_SESSION['pre_matr']) ? $_SESSION['pre_matr'] : '';
    $trimNum  = preg_replace('/[^0-9]/', '', $trim);
    $trimLbl  = ($trimNum !== '') ? 'Trimestre ' . $trimNum : htmlspecialchars($trim);

    $st = $bdd->prepare('SELECT mat_std, cni_std, nom_std FROM eleves WHERE ref_class = ? ORDER BY nom_std ASC');
    $st->execute(array($cls));
    $eleves = $st->fetchAll(PDO::FETCH_ASSOC);

    // Heures d'absence déjà enregistrées (une seule requête)
    $absMap = array();
    $sa = $bdd->prepare('SELECT ref_std, heure FROM absences WHERE ref_cls = ? AND ref_trim = ? ORDER BY id ASC');
    $sa->execute(array($cls, $trim));
    while ($r = $sa->fetch(PDO::FETCH_ASSOC)) { $absMap[(string)$r['ref_std']] = (string)$r['heure']; }

    $nbEleves = count($eleves);
    $totalHeures = 0; $nbAbsents = 0;
    foreach ($eleves as $e) {
        $h = isset($absMap[(string)$e['mat_std']]) ? (int)$absMap[(string)$e['mat_std']] : 0;
        $totalHeures += $h; if ($h > 0) { $nbAbsents++; }
    }

    // Retour de l'enregistrement
    $flash = null; $flashType = 'success';
    if (isset($_GET['saved'])) {
        $n = (int)$_GET['saved'];
        $flash = $n > 0 ? $n . ' ligne(s) d\'absences enregistrée(s).' : 'Aucune modification à enregistrer.';
        if (isset($_GET['err']) && (int)$_GET['err'] > 0) { $flash .= ' ' . (int)$_GET['err'] . ' valeur(s) invalide(s) ignorée(s).'; $flashType = 'warning'; }
    }
?>
<!DOCTYPE html>
<html lang="fr">
  <head>
    <?php Config::head(); ?>
    <title>GESCOAPC | Absences</title>
    <style>
        .abs-page { --a-primary: var(--primary-color, #0764a8); --a-card: var(--bg-card, #fff); --a-border: var(--border-color, #dee2e6);
                    --a-text: var(--text-main, #212529); --a-muted: var(--text-muted, #6c757d); --a-danger: #dc3545; --a-ok: #19784f; }

        /* Bandeau */
        .abs-hero { display: flex; align-items: center; gap: 16px; flex-wrap: wrap; padding: 18px 22px; margin-bottom: 18px; border-radius: 14px; color: #fff;
                    background: linear-gradient(120deg, #b02a37 0%, #dc3545 100%); box-shadow: 0 6px 18px rgba(220,53,69,.25); }
        .abs-hero .hero-icon { flex: 0 0 54px; height: 54px; border-radius: 14px; background: rgba(255,255,255,.18); display: grid; place-items: center; font-size: 1.5rem; }
        .abs-hero h1 { font-size: 1.2rem; font-weight: 700; margin: 0; }
        .abs-hero p { margin: 2px 0 0; opacity: .92; font-size: .88rem; }
        .abs-hero .hero-chips { margin-left: auto; display: flex; gap: 8px; flex-wrap: wrap; }
        .abs-hero .chip { background: rgba(255,255,255,.2); border-radius: 999px; padding: 5px 14px; font-size: .8rem; font-weight: 700; white-space: nowrap; }

        /* Cartes statistiques */
        .abs-stat { background: var(--a-card); border: 1px solid var(--a-border); border-radius: 12px; padding: 12px 16px; display: flex; align-items: center; gap: 12px; height: 100%; }
        .abs-stat .ico { flex: 0 0 42px; height: 42px; border-radius: 10px; display: grid; place-items: center; font-size: 1.05rem; }
        .abs-stat .val { font-size: 1.35rem; font-weight: 800; line-height: 1; color: var(--a-text); }
        .abs-stat .lab { font-size: .74rem; text-transform: uppercase; letter-spacing: .04em; color: var(--a-muted); font-weight: 700; }

        /* Tableau */
        .abs-card { background: var(--a-card); border: 1px solid var(--a-border); border-radius: 14px; box-shadow: 0 2px 10px rgba(0,0,0,.05); overflow: hidden; }
        .abs-toolbar { display: flex; gap: 10px; align-items: center; flex-wrap: wrap; padding: 14px 18px; border-bottom: 1px solid var(--a-border); }
        .abs-toolbar .search { position: relative; flex: 1 1 240px; max-width: 360px; }
        .abs-toolbar .search i { position: absolute; left: 12px; top: 50%; transform: translateY(-50%); color: var(--a-muted); }
        .abs-toolbar .search input { padding-left: 36px; border-radius: 10px; }
        .abs-scroll { max-height: 62vh; overflow: auto; }
        .abs-table { width: 100%; border-collapse: separate; border-spacing: 0; margin: 0; }
        .abs-table thead th { position: sticky; top: 0; z-index: 2; background: #1f2a37; color: #fff; font-size: .76rem; text-transform: uppercase; letter-spacing: .05em; padding: 11px 12px; white-space: nowrap; }
        .abs-table tbody td { padding: 8px 12px; border-bottom: 1px solid var(--a-border); color: var(--a-text); vertical-align: middle; }
        .abs-table tbody tr:hover td { background: color-mix(in srgb, var(--a-primary) 6%, transparent); }
        .abs-table tbody tr.changed td { background: color-mix(in srgb, #ffc107 16%, transparent); }
        .abs-table tbody tr.changed td:first-child { box-shadow: inset 4px 0 0 #ffc107; }
        .abs-table .mat { font-family: ui-monospace, Consolas, monospace; font-weight: 700; color: var(--a-primary); white-space: nowrap; }
        .abs-table .num { font-family: ui-monospace, Consolas, monospace; color: var(--a-muted); }
        .abs-table .nom { font-weight: 600; }
        .abs-input { width: 96px; text-align: center; font-weight: 700; border-radius: 10px; margin: 0 auto; }
        .abs-input:focus { border-color: var(--a-danger); box-shadow: 0 0 0 .2rem rgba(220,53,69,.18); }
        .abs-input.has-abs { color: var(--a-danger); }
        .abs-empty { padding: 36px; text-align: center; color: var(--a-muted); }

        /* Panneau latéral */
        .abs-side { position: sticky; top: 14px; background: var(--a-card); border: 1px solid var(--a-border); border-top: 4px solid var(--a-ok); border-radius: 14px; padding: 18px; }
        .abs-side h5 { font-size: .85rem; text-transform: uppercase; letter-spacing: .05em; font-weight: 800; color: var(--a-primary); margin: 0 0 12px; }
        .abs-side .line { display: flex; justify-content: space-between; align-items: center; padding: 8px 0; border-bottom: 1px dashed var(--a-border); font-size: .88rem; color: var(--a-text); }
        .abs-side .line:last-of-type { border-bottom: 0; }
        .btn-save { background: var(--a-ok); border-color: var(--a-ok); color: #fff; font-weight: 700; padding: 11px 18px; border-radius: 10px; }
        .btn-save:hover { filter: brightness(1.08); color: #fff; }
        .btn-save:disabled { opacity: .55; }
        .abs-dirty { display: none; font-size: .8rem; color: #b58100; font-weight: 700; }
        .abs-dirty.show { display: block; }

        /* Barre d'enregistrement fixe sur mobile */
        .abs-mobilebar { display: none; }
        @media (max-width: 991.98px) {
            .abs-side { position: static; }
            .abs-hero .hero-chips { margin-left: 0; }
            .abs-scroll { max-height: none; }
            .abs-table .mobile-hide { display: none; }
            .abs-mobilebar { display: flex; position: fixed; left: 0; right: 0; bottom: 0; z-index: 1040; gap: 10px; align-items: center; padding: 10px 14px;
                             background: var(--a-card); border-top: 1px solid var(--a-border); box-shadow: 0 -4px 14px rgba(0,0,0,.12); }
            .abs-mobilebar .btn-save { flex: 1; }
            .abs-page { padding-bottom: 80px; }
        }
    </style>
  </head>

<body>
    <?php if (!empty($flash)) Config::toast($flash, $flashType); ?>
    <?php include 'core/sidebar.php'; ?>

    <div class="main-content-wrapper abs-page">
        <!-- Barre supérieure -->
        <div class="mobile-navbar-fixed p-3 mb-4 rounded shadow-sm border">
            <div class="row align-items-center g-2">
                <div class="col-auto d-md-none">
                    <button class="btn btn-outline-dark btn-sm" id="toggleMobileMenu" type="button"><i class="fa fa-bars fa-lg"></i></button>
                </div>
                <div class="col-12 col-md">
                    <h4 class="m-0 fw-bold text-primary text-uppercase"><i class="fa fa-user-clock me-2"></i>Gestion des heures d'absences</h4>
                </div>
                <div class="col-12 col-md-auto d-flex justify-content-md-end">
                    <a href="discipline.php" class="btn btn-outline-danger btn-sm">Retour <i class="ms-2 fa fa-arrow-left"></i></a>
                </div>
            </div>
        </div>

        <div class="container-fluid p-0">

            <!-- Bandeau -->
            <div class="abs-hero">
                <div class="hero-icon"><i class="fa fa-gavel"></i></div>
                <div>
                    <h1>Registre des absences</h1>
                    <p>Saisissez le nombre d'heures d'absence de chaque élève, puis enregistrez.</p>
                </div>
                <div class="hero-chips">
                    <span class="chip"><i class="fa fa-school me-1"></i><?php echo $nom_cls; ?></span>
                    <span class="chip"><i class="fa fa-calendar-alt me-1"></i><?php echo $trimLbl; ?></span>
                </div>
            </div>

            <!-- Statistiques -->
            <div class="row g-3 mb-3">
                <div class="col-6 col-lg-3"><div class="abs-stat"><span class="ico" style="background:rgba(7,100,168,.14);color:#0764a8"><i class="fa fa-users"></i></span>
                    <div><div class="val"><?php echo $nbEleves; ?></div><div class="lab">Élèves</div></div></div></div>
                <div class="col-6 col-lg-3"><div class="abs-stat"><span class="ico" style="background:rgba(220,53,69,.14);color:#dc3545"><i class="fa fa-user-slash"></i></span>
                    <div><div class="val" id="statAbsents"><?php echo $nbAbsents; ?></div><div class="lab">Élèves absents</div></div></div></div>
                <div class="col-6 col-lg-3"><div class="abs-stat"><span class="ico" style="background:rgba(217,142,4,.16);color:#d98e04"><i class="fa fa-hourglass-half"></i></span>
                    <div><div class="val" id="statTotal"><?php echo $totalHeures; ?></div><div class="lab">Total d'heures</div></div></div></div>
                <div class="col-6 col-lg-3"><div class="abs-stat"><span class="ico" style="background:rgba(25,120,79,.15);color:#19784f"><i class="fa fa-calculator"></i></span>
                    <div><div class="val" id="statMoy"><?php echo $nbEleves ? round($totalHeures / $nbEleves, 1) : 0; ?></div><div class="lab">Moyenne / élève</div></div></div></div>
            </div>

            <!-- FORMULAIRE (c'est ce <form> qui manquait : le bouton n'envoyait rien) -->
            <form id="absForm" action="Controler/discipline/addabs.php" method="POST" autocomplete="off">
                <input type="hidden" name="cls" value="<?php echo htmlspecialchars($cls); ?>">
                <input type="hidden" name="trim" value="<?php echo htmlspecialchars($trim); ?>">

                <div class="row g-3">
                    <div class="col-12 col-lg-9">
                        <div class="abs-card">
                            <div class="abs-toolbar">
                                <div class="search">
                                    <i class="fa fa-search"></i>
                                    <input type="search" id="absSearch" class="form-control form-control-sm" placeholder="Rechercher un élève ou un matricule…">
                                </div>
                                <span class="text-muted small ms-auto"><i class="fa fa-keyboard me-1"></i>Entrée = élève suivant</span>
                            </div>
                            <div class="abs-scroll">
                                <table class="abs-table" id="absTable">
                                    <thead>
                                        <tr>
                                            <th style="width:56px">#</th>
                                            <th>N° inscription</th>
                                            <th class="mobile-hide">Matricule</th>
                                            <th>Nom et prénom</th>
                                            <th class="text-center" style="width:150px">Heures d'absence</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                    <?php if ($nbEleves === 0): ?>
                                        <tr><td colspan="5" class="abs-empty"><i class="fa fa-user-graduate fa-2x mb-2 d-block"></i>Aucun élève inscrit dans cette classe.</td></tr>
                                    <?php endif; ?>
                                    <?php $i = 0; foreach ($eleves as $e): $i++;
                                        $mat = (string)$e['mat_std'];
                                        $val = isset($absMap[$mat]) ? $absMap[$mat] : ''; ?>
                                        <tr data-search="<?php echo htmlspecialchars(mb_strtolower($pre_matr . $mat . ' ' . $e['cni_std'] . ' ' . $e['nom_std'], 'UTF-8')); ?>">
                                            <td class="num"><?php echo $i; ?></td>
                                            <td class="mat"><?php echo $pre_matr . $mat; ?></td>
                                            <td class="num mobile-hide"><?php echo $e['cni_std']; ?></td>
                                            <td class="nom"><?php echo $e['nom_std']; ?></td>
                                            <td class="text-center">
                                                <!-- name="abs[matricule]" : robuste même si le matricule contient un point ou un espace -->
                                                <input type="number" inputmode="numeric" min="0" max="999" step="1"
                                                       class="form-control form-control-sm abs-input<?php echo ((int)$val > 0) ? ' has-abs' : ''; ?>"
                                                       name="abs[<?php echo htmlspecialchars($mat, ENT_QUOTES); ?>]"
                                                       value="<?php echo ($val !== '') ? (int)$val : ''; ?>"
                                                       data-orig="<?php echo ($val !== '') ? (int)$val : ''; ?>" placeholder="0"
                                                       aria-label="Heures d'absence de <?php echo htmlspecialchars(strip_tags($e['nom_std'])); ?>">
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>

                    <!-- Panneau latéral -->
                    <div class="col-12 col-lg-3">
                        <div class="abs-side">
                            <h5><i class="fa fa-pen-to-square me-2"></i>Poste de saisie</h5>
                            <div class="line"><span>Classe</span><b class="text-primary"><?php echo $nom_cls; ?></b></div>
                            <div class="line"><span>Période</span><span class="badge bg-danger px-2"><?php echo $trimLbl; ?></span></div>
                            <div class="line"><span>Modifications</span><b id="nbChanged">0</b></div>
                            <div class="abs-dirty mt-2" id="dirtyMsg"><i class="fa fa-triangle-exclamation me-1"></i>Modifications non enregistrées</div>
                            <button type="submit" class="btn btn-save w-100 mt-3" id="btnSave" <?php echo $nbEleves ? '' : 'disabled'; ?>>
                                <i class="fa fa-save me-2"></i>Enregistrer le registre</button>
                            <div class="text-muted small mt-2">Laissez vide pour ne rien changer ; saisissez 0 pour remettre à zéro.</div>
                        </div>
                    </div>
                </div>

                <!-- Barre fixe mobile -->
                <div class="abs-mobilebar">
                    <span class="small fw-bold"><span id="nbChangedM">0</span> modif.</span>
                    <button type="submit" class="btn btn-save" <?php echo $nbEleves ? '' : 'disabled'; ?>><i class="fa fa-save me-2"></i>Enregistrer</button>
                </div>
            </form>

            <?php Footers::TDfoot(); ?>
        </div>
    </div>

    <?php Config::scriptJs(); ?>
    <script type="text/javascript">
    (function () {
        var form = document.getElementById('absForm');
        if (!form) { return; }
        var inputs = Array.prototype.slice.call(form.querySelectorAll('.abs-input'));
        var dirty = false, submitting = false;

        function recalc() {
            var total = 0, absents = 0, changed = 0;
            inputs.forEach(function (inp) {
                var v = inp.value === '' ? (inp.getAttribute('data-orig') === '' ? 0 : parseInt(inp.getAttribute('data-orig'), 10)) : parseInt(inp.value, 10);
                if (isNaN(v) || v < 0) { v = 0; }
                total += v; if (v > 0) { absents++; }
                var isChanged = inp.value !== '' && inp.value !== inp.getAttribute('data-orig');
                inp.closest('tr').classList.toggle('changed', isChanged);
                inp.classList.toggle('has-abs', v > 0);
                if (isChanged) { changed++; }
            });
            document.getElementById('statTotal').textContent = total;
            document.getElementById('statAbsents').textContent = absents;
            document.getElementById('statMoy').textContent = inputs.length ? (Math.round(total / inputs.length * 10) / 10) : 0;
            document.getElementById('nbChanged').textContent = changed;
            document.getElementById('nbChangedM').textContent = changed;
            document.getElementById('dirtyMsg').classList.toggle('show', changed > 0);
            dirty = changed > 0;
        }

        inputs.forEach(function (inp, idx) {
            inp.addEventListener('input', function () {
                if (inp.value !== '') {                       // bornes 0-999, entiers
                    var n = parseInt(inp.value, 10);
                    if (isNaN(n) || n < 0) { n = 0; }
                    if (n > 999) { n = 999; }
                    if (String(n) !== inp.value) { inp.value = n; }
                }
                recalc();
            });
            inp.addEventListener('focus', function () { inp.select(); });
            inp.addEventListener('keydown', function (e) {    // Entrée = élève suivant (au lieu d'envoyer le formulaire)
                if (e.key === 'Enter') {
                    e.preventDefault();
                    var next = inputs.slice(idx + 1).find(function (x) { return x.closest('tr').style.display !== 'none'; });
                    if (next) { next.focus(); }
                }
            });
        });

        // Recherche
        var search = document.getElementById('absSearch');
        if (search) {
            search.addEventListener('input', function () {
                var q = search.value.trim().toLowerCase();
                document.querySelectorAll('#absTable tbody tr[data-search]').forEach(function (tr) {
                    tr.style.display = (q === '' || tr.getAttribute('data-search').indexOf(q) !== -1) ? '' : 'none';
                });
            });
        }

        // Envoi : on évite le double clic et on prévient s'il n'y a rien à enregistrer
        form.addEventListener('submit', function (e) {
            if (submitting) { e.preventDefault(); return; }
            submitting = true; dirty = false;
            form.querySelectorAll('.btn-save').forEach(function (b) { b.disabled = true; b.innerHTML = '<span class="spinner-border spinner-border-sm me-2"></span>Enregistrement…'; });
        });
        window.addEventListener('beforeunload', function (e) { if (dirty && !submitting) { e.preventDefault(); e.returnValue = ''; } });

        recalc();
    })();
    </script>
  </body>
</html>
