<?php
    session_start();   
	require_once 'core/require.php'; 
	require_once 'Model/connexion.php';
     if (!isset($_SESSION['user'])) {
    session_unset();
    session_destroy();
    header('location: index.php');    
    exit();
    }

    // CORRECTION : le filtre de rôle doit s'appliquer aux utilisateurs connectés
    // (il était auparavant placé à l'intérieur du bloc "non connecté", donc inopérant)
    if (($_SESSION['user_role']!="admin") and ($_SESSION['user_role']!="cs") and ($_SESSION['user_role']!="pcpl")) {
       header('location: poste_de_saisie.php?trim=t1');    
       exit();
    }

    // CORRECTION : redirection dès que l'un des deux paramètres manque (|| et non &&)
    if((!isset($_GET['cls'])) || (!isset($_GET['trim']))) {
    
    header('location: discipline.php');    
    exit();
    }
    $etb->ShowEtb();
    $etb->CkLE();
    $etb->ckexneE();
    $admin->ShowAdmin($_SESSION['login']);
    $nbclasses=$class->NombreClasses();
?>

<!DOCTYPE html>
<html>
  <head>
   <?php Config::head(); ?>
    <title>GESCOAPC| MATIERES</title>
  </head>

<body>
    <div class="wrapper">
      <!-- Sidebar -->

      <!-- Inclusion du menu de navigation externe réutilisable -->
      <?php include 'core/sidebar.php'; ?>  
       
<div class="main-content-wrapper">
        <!-- Barre supérieure de navigation adaptative -->
        <div class="mobile-navbar-fixed p-3 mb-4 rounded shadow-sm border">
            <div class="row align-items-center g-2">
                <div class="col-auto d-md-none">
                    <button class="btn btn-outline-dark btn-sm" id="toggleMobileMenu"><i class="fa fa-bars fa-lg"></i></button>
                </div>
                <div class="col-12 col-md">
                    <h4 class="m-0 fw-bold text-primary text-uppercase">Gestion d'heures d'absences</h4>
                </div>
                <div class="col-12 col-md-auto d-flex justify-content-md-end">
                    <a href="discipline.php" class="btn btn-outline-danger btn-sm">Retour <i class="ms-2 fa fa-arrow-left"></i></a>
                </div>
            </div>
        </div>

        <div class="container-fluid mt-3">

            <div class="row mb-3">
                <div class="col-12">
                    <div class="card shadow-sm">
                        <div class="card-header bg-dark text-white py-2">
                            <h5 class="m-0 fw-bold"><i class="fa fa-gavel me-2"></i>Registre des absences</h5>
                        </div>
                        <div class="card-body">
                            <div class="row">

                                <?php if((isset($_GET['cls'])) and (isset($_GET['trim'])) ) {
                                     echo '
                                     <div class="col-md-10">
                                     <div class="table-responsive table-wrapper-scroll-y my-custom-scrollbar" style="font-size: 1em;">
                                            <table class="table-custom table-custom-striped table-custom-hover table-sm" cellspacing="0" cellpadding="0">
                                                <thead class="table-dark">
                                                    <tr>
                                                        <th>#</th>
                                                        <th>N_Inscript</th>
                                                        <th>Matricule</th>
                                                        <th>Nom et Pérenom</th>
                                                        <th>Total ABS</th>
                                                        <th></th>
                                                    </tr>
                                                </thead>
                                                <tbody class="table-hover">';
                                                $class->ShowAbsence_Cls($_GET['cls'], $_GET['trim']);
                                                $class->ShowInfosAbs_by_Class($_GET['cls'], $_GET['trim']);
                                } ?>

                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <?php 
                Footers::TDfoot();
            ?>
        </div>

		<?php 
		 	Config::scriptJs();
		?>
	</body>
</html>
