<?php
// less/patch.php
// Contrôle d'accès central : vérification HORS-LIGNE de la licence signée
// (signature RSA INOFIB + correspondance install_id + expiration).

if (!isset($GLOBALS['bdd']) || !($GLOBALS['bdd'] instanceof PDO)) {
    return;
}

require_once __DIR__ . '/licence_service.php';

$resultat = licence_verifier();

if ($resultat['valide']) {
    $_SESSION['licence_verifiee'] = true;
    return;
}

unset($_SESSION['licence_verifiee']);
header("Location: activation.php?motif=" . urlencode($resultat['motif']));
exit;