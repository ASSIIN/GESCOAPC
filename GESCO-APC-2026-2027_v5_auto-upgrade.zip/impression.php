<?php
    session_start();
    require_once 'core/require.php';
    require_once 'Model/connexion.php';
    if (!isset($_SESSION['user'])) {
        session_unset();
        session_destroy();
        header('location: index.php');
    }
    if (isset($ref_cls)) {
        $ref_cls = '';
    }
    $etb->ShowEtb();
    $etb->CkLE();
    $etb->ckexneE();
    $flashMessage = isset($_GET['ec']) ? 'Vérifiez si la classe existe puis réessayez.' : null;
?>
<!DOCTYPE html>
<html lang="fr">
  <head>
    <?php Config::head(); ?>
    <title>GESCOAPC | Impressions</title>
    <style>
        /* ---------- Page Impressions : thème clair/sombre via les variables du dashboard ---------- */
        .imp-page { --imp-primary: var(--primary-color, #0764a8); --imp-card: var(--bg-card, #fff); --imp-border: var(--border-color, #dee2e6);
                    --imp-text: var(--text-main, #212529); --imp-muted: var(--text-muted, #6c757d); }

        /* Bandeau d'introduction */
        .imp-hero { display: flex; align-items: center; gap: 16px; padding: 18px 22px; margin-bottom: 20px; border-radius: 14px; color: #fff;
                    background: linear-gradient(120deg, #0764a8 0%, #0a85d6 100%); box-shadow: 0 6px 18px rgba(7,100,168,.25); }
        .imp-hero .hero-icon { flex: 0 0 56px; height: 56px; border-radius: 14px; background: rgba(255,255,255,.18); display: grid; place-items: center; font-size: 1.6rem; }
        .imp-hero h1 { font-size: 1.25rem; font-weight: 700; margin: 0; }
        .imp-hero p { margin: 2px 0 0; opacity: .9; font-size: .9rem; }
        .imp-hero .hero-chips { margin-left: auto; display: flex; gap: 8px; flex-wrap: wrap; justify-content: flex-end; }
        .imp-hero .chip { background: rgba(255,255,255,.18); border-radius: 999px; padding: 4px 12px; font-size: .78rem; font-weight: 600; white-space: nowrap; }

        /* Menu des modules */
        .imp-nav { gap: 8px; }
        .imp-nav .nav-link { --accent: var(--imp-primary); display: flex; align-items: center; gap: 12px; text-align: left; width: 100%;
                    padding: 10px 12px; border-radius: 12px; color: var(--imp-text); background: var(--imp-card); border: 1px solid var(--imp-border);
                    transition: transform .15s ease, box-shadow .15s ease, border-color .15s ease; }
        .imp-nav .nav-link:hover { transform: translateX(2px); border-color: var(--accent); }
        .imp-nav .nav-link .ico { flex: 0 0 40px; height: 40px; border-radius: 10px; display: grid; place-items: center; font-size: 1.05rem;
                    color: var(--accent); background: color-mix(in srgb, var(--accent) 14%, transparent); }
        .imp-nav .nav-link .txt { min-width: 0; line-height: 1.2; }
        .imp-nav .nav-link .txt b { display: block; font-size: .92rem; }
        .imp-nav .nav-link .txt small { color: var(--imp-muted); font-size: .76rem; }
        .imp-nav .nav-link .num { margin-left: auto; font-size: .72rem; font-weight: 700; color: var(--imp-muted); }
        .imp-nav .nav-link.active { background: var(--imp-card); border-color: var(--accent); box-shadow: 0 4px 14px color-mix(in srgb, var(--accent) 28%, transparent); }
        .imp-nav .nav-link.active .ico { color: #fff; background: var(--accent); }
        .imp-nav .nav-link.active .num { color: var(--accent); }

        /* Panneau formulaire */
        .imp-panel { --accent: var(--imp-primary); background: var(--imp-card); border: 1px solid var(--imp-border); border-top: 4px solid var(--accent);
                     border-radius: 14px; box-shadow: 0 2px 10px rgba(0,0,0,.05); overflow: hidden; }
        .imp-panel .panel-head { display: flex; align-items: center; gap: 14px; padding: 18px 22px; border-bottom: 1px solid var(--imp-border); }
        .imp-panel .panel-head .ico { flex: 0 0 48px; height: 48px; border-radius: 12px; display: grid; place-items: center; font-size: 1.3rem; color: #fff; background: var(--accent); }
        .imp-panel .panel-head h2 { font-size: 1.1rem; font-weight: 700; margin: 0; color: var(--imp-text); }
        .imp-panel .panel-head p { margin: 2px 0 0; font-size: .85rem; color: var(--imp-muted); }
        .imp-panel .panel-body { padding: 22px; }
        .imp-panel .form-label { font-size: .78rem; font-weight: 700; letter-spacing: .03em; text-transform: uppercase; color: var(--imp-muted); margin-bottom: 4px; }
        .imp-panel .form-select { min-height: 44px; border-radius: 10px; }
        .imp-panel .form-select:focus { border-color: var(--accent); box-shadow: 0 0 0 .2rem color-mix(in srgb, var(--accent) 22%, transparent); }
        .imp-panel .panel-foot { display: flex; align-items: center; justify-content: space-between; gap: 12px; flex-wrap: wrap;
                     margin-top: 22px; padding-top: 18px; border-top: 1px dashed var(--imp-border); }
        .imp-panel .panel-foot .hint { font-size: .8rem; color: var(--imp-muted); }
        .imp-panel .btn-print { background: var(--accent); border-color: var(--accent); color: #fff; font-weight: 700; padding: 10px 28px; border-radius: 10px; }
        .imp-panel .btn-print:hover { filter: brightness(1.08); color: #fff; }
        .imp-panel .field-dyn { display: none; }
        .imp-panel .field-dyn.show { display: block; animation: impFade .2s ease; }
        @keyframes impFade { from { opacity: 0; transform: translateY(-4px); } to { opacity: 1; transform: none; } }

        /* Accents par module */
        .acc-1 { --accent: #0764a8; } .acc-2 { --accent: #198754; } .acc-3 { --accent: #d98e04; } .acc-4 { --accent: #6f42c1; }
        .acc-5 { --accent: #0aa2a2; } .acc-6 { --accent: #dc3545; } .acc-7 { --accent: #5c6b7a; }

        /* Mobile : menu horizontal défilant */
        @media (max-width: 991.98px) {
            .imp-hero { flex-wrap: wrap; padding: 14px 16px; }
            .imp-hero .hero-chips { margin-left: 0; justify-content: flex-start; }
            .imp-nav { flex-direction: row !important; flex-wrap: nowrap; overflow-x: auto; padding-bottom: 6px; scroll-snap-type: x proximity; }
            .imp-nav .nav-link { width: auto; min-width: 190px; scroll-snap-align: start; }
            .imp-nav .nav-link .txt small, .imp-nav .nav-link .num { display: none; }
            .imp-panel .panel-body, .imp-panel .panel-head { padding: 14px; }
            .imp-panel .btn-print { width: 100%; }
        }
    </style>
  </head>
<body>
    <?php if (!empty($flashMessage)) Config::toast($flashMessage, 'danger'); ?>
    <?php include 'core/sidebar.php'; ?>
    <div class="main-content-wrapper imp-page">
      <div class="mobile-navbar-fixed p-3 mb-4 rounded shadow-sm border">
        <div class="d-flex align-items-center justify-content-between gap-3">
          <button type="button" class="btn btn-outline-dark btn-sm d-md-none" id="toggleMobileMenu" aria-label="Ouvrir le menu"><i class="fa fa-bars"></i></button>
          <h4 class="m-0 fw-bold text-primary text-uppercase"><i class="fa fa-print me-2"></i>Impressions</h4>
        </div>
      </div>

      <div class="container-fluid p-0">

        <!-- ============ BANDEAU ============ -->
        <div class="imp-hero">
          <div class="hero-icon"><i class="fa fa-print"></i></div>
          <div>
            <h1>Centre d'impression</h1>
            <p>Choisissez un document, réglez les options, puis lancez l'impression (PDF).</p>
          </div>
          <div class="hero-chips">
            <span class="chip"><i class="fa fa-layer-group me-1"></i>7 modules</span>
            <span class="chip"><i class="fa fa-file-pdf me-1"></i>Export PDF</span>
          </div>
        </div>

        <div class="row g-3">

          <!-- ============ MENU DES MODULES ============ -->
          <div class="col-12 col-lg-4 col-xl-3">
            <div class="nav nav-pills flex-column imp-nav" id="impTabs" role="tablist" aria-orientation="vertical">
              <button class="nav-link acc-1 active" id="tab-1" data-bs-toggle="pill" data-bs-target="#pane-1" type="button" role="tab" aria-controls="pane-1" aria-selected="true">
                <span class="ico"><i class="fa fa-users"></i></span><span class="txt"><b>Fiches des élèves</b><small>Listes, relevés de notes</small></span><span class="num">01</span></button>
              <button class="nav-link acc-2" id="tab-2" data-bs-toggle="pill" data-bs-target="#pane-2" type="button" role="tab" aria-controls="pane-2" aria-selected="false">
                <span class="ico"><i class="fa fa-file-alt"></i></span><span class="txt"><b>Bulletins</b><small>Trimestriels et annuels</small></span><span class="num">02</span></button>
              <button class="nav-link acc-3" id="tab-3" data-bs-toggle="pill" data-bs-target="#pane-3" type="button" role="tab" aria-controls="pane-3" aria-selected="false">
                <span class="ico"><i class="fa fa-trophy"></i></span><span class="txt"><b>Tableaux d'honneur</b><small>Par classe et trimestre</small></span><span class="num">03</span></button>
              <button class="nav-link acc-4" id="tab-4" data-bs-toggle="pill" data-bs-target="#pane-4" type="button" role="tab" aria-controls="pane-4" aria-selected="false">
                <span class="ico"><i class="fa fa-certificate"></i></span><span class="txt"><b>Certificats de scolarité</b><small>Pension soldée ou bulletin</small></span><span class="num">04</span></button>
              <button class="nav-link acc-5" id="tab-5" data-bs-toggle="pill" data-bs-target="#pane-5" type="button" role="tab" aria-controls="pane-5" aria-selected="false">
                <span class="ico"><i class="fa fa-id-card"></i></span><span class="txt"><b>Cartes scolaires</b><small>Modèles A, B et C</small></span><span class="num">05</span></button>
              <button class="nav-link acc-6" id="tab-6" data-bs-toggle="pill" data-bs-target="#pane-6" type="button" role="tab" aria-controls="pane-6" aria-selected="false">
                <span class="ico"><i class="fa fa-gavel"></i></span><span class="txt"><b>Procès-verbaux (PV)</b><small>Classe, niveau ou session</small></span><span class="num">06</span></button>
              <button class="nav-link acc-7" id="tab-7" data-bs-toggle="pill" data-bs-target="#pane-7" type="button" role="tab" aria-controls="pane-7" aria-selected="false">
                <span class="ico"><i class="fa fa-chart-bar"></i></span><span class="txt"><b>Statistiques globales</b><small>Résultats de l'établissement</small></span><span class="num">07</span></button>
            </div>
          </div>

          <!-- ============ PANNEAUX ============ -->
          <div class="col-12 col-lg-8 col-xl-9">
            <div class="tab-content" id="impPanes">

              <!-- 1- FICHES DES ELEVES -->
              <div class="tab-pane fade show active" id="pane-1" role="tabpanel" aria-labelledby="tab-1" tabindex="0">
                <div class="imp-panel acc-1">
                  <div class="panel-head"><span class="ico"><i class="fa fa-users"></i></span>
                    <div><h2>Fiches des élèves</h2><p>Imprimez les listes d'élèves et les fiches de relevé de notes.</p></div></div>
                  <div class="panel-body">
                    <form action="fpdf185/classe_list.php" method="GET" enctype="multipart/form-data" target="_blank">
                      <div class="row g-3">
                        <div class="col-12 col-md-6 col-xl-4">
                          <label class="form-label" for="option">Document</label>
                          <select class="form-select" name="option" id="option" onchange="typeElt()" required>
                            <option value="">Choisir...</option>
                            <option value="clslist">Liste des élèves par classe</option>
                            <option value="notelist">Fiche de relevé des Notes</option>
                            <option value="listnv">Liste des élèves par niveau</option>
                            <option value="listsess">Liste des élèves par session</option>
                            <option value="alllist">Liste de tous les élèves</option>
                          </select>
                        </div>
                        <div class="col-12 col-md-6 col-xl-4 field-dyn" id="valclslist">
                          <label class="form-label" for="cls_list">Classe</label>
                          <select class="form-select" id="cls_list" name="refcls">
                            <option value="">Choisir...</option>
                            <?php $std->SelectClassesNames(); ?>
                          </select>
                        </div>
                        <div class="col-12 col-md-6 col-xl-4 field-dyn" id="vallistnv">
                          <label class="form-label" for="niv_list">Niveau</label>
                          <select class="form-select" id="niv_list" name="niveau">
                            <option value="">Choisir...</option>
                            <?php $class->SelectNiveauCls(); ?>
                          </select>
                        </div>
                        <div class="col-12 col-md-6 col-xl-4 field-dyn" id="vallistsess">
                          <label class="form-label" for="sess_list">Session</label>
                          <select class="form-select" id="sess_list" name="session">
                            <option value="">Choisir...</option>
                            <?php $class->SelectSessCls(); ?>
                          </select>
                        </div>
                      </div>
                      <div class="panel-foot">
                        <span class="hint"><i class="fa fa-circle-info me-1"></i>Les champs utiles apparaissent selon le document choisi.</span>
                        <button type="submit" class="btn btn-print"><i class="fa fa-print me-2"></i>Imprimer</button>
                      </div>
                    </form>
                  </div>
                </div>
              </div>

              <!-- 2- BULLETINS -->
              <div class="tab-pane fade" id="pane-2" role="tabpanel" aria-labelledby="tab-2" tabindex="0">
                <div class="imp-panel acc-2">
                  <div class="panel-head"><span class="ico"><i class="fa fa-file-alt"></i></span>
                    <div><h2>Bulletins</h2><p>Bulletin individuel ou de toute la classe, par trimestre ou annuel.</p></div></div>
                  <div class="panel-body">
                    <form action="fpdf185/bul_cls.php" method="GET" enctype="multipart/form-data" target="_blank">
                      <div class="row g-3">
                        <div class="col-12 col-md-6 col-xl-3">
                          <label class="form-label" for="sess_bul">Section</label>
                          <select class="form-select" name="sess_bul" id="sess_bul" required onchange="typeElt_Bul()">
                            <option value="">...</option>
                            <?php $class->SelectSessCls(); ?>
                          </select>
                        </div>
                        <div class="col-12 col-md-6 col-xl-3 field-dyn" id="cls_frg">
                          <label class="form-label">Classe</label>
                          <select class="form-select" name="cfg">
                            <option value="">Choisir...</option>
                            <?php $class->SelectCls_by_Sess('SFG'); ?>
                          </select>
                        </div>
                        <div class="col-12 col-md-6 col-xl-3 field-dyn" id="cls_ang">
                          <label class="form-label">Classe</label>
                          <select class="form-select" name="cag">
                            <option value="">Choisir...</option>
                            <?php $class->SelectCls_by_Sess('SAG'); ?>
                          </select>
                        </div>
                        <div class="col-12 col-md-6 col-xl-3 field-dyn" id="cls_frt">
                          <label class="form-label">Classe</label>
                          <select class="form-select" name="cft">
                            <option value="">Choisir...</option>
                            <?php $class->SelectCls_by_Sess('SFT'); ?>
                          </select>
                        </div>
                        <div class="col-12 col-md-6 col-xl-3 field-dyn" id="cls_ant">
                          <label class="form-label">Classe</label>
                          <select class="form-select" name="cat">
                            <option value="">Choisir...</option>
                            <?php $class->SelectCls_by_Sess('SAT'); ?>
                          </select>
                        </div>
                        <div class="col-12 col-md-6 col-xl-3 field-dyn" id="vall_trim">
                          <label class="form-label">Période</label>
                          <select class="form-select" name="vall_trim" required>
                            <option value="">...</option>
                            <option value="1">Trimestre 1</option>
                            <option value="2">Trimestre 2</option>
                            <option value="3">Trimestre 3</option>
                            <option value="an">Annuel</option>
                          </select>
                        </div>
                        <div class="col-12 col-md-6 col-xl-3">
                          <label class="form-label" for="type_bul">Type</label>
                          <select class="form-select" id="type_bul" name="type_bul" required>
                            <option value="">...</option>
                            <option value="bstd">INDIVIDUEL</option>
                            <option value="all">TOUS LES ÉLÈVES</option>
                          </select>
                        </div>
                      </div>
                      <div class="panel-foot">
                        <span class="hint"><i class="fa fa-circle-info me-1"></i>Choisissez d'abord la section pour afficher ses classes.</span>
                        <button type="submit" class="btn btn-print"><i class="fa fa-print me-2"></i>Imprimer</button>
                      </div>
                    </form>
                  </div>
                </div>
              </div>

              <!-- 3- TABLEAUX D'HONNEUR -->
              <div class="tab-pane fade" id="pane-3" role="tabpanel" aria-labelledby="tab-3" tabindex="0">
                <div class="imp-panel acc-3">
                  <div class="panel-head"><span class="ico"><i class="fa fa-trophy"></i></span>
                    <div><h2>Tableaux d'honneur</h2><p>Mettez à l'honneur les meilleurs élèves d'une classe.</p></div></div>
                  <div class="panel-body">
                    <form action="fpdf185/tb_hn.php" method="GET" enctype="multipart/form-data" target="_blank">
                      <div class="row g-3">
                        <div class="col-12 col-md-6 col-xl-4">
                          <label class="form-label" for="Tbulcls">Classe</label>
                          <select class="form-select" id="Tbulcls" name="tcls">
                            <option value="">Choisir...</option>
                            <?php $std->SelectClassesNames(); ?>
                          </select>
                        </div>
                        <div class="col-12 col-md-6 col-xl-4">
                          <label class="form-label" for="th_trim">Trimestre</label>
                          <select class="form-select" id="th_trim" name="bul" required>
                            <option value="">...</option>
                            <option value="1">Trimestre 1</option>
                            <option value="2">Trimestre 2</option>
                            <option value="3">Trimestre 3</option>
                          </select>
                        </div>
                        <div class="col-12 col-md-6 col-xl-4">
                          <label class="form-label" for="th_fond">Couleur de fond</label>
                          <select class="form-select" id="th_fond" name="f" required>
                            <option value="">...</option>
                            <option value="0">Sans fond</option>
                            <option value="1">Fond 1</option>
                            <option value="2">Fond 2</option>
                            <option value="3">Fond 3</option>
                            <option value="4">Fond 4</option>
                            <option value="5">Fond 5</option>
                          </select>
                        </div>
                      </div>
                      <div class="panel-foot">
                        <span class="hint"><i class="fa fa-circle-info me-1"></i>« Sans fond » économise l'encre.</span>
                        <button type="submit" class="btn btn-print"><i class="fa fa-print me-2"></i>Imprimer</button>
                      </div>
                    </form>
                  </div>
                </div>
              </div>

              <!-- 4- CERTIFICAT DE SCOLARITE -->
              <div class="tab-pane fade" id="pane-4" role="tabpanel" aria-labelledby="tab-4" tabindex="0">
                <div class="imp-panel acc-4">
                  <div class="panel-head"><span class="ico"><i class="fa fa-certificate"></i></span>
                    <div><h2>Certificats de scolarité</h2><p>Certificats pour les élèves d'une classe selon leur situation de pension.</p></div></div>
                  <div class="panel-body">
                    <form action="fpdf185/cert_cls.php" method="GET" enctype="multipart/form-data" target="_blank">
                      <div class="row g-3">
                        <div class="col-12 col-md-6">
                          <label class="form-label" for="cert_cls">Classe</label>
                          <select class="form-select" id="cert_cls" name="cls" required>
                            <option value="">Choisir...</option>
                            <?php $std->SelectClassesNames(); ?>
                          </select>
                        </div>
                        <div class="col-12 col-md-6">
                          <label class="form-label" for="cert_type">Type d'élèves</label>
                          <select class="form-select" id="cert_type" name="type" required>
                            <option value="">...</option>
                            <option value="ps">Pension Soldée</option>
                            <option value="pb">Pension Bulletin</option>
                            <option value="all">Tous les élèves</option>
                          </select>
                        </div>
                      </div>
                      <div class="panel-foot">
                        <span class="hint"><i class="fa fa-circle-info me-1"></i>Un certificat est généré par élève concerné.</span>
                        <button type="submit" class="btn btn-print"><i class="fa fa-print me-2"></i>Imprimer</button>
                      </div>
                    </form>
                  </div>
                </div>
              </div>

              <!-- 5- CARTES SCOLAIRES -->
              <div class="tab-pane fade" id="pane-5" role="tabpanel" aria-labelledby="tab-5" tabindex="0">
                <div class="imp-panel acc-5">
                  <div class="panel-head"><span class="ico"><i class="fa fa-id-card"></i></span>
                    <div><h2>Cartes scolaires</h2><p>Cartes d'élève pour une classe ou pour tout l'établissement.</p></div></div>
                  <div class="panel-body">
                    <form action="fpdf185/card_cls.php" method="GET" enctype="multipart/form-data" target="_blank">
                      <div class="row g-3">
                        <div class="col-12 col-md-6 col-xl-4">
                          <label class="form-label" for="card_cls">Classe</label>
                          <select class="form-select" id="card_cls" name="cls" required>
                            <option value="">Choisir...</option>
                            <option value="all">Toutes les Classes</option>
                            <?php $std->SelectClassesNames(); ?>
                          </select>
                        </div>
                        <div class="col-12 col-md-6 col-xl-4">
                          <label class="form-label" for="card_type">Type d'élèves</label>
                          <select class="form-select" id="card_type" name="type" required>
                            <option value="">...</option>
                            <option value="ps">Pension Soldée</option>
                            <option value="pb">Pension Bulletin</option>
                            <option value="all">Tous les élèves</option>
                          </select>
                        </div>
                        <div class="col-12 col-md-6 col-xl-4">
                          <label class="form-label" for="card_mdl">Modèle de carte</label>
                          <select class="form-select" id="card_mdl" name="mdl" required>
                            <option value="">...</option>
                            <option value="1">MODÈLE A</option>
                            <option value="2">MODÈLE B</option>
                            <option value="3">MODÈLE C</option>
                          </select>
                        </div>
                      </div>
                      <div class="panel-foot">
                        <span class="hint"><i class="fa fa-circle-info me-1"></i>Vérifiez que les photos des élèves sont enregistrées.</span>
                        <button type="submit" class="btn btn-print"><i class="fa fa-print me-2"></i>Imprimer</button>
                      </div>
                    </form>
                  </div>
                </div>
              </div>

              <!-- 6- PV -->
              <div class="tab-pane fade" id="pane-6" role="tabpanel" aria-labelledby="tab-6" tabindex="0">
                <div class="imp-panel acc-6">
                  <div class="panel-head"><span class="ico"><i class="fa fa-gavel"></i></span>
                    <div><h2>Procès-verbaux (PV)</h2><p>PV des résultats par classe, par niveau ou par session.</p></div></div>
                  <div class="panel-body">
                    <form action="fpdf185/pv.php" method="GET" enctype="multipart/form-data" target="_blank">
                      <div class="row g-3">
                        <div class="col-12 col-md-6 col-xl-4">
                          <label class="form-label" for="stat">Portée du PV</label>
                          <select class="form-select" name="stat" id="stat" onchange="typeElt_Stat()" required>
                            <option value="">...</option>
                            <option value="clspv">PV par classe</option>
                            <option value="pvnv">PV par niveau</option>
                            <option value="pvsess">PV par session</option>
                          </select>
                        </div>
                        <div class="col-12 col-md-6 col-xl-4 field-dyn" id="valclspv">
                          <label class="form-label" for="cls_pv">Classe</label>
                          <select class="form-select" id="cls_pv" name="refcls">
                            <option value="">Choisir...</option>
                            <?php $std->SelectClassesNames(); ?>
                          </select>
                        </div>
                        <div class="col-12 col-md-6 col-xl-4 field-dyn" id="valpvnv">
                          <label class="form-label" for="niv_pv">Niveau</label>
                          <select class="form-select" id="niv_pv" name="niveau">
                            <option value="">Choisir...</option>
                            <?php $class->SelectNiveauCls(); ?>
                          </select>
                        </div>
                        <div class="col-12 col-md-6 col-xl-4 field-dyn" id="valpvsess">
                          <label class="form-label" for="sess_pv">Session</label>
                          <select class="form-select" id="sess_pv" name="session">
                            <option value="">Choisir...</option>
                            <?php $class->SelectSessCls(); ?>
                          </select>
                        </div>
                        <div class="col-12 col-md-6 col-xl-4 field-dyn" id="evalpv">
                          <label class="form-label" for="eval_pv">Évaluation</label>
                          <select class="form-select" id="eval_pv" name="bul" required>
                            <option value="">...</option>
                            <option value="1">EVAL 1</option>
                            <option value="2">EVAL 2</option>
                            <option value="12">TRIM 1</option>
                            <option value="3">EVAL 3</option>
                            <option value="4">EVAL 4</option>
                            <option value="34">TRIM 2</option>
                            <option value="5">EVAL 5</option>
                            <option value="6">EVAL 6</option>
                            <option value="56">TRIM 3</option>
                          </select>
                        </div>
                      </div>
                      <div class="panel-foot">
                        <span class="hint"><i class="fa fa-circle-info me-1"></i>Choisissez la portée du PV pour afficher les champs associés.</span>
                        <button type="submit" class="btn btn-print"><i class="fa fa-print me-2"></i>Imprimer</button>
                      </div>
                    </form>
                  </div>
                </div>
              </div>

              <!-- 7- STATISTIQUES GLOBALES -->
              <div class="tab-pane fade" id="pane-7" role="tabpanel" aria-labelledby="tab-7" tabindex="0">
                <div class="imp-panel acc-7">
                  <div class="panel-head"><span class="ico"><i class="fa fa-chart-bar"></i></span>
                    <div><h2>Statistiques globales</h2><p>Synthèse des résultats de l'établissement pour la période choisie.</p></div></div>
                  <div class="panel-body">
                    <form action="fpdf185/stats_globales.php" method="GET" enctype="multipart/form-data" target="_blank">
                      <div class="row g-3">
                        <div class="col-12 col-md-6 col-xl-4">
                          <label class="form-label" for="stat_trim">Évaluation</label>
                          <select class="form-select" id="stat_trim" name="trim" required>
                            <option value="">...</option>
                            <option value="1">TRIM 1</option>
                            <option value="2">TRIM 2</option>
                            <option value="3">TRIM 3</option>
                            <option value="an">ANNUELLE</option>
                          </select>
                        </div>
                      </div>
                      <div class="panel-foot">
                        <span class="hint"><i class="fa fa-circle-info me-1"></i>Toutes les classes de l'établissement sont incluses.</span>
                        <button type="submit" class="btn btn-print"><i class="fa fa-print me-2"></i>Imprimer</button>
                      </div>
                    </form>
                  </div>
                </div>
              </div>

            </div>
          </div>
        </div>
      </div>
    </div>

    <?php Footers::TDfoot(); ?>
    <?php Config::scriptJs(); ?>
    <script type="text/javascript">
        function show(id, on) { var e = document.getElementById(id); if (e) { e.classList.toggle('show', !!on); } }

        // 1- Fiches des élèves
        function typeElt() {
            var opt = document.getElementById('option').value;
            show('valclslist', opt == 'clslist' || opt == 'notelist');
            show('vallistnv', opt == 'listnv');
            show('vallistsess', opt == 'listsess');
        }
        // 6- PV
        function typeElt_Stat() {
            var s = document.getElementById('stat').value;
            show('valclspv', s == 'clspv');
            show('valpvnv', s == 'pvnv');
            show('valpvsess', s == 'pvsess');
            show('evalpv', s == 'clspv' || s == 'pvnv' || s == 'pvsess');
        }
        // 2- Bulletins
        function typeElt_Bul() {
            var s = document.getElementById('sess_bul').value;
            show('cls_frg', s == 'SFG'); show('cls_ang', s == 'SAG'); show('cls_frt', s == 'SFT'); show('cls_ant', s == 'SAT');
            show('vall_trim', s == 'SFG' || s == 'SAG' || s == 'SFT' || s == 'SAT');
        }
        window.addEventListener('load', function () {
            typeElt(); typeElt_Stat(); typeElt_Bul();
            // Mémorise le module ouvert pendant la session (retour sur la page = même module)
            var KEY = 'gescoapc_imp_tab', tabs = document.querySelectorAll('#impTabs [data-bs-toggle="pill"]');
            try {
                var saved = sessionStorage.getItem(KEY), t = saved && document.getElementById(saved);
                if (t && window.bootstrap) { bootstrap.Tab.getOrCreateInstance(t).show(); }
            } catch (e) {}
            tabs.forEach(function (t) {
                t.addEventListener('shown.bs.tab', function () { try { sessionStorage.setItem(KEY, t.id); } catch (e) {} });
            });
        });
    </script>
  </body>
</html>
