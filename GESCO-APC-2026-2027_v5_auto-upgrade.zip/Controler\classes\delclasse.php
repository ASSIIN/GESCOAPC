<?php 
session_start();
// Désactivation des affichages d'erreurs pour éviter de corrompre les entêtes de redirection
ini_set('display_errors', 0);
error_reporting(0);

require_once '../../Model/connexion.php';
require_once '../../core/require.php';

$bdd = $GLOBALS['bdd'];

if (isset($_GET['id']) && !empty($_GET['id'])) {
    
    $id = htmlspecialchars($_GET['id']);
    
    // Utilisation d'une transaction PDO pour un nettoyage en cascade ultra-rapide et sécurisé
    $bdd->beginTransaction();
    
    try {
        // 1. Suppression des données financières liées aux élèves de cette classe
        if (isset($opt) && method_exists($opt, 'delVsmtbyClasse')) {
            $opt->delVsmtbyClasse($id);
            $opt->delRemisesbyClasse($id);
        } else {
            // Nettoyage direct par requêtes préparées si les méthodes d'objets sont indisponibles
            $stmt_vsm = $bdd->prepare('DELETE FROM versements WHERE ref_std IN (SELECT mat_std FROM eleves WHERE ref_class = ?)');
            $stmt_vsm->execute(array($id));
            
            $stmt_rms = $bdd->prepare('DELETE FROM remises WHERE ref_std IN (SELECT mat_std FROM eleves WHERE ref_class = ?)');
            $stmt_rms->execute(array($id));
        }

        // 2. Suppression des moyennes de trimestres pour la classe ciblée
        for ($t = 1; $t <= 3; $t++) {
            $stmt_trim = $bdd->prepare('DELETE FROM table_note_par_trim'.$t.' WHERE ref_cls = ?');
            $stmt_trim->execute(array($id));
        }

        // 3. Suppression des notes séquentielles de matières (EVAL 1 à EVAL 6)
        for ($ev = 1; $ev <= 6; $ev++) {
            $stmt_eval = $bdd->prepare('DELETE FROM table_note_par_mat_eval'.$ev.' WHERE ref_cls = ?');
            $stmt_eval->execute(array($id));
        }

        // 4. Suppression des anciennes tables de notes globales par matière
        $stmt_mat = $bdd->prepare('DELETE FROM table_note_par_mat WHERE ref_cls = ?');
        $stmt_mat->execute(array($id));

        // 5. Suppression de la discipline (absences et exclusions)
        $stmt_abs = $bdd->prepare('DELETE FROM absences WHERE ref_cls = ?');
        $stmt_abs->execute(array($id));

        $stmt_exc = $bdd->prepare('DELETE FROM exclusions WHERE ref_cls = ?');
        $stmt_exc->execute(array($id));

        // 6. Suppression des élèves inscrits dans cette classe
        $stmt_std = $bdd->prepare('DELETE FROM eleves WHERE ref_class = ?');
        $stmt_std->execute(array($id));

        // 7. Suppression des configurations de matières associées au bulletin
        $stmt_conf = $bdd->prepare('DELETE FROM config_bull WHERE ref_class = ?');
        $stmt_conf->execute(array($id));

        // 7bis. Suppression des compétences d'évaluation associées à cette classe
        $stmt_comp = $bdd->prepare('DELETE FROM competences_matieres WHERE ref_class = ?');
        $stmt_comp->execute(array($id));

        // 8. Suppression physique finale de la classe via l'objet maître $class
        if ($class->delClasse($id)) {
            // Validation finale de la transaction (Tout est nettoyé proprement d'un coup)
            $bdd->commit();
            header('location: ../../menu_classes.php?del_success=1');
            exit();
        } else {
            throw new Exception("Erreur lors de la suppression de la classe principale.");
        }

    } catch (Exception $e) {
        // En cas de panne ou de table manquante, on annule tout pour ne rien corrompre
        $bdd->rollBack();
        echo "Erreur système lors du nettoyage en cascade de la classe.";
    }

} else {
    header('location: ../../menu_classes.php');
    exit();
}
?>
