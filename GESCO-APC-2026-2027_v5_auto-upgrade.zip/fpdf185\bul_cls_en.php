<?php
session_start();
require_once '../Model/connexion.php';
require_once '../core/require.php';
 if (!isset($_SESSION['user'])) {
    session_unset();
    session_destroy();
    header('location: ../index.php');    
    }
	if (!isset($_GET['cls'])and !isset($_GET['vall_trim'])) 
	{
		header('location: ../impression.php?e');
	}
 	$refcls=htmlspecialchars($_GET['cls']);
  	$ckcls=$class->CkExistingCode($refcls);
    if (($refcls=="") or ($ckcls==false)) 
    {
    	header('location: ../impression.php?ec=0');
	}
	$refbul=$_GET['vall_trim'];
	if ($refbul=='an') {
	 // CORRECTION : bul_an_en.php inexistant → bulletin annuel (bul_an.php)
	 header('location:bul_an.php?cls='.$refcls.'');
	 exit;
	}

else{
	$exist_moy=$opt->Ck_ExistMoy_by_Cls($refcls,$refbul);
	if ($exist_moy==false) {
		header('location: ../calculs_notes.php');
	}

}
 $etb->ShowEtb();
$today=date('d-m-Y');

$faibles_mat='';
$nomcls='';
		if ($refbul=='1') {
			$eval1='1';
			$eval2='2';
			$titreB='FIRST TERM PROGRESS RECORD';
			$titreE='TERM 1';
		}elseif($refbul=='2') {
			$eval1='3';
			$eval2='4';
			$titreB='SECOND TERM PROGRESS RECORD';
			$titreE='TERM 2';
		}elseif($refbul=='3') {
			$eval1='5';
			$eval2='6';
			$titreB='THIRD TERM PROGRESS RECORD';
			$titreE='TERM 3';
		}else{
			$titreB='ANNUAL REPORT SHEET';
			$titreE='ANNUAL REPORT';
			$eval1='5';
			$eval2='6';

		}

require('fpdf.php');
$pdf = new FPDF();

class PDF extends FPDF
{
// En-tête
function Header()
{
	 $this->SetY(15);
    // Logo
    $this->Image('../plugins/images/'.$_SESSION['logo_etb'].'',10,6,30);
    // Police Arial gras 15
    $this->SetFont('Arial','B',15);
    // Décalage à droite
    $this->Cell(80);
    // Titre
    $this->Cell(30,10,'Titre',1,0,'C');
    // Saut de ligne
    $this->Ln(15);
}

// Pied de page
function Footer()
{
    // Positionnement à 1,5 cm du bas
    $this->SetY(-15);
    // Police Arial italique 8
    $this->SetFont('Arial','I',8);
    // Numéro de page
    $this->Cell(0,10,'Page '.$this->PageNo().'/{nb}',0,0,'C');
}
}
	$bdd = $GLOBALS['bdd'];
		$reponse0 = $bdd->query('SELECT * FROM eleves where ref_class="'.$refcls.'" order by nom_std asc');
		while($row0 = $reponse0->fetch(PDO::FETCH_ASSOC)) 
		{
			$refstd=$row0['mat_std'];
			$stdclasser=$class->RetrunStd_ClasserbyTrim($refbul,$refstd);

			$pdf->AddPage();
			//code for print data

	$bdd = $GLOBALS['bdd'];
	$reponse = $bdd->query('SELECT * FROM config_bull where ref_class="'.$refcls.'" order by nom_mat asc');

	/*En-tête*/
		$pdf->SetFont('Times','',6);
		$pdf->Image('../plugins/images/'.$_SESSION['logo_etb'].'',92,12,28);
		$pdf->Cell(70,3,'REPUBLIQUE DU CAMEROUN',0,0,'C');
		$pdf->Cell(50,3,'',0,0);
		$pdf->Cell(70,3,'REPUBLIC OF CAMEROON',0,1,'C');

		$pdf->Cell(70,3,'Paix-Travail-Patrie',0,0,'C');
		$pdf->Cell(50,3,'',0,0);
		$pdf->Cell(70,3,'Peace-Work-Fatherland',0,1,'C');

		$pdf->Cell(70,3, utf8_to_cp1252("".$_SESSION['minist_etb_fr'].""),0,0,'C');
		$pdf->Cell(50,3,'',0,0);
		$pdf->Cell(70,3,utf8_to_cp1252(''.$_SESSION['minist_etb_en'].''),0,1,'C');

		$pdf->Cell(70,3,utf8_to_cp1252("".$_SESSION['region_etb_fr'].""),0,0,'C');
		$pdf->Cell(50,3,'',0,0);
		$pdf->Cell(70,3,utf8_to_cp1252(''.$_SESSION['region_etb_en'].''),0,1,'C');

		$pdf->Cell(70,3,utf8_to_cp1252(''.$_SESSION['depart_etb_fr'].''),0,0,'C');
		$pdf->Cell(50,3,'',0,0);
		$pdf->Cell(70,3,utf8_to_cp1252(''.$_SESSION['depart_etb_en'].''),0,1,'C');
		$pdf->SetFont('Times','B',8);
		$pdf->Cell(70,4,utf8_to_cp1252(''.$_SESSION['nom_etb_fr'].''),0,0,'C');
		$pdf->Cell(50,3,'',0,0);
		$pdf->Cell(70,4,utf8_to_cp1252(''.$_SESSION['nom_etb_en'].''),0,1,'C');
		$pdf->SetFont('Times','',6);
		$pdf->Cell(70,4,utf8_to_cp1252(''.$_SESSION['code_pste_etb'].' / '.$_SESSION['tel_etb'].''),0,0,'C');
		$pdf->Cell(50,3,'',0,0);
		$pdf->Cell(70,3,utf8_to_cp1252(''.$_SESSION['code_pste_etb'].'/ '.$_SESSION['tel_etb'].''),0,1,'C');
		$pdf->SetFont('Times','',6);
		$pdf->Cell(70,3,utf8_to_cp1252(''.$_SESSION['email_etb'].''),0,0,'C');
		$pdf->SetFont('Times','I',10);
		$pdf->Cell(50,5,utf8_to_cp1252(''.$_SESSION['code_im_etb'].''),0,0,'C');
		$pdf->SetFont('Times','',6);
		$pdf->Cell(70,3,utf8_to_cp1252(''.$_SESSION['email_etb'].''),0,1,'C');
			$pdf->Ln();
			

			
				$pdf->SetFont('Times','I',6);
				$pdf->Cell(40,3,'',0,0,'C');
				$pdf->Cell(60,3,'School Year ',0,0,'R');
				$pdf->SetFont('Times','B',10);
				$pdf->Cell(40,3,''.$_SESSION['school_year'].'',0,0,'L');
				$pdf->Cell(40,3,'',0,1,'C');
	
	$pdf->SetFont('Times','B',12);

	$pdf->SetFillColor(214,223,236);
	$pdf->Cell(37,5,'',0,0,'C');
	$pdf->Cell(115,7,$titreB,1,0,'C',0);
	$pdf->Cell(20,5,'',0,1,'C');
	$pdf->Ln();
	//les information sur la classe

	$class->CkClasseByCode($refcls);
	$nbstd=$class->NbrStudentByClass($refcls);
	$nbstdclasser=$opt->NbrStudentClasserByClass($refcls,$refbul);
	$nbstdclasser=(float)$nbstdclasser;
	$nbM=$class->NbrBySexeByClass($refcls,'M');
	$nbF=$class->NbrBySexeByClass($refcls,'F');
	$moy_1er=$opt->ShowMoy_1er_Cls($refcls,$refbul);
	$moy_dern=$opt->ShowMoy_dern_Cls($refcls,$refbul);
	$nomcls=$_SESSION['nom_class'];
	$niveaucls=$_SESSION['ref_class_niveau'];
	$pdf->SetFont('Times','',10);

	$pdf->Cell(50,4,"Class: $nomcls",0,0,'L');
	$pdf->Cell(30,4,"Code: ($refcls)",0,0,'C');
	$pdf->Cell(20,4,"Level: $niveaucls",0,0,'C');
	$pdf->Cell(20,4,"Class enrol: $nbstd",0,0,'C');
	$pdf->Cell(10,4,"M: $nbM",0,0,'C');
	$pdf->Cell(10,4,"F: $nbF",0,0,'C');
	$pdf->Ln();
	$pdf->Cell(190,4,'',2,0,'C',0);
	$pdf->Ln();
		//les information de l'eleve
	$std->CkStdByCode_for_Bul($refstd);
	$num=$class->NumStudentByClass($refcls,$refstd);
	$rangstd=$opt->ShowRang_Std($refcls,$refstd,$refbul);
	$classer_std=$opt->ShowClasser_Std($refcls,$refstd,$refbul);
	$HeureAbs=$opt->ShowAbsStd_by_Cls($refcls,$refstd,$refbul);
	$nomstd=$_SESSION['nom_std'];
	$matstd=$_SESSION['mat_std'];
	$sexestd=$_SESSION['sexe_std'];
	$naissstd=$_SESSION['date_fr'];
	$lieu_nais=$_SESSION['lieu_nais'];

	$nomstd=substr($nomstd, 0,42);
	$nomstd= str_replace("&#039;", "'", $nomstd);
	$lieu_nais=mb_strtoupper($lieu_nais);
	$lieu_nais=substr($lieu_nais, 0,34);
	$lieu_nais = str_replace("&#039;", "'", $lieu_nais);

	$statut=$_SESSION['statut'];
	if ($statut=='O' or $statut=='OUI' ) {
		$statut='Yes';
	}
	else{
		$statut='No';
	}
	$rangstd=(string)$rangstd;
	$strrangstd='';
	if (($rangstd=='1') or ($rangstd=='21') or ($rangstd=='31') or ($rangstd=='41') or ($rangstd=='51') or ($rangstd=='61') or ($rangstd=='71') or ($rangstd=='81') or ($rangstd=='91') or ($rangstd=='101') or ($rangstd=='121') or ($rangstd=='131') or ($rangstd=='141') or ($rangstd=='151') or ($rangstd=='161') or ($rangstd=='171') or ($rangstd=='181') or ($rangstd=='191') or $rangstd=='201' or $rangstd=='221' or $rangstd=='231' or $rangstd=='241' or $rangstd=='251' or $rangstd=='261' or $rangstd=='271' or $rangstd=='281' or $rangstd=='291') {
		if ($sexestd=='M') {
			$strrangstd='st';
		}else{
			$strrangstd='st';
		}
		
	}
	elseif ($rangstd=='2' or $rangstd=='22' or $rangstd=='32' or $rangstd=='42' or $rangstd=='52' or $rangstd=='62' or $rangstd=='72' or $rangstd=='82' or $rangstd=='92' or $rangstd=='102' or $rangstd=='122' or $rangstd=='132' or $rangstd=='142' or $rangstd=='152' or $rangstd=='162' or $rangstd=='172' or $rangstd=='182' or $rangstd=='192' or $rangstd=='202' or $rangstd=='222' or $rangstd=='232' or $rangstd=='242' or $rangstd=='252' or $rangstd=='262' or $rangstd=='272' or $rangstd=='282' or $rangstd=='292') {
		$strrangstd='nd';
	}
	elseif ($rangstd=='3' or $rangstd=='23' or $rangstd=='33' or $rangstd=='43' or $rangstd=='53' or $rangstd=='63' or $rangstd=='73' or $rangstd=='83' or $rangstd=='93' or $rangstd=='103' or $rangstd=='123' or $rangstd=='133' or $rangstd=='143' or $rangstd=='153' or $rangstd=='163' or $rangstd=='173' or $rangstd=='183' or $rangstd=='193' or  $rangstd=='203' or $rangstd=='223' or $rangstd=='233' or $rangstd=='243' or $rangstd=='253' or $rangstd=='263' or $rangstd=='273' or $rangstd=='283' or $rangstd=='293') {
		$strrangstd='rd';
	}else
	{
		if ($classer_std=='Y') {
			$strrangstd='th';
		}else{
			$strrangstd='';
			
		}

		
	}
				
	$pdf->Image('../plugins/images/imgstd/'.$_SESSION['contenu_std'].'',165,38,22);
	$pdf->SetFont('Times','',10);
	$pdf->Cell(15,5,"Name of Student:",1,0,'L',1);
	$pdf->SetFont('Courier','B',10);
	$pdf->Cell(92,5,utf8_to_cp1252("$nomstd"),1,0,'L');
	$pdf->SetFont('Times','',10);
	$pdf->Cell(10,5,"Rep: ",1,0,'L',1);
	$pdf->Cell(8,5,utf8_to_cp1252($statut),1,0,'C');
	$pdf->Cell(18,5,utf8_to_cp1252("Cls Num:"),1,0,'L',1);
	$pdf->Cell(10,5,utf8_to_cp1252($num),1,0,'C');
	$pdf->Cell(12,5,utf8_to_cp1252("Matr"),1,0,'L',1);
	$pdf->Cell(25,5,utf8_to_cp1252($row0['cni_std']),1,0,'C');
	
	$pdf->Ln();
	$pdf->Cell(15,5,utf8_to_cp1252("Date of birth:"),1,0,'L',1);
	$pdf->Cell(20,5,utf8_to_cp1252($naissstd),1,0,'L');
	$pdf->Cell(5,5,utf8_to_cp1252("Place of birth:"),1,0,'L',1);
	$pdf->SetFont('Times','',9);
	$pdf->Cell(67,5,utf8_to_cp1252($lieu_nais),1,0,'L');
	$pdf->SetFont('Times','',10);
	$pdf->Cell(10,5,"Gender:",1,0,'C',1);
	$pdf->Cell(8,5,utf8_to_cp1252($sexestd),1,0,'C');
	$pdf->Cell(10,5,utf8_to_cp1252('Tel:'),1,0,'L',1);
	if ($row0['adresse_std']==NULL) {
		$nutel="";
	}
	else{
		$nutel=$row0['adresse_std'];
	}
	$pdf->Cell(20,5,utf8_to_cp1252($nutel),1,0,'C');
	$pdf->Cell(15,5,utf8_to_cp1252('N° Inscr:'),1,0,'L',1);
		$pdf->Cell(20,5,utf8_to_cp1252($_SESSION['pre_matr'].''.$matstd.''),1,0,'C');
	
	

	$pdf->SetFont('Times','B',9);
	$pdf->Ln();

	// DEBUT BULLETIN

	// Définition des en-têtes de colonne
$header = array('MATIÈRES', 'COMPÉTENCES ÉVALUÉES', 'Notes', 'Moy', 'CF', 'Total', 'Cote', '[m - M]',  'Apprt', 'Enseignant/VISA');

// Largeur des colonnes
$w = array(17, 90, 8, 8, 6, 8, 7, 10, 10, 26);
$pdf->Ln(2);
// En-tête
$pdf->SetFont('Times','B',8);
for($i=0;$i<count($header);$i++)
    $pdf->Cell($w[$i],5,utf8_to_cp1252($header[$i]),1,0,'C',1);
$pdf->Ln();



		/*matieres G1*/

		/*initiation des paramètres*/
		$Totalcoeff=0;
		$Totalpoint=0;

		$matieres = array();


		$bdd = $GLOBALS['bdd'];
		$reponse = $bdd->query('SELECT * FROM config_bull where (ref_class="'.$refcls.'") order by nom_mat asc');
		$pdf->SetFillColor(255,255,255);
 
		while($row = $reponse->fetch(PDO::FETCH_ASSOC)) 
		{
			$cknote1=$class->SelectNoteStd_by_MatCls($refcls,$row['ref_mat'],$eval1,$refstd);
			$cknote2=$class->SelectNoteStd_by_MatCls($refcls,$row['ref_mat'],$eval2,$refstd);
			$nmat=$mat->ReturnNom_matByIdname($row['ref_mat']);
			$teacher=$user->SelectTeacherName_by_mat_by_cls($row['ref_ens']);

			// compt
			$compt1=$mat->ReturnNom_ComptMatByClsByEval($refcls,$row['ref_mat'],$eval1);
			$compt2=$mat->ReturnNom_ComptMatByClsByEval($refcls,$row['ref_mat'],$eval2);
			$compt1=substr($compt1, 0,215);
			$compt2=substr($compt2, 0,215);
			$compt1=str_replace("’", "'", $compt1);
			$compt2=str_replace("’", "'", $compt2);
			if (strlen($compt1)<100) {
				$compt1.="\n ";
			}
			if (strlen($compt2)<100) {
				$compt2.="\n ";
			}

			

			$note1min=$class->SelectMINNoteby_MatClsbyEval($refcls,$row['ref_mat'],$eval1);
			$note2min=$class->SelectMINNoteby_MatClsbyEval($refcls,$row['ref_mat'],$eval2);
			$note1max=$class->SelectMAXNoteby_MatClsbyEval($refcls,$row['ref_mat'],$eval1);
			$note2max=$class->SelectMAXNoteby_MatClsbyEval($refcls,$row['ref_mat'],$eval2);

			if ($note1min!=NULL and $note2min!=NULL) {
				$minnote=($note1min+$note2min)/2;
				$minnote=round($minnote,2);
			}
			elseif ($note1min!=NULL and $note2min==NULL)
			{
				$minnote=$note1min;
				$minnote=round($minnote,2);
			}
			elseif ($note1min==NULL and $note2min!=NULL)
			{
				$minnote=$note2min;
				$minnote=round($minnote,2);
			}
			else{
				$minnote='';
			}

			if ($note1max!=NULL and $note2max!=NULL) {
				$maxnote=($note1max+$note2max)/2;
				$maxnote=round($maxnote,2);
			}
			elseif ($note1max!=NULL and $note2max==NULL)
			{
				
				$maxnote=$note1max;
				$maxnote=round($maxnote,2);
			}
				
			elseif ($note1max==NULL and $note2max!=NULL)
			{
				
				$maxnote=$note2max;
				$maxnote=round($maxnote,2);
			}
			else{
				$maxnote='';
			}


			/*contraintes */
				if (($cknote1==NULL) and ($cknote2>=0)) 
				{
					$note1='--';
					$note2=(float)$cknote2;
					$coeff=(float)$row['coeff_mat'];
					$note2=round($note2,2);
					$moy=$note2;
					$moy=round($moy,2);
					$total=$moy*$coeff;
					$total=round($total,2);
				}
				elseif (($cknote1>=0) and ($cknote2==NULL)) {
					$note2='--';
					$note1=(float)$cknote1;
					$coeff=(float)$row['coeff_mat'];
					$note1=round($note1,2);
					$moy=$note1;
					$moy=round($moy,2);
					$total=$moy*$coeff;
					$total=round($total,2);
				}
				elseif (($cknote1==NULL) and ($cknote2==NULL)) 
				{
					$note1='--';
					$note2='--';
					$coeff='--';
					$moy='--';
					
					$total='--';
				}
				else 
				{
					
					/*conversions pour les calculs*/
					$note1=(float)$cknote1;
					$note2=(float)$cknote2;
					$note1=round($note1,2);
					$note2=round($note2,2);
					$coeff=(float)$row['coeff_mat'];
					$moy=($note1+$note2)/2;
					$moy=round($moy,2);
					$total=$moy*$coeff;
					$total=round($total,2);
				}
				$Totalcoeff+=(float)$coeff;
				$Totalpoint+=(float)$total;

				/*APPRECIATION*/
			if (($moy>=0) and ($moy<10)) {
				$cote="D";
				$apr="CNA";
				$faibles_mat.=$nmat.', ';
			}elseif (($moy>=10) and ($moy<12)) {
				$cote="C";
				$apr="CMA";
			}
			elseif (($moy>=12) and ($moy<14)) {

				$cote="C+";
				$apr="CA";
			}
			elseif (($moy>=14) and ($moy<15)) {
				
				$cote="B";
				$apr="CBA";
			}
			elseif (($moy>=15) and ($moy<16)) {
				
				$cote="B+";
				$apr="CBA";
			}
			elseif (($moy>=16) and ($moy<18)) {
				
				$cote="A";
				$apr="CTBA";
			}
			elseif (($moy>=18) and ($moy<=20)) {
				
				$cote="A+";
				$apr="CTBA";
			}
			else{
				$apr="--";
				$cote="--";
			}


	// Définition des variables
	
$matieres = array(
    array(
        'matiere' => $nmat,
        'sous_competences' => array($compt1, $compt2),
        'notes' => array($note1, $note2),
        'moyenne' => $moy,
        'coeff' => $coeff,
        'total' => $total,
         'cote' => $cote,
         'mM' => $minnote." - ".$maxnote,
        'mention' => $apr,
        'enseignant' => $teacher
    )
);

// Données
	$pdf->SetFont('Times','',8);
foreach ($matieres as $matiere) {
    // Afficher les données de la matière
    $pdf->SetFont('helvetica','B',5);
    $pdf->Cell($w[0],8,utf8_to_cp1252($matiere['matiere']),1,0,'C');
    $pdf->SetFont('helvetica','I',6);
    $height = $pdf->GetY();
  $pdf->MultiCell($w[1],2,utf8_to_cp1252("".$matiere['sous_competences'][0].""),1,0,'L',0,2,'M');
$height = $pdf->GetY() - $height;
$pdf->SetXY($pdf->GetX() + 107, $pdf->GetY() - $height);

    $pdf->SetFont('Times','',8);
    $pdf->Cell($w[2],4,utf8_to_cp1252($matiere['notes'][0]),1,0,'C');
    $pdf->SetFont('Times','B',8);
    $pdf->Cell($w[3],8,utf8_to_cp1252($matiere['moyenne']),1,0,'C');
    $pdf->SetFont('Times','',8);
    $pdf->Cell($w[4],8,utf8_to_cp1252($matiere['coeff']),1,0,'C');
    $pdf->Cell($w[5],8,utf8_to_cp1252($matiere['total']),1,0,'C');
     $pdf->Cell($w[6],8,utf8_to_cp1252($matiere['cote']),1,0,'C');
     $pdf->SetFont('Times','',6);
    $pdf->Cell($w[7],8,utf8_to_cp1252($matiere['mM']),1,0,'C');
    $pdf->SetFont('Times','B',8);
  	$pdf->Cell($w[8],8,utf8_to_cp1252($matiere['mention']),1,0,'C');
  	$pdf->SetFont('Courier','',6);
    $pdf->Cell($w[9],4,utf8_to_cp1252($matiere['enseignant']),1,0,'L');
    $pdf->SetFont('Times','',8);
    $pdf->Ln();
    $pdf->Cell($w[0],0,'',0);
    $pdf->SetFont('helvetica','I',6);
     $height = $pdf->GetY();
  $pdf->MultiCell($w[1],2,utf8_to_cp1252("".$matiere['sous_competences'][1].""),1,0,'L',0,2,'M');
$height = $pdf->GetY() - $height;
$pdf->SetXY($pdf->GetX() + 107, $pdf->GetY() - $height);
     $pdf->SetFont('Times','',8);
    $pdf->Cell($w[2],4,utf8_to_cp1252($matiere['notes'][1]),1,0,'C');
    $pdf->Cell($w[3],0,'',0);
    $pdf->Cell($w[4],0,'',0);
    $pdf->Cell($w[5],0,'',0);
    $pdf->Cell($w[6],0,'',0);
    $pdf->Cell($w[7],0,'',0);
    $pdf->Cell($w[8],0,'',0);
    $pdf->Cell($w[9],0,'',0);
    $pdf->Ln();
    // Ajouter un espace après chaque matière
    $pdf->Ln(4);
  
    $pdf->Ln(2);
}
 }
	/*TOTAUX*/
	$TotauxMoy=$Totalpoint;
	$TotauxCoef=$Totalcoeff;
	if ($TotauxCoef==0) {
		$moyT="--";
	}else{
		$moyT=$TotauxMoy/$TotauxCoef;
			$moyT=round($moyT,2);
	}
	
	
	$pdf->Ln(1);
	if (($moyT>=0) and ($moyT<10)) {
				$coteT="D";
				$aprT="CNA";
			}elseif (($moyT>=10) and ($moyT<12)) {
				$coteT="C";
				$aprT="CMA";
			}
			elseif (($moyT>=12) and ($moyT<14)) {

				$coteT="C+";
				$aprT="CA";
			}
			elseif (($moyT>=14) and ($moyT<15)) {
				
				$coteT="B";
				$aprT="CBA";
			}
			elseif (($moyT>=15) and ($moyT<16)) {
				
				$coteT="B+";
				$aprT="CBA";
			}
			elseif (($moyT>=16) and ($moyT<18)) {
				
				$coteT="A";
				$aprT="CTBA";
			}
			elseif (($moyT>=18) and ($moyT<=20)) {
				
				$coteT="A+";
				$aprT="CTBA";
			}
			else{
				$aprT="--";
				$cote="--";
			}
		$pdf->SetFillColor(154,203,157);
	//$t_coef=$opt->NombreCoeffbyCls($refcls);
	$t_coef=$opt->NombreCoeffbyStd_Cls($refcls,$refbul,$refstd);
	$Moy_E1=$opt->ShowMoy_Seq_Std($refcls,$refstd,$eval1,$t_coef);
	$Moy_E2=$opt->ShowMoy_Seq_Std($refcls,$refstd,$eval2,$t_coef);

	$pdf->SetFont('Arial','B',8);
	$pdf->Cell(12,5,'Moy C'.$eval1.':',1,0,'C',1);
	$pdf->Cell(12,5,number_format($Moy_E1,2),1,0,'C',0);
	$pdf->Cell(12,5,'Moy C'.$eval2.':',1,0,'C',1);
	$pdf->Cell(12,5,number_format($Moy_E2,2),1,0,'C',0);
	$pdf->Cell(35,5,'',0,0,'C',0);
	$pdf->Cell(39,5,'TOTAL ',1,0,'C',1);
	$pdf->Cell(7,5,$TotauxCoef,1,0,'C',0);
	$pdf->Cell(15,5,$TotauxMoy,1,0,'C',0);
	$pdf->Cell(10,5,' Moy: ',1,0,'C',1);
	$pdf->Cell(12,5,number_format($moyT,2),1,0,'C',0);
	$pdf->Cell(10,5,' Apprt:',1,0,'C',1);
	$pdf->Cell(14,5,''.$aprT.'',1,0,'C',0);

	$pdf->Ln(1);

	
	/*FIN TOTAUX
		*/

	/* Autres Appreciations

		*/
		$avertmwk="--";
		$sblmwk="--";
		$th="--";
	if (($moyT>0) and ($moyT<7)) {
		$avertmwk="--";
		$sblmwk="X";
		$th="--";
	}
	 elseif(($moyT>7) and ($moyT<10)) {
	 	$sblmwk="--";
	 	$avertmwk="X";
		$th="--";
	}elseif (($moyT>=12)){
		$avertmwk="--";
		$sblmwk="--";
		$th="X";
	}
	
	/* Fin Autres Appreciations
		*/

	/*Fin Statistique
						*/
	$moy_General=$opt->ShowMoy_by_Cls($refcls,$refbul);
	$moy_General=round($moy_General,2);
	$moy_General=number_format($moy_General,2);



	$marge=10;

	$NbStd_Taux=$opt->ShowNbStd_for_TauxR_by_Cls($refcls,$refbul,$marge);
	//$nbstdclasser=(float)$nbstdclasser;
	if ($nbstdclasser>0) 
	{
	$taux_R=$NbStd_Taux*100/$nbstdclasser;
	$taux_R=round($taux_R,2);
	}
	else{
		$taux_R=0;
	}
	


	/*FIN Stat
		*/
$pdf->SetFillColor(0,167,223);
		
	$pdf->Ln();
	$pdf->SetFont('Times','B',8);
	$pdf->SetFont('Times','B',9);
	$pdf->Cell(40,4,'Discipline',1,0,'C',1);
	$pdf->Cell(2,4,'',0,0,'L',0);

	$pdf->Cell(50,4, utf8_to_cp1252('Travail de l\'élève'),1,0,'C',1);
	$pdf->Cell(2,4,'',0,0,'L',0);

	$pdf->Cell(40,4,'Profil de la classe',1,0,'C',1);
	
	$pdf->Cell(0,4,utf8_to_cp1252('Fait à'.$_SESSION['ville_etb'].', le ______________'),0,0,'R',0);

	$pdf->Ln();
	$pdf->Cell(30,4,utf8_to_cp1252('Abs. Non. J.(h)'),1,0,'L',0);
	$pdf->Cell(10,4,''.$HeureAbs.'',1,0,'C',0);
	$pdf->Cell(2,4,'',0,0,'L',0);

	$pdf->Cell(10,8,'Moy:',1,0,'L',0);
	$pdf->SetFont('Times','B',12);
	$pdf->SetFillColor(236,235,2);
	$pdf->Cell(15,8,number_format($moyT,2),1,0,'C',1);
	$pdf->SetFont('Times','B',8);
	$pdf->Cell(10,8,'Rang: ',1,0,'L',0);
	$pdf->SetFont('Times','B',12);
	if ($rangstd=='NC') {
		$pdf->Cell(15,8,''.$rangstd.''.$strrangstd,1,0,'C',1);
	}
	else{
		$pdf->Cell(15,8,''.$rangstd.''.$strrangstd.'/'.$nbstdclasser.'',1,0,'C',1);
	}
	$pdf->Cell(2,4,'',0,0,'L',0);
	$pdf->SetFont('Times','B',8);
	$pdf->Cell(25,4,utf8_to_cp1252('Moy Gen.'),1,0,'L',0);
	$pdf->Cell(15,4,number_format($moy_General,2),1,0,'C',0);


	$pdf->Ln();
	$pdf->Cell(30,4,utf8_to_cp1252('Consignes (h)'),1,0,'L',0);
	$pdf->Cell(10,4,'',1,0,'C',0);
	$pdf->Cell(2,8,'',0,0,'L',0);

	$pdf->Cell(52,4,'',0,0,'L',0);

	$pdf->Cell(25,4,'Moy 1er.',1,0,'L',0);
	$pdf->Cell(15,4,number_format($moy_1er,2),1,0,'C',0);
	$pdf->Cell(2,8,'',0,0,'L',0);

	$pdf->Cell(0,4,'Le Proviseur/Responsable',0,0,'L',0);
	

	$pdf->Ln();
	// CORRECTION : impression conditionnelle du cachet de l'établissement (paramètre p_ch)
	if ($etb->ChksigRE() && !empty($_SESSION['sign_respo_etb'])) {
		$pdf->Image('../plugins/images/'.$_SESSION['sign_respo_etb'], 175, $pdf->GetY(), 20);
	}
	$pdf->Cell(30,4,'Tableau d\'Honneur',1,0,'L',0);
	
	$pdf->Cell(10,4,''.$th.'',1,0,'C',0);
	$pdf->Cell(2,4,'',0,0,'L',0);

	$pdf->Cell(10,4,'Cote',1,0,'L',0);
	$pdf->Cell(15,4,$coteT,1,0,'C',0);
	$pdf->Cell(10,4,'Apprt',1,0,'L',0);
	$pdf->Cell(15,4,$aprT,1,0,'C',0);
	$pdf->Cell(2,4,'',0,0,'L',0);

	$pdf->Cell(25,4,'Moy der.',1,0,'L',0);
	$pdf->Cell(15,4,number_format($moy_dern,2),1,0,'C',0);

	$pdf->Ln();	
	$pdf->Cell(30,4,utf8_to_cp1252('Exclusion (jrs)'),1,0,'L',0);
	$pdf->Cell(10,4,'',1,0,'C',0);
	$pdf->Cell(2,4,'',0,0,'L',0);

	$pdf->Cell(50,4,utf8_to_cp1252('Visa du professeur pcpl:'),1,0,'C',1);
	$pdf->Cell(2,4,'',0,0,'L',0);

	$pdf->Cell(25,4,utf8_to_cp1252('Taux de R. (%)'),1,0,'L',0);
	$pdf->Cell(15,4,utf8_to_cp1252($taux_R),1,0,'C',0);
	$pdf->Cell(2,4,'',0,0,'L',0);

	$pdf->Ln();
	$pdf->Cell(30,4,utf8_to_cp1252('Blâme Travail'),1,0,'L',0);
	$pdf->Cell(10,4,$sblmwk,1,0,'C',0);
	$pdf->Cell(2,4,'',0,0,'L',0);

	$pdf->Cell(50,4,'',0,0,'L',0);

	$pdf->Ln();
	$pdf->Cell(30,4,utf8_to_cp1252('Avert,'),1,0,'L',0);
	$pdf->Cell(10,4,$avertmwk,1,0,'C',0);
	$pdf->Cell(2,4,'',0,0,'L',0);

	$pdf->Cell(50,4,'',0,0,'L',0);
	$pdf->Cell(60,2,'',0,0,'C',0);
	$pdf->Ln(3);
	
	$pdf->SetFont('Times','B',8);
	$pdf->Cell(105,5,'Un effort s\'imporse en:',0,0,'LC',0);
	$pdf->Cell(10,4,'',0,0,'C',0);
	
	$pdf->Ln();
	$pdf->SetFont('Times','I',6);
	$pdf->Cell(118,4,utf8_to_cp1252(''.$faibles_mat.''),0,0,'L',0);
	$pdf->SetFont('Times','B',10);
	

	
			/*FIN TOTAUX*/
			$faibles_mat="";
					

		}
		$pdf->Output('Bulletin_Trim_'.$refbul.'_'.$nomcls.'.pdf','I');	
?>
