# GESCOAPC — mise à jour responsive et offline

## Audit de la base

Le fichier `Model/gescoapc_25_26.sql` a été utilisé comme référence métier. Il contient **32 tables**, notamment `admins`, `eleves`, `classes`, `matieres`, les tables de notes par matière et par trimestre, les absences, la discipline, les pensions et les versements. Les comptes et rôles présents dans le dump (`admin`, `sg`, `ens`, `pcpl`, `caisse`) ont été conservés ; aucune table métier ni donnée SQL n’a été supprimée.

## Corrections appliquées

Les ressources frontend utilisées par le cœur sont désormais locales : Bootstrap **5.3.8**, Font Awesome **6.7.2 Free** et jQuery **4.0.0** dans `assets`. Le chargeur partagé `core/config.php` ne dépend plus d’un CDN et fournit également une notification Bootstrap réutilisable via `Config::toast()` ainsi qu’un mode sombre local.

Les références CDN inutiles ont été supprimées de `home.php`. Les chemins de logo et de favicon des composants partagés ont été réalignés sur les images présentes dans le projet. La sidebar moderne conserve les accès selon les rôles, y compris l’espace de saisie des enseignants.

Les boîtes de dialogue JavaScript natives ont été remplacées par des alertes/toasts Bootstrap dans la connexion, la gestion financière, l’impression, l’import Excel et les réglages de compte. Aucun appel applicatif `alert()` ou `confirm()` natif ne reste dans le code contrôlé.

Un fichier de copie historique PHP manifestement tronqué et syntaxiquement invalide a été neutralisé proprement afin de ne pas perturber l’application. La logique des contrôleurs actifs n’a pas été réécrite.

## Validation

Le contrôle PHP CLI a validé **141 fichiers PHP** sans erreur de syntaxe. Les fichiers frontend essentiels existent aux chemins attendus :

- `assets/bootstrap/css/bootstrap.min.css`
- `assets/bootstrap/js/bootstrap.bundle.min.js`
- `assets/fontawesome/css/all.min.css`
- `assets/fontawesome/webfonts/fa-solid-900.woff2`
- `assets/js/jquery-4.0.0.min.js`

Une seconde cartographie des routes a ensuite été effectuée avant correction. Les liens invalides vers `ges_fin.php`, `blank.html`, `allstudents.php`, `printing_by_user.php`, `me.php`, `std_notes.php`, `Controleur/tafsirs/deltaf.php` et `addDep.php` ont été réalignés sur les fichiers réellement présents. Le lien Finance pointe maintenant vers `gestion_fin.php`, le menu Opérations vers `operations.php`, les impressions vers `impression.php`, et le contrôleur département utilise la casse réelle `Controler/departs/adddep.php` ou `delDep.php` selon l’action.

La méthode historique `MyETB::CkLE()` était appelée par de nombreuses pages mais n’existait pas dans `core/etb_core.php`. Elle a été ajoutée sans changer les appels existants ; elle retourne un état de licence cohérent et laisse le contrôle détaillé de `less/patch.php` au processus de connexion. Les deux flux AJAX vérifiés (`enregistrer_note_ajax.php` et `ajouter_points.php`) existent toujours et leurs URLs n’ont pas été remplacées par des chemins inventés.

Le contrôleur de migration annuelle `Controler/classes/addclasse_by_migr.php` n’existe pas dans l’archive fournie et aucun équivalent réel n’a été trouvé. Aucun fichier fictif n’a été créé : le bouton correspondant est explicitement désactivé pour éviter une soumission vers une route inexistante.

## Installation Laragon

Décompresser le dossier `gescoapc` dans `C:\laragon\www\`. Importer `Model/gescoapc_25_26.sql` dans MySQL/MariaDB, puis ouvrir `http://localhost/gescoapc/`. La connexion PDO conserve le nom dynamique `gescoapc_` suivi de l’année choisie dans la session.

> Les modules métiers et les contrôleurs historiques restent volontairement conservés pour ne pas casser les liens existants. Une seconde passe peut ensuite nettoyer les fichiers legacy non référencés après vérification fonctionnelle écran par écran.
