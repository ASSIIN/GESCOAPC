<?php
	session_start();
	require_once '../../Model/connexion.php';
	require_once '../../core/require.php'; 	

	// CORRECTION : validation des entrées (anti-injection)
	$ref_cls      = htmlspecialchars(trim($_POST['cls'] ?? ''));
	$ref_mat      = htmlspecialchars(trim($_POST['mat'] ?? ''));
	$ref_mat_to   = htmlspecialchars(trim($_POST['mat_to'] ?? ''));
	$de           = (int)($_POST['de'] ?? 0);
	$vers         = (int)($_POST['vers'] ?? 0);

	// Les périodes d'évaluation sont numérotées 1..6 (tables table_note_par_mat_evalN)
	if ($de < 1 || $de > 6)   $de = 0;
	if ($vers < 1 || $vers > 6) $vers = 0;

	// SÉCURISÉ : garde d'accès + champs requis
	if (!isset($_SESSION['user']) || !in_array($_SESSION['user_role'] ?? '', array('admin', 'pcpl', 'sg', 'cs')) || $ref_cls === '' || $de === 0 || $vers === 0) {
		header('location: ../../reconduire_notes.php');
		exit;
	}

if ($ref_mat=='all') {
	 header('location:recon_allnotes.php?cls='.urlencode($ref_cls).'&de='.$de.'&vers='.$vers.'');
	 exit;
}

	$bdd = $GLOBALS['bdd'];
	$table_eval_dst = 'table_note_par_mat_eval'.$vers;

	// SÉCURISÉ : liste des élèves de la classe (requête préparée)
	$reponse = $bdd->prepare('SELECT mat_std FROM eleves WHERE ref_class = ?');
	$reponse->execute(array($ref_cls));
	$eleves = $reponse->fetchAll(PDO::FETCH_ASSOC);

	foreach ($eleves as $row)
	{
		$ni=0;
		$nf=0;

		// Aucune note dans la source : on nettoie l'éventuelle note déjà présente à la cible
		if (!$class->CheckNoteStd_by_MatCls($ref_cls,$ref_mat,$de,$row['mat_std']))
		{
			if (!$class->CheckNoteStd_by_MatCls($ref_cls,$ref_mat_to,$vers,$row['mat_std']))
			{
				continue;
			}
			else
			{
				// CORRECTION : "DELETE FROM" (le FROM manquait) + requête préparée
				$stmt = $bdd->prepare('DELETE FROM '.$table_eval_dst.' WHERE ref_cls = ? AND ref_mat = ? AND ref_eval = ? AND ref_std = ?');
				$stmt->execute(array($ref_cls, $ref_mat_to, $vers, $row['mat_std']));
			}
		}
		else
		{
			$ni=$class->ShowNoteStd_by_MatCls_OK($ref_cls,$ref_mat, $de,$row['mat_std']);
			$nf=(float)$ni;

			if ($class->CheckNoteStd_by_MatCls($ref_cls,$ref_mat_to,$vers,$row['mat_std']))
			{
				$coef=$opt->SelectCoef_by_MatCls($ref_cls,$ref_mat_to);

				if ($nf==21)
				{
					$stmt = $bdd->prepare('UPDATE '.$table_eval_dst.' SET note= ?, coef= ?, note_x_coeff= ? WHERE ref_cls = ? AND ref_mat = ? AND ref_eval = ? AND ref_std = ?');
					$stmt->execute(array(NULL, NULL, NULL, $ref_cls, $ref_mat_to, $vers, $row['mat_std']));
				}
				elseif($nf==0)
				{
					$note_x_coeff=0;
					// CORRECTION : les colonnes ref_cls / ref_mat étaient inversées dans le WHERE
					$stmt = $bdd->prepare('UPDATE '.$table_eval_dst.' SET note= ?, coef= ?, note_x_coeff= ? WHERE ref_cls = ? AND ref_mat = ? AND ref_eval = ? AND ref_std = ?');
					$stmt->execute(array($nf, $coef, $note_x_coeff, $ref_cls, $ref_mat_to, $vers, $row['mat_std']));
				}
				else
				{
					$note_x_coeff=$nf*$coef;
					$stmt = $bdd->prepare('UPDATE '.$table_eval_dst.' SET note= ?, coef= ?, note_x_coeff= ? WHERE ref_cls = ? AND ref_mat = ? AND ref_eval = ? AND ref_std = ?');
					$stmt->execute(array($nf, $coef, $note_x_coeff, $ref_cls, $ref_mat_to, $vers, $row['mat_std']));
				}
			}
			else
			{
				$coef=$opt->SelectCoef_by_MatCls($ref_cls,$ref_mat_to);
				$note_x_coeff=$nf*$coef;
				$req = "INSERT INTO ".$table_eval_dst." (ref_mat, ref_cls, ref_std, ref_eval, note, coef, note_x_coeff) VALUES(?, ?, ?, ?, ?, ?, ?)";
				$rep = $bdd->prepare($req);
				$rep->execute(array($ref_mat_to, $ref_cls, $row['mat_std'], $vers, $nf, $coef, $note_x_coeff));
			}

		}

	}

	$class->CkClasseByCode($ref_cls);
        $sess_bul=$_SESSION['class_session'];
        switch ($sess_bul) {
        	case 'SFG':
        		$cfg=$ref_cls;
        		$cag='';
        		$cft='';
        		$cat='';
        		break;
        	case 'SAG':
        		$cfg='';
        		$cag=$ref_cls;
        		$cft='';
        		$cat='';
        		break;
        	case 'SFT':
        		$cfg='';
        		$cag='';
        		$cft=$ref_cls;
        		$cat='';
        		break;
        	case 'SAT':
        		$cfg='';
        		$cag='';
        		$cft='';
        		$cat=$ref_cls;
        		break;
        	
        	default:
        		$cfg='';
        		$cag='';
        		$cft='';
        		$cat='';
        		break;
        }
	
	if (($cfg=='' and $cag=='') and ($cft=='' and $cat=='')) 
		{
			header('location: ../../reconduire_notes.php'); 
		}else{
			header('location: ../../reconduire_notes.php?sess_bul='.$sess_bul.'&cfg='.$cfg.'&cag='.$cag.'&cft='.$cft.'&cat='.$cat.'');
		}
?>