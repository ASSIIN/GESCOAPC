<?php
session_start();
ini_set('display_errors', 0);
error_reporting(0);

require_once '../../Model/connexion.php';
require_once '../../core/require.php'; 

$bdd = $GLOBALS['bdd'];

if (isset($_POST['idstd']) && !empty($_POST['idstd'])) {
    
    $id = (int)$_POST['idstd'];
    $refstd = $std->SelectMatrbyID($id);
    $refcls = trim((string)($_POST['refcls'] ?? ''));
    $new_cls = trim((string)($_POST['ref_cls'] ?? ''));
    
    $nom_std = mb_strtoupper(trim(preg_replace('/\s+/', ' ', htmlspecialchars($_POST['nom_std']))), 'UTF-8');
    $cni_std = mb_strtoupper(trim(preg_replace('/\s+/', ' ', htmlspecialchars($_POST['cni_std']))), 'UTF-8');
    $date_naiss = htmlspecialchars($_POST['date_naiss_std']);
    $sexe_std = htmlspecialchars($_POST['sexe']);
    $lieu_naiss_std = mb_strtoupper(trim(preg_replace('/\s+/', ' ', htmlspecialchars($_POST['lieu_naiss_std']))), 'UTF-8');
    $pere_std = mb_strtoupper(trim(preg_replace('/\s+/', ' ', htmlspecialchars($_POST['pere_std']))), 'UTF-8');
    $mere_std = mb_strtoupper(trim(preg_replace('/\s+/', ' ', htmlspecialchars($_POST['mere_std']))), 'UTF-8');
    $adresse_std = htmlspecialchars($_POST['adresse_std']);
    $localite_std = mb_strtoupper(trim(preg_replace('/\s+/', ' ', htmlspecialchars($_POST['localite_std']))), 'UTF-8');
    $statut = htmlspecialchars($_POST['statut']);
    $handicap = htmlspecialchars($_POST['handicap']);

    // Restauration des apostrophes sémantiques pour la base SQL
    $replacements = ["&#039;" => "'"];
    $nom_std = strtr($nom_std, $replacements);
    $lieu_naiss_std = strtr($lieu_naiss_std, $replacements);
    $localite_std = strtr($localite_std, $replacements);
    $mere_std = strtr($mere_std, $replacements);
    $pere_std = strtr($pere_std, $replacements);

    // Tableau associatif d'analyse des modifications soumises
    $elt = array(
        'ref_class' => $new_cls, 'nom_std' => $nom_std, 'cni_std' => $cni_std, 
        'date_nais' => $date_naiss, 'sexe_std' => $sexe_std, 'lieu_nais' => $lieu_naiss_std, 
        'pere_std' => $pere_std, 'mere_std' => $mere_std, 'adresse_std' => $adresse_std, 
        'localite_std' => $localite_std, 'statut' => $statut, 'handicap' => $handicap
    );
    
    foreach ($elt as $key => $value) {
        if ($value !== "" && $value !== NULL) {
            
            if ($key == 'ref_class') {
                // Gestion sécurisée du transfert d'historique de notes inter-classes
                $tab_ua = array('1','2','3','4','5','6');
                foreach ($tab_ua as $ua) {
                    if ($class->CheckNote_Tranfert_Std_by_Cls($refcls, $ua, $refstd)) {
                        
                        $req2 = $bdd->prepare('UPDATE table_note_par_mat_eval'.$ua.' SET ref_cls = ? WHERE ref_cls = ? AND ref_std = ?');
                        $req2->execute(array($new_cls, $refcls, $refstd));
                        
                        $n_ua = (int)$ua;
                        if ($n_ua <= 3) {
                            $req3 = $bdd->prepare('UPDATE table_note_par_trim'.$ua.' SET ref_cls = ? WHERE ref_cls = ? AND ref_std = ? AND ref_trim = ?');
                            $req3->execute(array($new_cls, $refcls, $refstd, $ua));
                        }
                    }
                    $class->DelMatieresObsoletes($refcls, $ua);
                }

                // Transfert du registre de discipline (absences)
                $reqi = $bdd->prepare('UPDATE absences SET ref_cls = ? WHERE ref_cls = ? AND ref_std = ?');
                $reqi->execute(array($new_cls, $refcls, $refstd));
            }

            // Exécution sécurisée de la mise à jour de la colonne concernée
            $req = $bdd->prepare("UPDATE eleves SET $key = ? WHERE id = ?");
            $req->execute(array($value, $id));
        }
    }

    // Traitement du téléversement de la photo 4x4 (si soumise)
    if (isset($_FILES['support']) && !empty($_FILES['support']['name'])) {
        $support = $_FILES['support'];
        $file_nom = basename($support['name']);
        $file_ext = strtolower(strrchr($file_nom, '.'));
        $tab_ext = array('.jpg', '.jpeg', '.png');

        if (in_array($file_ext, $tab_ext)) {
            $fichier = 'img' . $refstd . $file_ext;    
            // CORRECTION : chemin absolu (indépendant du répertoire de travail)
            $dossier = __DIR__ . '/../../plugins/images/imgstd/';
            $file_path = $dossier . $fichier;

            if (file_exists($file_path) && is_file($file_path)) {
                unlink($file_path);
            }

            if (move_uploaded_file($support['tmp_name'], $file_path)) {
                $req_img = $bdd->prepare('UPDATE eleves SET contenu_std = ? WHERE id = ?');
                $req_img->execute(array($fichier, $id));
            }
        }
    }

    // Redirection propre après modification
    if (!empty($new_cls)) {
        header('location: ../../home.php?cls=' . urlencode($new_cls));
    } else {
        header('location: ../../home.php?cls=' . urlencode($refcls));
    }
    exit();
} else {
    header('location: ../../home.php');
    exit();
}
?>
