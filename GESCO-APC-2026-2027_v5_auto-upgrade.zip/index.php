<?php
session_start();
require_once 'core/require.php';
require_once 'Model/checkdb.php';
if (isset($_SESSION['con_year']) && $_SESSION['con_year'] != '') {
    require_once 'Model/connexion.php';
    require_once 'less/patch.php';
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
  <script>document.documentElement.setAttribute('data-theme', localStorage.getItem('gescoapc-theme') || localStorage.getItem('theme') || 'light');</script>
  <?php Config::head(); ?>
  <title>GESCO-APC | Connexion</title>
  <style>
    /* Configuration des variables de couleur */
    :root {
      --bg-gradient: linear-gradient(135deg, rgba(15, 23, 42, 0.6), rgba(30, 41, 59, 0.4)), url('images/bg1.jpg') center/cover fixed;
      --card-bg: rgba(255, 255, 255, 0.85);
      --card-border: rgba(255, 255, 255, 0.4);
      --text-title: #0764a8;
      --input-bg: rgba(255, 255, 255, 0.9);
      --btn-primary: #19784f;
      --btn-hover: #135d3d;
    }

    [data-theme="dark"] {
      --card-bg: rgba(15, 23, 42, 0.85);
      --card-border: rgba(255, 255, 255, 0.08);
      --text-title: #38bdf8;
      --input-bg: rgba(30, 41, 59, 0.7);
    }

    /* Styles de base de la page */
    body.login-page { 
      min-height: 100vh; 
      display: flex; 
      align-items: center; 
      padding: 40px 16px; 
      background: var(--bg-gradient) !important;
      font-family: system-ui, -apple-system, sans-serif;
    }

    /* Carte de connexion moderne et vitrifiée (Glassmorphism) */
    .login-card { 
      width: 100%; 
      max-width: 440px; 
      margin: auto; 
      padding: clamp(24px, 6vw, 40px); 
      background: var(--card-bg) !important; 
      backdrop-filter: blur(16px); 
      -webkit-backdrop-filter: blur(16px);
      border: 1px solid var(--card-border) !important; 
      border-radius: 16px !important;
      box-shadow: 0 20px 25px -5px rgba(0, 0, 0, 0.15), 0 10px 10px -5px rgba(0, 0, 0, 0.04) !important;
      animation: loginIn 0.6s cubic-bezier(0.16, 1, 0.3, 1) both; 
    }

    .login-logo { 
      width: min(180px, 70%); 
      height: auto; 
      object-fit: contain; 
      transition: transform 0.3s ease;
    }
    
    .login-logo:hover {
      transform: scale(1.02);
    }

    .login-title { 
      color: var(--text-title) !important; 
      font-weight: 800; 
      letter-spacing: -0.01em; 
    }

    /* Personnalisation des champs de formulaire */
    .login-card .form-control,
    .login-card .form-select { 
      background: var(--input-bg) !important; 
      border: 1px solid rgba(0, 0, 0, 0.1);
      border-radius: 10px;
      transition: all 0.2s ease;
    }

    [data-theme="dark"] .login-card .form-control,
    [data-theme="dark"] .login-card .form-select {
      border-color: rgba(255, 255, 255, 0.1);
      color: #f8fafc;
    }

    .login-card .form-control:focus,
    .login-card .form-select:focus {
      border-color: var(--text-title);
      box-shadow: 0 0 0 3px rgba(7, 100, 168, 0.18);
    }

    /* Bouton principal optimisé */
    .btn-submit {
      background: var(--btn-primary);
      border: none;
      border-radius: 10px;
      padding: 12px;
      transition: all 0.2s ease;
    }

    .btn-submit:hover {
      background: var(--btn-hover);
      transform: translateY(-1px);
      box-shadow: 0 4px 12px rgba(25, 120, 79, 0.3);
    }

    .btn-submit:active {
      transform: translateY(0);
    }

    /* Bouton de changement de thème discret */
    .login-theme { 
      position: fixed; 
      top: 20px; 
      right: 20px; 
      border-radius: 50px;
      padding: 8px 16px;
      background: rgba(255, 255, 255, 0.8);
      border: 1px solid rgba(0, 0, 0, 0.05);
      backdrop-filter: blur(8px);
      transition: all 0.2s ease;
    }

    [data-theme="dark"] .login-theme {
      background: rgba(30, 41, 59, 0.8);
      border-color: rgba(255, 255, 255, 0.1);
      color: #f8fafc;
    }

    .login-theme:hover {
      transform: scale(1.05);
    }

    @keyframes loginIn { 
      from { opacity: 0; transform: translateY(16px); } 
      to { opacity: 1; transform: none; } 
    }

    @media (max-width: 480px) { 
      .login-theme { top: 12px; right: 12px; padding: 6px 12px; font-size: 0.85rem; } 
      .login-card { margin-top: 40px; padding: 24px 16px; } 
    }
  </style>
</head>
<body class="login-page">
  <button type="button" class="theme-toggle-btn login-theme" id="toggleTheme" data-theme-toggle>
    <i class="fa-solid fa-moon me-1" id="themeIcon" data-theme-icon></i>
    <span id="themeText" data-theme-text> Mode sombre</span>
  </button>
  
  <?php
  if (isset($_GET['lk'])) Config::toast('Licence activée avec succès. Connectez-vous pour accéder à votre application.', 'success');
  elseif (isset($_GET['el'])) Config::toast('Licence annuelle requise ou session expirée. Veuillez valider votre paiement.', 'danger');
  elseif (isset($_GET['e'])) Config::toast('Identifiant ou mot de passe incorrect.', 'warning');
  elseif (isset($_SESSION['fresh_install'])) { Config::toast('Première installation réussie : la base de données a été créée automatiquement. Connectez-vous avec le compte de démarrage.', 'success'); unset($_SESSION['fresh_install']); }
  ?>

  <main class="container-fluid">
    <div class="login-card card">
      <form action="check.php" method="post" class="needs-validation" novalidate>
        <img class="login-logo mb-4 mx-auto d-block" src="images/logo.png" alt="Logo GESCO-APC" width="220" height="105">
        <h1 class="login-title h4 text-center mb-4">Bienvenue dans GESCO-APC</h1>
        
        <div class="mb-3">
          <label class="visually-hidden" for="schoolYear">Année scolaire</label>
          <select class="form-select text-center fw-bold py-2" id="schoolYear" name="an" required>
            <option value="<?= htmlspecialchars($dbLastY ?? '', ENT_QUOTES, 'UTF-8') ?>"><?= htmlspecialchars($School_year1 ?? '', ENT_QUOTES, 'UTF-8') ?></option>
            <option selected value="<?= htmlspecialchars($dbcurrentY ?? '', ENT_QUOTES, 'UTF-8') ?>"><?= htmlspecialchars($School_year2 ?? '', ENT_QUOTES, 'UTF-8') ?></option>
          </select>
        </div>
        
        <div class="form-floating mb-3">
          <input type="text" class="form-control" id="floatingInput" placeholder="Identifiant" name="login" required autocomplete="username">
          <label for="floatingInput">Identifiant de connexion</label>
        </div>
        
        <div class="form-floating mb-4">
          <input type="password" class="form-control" id="floatingPassword" placeholder="Mot de passe" name="password" required autocomplete="current-password">
          <label for="floatingPassword">Mot de passe</label>
        </div>
        
        <button class="btn btn-lg w-100 fw-bold text-white btn-submit" type="submit">
          <i class="fa-solid fa-right-to-bracket me-2"></i>Se connecter
        </button>
      </form>
    </div>
  </main>
  <?php Config::scriptJs(); ?>
</body>
</html>
