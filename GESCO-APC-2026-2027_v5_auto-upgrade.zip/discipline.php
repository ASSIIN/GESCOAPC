<?php
    session_start();   
	require_once 'core/require.php'; 
	require_once 'Model/connexion.php';
     if (!isset($_SESSION['user'])) {
    session_unset();
    session_destroy();
    header('location: index.php');    
    exit();
    }

    // CORRECTION : sortie immédiate après redirection du rôle
    if (($_SESSION['user_role']!="admin") and ($_SESSION['user_role']!="pcpl") and ($_SESSION['user_role']!="sg")) {

      if ( ($_SESSION['user_role']=="caisse")) {
         header('location: menu_classes.php');    
      } 
      else{
          header('location: poste_de_saisie.php?trim=t1');   
        }
      exit();
      
    }

    $etb->ShowEtb();
    $etb->CkLE();
    $etb->ckexneE();
?>

<!DOCTYPE html>
<html>
  <head>
   <?php Config::head(); ?>
    <title>GESCOAPC| DISCIPLINE</title>
  </head>

<body>
    <div class="wrapper">
      <!-- Sidebar -->

      <!-- Inclusion du menu de navigation externe réutilisable -->
      <?php include 'core/sidebar.php'; ?>  
       
<div class="main-content-wrapper">
        <!-- Barre supérieure de navigation adaptative -->
        <div class="mobile-navbar-fixed p-3 mb-4 rounded shadow-sm border">
            <div class="row align-items-center g-2">
                <div class="col-auto d-md-none">
                    <button class="btn btn-outline-dark btn-sm" id="toggleMobileMenu"><i class="fa fa-bars fa-lg"></i></button>
                </div>
                <div class="col-12 col-md">
                    <h4 class="m-0 fw-bold text-primary text-uppercase">Discipline & absences</h4>
                </div>
                <div class="col-12 col-md-auto d-flex justify-content-md-end">
                    <input class="form-control form-control-sm" id="search" type="text" placeholder="&#xF002; Recherche ou Tri" style="font-family: Arial, FontAwesome">
                </div>
            </div>
        </div>

        <div class="container-fluid">
                <!-- ============================================================== -->
                <div class="row mt-4">
                    <div class="card shadow-sm">
                      <div class="card-header bg-primary text-white py-2">
                        <h5 class="m-0 fw-bold">Heures d'absence</h5>
                      </div>
                      <div class="card-body">
                                <div class="row">
                                   <div class="col-md-4">
                                    <form action="absences.php" method="GET" >                           
                                      <label for="inputState">CLASSE :</label>
                                         <select id="inputState" class="form-control" name="cls" required>
                                           <?php  $std-> SelectClassesNames(); ?>                           
                                        </select>
                                    </div>

                                    <div class="col-md-4">
                                       <label for="exampleInputEmail1" class="form-label">Trimestre</label>

                                       <select id="inputState" class="form-control" name="trim" required>
                                        <option value="" >...</option>
                                         <option value="1">Trim 1</option>
                                        <option value="2">Trim 2</option>
                                        <option value="3">Trim 3</option>
                                        
                                         </select>
                                    </div>
                                     <div class="col-md-4">
                                      <label for="exampleInputEmail1" class="form-label">Validation</label><br>
                                
                                      <button type="submit" class="btn btn-primary">Confirmer</button>
                                     </div>
                                     </div>
                                  </form>
                                  </div>
                      </div>
                    </div>
                </div>
                <!-- ============================================================== -->
                <!-- Gestion des Classes -->

       
        </div>
        <!-- ============================================================== -->
        <!-- End Page Content -->
        <!-- ============================================================== -->
    </div>

		<?php 
		 	Config::scriptJs();
		?>
        <script type="text/javascript">
            $('#exampleModal').on('show.bs.modal', function (event) {
  var button = $(event.relatedTarget) // Button that triggered the modal
  var recipient = button.data('whatever') // Extract info from data-* attributes
  // If necessary, you could initiate an AJAX request here (and then do the updating in a callback).
  // Update the modal's content. We'll use jQuery here, but you could use a data binding library or other methods instead.
  var modal = $(this)
  modal.find('.modal-title').text('New message to ' + recipient)
  modal.find('.modal-body input').val(recipient)
})
        </script>
	</body>
</html>