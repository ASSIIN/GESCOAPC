<?php
	session_start();
	require_once '../../Model/connexion.php';
	require_once '../../core/require.php'; 	
	$nom_dep= htmlspecialchars($_POST['nom_dep']);
	$abr_dep= htmlspecialchars($_POST['abr_dep']);
	$session= htmlspecialchars($_POST['session']);
	
	
  		
  		if (isset($nom_dep)) 
  		{
  			//echo 'Nom: '.$nom_classe.' <br> Niveau : '.$niveau.' <br> Session: '.$session.' <br> code : '.$codeswift.' ';

  			/* conversion*/
		$nom_dep=strtoupper($nom_dep);
		$abr_dep=strtoupper($abr_dep);

			$dep->setNom_dep($nom_dep);
			$dep->setAbr_dep($abr_dep);
			$dep->setRef_session($session);
		
			if ($dep->AddDep())
				{
				header('location: ../../menu_departements.php');
				}

				else  
			{
					echo "Erreur2";
				}
		}

		else  {
			echo "Erreur1";
		}
		
		
?>