<?php
require_once 'config.php';
session_start();
$msg = flash();
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Portail Licences INOFIB</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body { background: #0a0a0f; color: #fff; font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; min-height: 100vh; display: flex; flex-direction: column; }
        .hero { padding: 80px 0 42px; text-align: center; }
        .hero h1 { font-weight: 800; font-size: 2.5rem; }
        .hero p { color: #9aa0b5; max-width: 660px; margin: 12px auto 0; }
        .badge-inofib { background: rgba(255, 193, 7, 0.12); color: #ffc107; border: 1px solid rgba(255, 193, 7, 0.35); border-radius: 50rem; padding: 6px 16px; font-size: .78rem; letter-spacing: 1px; }
        .service-card { background: #1e1e2f; border: 1px solid #2d2d44; border-radius: 20px; padding: 28px; transition: .25s; height: 100%; display: flex; flex-direction: column; }
        .service-card:hover { transform: translateY(-6px); border-color: #ffc107; box-shadow: 0 18px 40px rgba(0,0,0,.45); }
        .service-icon { width: 60px; height: 60px; border-radius: 16px; background: rgba(255, 193, 7, .12); color: #ffc107; display: flex; align-items: center; justify-content: center; font-size: 24px; margin-bottom: 16px; }
        .service-card h5 { font-weight: 700; }
        .service-card small { color: #9aa0b5; }
        .prix-tag { color: #ffc107; font-weight: 800; }
        .tag-bientot { background: rgba(220,53,69,.14); color: #f66; border: 1px solid rgba(220,53,69,.4); border-radius: 50rem; padding: 4px 12px; font-size: .7rem; font-weight: 700; }
        .outil-link { color: #0d6efd; }
        .promo-strip { background: linear-gradient(90deg, #1a1a2e, #252547); border: 1px solid #2d2d44; border-radius: 16px; padding: 18px 22px; }
        .promo-strip .t { font-weight: 800; }
    </style>
</head>
<body>

<div class="container">
    <div class="hero">
        <span class="badge-inofib"><i class="fa-solid fa-shield-halved me-2"></i>Plateforme officielle</span>
        <h1 class="mt-3">Portail des Licences <span class="text-warning">INOFIB</span></h1>
        <p>Choix du service. L'acquisition ou le renouvellement de votre licence est instantane apres reglement via Assiin Pay, l'obtention de la cle se fait par email et directement en ligne.</p>
    </div>

    <?php if ($msg): ?>
    <div class="col-lg-6 mx-auto"><div class="alert alert-success small mb-4 text-center"><?= e($msg) ?></div></div>
    <?php endif; ?>

    <div class="row g-4 justify-content-center pb-4">
        <?php foreach (PRODUITS as $code => $info):
            $tarifs_prod = produit_tarifs($code);
            $prix_min = min(array_column($tarifs_prod, 'prix'));
            $prix_max = max(array_column($tarifs_prod, 'prix'));
        ?>
        <div class="col-md-6 col-lg-3">
            <div class="service-card">
                <div class="service-icon"><i class="<?= e($info['icone']) ?>"></i></div>
                <div class="d-flex justify-content-between align-items-center mb-2">
                    <h5 class="mb-0"><?= e($info['titre']) ?></h5>
                    <?php if (empty($info['dispo'])): ?><span class="tag-bientot">Bientot</span><?php endif; ?>
                </div>
                <small><?= e($info['desc']) ?></small>
                <div class="mt-auto pt-3">
                    <?php if (!empty($info['dispo'])): ?>
                        <div class="prix-tag" style="font-size:.85rem;"><?= hr($prix_min) ?> - <?= hr($prix_max) ?> XAF
                            <span class="text-white-50 d-block" style="font-weight:400;font-size:.72rem;"><?= e(LIBELLE_DUREE) ?></span>
                        </div>
                        <div class="d-flex gap-2 mt-2">
                            <a href="service.php?produit=<?= rawurlencode($code) ?>" class="btn btn-warning btn-sm rounded-pill px-3 text-dark fw-bold flex-grow-1">Acheter</a>
                            <a href="essai.php?produit=<?= rawurlencode($code) ?>" class="btn btn-outline-success btn-sm rounded-pill px-3 fw-bold" title="1 mois gratuit, non renouvelable">Essai 1 mois</a>
                        </div>
                    <?php else: ?>
                        <span class="text-white-50 small d-block">Disponible dans une prochaine version</span>
                        <span class="btn btn-outline-secondary btn-sm rounded-pill px-3 fw-bold mt-2 disabled">Bientot</span>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        <?php endforeach; ?>

        <!-- Outils : recuperation + renouvellement -->
        <div class="col-md-6 col-lg-3">
            <div class="service-card" style="border-color:rgba(13,110,253,.45);">
                <div class="service-icon" style="background:rgba(13,110,253,.15);color:#0d6efd;"><i class="fa-solid fa-key"></i></div>
                <h5>Cle perdue ou ordinateur change ?</h5>
                <small>Retrouvez votre licence deja payee en indiquant le nom de votre etablissement et votre email. Telechargement ou lien envoye par email, puis renouvellement sans perdre votre identifiant.</small>
                <div class="mt-auto pt-3 d-flex justify-content-between align-items-center">
                    <span class="prix-tag" style="font-size:.8rem;">Connexion nom + email</span>
                    <a href="recuperer_cle.php" class="btn btn-outline-primary btn-sm rounded-pill px-3 fw-bold">Recuperer ma cle</a>
                </div>
            </div>
        </div>

        <div class="col-md-6 col-lg-3">
            <div class="service-card" style="border-color:rgba(23,162,184,.45);">
                <div class="service-icon" style="background:rgba(23,162,184,.15);color:#17a2b8;"><i class="fa-solid fa-arrows-rotate"></i></div>
                <h5>Renouvellement</h5>
                <small>Renouvelez une licence arrivee a expiration : meme install_id, effectif actualisable (hausse du nombre d'eleves) et facturation au nouveau tarif.</small>
                <div class="mt-auto pt-3 d-flex justify-content-between align-items-center">
                    <span class="prix-tag" style="font-size:.78rem;"><?= DUREE_PAYEE_MOIS ?> mois factures<br><span class="text-white-50" style="font-weight:400;font-size:.7rem;">1er mois deja offert (essai)</span></span>
                    <a href="service.php?mode=renouvellement" class="btn btn-outline-info btn-sm rounded-pill px-3 fw-bold">Renouveler</a>
                </div>
            </div>
        </div>
    </div>

    <div class="promo-strip d-flex flex-wrap align-items-center justify-content-between gap-3 mt-2 mb-5">
        <div class="d-flex align-items-center gap-3">
            <i class="fa-solid fa-bullhorn fa-2x text-warning"></i>
            <div>
                <div class="t text-white">Bientot dans votre poche : RX-PHARMA et FINHELP</div>
                <div class="small text-white-50">Gestion de pharmacie (ventes/stock) et comptabilite professionnelle (type Sage). Les modules finance sont en cours de developpement - suivez les annonces INOFIB.</div>
            </div>
        </div>
        <a href="index.php" class="btn btn-outline-warning btn-sm rounded-pill fw-bold"><i class="fa-solid fa-envelope me-1"></i>Contact : <?= e(EMAIL_CONTACT) ?></a>
    </div>
</div>

<footer class="mt-auto py-4 text-center small text-muted border-top" style="border-color:#1c1c2e !important;">
    <i class="fa-solid fa-lock me-1 text-warning"></i> Transactions securisees Assiin Pay - Paiement sans confirmation manuelle. Contact : <?= e(EMAIL_CONTACT) ?>
</footer>

<script src="https://code.jquery.com/jquery-3.7.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>