<?php
require_once 'config.php';
require_once 'Model/connexion.php';
require_once 'classes/Etablissement.php';
require_once 'classes/Keys.php';

$type = $_GET['type'] ?? 'licence';
$token = trim($_GET['token'] ?? '');

$db = Base::connexion();
$etab = new Etablissement($db);

// Mode recuperation : lien de telechargement envoye par email (impossible à partager durablement)
if ($token !== '') {
    $tok = $etab->tokenValable($token);
    if (!$tok) {
        die("Lien de telechargement invalide ou expire. Refaites une demande sur la page 'Recuperer ma cle'.");
    }
    $etablissement = $etab->parId((int)$tok['etab_id']);
    if (!$etablissement) {
        die("Etablissement introuvable.");
    }
    $etab_id = (int)$etablissement['id'];
    $type = 'licence';
    $via_token = true;
} else {
    $etab_id = (int)($_GET['etab_id'] ?? 0);
    if ($etab_id === 0 || !($etablissement = $etab->parId($etab_id))) {
        die("Etablissement introuvable.");
    }
    $via_token = false;
}

$produit = $etablissement['produit'] ?? 'GESCO-APC';
$info = produit_info($produit);
$titre_produit = $info ? $info['titre'] : $produit;
$nom_asc = preg_replace('/[^A-Za-z0-9]+/', '_', $etablissement['nom_etab']);
$type_lic = $etab->derniereTypeLicence((int)$etablissement['id']);
$libelle_type_lic = $type_lic === 'essai'
    ? 'LICENCE D\'EVALUATION GRATUITE (' . DUREE_ESSAI_MOIS . ' mois, non renouvelable)'
    : 'LICENCE ANNUEL ' . $titre_produit . ' (' . DUREE_PAYEE_MOIS . ' mois factures + 1 mois offert = 12 mois)';

switch ($type) {
    case 'licence':
        if (empty($etablissement['licence_key'])) {
            die("Aucune licence generee pour cet etablissement. Rien a telecharger.");
        }
        if ($via_token) {
            $etab->consommerToken($token);
        }
        $nom_fichier = 'licence_' . $produit . '_' . $nom_asc . '.txt';
        header('Content-Type: text/plain; charset=utf-8');
        header('Content-Disposition: attachment; filename="' . $nom_fichier . '"');
        echo $etablissement['nom_etab'] . "\r\n";
        echo $libelle_type_lic . " - INOFIB\r\n\r\n";
        echo "Install ID     : " . $etablissement['install_id'] . "\r\n";
        echo "Annee scolaire : " . ($etablissement['annee_scolaire'] ?? '-') . "\r\n";
        echo "Tarif          : " . ($etablissement['tarif_code'] ?? '-') . "\r\n";
        echo "Du             : " . $etablissement['debut_licence'] . "\r\n";
        echo "Au             : " . $etablissement['fin_licence'] . "\r\n\r\n";
        echo "== CLE DE LICENCE (a installer dans le logiciel) ==\r\n\r\n";
        echo $etablissement['licence_key'] . "\r\n\r\n";
        echo "== CLE PUBLIQUE SERVEUR INOFIB (verification de la signature) ==\r\n\r\n";
        echo Keys::chargerPublique();
        break;

    case 'publique':
        header('Content-Type: application/x-pem-file');
        header('Content-Disposition: attachment; filename="inofib_cle_publique.pem"');
        echo Keys::chargerPublique();
        break;

    case 'etab_pub':
        if (empty($etablissement['cle_pub_etab'])) {
            die("Pas de cle publique pour cet etablissement.");
        }
        header('Content-Type: application/x-pem-file');
        header('Content-Disposition: attachment; filename="etablissement_' . (int)$etab_id . '_publique.pem"');
        echo $etablissement['cle_pub_etab'];
        break;

    case 'etab_priv':
        session_start();
        if (!isset($_SESSION['admin_id'])) {
            die("Acces reserve au super administrateur.");
        }
        if (empty($etablissement['cle_priv_etab'])) {
            die("Pas de cle privee pour cet etablissement.");
        }
        header('Content-Type: application/x-pem-file');
        header('Content-Disposition: attachment; filename="etablissement_' . (int)$etab_id . '_privee.pem"');
        echo $etablissement['cle_priv_etab'];
        break;

    default:
        die("Type de cle inconnu.");
}