<?php
// Alias de compatibilite : le lien d'activation GESCO-APC pointe vers ce fichier.
// On redirige vers le formulaire generique multi-produits.
$query = $_GET;
$query['produit'] = 'GESCO-APC';
header('Location: service.php?' . http_build_query($query));
exit;