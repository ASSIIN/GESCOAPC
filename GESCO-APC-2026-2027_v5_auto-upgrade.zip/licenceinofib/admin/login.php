<?php
require_once '../config.php';
require_once '../Model/connexion.php';
require_once '../classes/Auth.php';

$auth = new Auth(Base::connexion());
if ($auth->verifier()) {
    header('Location: index.php');
    exit;
}
$erreur = isset($_GET['err']);
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Connexion Super Admin - Licences INOFIB</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body { background: #0a0a0f; color: #fff; display: flex; align-items: center; justify-content: center; min-height: 100vh; font-family: 'Segoe UI', sans-serif; }
        .login-card { background: #1e1e2f; border: 1px solid #2d2d44; border-radius: 20px; padding: 36px; max-width: 400px; width: 100%; }
        .form-control { background: #151522; border-color: #2d2d44; color: #fff; }
        .form-control:focus { background: #151522; color: #fff; border-color: #ffc107; box-shadow: 0 0 0 .2rem rgba(255,193,7,.15); }
    </style>
</head>
<body>

<div class="login-card">
    <div class="text-center mb-4">
        <i class="fa-solid fa-user-shield fa-3x text-warning mb-3"></i>
        <h4 class="fw-bold">Espace Super Admin</h4>
        <p class="text-white-50 small">Consultation des cles privees et publiques des etablissements</p>
    </div>

    <?php if ($erreur): ?>
    <div class="alert alert-danger py-2 small">Identifiants incorrects.</div>
    <?php endif; ?>

    <form action="verif.php" method="POST">
        <div class="mb-3">
            <label class="form-label small fw-bold text-white-50">Identifiant</label>
            <input type="text" name="login" class="form-control" required autofocus placeholder="superadmin">
        </div>
        <div class="mb-4">
            <label class="form-label small fw-bold text-white-50">Mot de passe</label>
            <input type="password" name="password" class="form-control" required placeholder="••••••••">
        </div>
        <div class="d-grid">
            <button class="btn btn-warning rounded-pill fw-bold text-dark py-2">
                <i class="fa-solid fa-right-to-bracket me-2"></i>Se connecter
            </button>
        </div>
    </form>

    <div class="mt-3 text-center">
        <a href="../index.php" class="small text-white-50 text-decoration-none"><i class="fa-solid fa-arrow-left me-1"></i>Retour au portail</a>
    </div>
</div>

</body>
</html>