<?php
require_once '../config.php';
require_once '../Model/connexion.php';
require_once '../classes/Auth.php';
require_once '../classes/Etablissement.php';

$auth = new Auth(Base::connexion());
if (!$auth->verifier()) {
    header('Location: login.php');
    exit;
}

$db = Base::connexion();
$etab = new Etablissement($db);

$filtre_etab = (int)($_GET['etab_id'] ?? 0);
$filtre_produit = $_GET['produit'] ?? '';

if ($filtre_etab > 0) {
    $lignes = $etab->syncsDe($filtre_etab, 100);
} else {
    $sql = 'SELECT t.*, e.nom_etab, e.ville FROM telemetrie t JOIN etablissements e ON e.id = t.etab_id';
    $params = [];
    if ($filtre_produit !== '' && produit_info($filtre_produit)) {
        $sql .= ' WHERE t.produit = ?';
        $params[] = $filtre_produit;
    }
    $sql .= ' ORDER BY t.cree_le DESC LIMIT 200';
    $stmt = $db->prepare($sql);
    $stmt->execute($params);
    $lignes = $stmt->fetchAll();
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Telemetrie & sauvegardes - INOFIB</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body { background: #0a0a0f; color: #fff; font-family: 'Segoe UI', sans-serif; }
        .navbar-custom { background: #12121d; border-bottom: 1px solid #23233a; }
        .box { background: #1e1e2f; border: 1px solid #2d2d44; border-radius: 16px; padding: 20px; }
        .table-custom { --bs-table-bg: transparent; --bs-table-color: #e6e8f0; --bs-table-border-color: #2d2d44; }
        .table-custom thead th { color: #8b92ab; font-size: .72rem; text-transform: uppercase; }
        .badge-soft { padding: 5px 11px; border-radius: 50rem; font-size: .7rem; font-weight: 600; }
        .badge-produit { background: rgba(255,193,7,.12); color: #ffc107; border: 1px solid rgba(255,193,7,.35); border-radius: 50rem; padding: 2px 9px; font-size: .68rem; }
    </style>
</head>
<body>

<nav class="navbar navbar-custom">
    <div class="container">
        <a class="navbar-brand text-white fw-bold" href="index.php"><i class="fa-solid fa-arrow-left me-2 text-warning"></i>Super Admin</a>
        <span class="text-white-50 small">Telemetrie & sauvegardes automatiques</span>
    </div>
</nav>

<div class="container py-4">

    <div class="box mb-4">
        <div class="d-flex flex-wrap justify-content-between align-items-center gap-2">
            <div>
                <h5 class="fw-bold mb-1"><i class="fa-solid fa-database me-2 text-info"></i>Remontees periodiques</h5>
                <small class="text-white-50">Chaque client connecte a Internet pousse une archive periodique (effectifs, structure, donnees) utilisee pour restauration ou audit. Un effectif reel qui depasse la tranche payee est signale pour facturation au renouvellement.</small>
            </div>
            <form method="GET" class="d-flex gap-2">
                <input type="text" name="etab_id" class="form-control form-control-sm bg-dark text-white border-secondary" placeholder="ID etablissement" style="width:140px" value="<?= $filtre_etab ?: '' ?>">
                <select name="produit" class="form-select form-select-sm bg-dark text-white border-secondary" style="width:170px">
                    <option value="">Toutes produits</option>
                    <?php foreach (produits_achetables() as $code => $info): ?>
                    <option value="<?= e($code) ?>" <?= $filtre_produit === $code ? 'selected' : '' ?>><?= e($info['titre']) ?></option>
                    <?php endforeach; ?>
                </select>
                <button class="btn btn-sm btn-primary rounded-pill fw-bold">Filtrer</button>
            </form>
        </div>
    </div>

    <div class="box">
        <div class="table-responsive">
            <table class="table table-custom align-middle small mb-0">
                <thead><tr><th>Le</th><th>Produit</th><th>Etablissement</th><th>Version</th><th>Effectif</th><th>Depassement</th><th>Archive</th><th></th></tr></thead>
                <tbody>
                    <?php if (empty($lignes)): ?>
                    <tr><td colspan="8" class="text-center text-white-50 py-4">Aucune remontee. Les clients envoient leurs donnees lors d'une connexion Internet periodique.</td></tr>
                    <?php endif; ?>
                    <?php foreach ($lignes as $l): $dep = depassement_pct($l['nb_eleves'], $l['tarif_code'] ?? ''); ?>
                    <tr>
                        <td class="text-nowrap"><?= htmlspecialchars($l['cree_le']) ?></td>
                        <td><span class="badge-produit"><?= e(($i = produit_info($l['produit'])) ? $i['titre'] : $l['produit']) ?></span></td>
                        <td class="fw-bold text-white"><?= htmlspecialchars($l['nom_etab'] ?? '#' . $l['etab_id']) ?><div class="small text-white-50"><?= htmlspecialchars($l['ville'] ?? '') ?></div></td>
                        <td><?= htmlspecialchars($l['version_logiciel'] ?? '-') ?></td>
                        <td><?= (int)$l['nb_eleves'] ?> eleves</td>
                        <td>
                            <?php if ($dep > 0): ?>
                                <span class="badge-soft bg-danger-subtle text-danger border border-danger-subtle">+<?= $dep ?>%</span>
                            <?php else: ?>
                                <span class="badge-soft bg-success-subtle text-success border border-success-subtle">OK</span>
                            <?php endif; ?>
                        </td>
                        <td><?= !empty($l['payload']) ? 'oui' : 'non' ?></td>
                        <td class="text-end">
                            <?php if (!empty($l['payload'])): ?>
                            <a href="telecharger_sauvegarde.php?id=<?= (int)$l['id'] ?>" class="btn btn-sm btn-outline-info rounded-pill fw-bold"><i class="fa-solid fa-download me-1"></i>Sauvegarde</a>
                            <?php endif; ?>
                            <a href="etab.php?id=<?= (int)$l['etab_id'] ?>" class="btn btn-sm btn-outline-secondary rounded-pill fw-bold">Fiche</a>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>

</div>
</body>
</html>