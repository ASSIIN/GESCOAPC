<?php
require_once '../config.php';
require_once '../Model/connexion.php';
require_once '../classes/Auth.php';
require_once '../classes/Etablissement.php';

$auth = new Auth(Base::connexion());
if (!$auth->verifier()) {
    header('Location: login.php');
    exit;
}

$db = Base::connexion();
$etab = new Etablissement($db);

$id_tele = (int)($_GET['id'] ?? 0);
$row = $id_tele ? $etab->deriveTelemetrie($id_tele) : null;
if (!$row) {
    die('Remontee introuvable.');
}

$json = null;
if (!empty($row['payload'])) {
    $dec = base64_decode($row['payload']);
    if ($dec !== false) {
        $gz = @gzdecode($dec);
        if ($gz !== false) {
            $json = $gz;
        } else {
            $json = $dec;
        }
    }
}

if ($json === null) {
    die('Aucune archive exploitable pour cette remontee.');
}

$nom = preg_replace('/[^A-Za-z0-9]+/', '_', $row['nom_etab']);
$fichier = 'sauvegarde_' . ($row['produit'] ?? 'INOFIB') . '_' . $nom . '_' . date('Ymd_His', strtotime($row['cree_le'])) . '.json';

header('Content-Type: application/json; charset=utf-8');
header('Content-Disposition: attachment; filename="' . $fichier . '"');
header('Cache-Control: no-store');

$pretty = json_encode(json_decode($json), JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
echo $pretty === false ? $json : $pretty;