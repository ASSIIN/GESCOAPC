<?php
require_once '../config.php';
require_once '../Model/connexion.php';
require_once '../classes/Auth.php';

$login = trim($_POST['login'] ?? '');
$password = $_POST['password'] ?? '';

$auth = new Auth(Base::connexion());

if ($login !== '' && $password !== '' && $auth->connecter($login, $password)) {
    header('Location: index.php');
} else {
    header('Location: login.php?err=1');
}
exit;