<?php
require_once '../Model/connexion.php';
require_once '../classes/Auth.php';
require_once '../classes/Keys.php';

$auth = new Auth(Base::connexion());
if (!$auth->verifier()) {
    header('Location: login.php');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && Keys::generer()) {
    $_SESSION['flash'] = 'Paire de cles serveur regeneree avec succes.';
} else {
    $_SESSION['flash'] = 'Echec de la regeneration des cles.';
}
header('Location: index.php');
exit;