<?php
require_once '../config.php';
require_once '../Model/connexion.php';
require_once '../classes/Auth.php';
require_once '../classes/Etablissement.php';
require_once '../classes/Keys.php';

$auth = new Auth(Base::connexion());
if (!$auth->verifier()) {
    header('Location: login.php');
    exit;
}

$db = Base::connexion();
$etab = new Etablissement($db);

$produit_f = isset($_GET['produit']) ? $_GET['produit'] : '';
if ($produit_f !== '' && produit_info($produit_f)) {
    $etablissements = $etab->tousProduit($produit_f);
} else {
    $etablissements = $etab->tous();
    $produit_f = '';
}

// Dépassement effectif reel / tranche payee
$nb_depassements = 0;
$nb_sync = 0;
foreach ($etablissements as $row) {
    if (depassement_pct($row['nb_eleves_reel'] ?? 0, $row['tarif_code'] ?? '', $row['produit'] ?? 'GESCO-APC') > 0) {
        $nb_depassements++;
    }
    if (!empty($row['derniere_sync'])) {
        $nb_sync++;
    }
}

$stats = $db->query("SELECT
    (SELECT COUNT(*) FROM etablissements) AS total,
    (SELECT COUNT(*) FROM etablissements WHERE statut = 'actif') AS actifs,
    (SELECT COALESCE(SUM(montant),0) FROM commandes WHERE statut = 'payee') AS ca,
    (SELECT COUNT(*) FROM commandes WHERE statut = 'en_attente') AS en_attente
")->fetch();

$msg = flash();

$verification = false;
$licence_test = isset($_GET['verif']) ? trim($_GET['verif']) : '';
if ($licence_test !== '') {
    $verification = Keys::verifierLicence($licence_test);
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin - Licences INOFIB</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body { background: #0a0a0f; color: #fff; font-family: 'Segoe UI', sans-serif; }
        .navbar-custom { background: #12121d; border-bottom: 1px solid #23233a; }
        .stat-card { background: #1e1e2f; border: 1px solid #2d2d44; border-radius: 16px; padding: 20px; }
        .stat-card .num { font-size: 1.6rem; font-weight: 800; }
        .table-custom { --bs-table-bg: transparent; --bs-table-color: #e6e8f0; --bs-table-border-color: #2d2d44; }
        .table-custom thead th { color: #8b92ab; font-size: .72rem; text-transform: uppercase; letter-spacing: .5px; }
        .table-custom tbody tr:hover { background: #1a1a2e; }
        .badge-soft { padding: 6px 12px; border-radius: 50rem; font-size: .72rem; font-weight: 600; }
        .keys-panel { background: #151522; border: 1px solid #2d2d44; border-radius: 14px; padding: 16px; }
        .keys-panel pre { max-height: 200px; overflow: auto; white-space: pre-wrap; word-break: break-all; }
        .badge-produit { background: rgba(255,193,7,.12); color: #ffc107; border: 1px solid rgba(255,193,7,.35); border-radius: 50rem; padding: 2px 9px; font-size: .68rem; }
    </style>
</head>
<body>

<nav class="navbar navbar-expand-lg navbar-custom">
    <div class="container">
        <a class="navbar-brand text-white fw-bold" href="index.php"><i class="fa-solid fa-user-shield text-warning me-2"></i>Super Admin</a>
        <div class="ms-auto d-flex align-items-center gap-3">
            <a href="telemetrie.php" class="btn btn-outline-info btn-sm rounded-pill fw-bold"><i class="fa-solid fa-database me-1"></i>Telemetrie & sauvegardes</a>
            <span class="text-white-50 small"><i class="fa-solid fa-user me-1"></i><?= htmlspecialchars($auth->identite()) ?></span>
            <a href="logout.php" class="btn btn-outline-secondary btn-sm rounded-pill fw-bold">Deconnexion</a>
        </div>
    </div>
</nav>

<div class="container py-4">

    <?php if ($msg): ?>
    <div class="alert alert-success small"><?= htmlspecialchars($msg ?? '') ?></div>
    <?php endif; ?>

    <div class="row g-3 mb-4">
        <div class="col-6 col-lg-3"><div class="stat-card"><div class="text-white-50 small">Etablissements</div><div class="num text-white"><?= (int)$stats['total'] ?></div></div></div>
        <div class="col-6 col-lg-3"><div class="stat-card"><div class="text-white-50 small">Licences actives</div><div class="num text-success"><?= (int)$stats['actifs'] ?></div></div></div>
        <div class="col-6 col-lg-3"><div class="stat-card"><div class="text-white-50 small">Paiements en attente</div><div class="num text-warning"><?= (int)$stats['en_attente'] ?></div></div></div>
        <div class="col-6 col-lg-3"><div class="stat-card"><div class="text-white-50 small">Chiffre d'affaires</div><div class="num text-warning"><?= hr($stats['ca']) ?> XAF</div></div></div>
    </div>

    <div class="row g-3 mb-4">
        <div class="col-md-4"><div class="stat-card"><div class="text-white-50 small">Depassements d'effectif constates</div><div class="num <?= $nb_depassements ? 'text-danger' : 'text-white' ?>"><?= (int)$nb_depassements ?></div><div class="small text-white-50">effectif reel > tranche payee - a facturer au renouvellement</div></div></div>
        <div class="col-md-4"><div class="stat-card"><div class="text-white-50 small">Clients connectes (telemetrie)</div><div class="num text-info"><?= (int)$nb_sync ?> / <?= count($etablissements) ?></div><div class="small text-white-50">remontee automatique periodique</div></div></div>
        <div class="col-md-4">
            <div class="stat-card">
                <div class="text-white-50 small">Filtrer par produit</div>
                <form method="GET" class="mt-2">
                    <select name="produit" class="form-select form-select-sm bg-dark text-white border-secondary" onchange="this.form.submit()">
                        <option value="">Tous les produits</option>
                        <?php foreach (produits_achetables() as $code => $info): ?>
                        <option value="<?= e($code) ?>" <?= $produit_f === $code ? 'selected' : '' ?>><?= e($info['titre']) ?></option>
                        <?php endforeach; ?>
                    </select>
                </form>
            </div>
        </div>
    </div>

    <div class="d-flex flex-wrap justify-content-between align-items-center mb-3 gap-2">
        <h5 class="fw-bold mb-0"><i class="fa-solid fa-building-columns me-2 text-warning"></i>Etablissements et leurs cles</h5>
        <form action="generer_cles.php" method="POST" class="d-inline" onsubmit="return confirm('Regenerer la paire de cles serveur ? Les anciennes licences ne seront plus verifiables si la cle publique change.');">
            <button class="btn btn-outline-warning btn-sm rounded-pill fw-bold"><i class="fa-solid fa-rotate me-1"></i>Regenerer les cles serveur</button>
        </form>
    </div>

    <div class="table-responsive keys-panel mb-4">
        <table class="table table-custom align-middle mb-0">
            <thead>
                <tr><th>#</th><th>Produit</th><th>Etablissement</th><th>Install ID</th><th>Tarif / Effectif</th><th>Statut</th><th>Echeance</th><th>Dernier sync</th><th>Actions</th></tr>
            </thead>
            <tbody>
                <?php if (empty($etablissements)): ?>
                <tr><td colspan="9" class="text-center text-white-50 py-4">Aucun etablissement enregistre pour le moment.</td></tr>
                <?php endif; ?>
                <?php foreach ($etablissements as $row):
                    $exp = $row['fin_licence'] !== null && strtotime($row['fin_licence']) < time();
                    $dep = depassement_pct($row['nb_eleves_reel'] ?? 0, $row['tarif_code'] ?? '', $row['produit'] ?? 'GESCO-APC');
                    $type_lic = $etab->derniereTypeLicence((int)$row['id']);
                ?>
                <tr>
                    <td class="text-white-50"><?= (int)$row['id'] ?></td>
                    <td><span class="badge-produit"><?= e(($info_prod = produit_info($row['produit'] ?? 'GESCO-APC')) ? $info_prod['titre'] : $row['produit']) ?></span>
                        <?php if ($type_lic === 'essai'): ?><span class="badge bg-info-subtle text-info border border-info-subtle ms-1" title="Licence d'evaluation gratuite">ESSAI</span><?php endif; ?>
                    </td>
                    <td class="fw-bold text-white"><?= htmlspecialchars($row['nom_etab']) ?>
                        <?php if ($dep > 0): ?>
                            <span class="badge bg-danger-subtle text-danger border border-danger-subtle ms-1" title="Effectif reel depasse la tranche payee">+<?= $dep ?>%</span>
                        <?php endif; ?>
                        <div class="small text-white-50">
                            <?= htmlspecialchars($row['ville']) ?><?= !empty($row['abrege']) ? ' - ' . htmlspecialchars($row['abrege']) : '' ?><?= !empty($row['niu']) ? ' - NIU ' . htmlspecialchars($row['niu']) : '' ?><?= !empty($row['annee_scolaire']) ? ' - Session ' . htmlspecialchars($row['annee_scolaire']) : '' ?>
                        </div></td>
                    <td><code class="small text-white-50"><?= htmlspecialchars($row['install_id']) ?></code></td>
                    <td>
                        <?= $row['tarif_code'] ? htmlspecialchars(strtoupper($row['tarif_code'])) : '-' ?>
                        <div class="small text-white-50">declare : <?= (int)$row['nb_eleves'] ?><?= (int)($row['nb_eleves_reel'] ?? 0) > 0 ? ' / reel : ' . (int)$row['nb_eleves_reel'] : '' ?></div>
                    </td>
                    <td>
                        <?php if ($row['statut'] === 'actif'): ?>
                            <span class="badge badge-soft bg-success-subtle text-success border border-success-subtle"><?= $exp ? 'EXPIREE' : 'ACTIF' ?></span>
                        <?php else: ?>
                            <span class="badge badge-soft bg-warning-subtle text-warning border border-warning-subtle">EN ATTENTE</span>
                        <?php endif; ?>
                    </td>
                    <td class="small"><?= $row['fin_licence'] ? htmlspecialchars($row['fin_licence']) : '-' ?></td>
                    <td class="small"><?= $row['derniere_sync'] ? htmlspecialchars($row['derniere_sync']) : 'jamais' ?></td>
                    <td>
                        <a href="etab.php?id=<?= (int)$row['id'] ?>" class="btn btn-sm btn-warning rounded-pill fw-bold text-dark">
                            <i class="fa-solid fa-key me-1"></i>Cles
                        </a>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>

    <div class="row g-3">
        <div class="col-lg-7">
            <div class="keys-panel">
                <h6 class="fw-bold mb-2"><i class="fa-solid fa-address-card me-2 text-warning"></i>Cle publique serveur INOFIB</h6>
                <pre class="small text-white-50 mb-3"><?= htmlspecialchars(Keys::chargerPublique()) ?></pre>
                <a href="../telecharger_cle.php?type=publique" class="btn btn-sm btn-outline-secondary rounded-pill fw-bold"><i class="fa-solid fa-download me-1"></i>Telecharger la cle publique</a>
            </div>
        </div>
        <div class="col-lg-5">
            <div class="keys-panel">
                <h6 class="fw-bold mb-2"><i class="fa-solid fa-shield-halved me-2 text-warning"></i>Verification d'une licence</h6>
                <form method="GET" action="index.php">
                    <div class="input-group mb-2">
                        <input type="text" name="verif" class="form-control" placeholder="Collez une cle de licence..." value="<?= htmlspecialchars($licence_test) ?>">
                    </div>
                    <div class="d-grid">
                        <button class="btn btn-sm btn-outline-light rounded-pill fw-bold">Verifier la signature</button>
                    </div>
                </form>
                <?php if ($licence_test !== ''): ?>
                <div class="mt-3">
                    <?php if ($verification): ?>
                        <span class="badge bg-success-subtle text-success border border-success-subtle"><i class="fa-solid fa-check me-1"></i>Signature VALIDE</span>
                    <?php else: ?>
                        <span class="badge bg-danger-subtle text-danger border border-danger-subtle"><i class="fa-solid fa-xmark me-1"></i>Signature INVALIDE</span>
                    <?php endif; ?>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

</div>

</body>
</html>