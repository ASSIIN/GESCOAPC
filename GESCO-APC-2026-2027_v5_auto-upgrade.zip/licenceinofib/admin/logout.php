<?php
require_once '../Model/connexion.php';
require_once '../classes/Auth.php';

$auth = new Auth(Base::connexion());
$auth->deconnecter();
header('Location: login.php');
exit;