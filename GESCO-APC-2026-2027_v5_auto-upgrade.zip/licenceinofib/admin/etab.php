<?php
require_once '../config.php';
require_once '../Model/connexion.php';
require_once '../classes/Auth.php';
require_once '../classes/Etablissement.php';
require_once '../classes/Keys.php';

$auth = new Auth(Base::connexion());
if (!$auth->verifier()) {
    header('Location: login.php');
    exit;
}

$db = Base::connexion();
$etab = new Etablissement($db);
$id = (int)($_GET['id'] ?? 0);
$row = $id ? $etab->parId($id) : null;
if (!$row) {
    die("Etablissement introuvable.");
}

$historique = $etab->historiqueLicences($id);
$commandes = $etab->commandesDe($id);
$valide = !empty($row['licence_key']) && Keys::verifierLicence($row['licence_key']);
$info_prod = produit_info($row['produit'] ?? 'GESCO-APC');
$dep_effectif = depassement_pct($row['nb_eleves_reel'] ?? 0, $row['tarif_code'] ?? '', $row['produit'] ?? 'GESCO-APC');
$derniere_tele = $etab->derniereTelemetrie($id);
$type_lic = $etab->derniereTypeLicence($id);

// ------------------------------------------------------------
// Actions super admin : licence de secours, correction de nom,
// desactivation, suppression de l'historique ou de l'etablissement.
// ------------------------------------------------------------
$action = trim((string)($_POST['action'] ?? ''));
if ($action !== '') {
    if ($action === 'licence_secours') {
        $tarif = trim((string)($_POST['tarif_code'] ?? $row['tarif_code'] ?? 't1'));
        $tarifs = produit_tarifs($row['produit'] ?? 'GESCO-APC');
        if (!isset($tarifs[$tarif])) {
            $tarif = isset($tarifs[$row['tarif_code'] ?? '']) ? $row['tarif_code'] : 't1';
        }
        $montant = max(0, (int)($_POST['montant'] ?? 0));
        $motif = trim((string)($_POST['motif'] ?? 'secours'));
        $r = $etab->octroyerLicenceSecours($id, $tarif, $montant, $motif !== '' ? $motif : 'secours');
        if ($r && $r['cle']) {
            flash('Licence de secours générée (commande ' . $r['ref'] . '). Téléchargez le fichier .txt et transmettez-le à l\'établissement.');
        } else {
            flash('Échec de la génération de la licence de secours (voir paiement/log_paiement.txt).');
        }
    } elseif ($action === 'corriger_nom') {
        $nouveau_nom = trim((string)($_POST['nom_etab'] ?? ''));
        $clef = $etab->corrigerNomEtRegenerer($id, $nouveau_nom);
        if ($clef) {
            flash('Nom corrigé en « ' . $nouveau_nom . ' » et licence régénérée : téléchargez le nouveau fichier .txt (client : import du fichier, le nom sera mis à jour automatiquement).');
        } else {
            flash('Correction impossible : nom vide ou établissement introuvable.');
        }
    } elseif ($action === 'desactiver') {
        $etab->changerStatut($id, 'en_attente');
        flash('Licence désactivée : le client sera bloqué au prochain contrôle (licence expirée).');
    } elseif ($action === 'supprimer_historique') {
        $etab->supprimerToutHistorique($id);
        flash('Historique supprimé (licences, commandes, télémétrie, tokens) et licence locale effacée.');
    } elseif ($action === 'supprimer_etab') {
        $db->prepare('DELETE FROM recup_tokens WHERE etab_id = ?')->execute([$id]);
        $db->prepare('DELETE FROM telemetrie WHERE etab_id = ?')->execute([$id]);
        $db->prepare('DELETE FROM commandes WHERE etab_id = ?')->execute([$id]);
        $db->prepare('DELETE FROM licences WHERE etab_id = ?')->execute([$id]);
        $db->prepare('DELETE FROM etablissements WHERE id = ?')->execute([$id]);
        flash('Établissement #' . $id . ' supprimé.');
        header('Location: index.php');
        exit;
    }
    header('Location: etab.php?id=' . (int)$id . '#actions');
    exit;
}

$msg = flash();
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Etablissement #<?= (int)$id ?> - Licences INOFIB</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body { background: #0a0a0f; color: #fff; font-family: 'Segoe UI', sans-serif; }
        .navbar-custom { background: #12121d; border-bottom: 1px solid #23233a; }
        .box { background: #1e1e2f; border: 1px solid #2d2d44; border-radius: 16px; padding: 20px; }
        .box pre { background: #151522; border: 1px solid #2d2d44; border-radius: 10px; padding: 12px; max-height: 220px; overflow: auto; white-space: pre-wrap; word-break: break-all; font-size: .72rem; }
        .table-custom { --bs-table-bg: transparent; --bs-table-color: #e6e8f0; --bs-table-border-color: #2d2d44; }
        .table-custom thead th { color: #8b92ab; font-size: .73rem; text-transform: uppercase; }
    </style>
</head>
<body>

<nav class="navbar navbar-custom">
    <div class="container">
        <a class="navbar-brand text-white fw-bold" href="index.php"><i class="fa-solid fa-arrow-left me-2 text-warning"></i>Super Admin</a>
        <span class="text-white-50 small"><?= htmlspecialchars($auth->identite()) ?></span>
    </div>
</nav>

<div class="container py-4">

    <?php if ($msg): ?>
    <div class="alert alert-success small"><?= htmlspecialchars($msg) ?></div>
    <?php endif; ?>

    <div class="d-flex flex-wrap justify-content-between align-items-center mb-4 gap-2">
        <div>
            <h4 class="fw-bold mb-0"><?= htmlspecialchars($row['nom_etab']) ?>
                <?php if ($info_prod): ?><span class="badge badge-soft bg-warning-subtle text-warning border border-warning-subtle ms-2"><?= e($info_prod['titre']) ?></span><?php endif; ?>
                <?php if ($type_lic === 'essai'): ?><span class="badge bg-info-subtle text-info border border-info-subtle ms-2">ESSAI GRATUIT</span><?php endif; ?>
            </h4>
            <span class="text-white-50 small">Install ID : <code><?= htmlspecialchars($row['install_id']) ?></code>
                <?php if (!empty($row['abrege']) || !empty($row['niu']) || !empty($row['annee_scolaire'])): ?>
                <span class="ms-2">·</span> <span class="ms-1"><?= $row['abrege'] ? 'Abrév. : ' . htmlspecialchars($row['abrege']) : '' ?><?= $row['abrege'] && ($row['niu'] || $row['annee_scolaire']) ? ' · ' : '' ?><?= $row['niu'] ? 'NIU : ' . htmlspecialchars($row['niu']) : '' ?><?= $row['niu'] && $row['annee_scolaire'] ? ' · ' : '' ?><?= $row['annee_scolaire'] ? 'Session ' . htmlspecialchars($row['annee_scolaire']) : '' ?></span>
                <?php endif; ?>
                <?php if ($row['statut'] === 'actif'): ?>
                    <span class="badge bg-success-subtle text-success border border-success-subtle ms-2"><?= $valide ? 'LICENCE VALIDE' : 'LICENCE INVALIDE' ?></span>
                <?php else: ?>
                    <span class="badge bg-warning-subtle text-warning border border-warning-subtle ms-2">EN ATTENTE DE PAIEMENT</span>
                <?php endif; ?>
            </span>
        </div>
        <div class="d-flex gap-2">
            <a href="../telecharger_cle.php?etab_id=<?= (int)$id ?>&type=licence" class="btn btn-warning btn-sm rounded-pill fw-bold text-dark"><i class="fa-solid fa-download me-1"></i>Cle de licence</a>
            <a href="../telecharger_cle.php?etab_id=<?= (int)$id ?>&type=etab_pub" class="btn btn-outline-secondary btn-sm rounded-pill fw-bold"><i class="fa-solid fa-download me-1"></i>Cle publique etab</a>
            <a href="../telecharger_cle.php?etab_id=<?= (int)$id ?>&type=etab_priv" class="btn btn-outline-danger btn-sm rounded-pill fw-bold"><i class="fa-solid fa-download me-1"></i>Cle privee etab</a>
        </div>
    </div>

    <div class="row g-3 mb-4">
        <div class="col-md-2"><div class="box"><div class="text-white-50 small">Effectif declare</div><div class="fw-bold fs-5"><?= (int)$row['nb_eleves'] ?> eleves</div></div></div>
        <div class="col-md-2"><div class="box"><div class="text-white-50 small">Effectif reel (tele)</div><div class="fw-bold fs-5 <?= $dep_effectif > 0 ? 'text-danger' : '' ?>"><?= (int)($row['nb_eleves_reel'] ?? 0) ?> eleves</div></div></div>
        <div class="col-md-2"><div class="box"><div class="text-white-50 small">Depassement</div><div class="fw-bold fs-5 <?= $dep_effectif > 0 ? 'text-danger' : 'text-white' ?>"><?= $dep_effectif > 0 ? '+' . $dep_effectif . '%' : 'aucun' ?></div></div></div>
        <div class="col-md-2"><div class="box"><div class="text-white-50 small">Tarif</div><div class="fw-bold fs-5 text-warning"><?= $row['tarif_code'] ? htmlspecialchars(strtoupper($row['tarif_code'])) : '-' ?></div></div></div>
        <div class="col-md-2"><div class="box"><div class="text-white-50 small">Periode</div><div class="fw-bold fs-6"><?= $row['debut_licence'] ? htmlspecialchars($row['debut_licence']) : '-' ?><span class="text-white-50"> → </span><?= $row['fin_licence'] ? htmlspecialchars($row['fin_licence']) : '-' ?></div></div></div>
        <div class="col-md-2"><div class="box"><div class="text-white-50 small">Contact / version</div><div class="fw-bold fs-6"><?= htmlspecialchars($row['email']) ?><div class="small text-white-50"><?= htmlspecialchars($row['telephone']) ?><?= $row['version_logiciel'] ? ' - v' . htmlspecialchars($row['version_logiciel']) : '' ?></div></div></div></div>
    </div>

    <?php $tarifs = produit_tarifs($row['produit'] ?? 'GESCO-APC'); ?>
    <div class="box mb-4" id="actions">
        <h6 class="fw-bold mb-3"><i class="fa-solid fa-user-shield me-2 text-warning"></i>Actions super admin <span class="text-white-50 small fw-normal">(passerelle en panne, paiement manuel, nom mal saisi)</span></h6>
        <div class="row g-3">
            <div class="col-lg-4">
                <form method="POST" class="p-3 rounded" style="background:#151522; border:1px solid #2d2d44;">
                    <p class="fw-bold small mb-2">Générer une licence de <span class="text-warning">secours</span></p>
                    <div class="mb-2">
                        <select name="tarif_code" class="form-select form-select-sm bg-dark text-white border-secondary">
                            <?php foreach ($tarifs as $code => $cfg): ?>
                            <option value="<?= e($code) ?>" <?= ($row['tarif_code'] ?? '') === $code ? 'selected' : '' ?>><?= htmlspecialchars($cfg['libelle']) ?> — <?= hr($cfg['prix']) ?> XAF</option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="mb-2">
                        <input type="number" name="montant" class="form-control form-control-sm bg-dark text-white border-secondary" min="0" value="<?= (int)($tarifs[$row['tarif_code'] ?? 't1']['prix'] ?? 0) ?>" placeholder="Montant (XAF)">
                    </div>
                    <input type="hidden" name="action" value="licence_secours">
                    <button class="btn btn-warning btn-sm w-100 rounded-pill fw-bold text-dark"><i class="fa-solid fa-key me-1"></i>Générer et marquer payée</button>
                </form>
            </div>
            <div class="col-lg-4">
                <form method="POST" class="p-3 rounded" style="background:#151522; border:1px solid #2d2d44;">
                    <p class="fw-bold small mb-2">Corriger le <span class="text-warning">nom</span> (mal saisi)</p>
                    <div class="mb-2">
                        <input type="text" name="nom_etab" class="form-control form-control-sm bg-dark text-white border-secondary" value="<?= htmlspecialchars($row['nom_etab']) ?>" maxlength="120" required>
                    </div>
                    <input type="hidden" name="action" value="corriger_nom">
                    <button class="btn btn-secondary btn-sm w-100 rounded-pill fw-bold" onclick="return confirm('Le nom sera corrigé et une licence régénérée avec le nouveau nom. Continuer ?');"><i class="fa-solid fa-pen me-1"></i>Corriger + régénérer</button>
                </form>
            </div>
            <div class="col-lg-4">
                <p class="fw-bold small mb-2">Désactiver / supprimer</p>
                <div class="d-grid gap-2 p-3 rounded" style="background:#151522; border:1px solid #2d2d44;">
                    <form method="POST" onsubmit="return confirm('Désactiver cette licence ? Le client sera bloqué.');">
                        <input type="hidden" name="action" value="desactiver">
                        <button class="btn btn-outline-light btn-sm w-100 rounded-pill fw-bold"><i class="fa-solid fa-circle-minus me-1"></i>Désactiver la licence</button>
                    </form>
                    <form method="POST" onsubmit="return confirm('Supprimer l'historique (licences, commandes, télémétrie) et vider la clé locale ?');">
                        <input type="hidden" name="action" value="supprimer_historique">
                        <button class="btn btn-outline-warning btn-sm w-100 rounded-pill fw-bold"><i class="fa-solid fa-trash me-1"></i>Supprimer historique + clé</button>
                    </form>
                    <form method="POST" onsubmit="return confirm('SUPPRIMER DÉFINITIVEMENT cet établissement et toutes ses données ?');">
                        <input type="hidden" name="action" value="supprimer_etab">
                        <button class="btn btn-outline-danger btn-sm w-100 rounded-pill fw-bold"><i class="fa-solid fa-skull me-1"></i>Supprimer l'établissement</button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <?php if ($derniere_tele): ?>
    <div class="box mb-4">
        <h6 class="fw-bold mb-2"><i class="fa-solid fa-database me-2 text-info"></i>Derniere sauvegarde / telemetrie</h6>
        <div class="d-flex flex-wrap gap-4 align-items-center">
            <div class="small text-white-50">Le <b class="text-white"><?= htmlspecialchars($derniere_tele['cree_le']) ?></b> - effectif constate <b class="text-info"><?= (int)$derniere_tele['nb_eleves'] ?></b> eleves
                <?php if ((int)$derniere_tele['depassement']): ?><span class="badge bg-danger-subtle text-danger border border-danger-subtle ms-1">dépassement +<?= depassement_pct($derniere_tele['nb_eleves'], $row['tarif_code']) ?>%</span><?php endif; ?>
            </div>
            <a href="telemetrie.php?etab_id=<?= (int)$id ?>" class="btn btn-sm btn-outline-info rounded-pill fw-bold"><i class="fa-solid fa-history me-1"></i>Historique des syncs</a>
        </div>
    </div>
    <?php endif; ?>

    <div class="row g-3 mb-4">
        <div class="col-lg-6">
            <div class="box">
                <h6 class="fw-bold mb-2"><i class="fa-solid fa-lock me-2 text-warning"></i>Cle de licence (privee)</h6>
                <?php if ($row['licence_key']): ?>
                    <pre><?= htmlspecialchars($row['licence_key']) ?></pre>
                <?php else: ?>
                    <p class="text-white-50 small mb-0">Aucune licence generee. En attente du paiement.</p>
                <?php endif; ?>
            </div>
        </div>
        <div class="col-lg-6">
            <div class="box mb-3">
                <h6 class="fw-bold mb-2"><i class="fa-solid fa-key me-2 text-primary"></i>Cle publique designee par l'etablissement</h6>
                <?php if ($row['cle_pub_etab']): ?>
                    <pre><?= htmlspecialchars($row['cle_pub_etab']) ?></pre>
                <?php else: ?>
                    <p class="text-white-50 small mb-0">Non generee.</p>
                <?php endif; ?>
            </div>
            <div class="box">
                <h6 class="fw-bold mb-2"><i class="fa-solid fa-eye-slash me-2 text-danger"></i>Cle privee de l'etablissement</h6>
                <?php if ($row['cle_priv_etab']): ?>
                    <pre><?= htmlspecialchars($row['cle_priv_etab']) ?></pre>
                <?php else: ?>
                    <p class="text-white-50 small mb-0">Non generee.</p>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <div class="row g-3">
        <div class="col-lg-6">
            <div class="box">
                <h6 class="fw-bold mb-3"><i class="fa-solid fa-clock-rotate-left me-2 text-warning"></i>Historique des licences</h6>
                <div class="table-responsive">
                    <table class="table table-custom align-middle small mb-0">
                        <thead><tr><th>Date</th><th>Type</th><th>Tarif</th><th>Montant</th><th>Du</th><th>Au</th><th>Statut</th></tr></thead>
                        <tbody>
                            <?php foreach ($historique as $h): ?>
                            <tr>
                                <td><?= htmlspecialchars($h['cree_le']) ?></td>
                                <td>
                                    <?php if (($h['type'] ?? 'payee') === 'essai'): ?>
                                        <span class="badge bg-info-subtle text-info border border-info-subtle">ESSAI (gratuit)</span>
                                    <?php else: ?>
                                        <span class="badge bg-success-subtle text-success border border-success-subtle">ABONNEMENT</span>
                                    <?php endif; ?>
                                </td>
                                <td><?= htmlspecialchars(strtoupper($h['tarif_code'])) ?></td>
                                <td><?= hr($h['montant']) ?> XAF</td>
                                <td><?= htmlspecialchars($h['debut']) ?></td>
                                <td><?= htmlspecialchars($h['fin']) ?></td>
                                <td><span class="badge bg-success-subtle text-success border border-success-subtle"><?= htmlspecialchars($h['statut']) ?></span></td>
                            </tr>
                            <?php endforeach; ?>
                            <?php if (empty($historique)): ?><tr><td colspan="7" class="text-center text-white-50 py-3">Aucune licence</td></tr><?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        <div class="col-lg-6">
            <div class="box">
                <h6 class="fw-bold mb-3"><i class="fa-solid fa-receipt me-2 text-warning"></i>Commandes de paiement</h6>
                <div class="table-responsive">
                    <table class="table table-custom align-middle small mb-0">
                        <thead><tr><th>Ref</th><th>Tarif</th><th>Montant</th><th>Statut</th><th>Le</th></tr></thead>
                        <tbody>
                            <?php foreach ($commandes as $c): ?>
                            <tr>
                                <td><code class="small text-white-50"><?= htmlspecialchars($c['ref_commande']) ?></code></td>
                                <td><?= htmlspecialchars(strtoupper($c['tarif_code'])) ?></td>
                                <td><?= hr($c['montant']) ?> XAF</td>
                                <td>
                                    <?php if ($c['statut'] === 'payee'): ?>
                                        <span class="badge bg-success-subtle text-success border border-success-subtle">PAYEE</span>
                                    <?php else: ?>
                                        <span class="badge bg-warning-subtle text-warning border border-warning-subtle">EN ATTENTE</span>
                                    <?php endif; ?>
                                </td>
                                <td><?= htmlspecialchars($c['paye_le'] ?? $c['cree_le']) ?></td>
                            </tr>
                            <?php endforeach; ?>
                            <?php if (empty($commandes)): ?><tr><td colspan="5" class="text-center text-white-50 py-3">Aucune commande</td></tr><?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

</div>

</body>
</html>