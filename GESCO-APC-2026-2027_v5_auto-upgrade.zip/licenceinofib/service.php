<?php
require_once 'config.php';

$produit = strtoupper(trim($_GET['produit'] ?? 'GESCO-APC'));
$info = produit_info($produit);
if (!$info) {
    header('Location: index.php');
    exit;
}
$tarifs = produit_tarifs($produit);
$mode = isset($_GET['mode']) && $_GET['mode'] === 'renouvellement' ? 'renouvellement' : 'achat';

// Annee scolaire visee : courante (achat) ou suivante (renouvellement), ajustable par l'utilisateur
$annees_dispo = annees_scolaires_disponibles(2);
$annee_defaut = $mode === 'renouvellement' ? ($annees_dispo[1]['code'] ?? $annees_dispo[0]['code']) : $annees_dispo[0]['code'];
$annee_scolaire = trim($_GET['annee_scolaire'] ?? '');
if ($annee_scolaire === '' || !annee_scolaire_bornes($annee_scolaire)) {
    $annee_scolaire = $annee_defaut;
}

// Pré-remplissage (lien d'activation du logiciel client / page de récupération)
$pre = [
    'nom_etab' => trim($_GET['nom_etab'] ?? ''),
    'abrege'   => trim($_GET['abrege'] ?? ''),
    'ville'    => trim($_GET['ville'] ?? ''),
    'email'    => trim($_GET['email'] ?? ''),
    'telephone'=> trim($_GET['telephone'] ?? ''),
    'niu'      => trim($_GET['niu'] ?? ''),
    'install_id' => trim(($_GET['install_id'] ?? '') !== '' ? $_GET['install_id'] : ($_GET['iid'] ?? '')),
    'nb_eleves'  => isset($_GET['nb_eleves']) ? (int)$_GET['nb_eleves'] : 0,
];

$err_msg = [
    'champs'  => 'Veuillez remplir tous les champs obligatoires.',
    'install' => 'Identifiant d\'installation invalide (lettres, chiffres, tirets).',
    'produit' => 'Ce produit n\'est pas encore disponible.',
    'tarif'   => 'Tarif inconnu.',
];
$err = isset($_GET['err']) ? ($err_msg[$_GET['err']] ?? null) : null;

$libelle_produit = $info['titre'];
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Licence <?= e($libelle_produit) ?> - <?= $mode === 'achat' ? 'Achat' : 'Renouvellement' ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body { background: #0a0a0f; color: #fff; font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; padding-bottom: 60px; }
        .topbar { padding: 24px 0; }
        .form-card { background: #1e1e2f; border: 1px solid #2d2d44; border-radius: 22px; padding: 34px; }
        .form-control, .form-select { background: #151522; border-color: #2d2d44; color: #fff; }
        .form-control:focus, .form-select:focus { background: #151522; color: #fff; border-color: #ffc107; box-shadow: 0 0 0 .2rem rgba(255,193,7,.15); }
        .form-label { color: #b9bfd4; font-size: .85rem; font-weight: 600; }
        .tarif-box { background: #151522; border: 1px solid #2d2d44; border-radius: 14px; padding: 14px 18px; }
        .tarif-box .choix { color: #9aa0b5; font-size: .8rem; }
        .tarif-box .montant { color: #ffc107; font-weight: 800; font-size: 1.05rem; }
        .recap { background: rgba(255,193,7,.08); border: 1px solid rgba(255,193,7,.4); border-radius: 16px; padding: 18px; }
        .recap .total { font-size: 1.7rem; font-weight: 800; color: #ffc107; }
        .badge-produit { background: rgba(255,193,7,.12); color: #ffc107; border: 1px solid rgba(255,193,7,.35); border-radius: 50rem; padding: 4px 12px; font-size: .72rem; }
    </style>
</head>
<body>

<div class="container">
    <div class="topbar d-flex justify-content-between align-items-center">
        <a href="index.php" class="text-white-50 text-decoration-none"><i class="fa-solid fa-arrow-left me-2"></i>Retour</a>
        <span class="text-white-50 small"><i class="fa-solid fa-shield-halved me-1 text-warning"></i>Assiin Pay</span>
    </div>

    <div class="row justify-content-center">
        <div class="col-lg-7">
            <div class="form-card">
                <?php if ($err): ?>
                <div class="alert alert-danger py-2 small"><?= e($err) ?></div>
                <?php endif; ?>

                <h3 class="fw-bold mb-1"><i class="<?= e($info['icone']) ?> me-2 text-warning"></i>Licence <?= e($libelle_produit) ?></h3>
                <p class="text-white-50 small mb-4">Licence annuelle de 12 mois (1er mois gratuit + <?= DUREE_PAYEE_MOIS ?> mois factures). <?= $mode === 'achat' ? 'Premiere acquisition' : 'Renouvellement de licence' ?> - le tarif est calcule automatiquement selon l'effectif eleves.</p>

                <form action="trait_commande.php" method="POST">
                    <input type="hidden" name="mode" value="<?= $mode ?>">
                    <input type="hidden" name="produit" value="<?= e($produit) ?>">

                    <div class="row g-3 mb-4">
                        <div class="col-md-12">
                            <label class="form-label">Année scolaire de la licence *</label>
                            <select name="annee_scolaire" class="form-select" required>
                                <?php foreach ($annees_dispo as $a): ?>
                                <option value="<?= e($a['code']) ?>" <?= $a['code'] === $annee_scolaire ? 'selected' : '' ?>>
                                    <?= e($a['libelle']) ?> (du <?= e($a['debut']) ?> au <?= e($a['fin']) ?>)
                                </option>
                                <?php endforeach; ?>
                            </select>
                            <div class="form-text text-white-50">La licence couvre toujours une année scolaire complète (septembre - août). Le 1er mois est offert (essai) : vous ne payez que <?= DUREE_PAYEE_MOIS ?> mois.</div>
                        </div>
                        <div class="col-md-12">
                            <label class="form-label">Nom de l'etablissement *</label>
                            <input type="text" name="nom_etab" class="form-control" required placeholder="Ex : Lycee Bilingue de Yaounde" value="<?= e($pre['nom_etab']) ?>">
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Abreviation (optionnel)</label>
                            <input type="text" name="abrege" class="form-control" maxlength="80" placeholder="Ex : LB-YDE" value="<?= e($pre['abrege']) ?>">
                            <div class="form-text" style="color:#6b7280;">Permet de distinguer les etablissements portant le meme nom.</div>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">NIU / matricule (optionnel)</label>
                            <input type="text" name="niu" class="form-control" maxlength="40" placeholder="Ex : M02#####" value="<?= e($pre['niu']) ?>">
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Ville</label>
                            <input type="text" name="ville" class="form-control" placeholder="Yaounde, Douala, ..." value="<?= e($pre['ville']) ?>">
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Telephone</label>
                            <input type="tel" name="telephone" class="form-control" placeholder="6XX XX XX XX" value="<?= e($pre['telephone']) ?>">
                        </div>
                        <div class="col-md-12">
                            <label class="form-label">Email de reception de la licence *</label>
                            <input type="email" name="email" class="form-control" required placeholder="direction@ecole.cm" value="<?= e($pre['email']) ?>">
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Identifiant d'installation (install_id) *</label>
                            <input type="text" name="install_id" class="form-control" required placeholder="UUID genere par l'application" value="<?= e($pre['install_id']) ?>">
                            <div class="form-text" style="color:#6b7280;">Se trouve dans le logiciel (ecran d'activation). Conservez-le pour le renouvellement.</div>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Effectif total eleves *</label>
                            <input type="number" name="nb_eleves" id="nb_eleves" class="form-control" min="1" required placeholder="Ex : 350" value="<?= $pre['nb_eleves'] > 0 ? $pre['nb_eleves'] : '' ?>">
                        </div>
                    </div>

                    <div class="d-flex flex-column gap-2 mb-4">
                        <?php foreach ($tarifs as $code => $t): ?>
                        <div class="tarif-box d-flex justify-content-between align-items-center">
                            <div>
                                <div class="choix"><?= $t['max'] === null ? 'Plus de ' . $t['min'] . ' eleves' : $t['min'] . ' a ' . $t['max'] . ' eleves' ?></div>
                                <div class="choix">Licence annuelle</div>
                            </div>
                            <div class="montant"><?= hr($t['prix']) ?> XAF</div>
                        </div>
                        <?php endforeach; ?>
                    </div>

                    <div class="recap d-flex align-items-center justify-content-between mb-4">
                        <div>
                            <span class="text-white-50 small d-block">Tarif applique</span>
                            <strong id="tarif_libelle" class="text-white">Saisissez l'effectif</strong>
                        </div>
                        <div class="text-end">
                            <span class="text-white-50 small d-block">Total a payer</span>
                            <span class="total" id="total_prix">--</span>
                        </div>
                    </div>

                    <button type="submit" class="btn btn-warning btn-lg w-100 rounded-pill py-3 text-dark fw-bold">
                        <i class="fa-solid fa-shield-halved me-2"></i>Proceder au paiement securise
                    </button>
                </form>
            </div>
        </div>
    </div>
</div>

<script src="https://code.jquery.com/jquery-3.7.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
$(function () {
    var TARIF = <?= json_encode(array_map(fn($t) => ['libelle' => $t['libelle'], 'prix' => $t['prix'], 'min' => $t['min'], 'max' => $t['max']], $tarifs), JSON_UNESCAPED_UNICODE) ?>;
    function calc(nb) {
        if (!nb || nb < 1) { $('#tarif_libelle').text('Saisissez l\'effectif'); $('#total_prix').text('--'); return; }
        var code = 't5';
        for (var k in TARIF) {
            if (TARIF[k].max === null) { code = k; break; }
            if (nb <= TARIF[k].max) { code = k; break; }
        }
        var cfg = TARIF[code];
        $('#tarif_libelle').text(cfg.libelle);
        $('#total_prix').text(cfg.prix.toLocaleString('fr-FR').replace(/\u202f|,/g, ' ') + ' XAF');
    }
    $('#nb_eleves').on('input', function () { calc(parseInt(this.value, 10)); });
    calc(<?= $pre['nb_eleves'] ?>);
});
</script>
</body>
</html>