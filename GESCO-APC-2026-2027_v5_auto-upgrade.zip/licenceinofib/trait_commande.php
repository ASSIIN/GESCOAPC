<?php
require_once 'config.php';
require_once 'Model/connexion.php';
require_once 'classes/Etablissement.php';

$produit     = strtoupper(trim($_POST['produit'] ?? ''));
$mode        = ($_POST['mode'] ?? '') === 'renouvellement' ? 'renouvellement' : 'achat';
$nom_etab    = trim($_POST['nom_etab'] ?? '');
$abrege      = trim($_POST['abrege'] ?? '');
$ville       = trim($_POST['ville'] ?? '');
$email       = trim($_POST['email'] ?? '');
$telephone   = trim($_POST['telephone'] ?? '');
$niu         = trim($_POST['niu'] ?? '');
$install_id  = trim($_POST['install_id'] ?? '');
$nb_eleves   = (int)($_POST['nb_eleves'] ?? 0);
$annee_scolaire = trim($_POST['annee_scolaire'] ?? '');

function trait_redirect_erreur($produit, $err)
{
    header('Location: service.php?produit=' . rawurlencode($produit) . '&err=' . rawurlencode($err));
    exit;
}

if (!produit_info($produit) || empty(produit_info($produit)['dispo'])) {
    trait_redirect_erreur('GESCO-APC', 'produit');
}
if ($nom_etab === '' || $email === '' || $install_id === '' || $nb_eleves < 1) {
    trait_redirect_erreur($produit, 'champs');
}
if (strlen($install_id) > 64 || !preg_match('/^[A-Za-z0-9\-_]+$/', $install_id)) {
    trait_redirect_erreur($produit, 'install');
}
if ($annee_scolaire === '' || !annee_scolaire_bornes($annee_scolaire)) {
    trait_redirect_erreur($produit, 'annee');
}

$tarif_code = tarif_pour_effectif($nb_eleves, $produit);
$tarifs = produit_tarifs($produit);
$montant = $tarifs[$tarif_code]['prix'];

$db = Base::connexion();
$etab = new Etablissement($db);
$etab_id = $etab->inscrireOuMAJ([
    'nom_etab'   => $nom_etab,
    'abrege'     => $abrege !== '' ? $abrege : null,
    'ville'      => $ville,
    'email'      => $email,
    'telephone'  => $telephone,
    'niu'        => $niu !== '' ? $niu : null,
    'install_id' => $install_id,
    'nb_eleves'  => $nb_eleves,
    'tarif_code' => $tarif_code,
    'produit'    => $produit,
    'annee_scolaire' => $annee_scolaire,
]);

$commande = $etab->creerCommande($etab_id, $tarif_code, $montant, $produit, $annee_scolaire);

header('Location: paiement/index.php?ref=' . rawurlencode($commande['ref'])
    . '&etab_id=' . $etab_id
    . '&tarif=' . $tarif_code
    . '&montant=' . $montant
    . '&produit=' . rawurlencode($produit));
exit;