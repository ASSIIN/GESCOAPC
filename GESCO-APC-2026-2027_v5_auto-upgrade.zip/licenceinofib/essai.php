<?php
require_once 'config.php';
require_once 'Model/connexion.php';
require_once 'classes/Etablissement.php';
require_once 'classes/Mailer.php';

session_start();

$produit = strtoupper(trim($_GET['produit'] ?? 'GESCO-APC'));
$info = produit_info($produit);
if (!$info || empty($info['dispo'])) {
    header('Location: index.php');
    exit;
}

$db = Base::connexion();
$etab = new Etablissement($db);

// Annee scolaire ciblee par l'essai (courante par defaut)
$annees_dispo = annees_scolaires_disponibles(2);
$annee_scolaire = trim($_GET['annee_scolaire'] ?? '');
if ($annee_scolaire === '' || !annee_scolaire_bornes($annee_scolaire)) {
    $annee_scolaire = $annees_dispo[0]['code'];
}

// Pré-remplissage (lien d'activation du logiciel client)
$pre = [
    'nom_etab' => trim($_GET['nom_etab'] ?? ''),
    'abrege' => trim($_GET['abrege'] ?? ''),
    'ville' => trim($_GET['ville'] ?? ''),
    'email' => trim($_GET['email'] ?? ''),
    'telephone' => trim($_GET['telephone'] ?? ''),
    'niu' => trim($_GET['niu'] ?? ''),
    'install_id' => ($_GET['install_id'] ?? '') !== '' ? trim($_GET['install_id']) : trim($_GET['iid'] ?? ''),
    'nb_eleves' => isset($_GET['nb_eleves']) ? (int)$_GET['nb_eleves'] : 0,
];

$cle_generee = null;
$row_essai = null;
$erreur = null;
$email_essai_ok = null;

// ------------------------------------------------------------
// CREATION DE LA LICENCE D'ESSAI GRATUITE
// ------------------------------------------------------------
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'cree') {
    $nom = trim($_POST['nom_etab'] ?? '');
    $abrege = trim($_POST['abrege'] ?? '');
    $ville = trim($_POST['ville'] ?? '');
    $telephone = trim($_POST['telephone'] ?? '');
    $niu = trim($_POST['niu'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $iid = trim($_POST['install_id'] ?? '');
    $nb = max(1, (int)($_POST['nb_eleves'] ?? 1));
    $annee_scolaire = trim($_POST['annee_scolaire'] ?? '');
    if (!annee_scolaire_bornes($annee_scolaire)) {
        $annee_scolaire = $annees_dispo[0]['code'];
    }

    if ($nom === '' || $email === '' || $iid === '') {
        $erreur = 'Nom de l\'établissement, email et identifiant d\'installation sont obligatoires.';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $erreur = 'Adresse email invalide.';
    } else {
        // Essai unique : bloquer si l'installation ou l'etablissement a deja un dossier.
        // L'essai gratuit (1 mois) est NON renouvelable ; le paiement reprend l'historique.
        $exist = $etab->parInstallId($iid);
        $trouve = $etab->trouverParIdentifiants($nom, $email, $abrege !== '' ? $abrege : null, $niu !== '' ? $niu : null);
        if ($exist || $trouve) {
            $erreur = 'Un dossier existe déjà pour cette installation ou cet établissement. L\'essai gratuit de 1 mois est unique et non renouvelable : pour continuer, abonnez-vous (vous ne payez que ' . DUREE_PAYEE_MOIS . ' mois, le 1er mois étant déjà offert) ou contactez ' . e(EMAIL_CONTACT) . '.';
        } else {
            $tarif_code = tarif_pour_effectif($nb, $produit);
            $etab_id = $etab->inscrireOuMAJ([
                'nom_etab' => $nom,
                'abrege' => $abrege !== '' ? $abrege : null,
                'ville' => $ville,
                'email' => $email,
                'telephone' => $telephone,
                'niu' => $niu !== '' ? $niu : null,
                'install_id' => $iid,
                'nb_eleves' => $nb,
                'tarif_code' => $tarif_code,
                'produit' => $produit,
                'annee_scolaire' => $annee_scolaire,
            ]);
            $cle = $etab->creerEssai($etab_id, $produit);
            if ($cle) {
                $cle_generee = $cle;
                $row_essai = $etab->parId($etab_id);
                $lien = url_portail('/telecharger_cle.php?etab_id=' . (int)$etab_id . '&type=licence');
                $corps = '<html><body style="font-family:Arial;color:#222">'
                    . '<h2 style="color:#19784f">Bonjour ' . htmlspecialchars($nom) . ',</h2>'
                    . '<p>Votre <b>licence d\'évaluation gratuite</b> pour <b>' . htmlspecialchars($info['titre'] ?? $produit) . '</b> est prête.</p>'
                    . '<p>Elle expire le <b>' . date('d/m/Y', strtotime($row_essai['fin_licence'])) . '</b>.</p>'
                    . '<p style="text-align:center"><a href="' . htmlspecialchars($lien) . '" style="background:#19784f;color:#fff;padding:10px 22px;border-radius:6px;text-decoration:none">Télécharger ma clé d\'essai</a></p>'
                    . '<p>Identifiant d\'installation à saisir à l\'écran d\'activation : <b>' . htmlspecialchars($iid) . '</b></p>'
                    . '<p>À l\'expiration, abonnez-vous : vous payez uniquement ' . DUREE_PAYEE_MOIS . ' mois (1 an au total), même si vous ne vous abonnez que dans quelques mois.</p>'
                    . '<hr><p style="color:#888;font-size:12px">INOFIB - Contact : ' . htmlspecialchars(EMAIL_CONTACT) . '</p></body></html>';
                $email_essai_ok = Mailer::envoyer($email, 'Votre licence d\'essai gratuit ' . ($info['titre'] ?? $produit) . ' INOFIB', $corps);
            } else {
                $erreur = 'La clé d\'essai n\'a pas pu être générée. Contactez ' . e(EMAIL_CONTACT) . '.';
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Essai gratuit 1 mois - INOFIB</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body { background: #0a0a0f; color: #fff; font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; padding-bottom: 60px; }
        .topbar { padding: 24px 0; }
        .card-dark { background: #1e1e2f; border: 1px solid #2d2d44; border-radius: 20px; padding: 28px; }
        .form-control, .form-select { background: #151522; border-color: #2d2d44; color: #fff; }
        .form-control:focus { background: #151522; color: #fff; border-color: #19784f; box-shadow: 0 0 0 .2rem rgba(25,120,79,.15); }
        .form-label { color: #b9bfd4; font-size: .85rem; font-weight: 600; }
        .form-text { color: #7a8199; }
        .install-mono { font-family: Consolas, monospace; letter-spacing: 1px; color: #6ea8fe; font-size: .83rem; word-break: break-all; }
        .cle-mono { font-family: Consolas, monospace; font-size: .78rem; color: #ffd77a; background: #262616; border: 1px dashed #8a7a2a; border-radius: 8px; padding: 10px 14px; word-break: break-all; }
        .badge-produit { background: rgba(255,193,7,.12); color: #ffc107; border: 1px solid rgba(255,193,7,.35); border-radius: 50rem; padding: 3px 10px; font-size: .7rem; }
    </style>
</head>
<body>

<div class="container">
    <div class="topbar d-flex justify-content-between align-items-center">
        <a href="index.php" class="text-white-50 text-decoration-none"><i class="fa-solid fa-arrow-left me-2"></i>Retour</a>
        <span class="text-white-50 small"><i class="fa-solid fa-shield-halved me-1 text-warning"></i>INOFIB</span>
    </div>

    <div class="row justify-content-center">
        <div class="col-lg-7">

            <?php if ($cle_generee): ?>
            <div class="card-dark mb-4">
                <h3 class="fw-bold mb-1 text-success"><i class="fa-solid fa-circle-check me-2"></i>Votre licence d'évaluation est prête !</h3>
                <p class="text-white-50 small mb-3">
                    <span class="badge-produit"><?= e($info['titre']) ?></span>
                    <span class="badge-produit">Année scolaire <?= e($row_essai['annee_scolaire'] ?? '') ?></span>
                    Essai gratuit de <b><?= DUREE_ESSAI_MOIS ?> mois</b>, du <?= e($row_essai['debut_licence']) ?> au <b><?= e($row_essai['fin_licence']) ?></b>, même sans connexion internet.
                    <?php if ($email_essai_ok): ?><span class="d-block mt-1"><i class="fa-solid fa-envelope me-1 text-info"></i>Le lien de téléchargement a aussi été envoyé à <?= e($row_essai['email']) ?>.</span><?php endif; ?>
                </p>

                <label class="form-label">Identifiant d'installation (à conserver)</label>
                <div class="install-mono mb-3"><?= e($row_essai['install_id']) ?></div>

                <label class="form-label">Votre clé d'essai (copiez-la ou téléchargez-la)</label>
                <div class="cle-mono mb-3"><?= e($cle_generee) ?></div>

                <div class="d-flex flex-wrap gap-2 mb-3">
                    <a href="telecharger_cle.php?etab_id=<?= (int)$row_essai['id'] ?>&type=licence" class="btn btn-warning rounded-pill fw-bold text-dark px-4"><i class="fa-solid fa-download me-1"></i>Télécharger la clé</a>
                    <a href="index.php" class="btn btn-outline-light rounded-pill px-4">Plus tard</a>
                </div>

                <div class="small text-white-50 p-3 rounded" style="background:#15301f;border:1px solid #1e452c;">
                    <b><i class="fa-solid fa-gift me-1 text-success"></i>L'essai est unique et non renouvelable.</b><br>
                    Après expiration, abonnez-vous depuis la page d'accueil : vous ne payez que <b><?= DUREE_PAYEE_MOIS ?> mois</b> (<?= e(LIBELLE_DUREE) ?>), quel que soit le moment de l'année. Votre effectif élèves détermine le tarif et tous vos réglages sont conservés.
                </div>
            </div>

            <?php else: ?>
            <div class="card-dark mb-4">
                <h3 class="fw-bold mb-1"><i class="fa-solid fa-gift me-2 text-success"></i>Essai gratuit <?= DUREE_ESSAI_MOIS ?> mois</h3>
                <p class="text-white-50 small mb-3">
                    <span class="badge-produit"><?= e($info['titre']) ?></span>
                    Testez <?= e($info['titre']) ?> pendant <b>1 mois entier, gratuitement</b>, avec toutes les fonctions. À l'expiration, abonnez-vous : vous ne payez que <?= DUREE_PAYEE_MOIS ?> mois (soit 1 an au total). L'essai est <b>unique et non renouvelable</b>.
                </p>

                <?php if ($erreur): ?>
                <div class="alert alert-warning py-2 small"><?= e($erreur) ?></div>
                <?php endif; ?>

                <form method="POST" class="row g-3">
                    <input type="hidden" name="action" value="cree">
                    <div class="col-md-12">
                        <label class="form-label">Année scolaire de l'essai *</label>
                        <select name="annee_scolaire" class="form-select" required>
                            <?php foreach ($annees_dispo as $a): ?>
                            <option value="<?= e($a['code']) ?>" <?= $a['code'] === $annee_scolaire ? 'selected' : '' ?>>
                                <?= e($a['libelle']) ?> (du <?= e($a['debut']) ?> au <?= e($a['fin']) ?>)
                            </option>
                            <?php endforeach; ?>
                        </select>
                        <div class="form-text">L'essai s'arrête au plus tard à la fin de cette année scolaire, même sans connexion internet.</div>
                    </div>
                    <div class="col-md-12">
                        <label class="form-label">Nom de l'établissement *</label>
                        <input type="text" name="nom_etab" class="form-control" required placeholder="Ex : Lycee Bilingue de Yaounde" value="<?= e($pre['nom_etab']) ?>">
                    </div>
                    <div class="col-md-6">
                        <label class="form-label">Abréviation (optionnel)</label>
                        <input type="text" name="abrege" class="form-control" maxlength="80" placeholder="Ex : LB-YDE" value="<?= e($pre['abrege']) ?>">
                    </div>
                    <div class="col-md-6">
                        <label class="form-label">NIU / matricule (optionnel)</label>
                        <input type="text" name="niu" class="form-control" maxlength="40" placeholder="Ex : M02#####" value="<?= e($pre['niu']) ?>">
                    </div>
                    <div class="col-md-6">
                        <label class="form-label">Ville</label>
                        <input type="text" name="ville" class="form-control" placeholder="Yaounde, Douala, ..." value="<?= e($pre['ville']) ?>">
                    </div>
                    <div class="col-md-6">
                        <label class="form-label">Téléphone</label>
                        <input type="tel" name="telephone" class="form-control" placeholder="6XX XX XX XX" value="<?= e($pre['telephone']) ?>">
                    </div>
                    <div class="col-md-12">
                        <label class="form-label">Email *</label>
                        <input type="email" name="email" class="form-control" required placeholder="direction@ecole.cm" value="<?= e($pre['email']) ?>">
                    </div>
                    <div class="col-md-6">
                        <label class="form-label">Identifiant d'installation (install_id) *</label>
                        <input type="text" name="install_id" class="form-control" required placeholder="UUID généré par l'application" value="<?= e($pre['install_id']) ?>">
                        <div class="form-text">Se trouve dans le logiciel (écran d'activation). Conservez-le : c'est lui qui rend l'essai unique.</div>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label">Effectif total élèves *</label>
                        <input type="number" name="nb_eleves" class="form-control" min="1" required placeholder="Ex : 120" value="<?= $pre['nb_eleves'] > 0 ? $pre['nb_eleves'] : '' ?>">
                        <div class="form-text">Détermine le tarif de votre futur abonnement (tranche par effectif).</div>
                    </div>
                    <div class="col-12 mt-2">
                        <button class="btn btn-success w-100 rounded-pill fw-bold py-2"><i class="fa-solid fa-gift me-2"></i>Générer ma clé d'essai gratuite</button>
                        <div class="text-center small text-white-50 mt-2">Gratuit. Non renouvelable. Aucun paiement, aucune carte.</div>
                    </div>
                </form>
            </div>
            <?php endif; ?>

            <div class="small text-white-50">
                <i class="fa-solid fa-lock me-1 text-warning"></i> Une fois la clé d'essai activée, vous utilisez le logiciel exactement comme en version payante. Aucune carte bancaire n'est demandée.
            </div>
        </div>
    </div>
</div>

</body>
</html>