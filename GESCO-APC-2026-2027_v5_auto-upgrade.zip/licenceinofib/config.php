<?php
// Identifiants de base de donnees PAR VARIABLES D'ENVIRONNEMENT.
// Production : renseignez INOFIB_DB_* dans public_html/.htaccess (SetEnv)
// ou via le gestionnaire de variables d'environnement de cPanel.
// Aucun secret en dur dans ce fichier (ni mot de passe, ni identifiant).
//
// Exemple .htaccess (a renseigner SUR LE SERVEUR, hors git) :
//   SetEnv INOFIB_DB_HOST "localhost"
//   SetEnv INOFIB_DB_NAME "nom_base"
//   SetEnv INOFIB_DB_USER "utilisateur"
//   SetEnv INOFIB_DB_PASS "motdepasse"
define('DB_HOST', getenv('INOFIB_DB_HOST') ?: 'localhost');
define('DB_NAME', getenv('INOFIB_DB_NAME') ?: 'licenceinofib');
define('DB_USER', getenv('INOFIB_DB_USER') ?: 'root');
define('DB_PASS', getenv('INOFIB_DB_PASS') ?: '');

define('APP_URL', '/licenceinofib');
define('APP_NAME', 'Licences INOFIB');
define('EMAIL_CONTACT', 'contact@licences.inofib.com');

// Expediteur utilise par PHP mail() pour l'envoi des liens de recuperation
define('MAIL_FROM', 'Licences INOFIB <contact@licences.inofib.com>');
// Duree de validite (heures) d'un lien de telechargement de licence
define('RECUP_TOKEN_VALIDITE_H', 48);
// Intervalle minimal (jours) entre deux remontees telemetriques d'un client
define('TELEMETRIE_INTERVAL_JOURS', 6);

// Licence d'evaluation gratuite : 1 mois, non renouvelable gratuitement
define('DUREE_ESSAI_MOIS', 1);
// A l'abonnement, 1 mois a deja ete offert (l'essai) => on facture 11 mois.
// Une licence represente toujours 12 mois = annee scolaire (septembre - aout),
// meme si le client laisse passer des mois avant de s'abonner.
define('DUREE_PAYEE_MOIS', 11);
// Duree totale affichee (grille tarifaire) : 12 mois
define('DUREE_LICENCE_MOIS', 12);
define('KEYS_DIR', __DIR__ . '/keys');

// ------------------------------------------------------------------
// Catalogue des produits INOFIB
//   dispo = true  => achat de licence actif
//   dispo = false => logiciel en cours de developpement (publicite)
// ------------------------------------------------------------------
define('PRODUITS', [
    'GESCO-APC' => [
        'titre' => 'GESCO-APC',
        'type'  => 'Gestion scolaire',
        'desc'  => 'Application de gestion scolaire (secondaire) : effectifs, notes, bulletins, absences.',
        'icone' => 'fa-solid fa-school',
        'dispo' => true,
        'promo' => false,
    ],
    'NDALERE-PRIM' => [
        'titre' => 'NDALERE-PRIM',
        'type'  => 'Gestion scolaire primaire',
        'desc'  => 'Application de gestion des ecoles primaires : eleves, classes, notes et annuaire.',
        'icone' => 'fa-solid fa-graduation-cap',
        'dispo' => true,
        'promo' => false,
    ],
    'RX-PHARMA' => [
        'titre' => 'RX-PHARMA',
        'type'  => 'Pharmacie',
        'desc'  => 'Gestion des ventes et du stock d\'une pharmacie. Module finance en cours de developpement.',
        'icone' => 'fa-solid fa-pills',
        'dispo' => false,
        'promo' => true,
    ],
    'FINHELP' => [
        'titre' => 'FINHELP',
        'type'  => 'Comptabilite',
        'desc'  => 'Logiciel de gestion comptable (type Sage Saari). Modules finance en cours de developpement.',
        'icone' => 'fa-solid fa-chart-pie',
        'dispo' => false,
        'promo' => true,
    ],
]);

// ------------------------------------------------------------------
// Grille tarifaire PAR PRODUIT (effectif = nb d'eleves)
// Une licence couvre une ANNEES SCOLAIRE (12 mois : septembre - aout).
// Tranches pour les grandes structures : 300 / 700 / 1500 / 2000 eleves,
// avec un PLAFOND de 500 000 XAF par annee scolaire.
//   GESCO-APC    : minimum 50 000 XAF (secondaire)
//   NDALERE-PRIM : minimum 35 000 XAF (ecoles primaires)
// Les prix sont facilement modifiables ici.
// ------------------------------------------------------------------
define('PLAFOND_TARIF_XAF', 500000);

define('TARIFS_PAR_PRODUIT', [
    'GESCO-APC' => [
        't1' => ['libelle' => 'Licence annuelle (1 a 300 eleves)',      'prix' => 50000,  'min' => 1,    'max' => 300],
        't2' => ['libelle' => 'Licence annuelle (301 a 700 eleves)',    'prix' => 100000, 'min' => 301,  'max' => 700],
        't3' => ['libelle' => 'Licence annuelle (701 a 1500 eleves)',   'prix' => 200000, 'min' => 701,  'max' => 1500],
        't4' => ['libelle' => 'Licence annuelle (1501 a 2000 eleves)',  'prix' => 350000, 'min' => 1501, 'max' => 2000],
        't5' => ['libelle' => 'Licence annuelle (plus de 2000 eleves)', 'prix' => 500000, 'min' => 2001, 'max' => null],
    ],
    'NDALERE-PRIM' => [
        't1' => ['libelle' => 'Licence annuelle (1 a 300 eleves)',      'prix' => 35000,  'min' => 1,    'max' => 300],
        't2' => ['libelle' => 'Licence annuelle (301 a 700 eleves)',    'prix' => 70000,  'min' => 301,  'max' => 700],
        't3' => ['libelle' => 'Licence annuelle (701 a 1500 eleves)',   'prix' => 140000, 'min' => 701,  'max' => 1500],
        't4' => ['libelle' => 'Licence annuelle (1501 a 2000 eleves)',  'prix' => 250000, 'min' => 1501, 'max' => 2000],
        't5' => ['libelle' => 'Licence annuelle (plus de 2000 eleves)', 'prix' => 500000, 'min' => 2001, 'max' => null],
    ],
]);

// Duree facturable affichee pour un abonnement (voir DUREE_PAYEE_MOIS)
define('LIBELLE_DUREE', '1 mois gratuit + ' . DUREE_PAYEE_MOIS . ' mois = 12 mois (annee scolaire)');

// ------------------------------------------------------------------
// ANNEES SCOLAIRES : une licence couvre toujours une annee scolaire
// (septembre - aout). Format court interne : "26_27" (= 2026/2027).
// Format canonique (signe dans la cle) : "2026_2027".
// ------------------------------------------------------------------

// "26_27" -> ['an1'=>2026,'an2'=>2027] ; gere aussi "2026/2027", "2026_2027", "26-27"
function annee_scolaire_annees($code)
{
    $code = trim((string)$code);
    if (preg_match('/^(\d{2})[_\/-](\d{2})$/', $code, $m)) {
        return [(int)('20' . $m[1]), (int)('20' . $m[2])];
    }
    if (preg_match('/^(\d{4})[_\/-](\d{4})$/', $code, $m)) {
        return [(int)$m[1], (int)$m[2]];
    }
    if (preg_match('/^(\d{6})$/u', $code, $m)) { // 20262027 / 2627
        $y = substr($m[1], 0, 4);
        $z = substr($m[1], 4);
        $z = strlen($z) === 2 ? '20' . $z : $z;
        return [(int)$y, (int)$z];
    }
    return null;
}

// Code court "26_27" a partir de deux annees
function annee_scolaire_code($an1, $an2)
{
    return substr((string)$an1, 2) . '_' . substr((string)$an2, 2);
}

// Bornes [01/09 an1, 31/08 an2] + libelle + code canonique signe
function annee_scolaire_bornes($code)
{
    $a = annee_scolaire_annees($code);
    if (!$a) {
        return null;
    }
    list($an1, $an2) = $a;
    return [
        'code' => annee_scolaire_code($an1, $an2),
        'canon' => $an1 . '_' . $an2,
        'libelle' => $an1 . '/' . $an2,
        'debut' => sprintf('%04d-09-01', $an1),
        'fin' => sprintf('%04d-08-31', $an2),
    ];
}

// Annee scolaire en cours (selon la date du serveur)
function annee_scolaire_courante()
{
    $y = (int)date('Y');
    $an1 = (int)date('m') >= 9 ? $y : $y - 1;
    return annee_scolaire_code($an1, $an1 + 1);
}

// Liste des annees scolaires proposables (courante + suivantes)
function annees_scolaires_disponibles($nb = 2)
{
    $liste = [];
    $courante = annee_scolaire_courante();
    $a = annee_scolaire_annees($courante);
    for ($i = 0; $i < $nb; $i++) {
        $an1 = $a[0] + $i;
        $liste[] = annee_scolaire_bornes(annee_scolaire_code($an1, $an1 + 1));
    }
    return $liste;
}

function produit_info($code)
{
    $code = (string)$code;
    return isset(PRODUITS[$code]) ? PRODUITS[$code] : null;
}

function produits_achetables()
{
    return array_filter(PRODUITS, fn($p) => !empty($p['dispo']));
}

// Grille tarifaire d'un produit (fallback GESCO-APC)
function produit_tarifs($produit)
{
    $p = (string)$produit;
    return isset(TARIFS_PAR_PRODUIT[$p]) ? TARIFS_PAR_PRODUIT[$p] : TARIFS_PAR_PRODUIT['GESCO-APC'];
}

function tarif_pour_effectif($nb_eleves, $produit = 'GESCO-APC') {
    $nb = (int)$nb_eleves;
    foreach (produit_tarifs($produit) as $code => $cfg) {
        if ($nb >= $cfg['min'] && ($cfg['max'] === null || $nb <= $cfg['max'])) {
            return $code;
        }
    }
    return 't5';
}

// Limite superieure d'effectif autorisee pour un code tarifaire (null = illimite)
function tarif_limite($code, $produit = 'GESCO-APC')
{
    $tarifs = produit_tarifs($produit);
    return isset($tarifs[$code]) && $tarifs[$code]['max'] !== null ? (int)$tarifs[$code]['max'] : null;
}

// Pourcentage de depassement de l'effectif reel par rapport a la tranche payee
function depassement_pct($nb_eleves_reel, $code_tarif, $produit = 'GESCO-APC')
{
    $limite = tarif_limite($code_tarif, $produit);
    if ($limite === null) {
        return 0.0;
    }
    $reel = (int)$nb_eleves_reel;
    if ($reel <= $limite) {
        return 0.0;
    }
    return round(($reel - $limite) / $limite * 100, 1);
}

function hr($prix) {
    return number_format((int)$prix, 0, ',', ' ');
}

function e($v) {
    return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8');
}

function flash($msg = null) {
    if ($msg !== null) {
        $_SESSION['flash'] = $msg;
        return;
    }
    if (isset($_SESSION['flash'])) {
        $m = $_SESSION['flash'];
        unset($_SESSION['flash']);
        return $m;
    }
    return null;
}

// URL absolue du portail (pour les liens envoyes par email), deduite du serveur
function url_portail($suffix = '')
{
    $host = isset($_SERVER['HTTP_HOST']) ? $_SERVER['HTTP_HOST'] : 'licences.inofib.com';
    $scheme = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
    $path = $_SERVER['SCRIPT_NAME'] ?? '';
    foreach (['/paiement/', '/admin/', '/api/'] as $seg) {
        $path = str_replace($seg, '/', $path);
    }
    $base = rtrim(dirname($path), '/');
    if ($base === '' || $base === '/') {
        $base = '/licenceinofib';
    }
    return $scheme . '://' . $host . $base . $suffix;
}