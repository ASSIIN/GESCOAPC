<?php
/**
 * api/telemetrie.php
 * Reception des remontees automatiques des logiciels clients INOFIB :
 *   - archive/sauvegarde periodique des donnees (restauration ou audit)
 *   - controle de l'effectif reel par rapport a la tranche payee (facturation au renouvellement)
 * Authentification : la licence signee elle-meme, passee en en-tete Authorization: Bearer <cle>.
 */
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../Model/connexion.php';
require_once __DIR__ . '/../classes/Etablissement.php';
require_once __DIR__ . '/../classes/Keys.php';

function reponse_json($data, $code = 200)
{
    http_response_code($code);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($data, JSON_UNESCAPED_UNICODE);
    exit;
}

if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') {
    reponse_json(['ok' => false, 'erreur' => 'methode_invalide'], 405);
}

$auth = $_SERVER['HTTP_AUTHORIZATION'] ?? '';
if (preg_match('/^Bearer\s+(.+)$/i', $auth, $m)) {
    $cle_licence = trim($m[1]);
} else {
    reponse_json(['ok' => false, 'erreur' => 'authentification_requise'], 401);
}

$payload_json = null;
if (!Keys::verifierLicence($cle_licence, $payload_json)) {
    reponse_json(['ok' => false, 'erreur' => 'licence_invalide'], 401);
}
$donnees_licence = json_decode($payload_json, true);
if (!is_array($donnees_licence) || empty($donnees_licence['iid'])) {
    reponse_json(['ok' => false, 'erreur' => 'licence_illisible'], 400);
}

$raw = file_get_contents('php://input');
$corps = json_decode($raw ?: '{}', true);
if (!is_array($corps)) {
    reponse_json(['ok' => false, 'erreur' => 'corps_invalide'], 400);
}

$db = Base::connexion();
$etab = new Etablissement($db);
$etablissement = $etab->parInstallId($donnees_licence['iid']);

if (!$etablissement) {
    reponse_json(['ok' => false, 'erreur' => 'etablissement_inconnu'], 404);
}
if (($donnees_licence['produit'] ?? '') !== ($etablissement['produit'] ?? '')) {
    reponse_json(['ok' => false, 'erreur' => 'produit_incoherent'], 400);
}

$resultat = $etab->telemetrieEnregistrer([
    'install_id' => $etablissement['install_id'],
    'version'    => isset($corps['version']) ? substr((string)$corps['version'], 0, 120) : null,
    'nb_eleves'  => max(0, (int)($corps['nb_eleves'] ?? 0)),
    'par_niveau' => isset($corps['par_niveau']) && is_array($corps['par_niveau']) ? $corps['par_niveau'] : null,
    'sauvegarde' => isset($corps['sauvegarde']) ? substr((string)$corps['sauvegarde'], 0, 4000000) : null,
]);

if (!$resultat) {
    reponse_json(['ok' => false, 'erreur' => 'enregistrement_impossible'], 500);
}

reponse_json([
    'ok' => true,
    'etab_id' => $resultat['etab_id'],
    'produit' => $etablissement['produit'],
    'nb_eleves' => $resultat['nb_eleves'],
    'tarif' => $resultat['tarif'],
    'depassement' => $resultat['depassement'],
    'depassement_pct' => $resultat['depassement_pct'],
    'fin_licence' => $resultat['fin_licence'],
    'statut_licence' => $resultat['fin_licence'] !== null && strtotime($resultat['fin_licence']) >= time() ? 'actif' : 'expire',
    'message' => 'Donnees enregistrees. Merci.',
]);