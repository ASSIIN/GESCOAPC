<?php
require_once __DIR__ . '/../Model/connexion.php';

class Database
{
    public function getConnection()
    {
        return Base::connexion();
    }
}