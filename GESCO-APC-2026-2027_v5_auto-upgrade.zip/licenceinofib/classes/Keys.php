<?php
require_once __DIR__ . '/../config.php';

class Keys
{
    private static function cheminCnf($p)
    {
        return str_replace('\\', '/', $p);
    }

    private static function cliDispo()
    {
        if (stripos(PHP_OS, 'WIN') === 0) {
            $candidats = glob('C:/laragon/bin/apache/*/bin/openssl.exe');
            if (is_array($candidats)) {
                $candidats = array_merge($candidats, [
                    'C:/laragon/bin/git/mingw64/bin/openssl.exe',
                    'C:/laragon/bin/git/usr/bin/openssl.exe',
                ]);
            } else {
                $candidats = [];
            }
            foreach ($candidats as $c) {
                if (is_file($c)) {
                    return $c;
                }
            }
            @exec('where openssl 2>NUL', $out, $code);
            if ((int)$code === 0 && !empty($out) && is_file(trim($out[0]))) {
                return trim($out[0]);
            }
            return null;
        }

        @exec('command -v openssl 2>/dev/null', $out, $code);
        if ((int)$code === 0 && !empty($out)) {
            return trim($out[0]);
        }
        return null;
    }

    private static function genererViaCli($fichier_prive)
    {
        $cli = self::cliDispo();
        if ($cli === null) {
            return false;
        }
        $redirect = stripos(PHP_OS, 'WIN') === 0 ? ' 2>NUL' : ' 2>/dev/null';
        $cmd = '"' . $cli . '" genrsa -out "' . self::cheminCnf($fichier_prive) . '" 2048' . $redirect;
        exec($cmd, $out, $code);
        if ((int)$code !== 0 || !file_exists($fichier_prive)) {
            return false;
        }
        $res = openssl_pkey_get_private(file_get_contents($fichier_prive));
        return $res !== false;
    }

    public static function generer($dossier = null)
    {
        $dossier = $dossier ?: KEYS_DIR;
        if (!is_dir($dossier)) {
            mkdir($dossier, 0755, true);
        }
        $prive = $dossier . '/private.pem';
        if (!self::genererViaCli($prive) || !is_writable($dossier)) {
            return false;
        }
        $res = openssl_pkey_get_private(file_get_contents($prive));
        $details = openssl_pkey_get_details($res);
        file_put_contents($dossier . '/public.pem', $details['key'], LOCK_EX);
        return true;
    }

    public static function chargerPrive()
    {
        $fichier = KEYS_DIR . '/private.pem';
        if (!file_exists($fichier) || filesize($fichier) < 100) {
            self::generer();
        }
        return file_get_contents($fichier);
    }

    public static function chargerPublique()
    {
        $fichier = KEYS_DIR . '/public.pem';
        if (!file_exists($fichier)) {
            self::generer();
        }
        return file_get_contents($fichier);
    }

    public static function b64u($data)
    {
        return rtrim(strtr(base64_encode($data), '+/', '-_'), '=');
    }

    public static function fromB64u($data)
    {
        return base64_decode(strtr($data, '-_', '+/'));
    }

    public static function signerLicence($payloadJson)
    {
        $prive = openssl_pkey_get_private(self::chargerPrive());
        $sig = '';
        openssl_sign($payloadJson, $sig, $prive, OPENSSL_ALGO_SHA256);
        return self::b64u($payloadJson) . '.' . self::b64u($sig);
    }

    public static function verifierLicence($licenceKey, &$payloadJson = null)
    {
        $parts = explode('.', $licenceKey, 2);
        if (count($parts) !== 2) {
            return false;
        }
        $payloadJson = self::fromB64u($parts[0]);
        $sig = self::fromB64u($parts[1]);
        if ($payloadJson === false || $sig === false) {
            return false;
        }
        $publique = openssl_pkey_get_public(self::chargerPublique());
        $ok = openssl_verify($payloadJson, $sig, $publique, OPENSSL_ALGO_SHA256);
        return $ok === 1;
    }

    public static function genererPaireEtab()
    {
        $tmp = KEYS_DIR . '/.tmp_' . bin2hex(random_bytes(6)) . '.pem';
        if (!self::genererViaCli($tmp)) {
            return null;
        }
        $res = openssl_pkey_get_private(file_get_contents($tmp));
        $details = openssl_pkey_get_details($res);
        $prive = file_get_contents($tmp);
        @unlink($tmp);
        return ['priv' => $prive, 'pub' => $details['key']];
    }
}