<?php
class Auth
{
    private $db;

    public function __construct($db)
    {
        $this->db = $db;
        if (!ob_get_level()) {
            ob_start();
        }
        if (session_status() !== PHP_SESSION_ACTIVE) {
            session_set_cookie_params([
                'httponly' => true,
                'samesite' => 'Lax',
                'secure'   => !empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off',
            ]);
            session_start();
        }
    }

    public function connecter($login, $password)
    {
        $stmt = $this->db->prepare('SELECT * FROM admins WHERE login = ? AND role = ?');
        $stmt->execute([$login, 'super_admin']);
        $admin = $stmt->fetch();
        if ($admin && password_verify($password, $admin['password'])) {
            session_regenerate_id(true);
            $_SESSION['admin_id'] = (int)$admin['id'];
            $_SESSION['admin_login'] = $admin['login'];
            return true;
        }
        return false;
    }

    public function verifier()
    {
        return isset($_SESSION['admin_id']);
    }

    public function identite()
    {
        return isset($_SESSION['admin_login']) ? $_SESSION['admin_login'] : '';
    }

    public function deconnecter()
    {
        $_SESSION = [];
        if (ini_get('session.use_cookies')) {
            $p = session_get_cookie_params();
            setcookie(session_name(), '', time() - 42000, $p['path'], $p['domain'], $p['secure'], $p['httponly']);
        }
        session_destroy();
    }
}