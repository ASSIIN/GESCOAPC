<?php
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/Keys.php';

class Etablissement
{
    private $db;

    public function __construct($db)
    {
        $this->db = $db;
    }

    public function parId($id)
    {
        $stmt = $this->db->prepare('SELECT * FROM etablissements WHERE id = ?');
        $stmt->execute([(int)$id]);
        return $stmt->fetch() ?: null;
    }

    public function parInstallId($install_id)
    {
        $stmt = $this->db->prepare('SELECT * FROM etablissements WHERE install_id = ?');
        $stmt->execute([$install_id]);
        return $stmt->fetch() ?: null;
    }

    public function inscrireOuMAJ($data)
    {
        $produit = isset($data['produit']) && produit_info($data['produit']) ? $data['produit'] : 'GESCO-APC';
        $existant = $this->parInstallId($data['install_id']);
        $annee = !empty($data['annee_scolaire']) ? $data['annee_scolaire'] : annee_scolaire_courante();

        if ($existant) {
            $stmt = $this->db->prepare('UPDATE etablissements
                SET nom_etab = ?, ville = ?, email = ?, telephone = ?, nb_eleves = ?, tarif_code = ?, produit = ?,
                    abrege = ?, niu = ?, annee_scolaire = ?
                WHERE id = ?');
            $stmt->execute([
                $data['nom_etab'],
                $data['ville'] ?? null,
                $data['email'] ?? null,
                $data['telephone'] ?? null,
                (int)($data['nb_eleves'] ?? 0),
                $data['tarif_code'],
                $produit,
                $data['abrege'] ?? null,
                $data['niu'] ?? null,
                $annee,
                (int)$existant['id'],
            ]);
            return (int)$existant['id'];
        }

        $paire = Keys::genererPaireEtab();
        $stmt = $this->db->prepare('INSERT INTO etablissements
            (nom_etab, install_id, ville, email, telephone, nb_eleves, tarif_code, produit,
             cle_priv_etab, cle_pub_etab, statut, abrege, niu, annee_scolaire)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)');
        $stmt->execute([
            $data['nom_etab'],
            $data['install_id'],
            $data['ville'] ?? null,
            $data['email'] ?? null,
            $data['telephone'] ?? null,
            (int)($data['nb_eleves'] ?? 0),
            $data['tarif_code'],
            $produit,
            $paire['priv'],
            $paire['pub'],
            'en_attente',
            $data['abrege'] ?? null,
            $data['niu'] ?? null,
            $annee,
        ]);
        return (int)$this->db->lastInsertId();
    }

    public function creerCommande($etab_id, $tarif_code, $montant, $produit = 'GESCO-APC', $annee_scolaire = null)
    {
        $ref = 'LI-' . $etab_id . '-' . $tarif_code . '-' . time() . '-' . strtoupper(substr(uniqid(), -6));
        $stmt = $this->db->prepare('INSERT INTO commandes (ref_commande, etab_id, tarif_code, montant, produit, annee_scolaire, statut)
            VALUES (?, ?, ?, ?, ?, ?, ?)');
        $stmt->execute([$ref, (int)$etab_id, $tarif_code, (int)$montant, $produit, $annee_scolaire, 'en_attente']);
        return ['ref' => $ref, 'id' => (int)$this->db->lastInsertId()];
    }

    public function finaliserPaiement($etab_id, $tarif_code, $montant, $ref_passerelle, $external_reference)
    {
        if ($external_reference !== '') {
            $this->db->prepare('UPDATE commandes
                SET statut = ?, ref_passerelle = ?, external_reference = ?, paye_le = NOW()
                WHERE ref_commande = ? AND statut = ?')
                ->execute(['payee', $ref_passerelle, $external_reference, $external_reference, 'en_attente']);
        } else {
            $this->db->prepare('UPDATE commandes
                SET statut = ?, ref_passerelle = ?, external_reference = ?, paye_le = NOW()
                WHERE etab_id = ? AND statut = ?')
                ->execute(['payee', $ref_passerelle, $external_reference, (int)$etab_id, 'en_attente']);
        }

        $etab = $this->parId($etab_id);
        if (!$etab) {
            return null;
        }
        $produit = $etab['produit'] ?? 'GESCO-APC';

        // Une licence couvre TOUJOURS une annee scolaire complete (septembre - aout).
        // Le 1er mois est gratuit (essai) : souscrire en cours d'annee revient a facturer
        // DUREE_PAYEE_MOIS mois pour les 12 mois de l'annee scolaire ciblee.
        $annee = $etab['annee_scolaire'] ?? annee_scolaire_courante();
        $bornes = annee_scolaire_bornes($annee);
        if (!$bornes) {
            $bornes = annee_scolaire_bornes(annee_scolaire_courante());
            $annee = $bornes['code'];
        }
        $debut = $bornes['debut'];
        $fin = $bornes['fin'];

        $payload = json_encode([
            'v' => 1,
            'produit' => $produit,
            'etab' => $etab['nom_etab'],
            'iid' => $etab['install_id'],
            'annee' => $bornes['canon'],
            'annee_libelle' => $bornes['libelle'],
            'debut' => $debut,
            'fin' => $fin,
            'nb_poste' => 1,
            'tarif' => $tarif_code,
            'email' => $etab['email'],
        ], JSON_UNESCAPED_UNICODE | JSON_HEX_APOS | JSON_HEX_QUOT);

        $cle = Keys::signerLicence($payload);

        $this->db->prepare('UPDATE etablissements
            SET licence_key = ?, tarif_code = ?, debut_licence = ?, fin_licence = ?, nb_poste = 1, statut = ?,
                annee_scolaire = ?
            WHERE id = ?')
            ->execute([$cle, $tarif_code, $debut, $fin, 'actif', $annee, (int)$etab_id]);

        $this->db->prepare('INSERT INTO licences (etab_id, produit, tarif_code, montant, licence_key, debut, fin, statut, type, annee_scolaire)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)')
            ->execute([(int)$etab_id, $produit, $tarif_code, (int)$montant, $cle, $debut, $fin, 'active', 'payee', $annee]);

        file_put_contents(
            __DIR__ . '/../paiement/log_paiement.txt',
            date('[Y-m-d H:i:s]') . " Succes - Licence {$produit} {$tarif_code} generee pour l'etablissement #{$etab_id} ({$montant} XAF, Commande: {$external_reference})" . PHP_EOL,
            FILE_APPEND
        );

        return $cle;
    }

    // ------------------------------------------------------------
    // Licence de SECOURS (super admin) : a emettre manuellement lorsque
    // la passerelle de paiement est en panne, pour un paiement regle hors
    // ligne, ou pour rattraper un nom mal saisi. La commande est creee
    // puis marquee payee directement.
    // ------------------------------------------------------------
    public function octroyerLicenceSecours($etab_id, $tarif_code, $montant, $motif = 'secours')
    {
        $etab = $this->parId($etab_id);
        if (!$etab) {
            return null;
        }
        $produit = $etab['produit'] ?? 'GESCO-APC';
        $annee = $etab['annee_scolaire'] ?? annee_scolaire_courante();
        $c = $this->creerCommande($etab_id, $tarif_code, (int)$montant, $produit, $annee);
        $ref_passerelle = 'SECOURS-MANUELLE-' . strtoupper(substr($motif, 0, 12));
        $cle = $this->finaliserPaiement($etab_id, $tarif_code, (int)$montant, $ref_passerelle, $c['ref']);
        return ['ref' => $c['ref'], 'id' => (int)$c['id'], 'cle' => $cle];
    }

    // Corrige le nom d'un etablissement mal saisi puis REGENERE une licence
    // signee avec le nom corrige (le fichier .txt telecharge portera la
    // nouvelle valeur et le client se re-calonera automatiquement a l'import).
    public function corrigerNomEtRegenerer($etab_id, $nouveau_nom)
    {
        $etab = $this->parId($etab_id);
        $nouveau_nom = trim((string)$nouveau_nom);
        if (!$etab || $nouveau_nom === '') {
            return null;
        }
        $this->db->prepare('UPDATE etablissements SET nom_etab = ? WHERE id = ?')
            ->execute([$nouveau_nom, (int)$etab_id]);
        $etab = $this->parId($etab_id);

        $produit = $etab['produit'] ?? 'GESCO-APC';
        $annee = $etab['annee_scolaire'] ?? annee_scolaire_courante();
        $bornes = annee_scolaire_bornes($annee);
        if (!$bornes) {
            $bornes = annee_scolaire_bornes(annee_scolaire_courante());
            $annee = $bornes['code'];
        }

        $payload = json_encode([
            'v' => 1,
            'produit' => $produit,
            'etab' => $nouveau_nom,
            'iid' => $etab['install_id'],
            'annee' => $bornes['canon'],
            'annee_libelle' => $bornes['libelle'],
            'debut' => $bornes['debut'],
            'fin' => $bornes['fin'],
            'nb_poste' => 1,
            'tarif' => $etab['tarif_code'] ?? null,
            'email' => $etab['email'],
        ], JSON_UNESCAPED_UNICODE | JSON_HEX_APOS | JSON_HEX_QUOT);

        $cle = Keys::signerLicence($payload);

        $this->db->prepare('UPDATE etablissements
            SET licence_key = ?, debut_licence = ?, fin_licence = ?, nb_poste = 1, statut = ?, annee_scolaire = ?
            WHERE id = ?')
            ->execute([$cle, $bornes['debut'], $bornes['fin'], 'actif', $annee, (int)$etab_id]);

        $this->db->prepare('INSERT INTO licences (etab_id, produit, tarif_code, montant, licence_key, debut, fin, statut, type, annee_scolaire)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)')
            ->execute([(int)$etab_id, $produit, $etab['tarif_code'] ?? null, 0, $cle, $bornes['debut'], $bornes['fin'], 'active', 'corrigee', $annee]);

        return $cle;
    }

    // Active ou desactive l'etablissement cote portail. La desactivation rend
    // la licence expiree cote client (la date fin_licence est reculee).
    public function changerStatut($etab_id, $statut)
    {
        $sql = 'UPDATE etablissements SET statut = ?';
        $args = [$statut];
        if ($statut !== 'actif') {
            $sql .= ', fin_licence = ?';
            $args[] = date('Y-m-d', time() - 86400);
        }
        $sql .= ' WHERE id = ?';
        $args[] = (int)$etab_id;
        $this->db->prepare($sql)->execute($args);
        return true;
    }

    // Supprime l'historique (licences, commandes, telemetrie, tokens) d'un etablissement.
    public function supprimerToutHistorique($etab_id)
    {
        $this->db->prepare('DELETE FROM recup_tokens WHERE etab_id = ?')->execute([(int)$etab_id]);
        $this->db->prepare('DELETE FROM telemetrie WHERE etab_id = ?')->execute([(int)$etab_id]);
        $this->db->prepare('DELETE FROM commandes WHERE etab_id = ?')->execute([(int)$etab_id]);
        $this->db->prepare('DELETE FROM licences WHERE etab_id = ?')->execute([(int)$etab_id]);
        $this->db->prepare("UPDATE etablissements SET licence_key = NULL, debut_licence = NULL, fin_licence = NULL, statut = 'en_attente' WHERE id = ?")
            ->execute([(int)$etab_id]);
        return true;
    }

    public function tous()
    {
        return $this->db->query('SELECT * FROM etablissements ORDER BY cree_le DESC')->fetchAll();
    }

    public function tousProduit($produit = null)
    {
        if ($produit !== null && $produit !== '') {
            $stmt = $this->db->prepare('SELECT * FROM etablissements WHERE produit = ? ORDER BY cree_le DESC');
            $stmt->execute([$produit]);
            return $stmt->fetchAll();
        }
        return $this->tous();
    }

    public function historiqueLicences($etab_id)
    {
        $stmt = $this->db->prepare('SELECT * FROM licences WHERE etab_id = ? ORDER BY cree_le DESC');
        $stmt->execute([(int)$etab_id]);
        return $stmt->fetchAll();
    }

    public function commandesDe($etab_id)
    {
        $stmt = $this->db->prepare('SELECT * FROM commandes WHERE etab_id = ? ORDER BY cree_le DESC');
        $stmt->execute([(int)$etab_id]);
        return $stmt->fetchAll();
    }

    // ------------------------------------------------------------
    // Licence d'evaluation gratuite (1 mois, non renouvelable gratuitement)
    // ------------------------------------------------------------
    public function derniereTypeLicence($etab_id)
    {
        $stmt = $this->db->prepare('SELECT type FROM licences WHERE etab_id = ? ORDER BY cree_le DESC, id DESC LIMIT 1');
        $stmt->execute([(int)$etab_id]);
        $type = $stmt->fetchColumn();
        return $type !== false ? $type : null;
    }

    public function aDejaEssai($etab_id, $produit)
    {
        $stmt = $this->db->prepare('SELECT COUNT(*) FROM licences WHERE etab_id = ? AND produit = ? AND type = ?');
        $stmt->execute([(int)$etab_id, $produit, 'essai']);
        return (int)$stmt->fetchColumn() > 0;
    }

    public function aDejaLicence($etab_id)
    {
        $stmt = $this->db->prepare('SELECT COUNT(*) FROM licences WHERE etab_id = ?');
        $stmt->execute([(int)$etab_id]);
        return (int)$stmt->fetchColumn() > 0;
    }

    // Recherche d'un etablissement deja enregistre, par email + nom, abreviation ou NIU.
    // Sert a empecher l'essai gratuit renouvelable et a signaler les doublons de nom.
    public function trouverParIdentifiants($nom, $email, $abrege = null, $niu = null)
    {
        $nom = mb_strtolower(trim(preg_replace('/\s+/u', ' ', $nom)));
        $email = mb_strtolower(trim($email));
        $abrege = $abrege !== null && $abrege !== '' ? mb_strtolower(trim($abrege)) : null;
        $niu = $niu !== null && $niu !== '' ? mb_strtolower(trim(preg_replace('/\s+/u', '', $niu))) : null;

        $rows = $this->db->query('SELECT * FROM etablissements')->fetchAll();
        foreach ($rows as $r) {
            $r_nom = mb_strtolower(preg_replace('/\s+/u', ' ', (string)($r['nom_etab'] ?? '')));
            $r_email = mb_strtolower(trim((string)($r['email'] ?? '')));
            $r_abrege = $r['abrege'] !== null ? mb_strtolower(trim($r['abrege'])) : null;
            $r_niu = $r['niu'] !== null ? mb_strtolower(trim(preg_replace('/\s+/u', '', $r['niu']))) : null;

            if ($r_email !== '' && $r_email === $email && $r_nom === $nom) {
                return $r;
            }
            if ($abrege !== null && $r_abrege !== null && $r_abrege === $abrege) {
                return $r;
            }
            if ($niu !== null && $r_niu !== null && $r_niu === $niu) {
                return $r;
            }
        }
        return null;
    }

    // Genere une licence d'evaluation gratuite (DUREE_ESSAI_MOIS mois, montant 0).
    public function creerEssai($etab_id, $produit, $mois = null)
    {
        $etab = $this->parId($etab_id);
        if (!$etab) {
            return null;
        }
        $mois = $mois ? (int)$mois : DUREE_ESSAI_MOIS;
        // L'essai respecte l'annee scolaire en cours : 1 mois, borne a la fin de l'annee.
        $annee = $etab['annee_scolaire'] ?? annee_scolaire_courante();
        $bornes = annee_scolaire_bornes($annee);
        if (!$bornes) {
            $bornes = annee_scolaire_bornes(annee_scolaire_courante());
            $annee = $bornes['code'];
        }
        $debut = date('Y-m-d');
        $fin_calc = date('Y-m-d', strtotime('+' . $mois . ' months'));
        $fin = strtotime($fin_calc) < strtotime($bornes['fin']) ? $fin_calc : $bornes['fin'];

        $payload = json_encode([
            'v' => 1,
            'produit' => $produit,
            'etab' => $etab['nom_etab'],
            'iid' => $etab['install_id'],
            'annee' => $bornes['canon'],
            'annee_libelle' => $bornes['libelle'],
            'debut' => $debut,
            'fin' => $fin,
            'nb_poste' => 1,
            'tarif' => $etab['tarif_code'] ?? null,
            'email' => $etab['email'],
            'essai' => 1,
        ], JSON_UNESCAPED_UNICODE | JSON_HEX_APOS | JSON_HEX_QUOT);

        $cle = Keys::signerLicence($payload);

        $this->db->prepare('UPDATE etablissements
            SET licence_key = ?, debut_licence = ?, fin_licence = ?, nb_poste = 1, statut = ?, annee_scolaire = ?
            WHERE id = ?')
            ->execute([$cle, $debut, $fin, 'actif', $annee, (int)$etab_id]);

        $this->db->prepare('INSERT INTO licences (etab_id, produit, tarif_code, montant, licence_key, debut, fin, statut, type, annee_scolaire)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)')
            ->execute([(int)$etab_id, $produit, $etab['tarif_code'] ?? null, 0, $cle, $debut, $fin, 'active', 'essai', $annee]);

        return $cle;
    }

    // ------------------------------------------------------------
    // Recuperation d'une licence deja payee (par nom + email)
    // ------------------------------------------------------------
    public function rechercherParNomEmail($nom, $email, $abrege = null, $niu = null)
    {
        $nom = mb_strtolower(trim(preg_replace('/\s+/u', ' ', $nom)));
        $email = mb_strtolower(trim($email));
        $abrege = $abrege !== null && $abrege !== '' ? mb_strtolower(trim($abrege)) : null;
        $niu = $niu !== null && $niu !== '' ? mb_strtolower(trim(preg_replace('/\s+/u', '', $niu))) : null;

        $stmt = $this->db->prepare('SELECT *, LOWER(nom_etab) AS nom_min FROM etablissements
            WHERE email <> "" AND LOWER(email) = ?');
        $stmt->execute([$email]);
        $rows = $stmt->fetchAll();

        $resultats = [];
        foreach ($rows as $r) {
            $r_nom = mb_strtolower(preg_replace('/\s+/u', ' ', $r['nom_etab']));
            $nom_ok = $r_nom === $nom;
            similar_text($nom, $r_nom, $pct);
            $abrege_ok = $abrege !== null && $r['abrege'] !== null && mb_strtolower(trim($r['abrege'])) === $abrege;
            $niu_ok = $niu !== null && $r['niu'] !== null && mb_strtolower(trim(preg_replace('/\s+/u', '', $r['niu']))) === $niu;
            if ($nom_ok || $pct >= 60 || $abrege_ok || $niu_ok) {
                $resultats[] = $r;
            }
        }
        return $resultats;
    }

    public function creerTokenRecup($etab_id, $produit, $type = 'telecharger')
    {
        $token = bin2hex(random_bytes(24));
        $expire = date('Y-m-d H:i:s', time() + RECUP_TOKEN_VALIDITE_H * 3600);
        $stmt = $this->db->prepare('INSERT INTO recup_tokens (token, etab_id, produit, type, expire_le) VALUES (?, ?, ?, ?, ?)');
        $stmt->execute([$token, (int)$etab_id, $produit, $type, $expire]);
        return $token;
    }

    public function tokenValable($token)
    {
        $stmt = $this->db->prepare('SELECT * FROM recup_tokens WHERE token = ? LIMIT 1');
        $stmt->execute([$token]);
        $row = $stmt->fetch() ?: null;
        if (!$row || (int)$row['consomme'] === 1 || strtotime($row['expire_le']) < time()) {
            return null;
        }
        return $row;
    }

    public function consommerToken($token)
    {
        $stmt = $this->db->prepare('UPDATE recup_tokens SET consomme = 1 WHERE token = ?');
        $stmt->execute([$token]);
    }

    // ------------------------------------------------------------
    // Telemetrie / sauvegarde automatique
    // ------------------------------------------------------------
    public function telemetrieEnregistrer(array $t)
    {
        $etab = $this->parInstallId($t['install_id']);
        if (!$etab) {
            return null;
        }

        $nb_eleves = max(0, (int)($t['nb_eleves'] ?? 0));
        $tarif = $etab['tarif_code'];
        $produit = $etab['produit'] ?? 'GESCO-APC';
        $depassement = depassement_pct($nb_eleves, $tarif, $produit) > 0 ? 1 : 0;
        $par_niveau = isset($t['par_niveau']) && is_array($t['par_niveau'])
            ? json_encode($t['par_niveau'], JSON_UNESCAPED_UNICODE) : null;

        $stmt = $this->db->prepare('INSERT INTO telemetrie
            (etab_id, produit, install_id, version_logiciel, nb_eleves, par_niveau, tarif_code, depassement, payload)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)');
        $stmt->execute([
            (int)$etab['id'],
            $etab['produit'],
            $t['install_id'],
            isset($t['version']) ? substr($t['version'], 0, 120) : null,
            $nb_eleves,
            $par_niveau,
            $tarif,
            $depassement,
            isset($t['sauvegarde']) ? $t['sauvegarde'] : null,
        ]);

        $this->db->prepare('UPDATE etablissements
            SET nb_eleves_reel = ?, version_logiciel = ?, derniere_sync = NOW()
            WHERE id = ?')
            ->execute([$nb_eleves, isset($t['version']) ? substr($t['version'], 0, 120) : null, (int)$etab['id']]);

        return [
            'etab_id' => (int)$etab['id'],
            'annee_scolaire' => $etab['annee_scolaire'] ?? null,
            'nb_eleves' => $nb_eleves,
            'tarif' => $tarif,
            'depassement' => (bool)$depassement,
            'depassement_pct' => depassement_pct($nb_eleves, $tarif, $produit),
            'fin_licence' => $etab['fin_licence'],
        ];
    }

    public function derniereTelemetrie($etab_id)
    {
        $stmt = $this->db->prepare('SELECT * FROM telemetrie WHERE etab_id = ? ORDER BY cree_le DESC LIMIT 1');
        $stmt->execute([(int)$etab_id]);
        return $stmt->fetch() ?: null;
    }

    public function syncsDe($etab_id, $limite = 20)
    {
        $stmt = $this->db->prepare('SELECT * FROM telemetrie WHERE etab_id = ? ORDER BY cree_le DESC LIMIT ' . (int)$limite);
        $stmt->execute([(int)$etab_id]);
        return $stmt->fetchAll();
    }

    public function deriveTelemetrie($id_telemetrie)
    {
        $stmt = $this->db->prepare('SELECT t.*, e.nom_etab, e.ville, e.email, e.install_id
            FROM telemetrie t JOIN etablissements e ON e.id = t.etab_id WHERE t.id = ?');
        $stmt->execute([(int)$id_telemetrie]);
        return $stmt->fetch() ?: null;
    }
}