<?php
require_once __DIR__ . '/../config.php';

class Mailer
{
    /** Envoi d'un email. Renvoie true si l'envoi a ete tente par mail(),
     *  false en cas d'erreur technique. Le message est toujours journalise. */
    public static function envoyer($to, $subject, $bodyHtml, $bodyPlain = '')
    {
        $ok = false;
        try {
            $headers = array_filter([
                'MIME-Version' => '1.0',
                'Content-type' => 'text/html; charset=UTF-8',
                'From' => MAIL_FROM,
            ], fn($v) => $v !== '');

            $headers = implode("\r\n", array_map(
                fn($k, $v) => "$k: $v",
                array_keys($headers),
                array_values($headers)
            ));

            $ok = @mail($to, '=?UTF-8?B?' . base64_encode($subject) . '?=', $bodyHtml, $headers);
        } catch (Throwable $e) {
            $ok = false;
        }

        $log = __DIR__ . '/../mails_envoyes.log';
        try {
            $ligne = date('[Y-m-d H:i:s]') . " -> {$to} | " . ($ok ? 'ENVOYE' : 'ECHEC') . ' | ' . str_replace(["\r", "\n"], ' ', $subject) . PHP_EOL;
            file_put_contents($log, $ligne, FILE_APPEND);
        } catch (Throwable $e) {
        }

        return $ok;
    }
}