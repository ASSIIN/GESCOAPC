<?php
// /paiement/config.php - AUCUN secret en dur : tout vient des variables
// d'environnement definies dans public_html/.htaccess (SetEnv) ou via cPanel.
//
// Exemple .htaccess (a renseigner SUR LE SERVEUR, hors git) :
//   SetEnv ASSIIN_API_KEY     "apay-xxxxxxxxxxxxxxxx"
//   SetEnv ASSIIN_API_SECRET  "sk_live_xxxxxxxxxxxxxxxxxxxxxxxxxxxx"
//   SetEnv ASSIIN_API_NAME    "INOFIB"
//   SetEnv ASSIIN_ENDPOINT    "https://pay.assiine.org/paiement/colma.php"
//   SetEnv ASSIIN_CALLBACK    "https://licences.inofib.com/paiement/callback.php"

define('API_KEY', getenv('ASSIIN_API_KEY'));
define('API_SECRET', getenv('ASSIIN_API_SECRET'));
define('API_NAME', getenv('ASSIIN_API_NAME') ?: 'INOFIB');
define('ENDPOINT', getenv('ASSIIN_ENDPOINT') ?: 'https://pay.assiine.org/paiement/colma.php');
define('CALLBACK_URL', getenv('ASSIIN_CALLBACK') ?: 'https://licences.inofib.com/paiement/callback.php');

if (empty(API_KEY) || empty(API_SECRET)) {
    http_response_code(503);
    exit('Passerelle de paiement non configuree (variables ASSIIN_*).');
}