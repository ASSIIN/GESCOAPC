<?php
/**
 * /paiement/error.php (Sur le serveur du Marchand)
 * Interface d'affichage des échecs de paiement et de réessai
 */
require_once 'config.php';

// 1. Initialisation des variables de diagnostic
$reference = 'Inconnue';
$reason = 'Le paiement a été annulé ou rejeté par l\'opérateur.';

// 2. Lecture des paramètres d'erreur (si fournis par la plateforme)
if (isset($_GET['ref'])) {
    $reference = htmlspecialchars($_GET['ref']);
}

if (isset($_GET['message'])) {
    $reason = htmlspecialchars($_GET['message']);
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Échec du Paiement || Assiin Pay</title>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body { background: #f8f9fa; display: flex; align-items: center; justify-content: center; height: 100vh; font-family: 'Inter', system-ui, sans-serif; }
        .error-card { background: white; padding: 40px; border-radius: 20px; box-shadow: 0 15px 35px rgba(0,0,0,0.06); text-align: center; max-width: 450px; border: 1px solid #eef2f3; }
        .icon-error { font-size: 70px; color: #dc3545; margin-bottom: 20px; }
    </style>
</head>
<body>

<div class="error-card">
    <div class="icon-error">
        <i class="fa-solid fa-circle-xmark"></i>
    </div>
    <h2 class="fw-bold mb-3">Paiement Échoué</h2>
    <p class="text-muted mb-4">Nous n'avons pas pu valider votre transaction. L'argent n'a pas été débité de votre compte mobile money.</p>
    
    <!-- Boîte de diagnostic -->
    <div class="bg-light p-3 rounded-3 mb-4 text-start border">
        <div class="d-flex justify-content-between mb-2">
            <span class="text-muted small">Référence commande :</span>
            <span class="fw-bold small text-dark"><?= $reference ?></span>
        </div>
        <div class="mb-0">
            <span class="text-muted small d-block mb-1">Raison du rejet :</span>
            <div class="alert alert-danger small py-2 px-3 mb-0 border-0 bg-danger-subtle text-danger">
                <i class="fa-solid fa-triangle-exclamation me-2"></i><?= $reason ?>
            </div>
        </div>
    </div>
    
    <!-- Boutons d'action -->
    <div class="d-grid gap-2">
        <a href="../service_gescoapc.php" class="btn btn-danger btn-lg rounded-pill fw-bold py-2 fs-6">
            <i class="fa-solid fa-arrow-rotate-left me-2"></i>Réessayer le paiement
        </a>
        <a href="../index.php" class="btn btn-outline-secondary rounded-pill fw-bold py-2 fs-6 border-0">
            Annuler et revenir au portail Licences
        </a>
    </div>
</div>

<script src="https://code.jquery.com/jquery-3.7.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
