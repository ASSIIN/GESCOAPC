<?php
/**
 * /paiement/callback.php (Serveur marchand : Plateforme Licences INOFIB)
 * Interface universelle : gere l'IPN asynchrone (POST) et le retour client (GET)
 * La logique de verification des signatures HMAC est conservee a l'identique.
 */
require_once 'config.php';
require_once '../Model/connexion.php';
require_once '../classes/Database.php';
require_once '../classes/Etablissement.php';

session_start();

register_shutdown_function(function () {
    $e = error_get_last();
    if ($e && in_array($e['type'], [E_ERROR, E_PARSE, E_CORE_ERROR, E_COMPILE_ERROR, E_USER_ERROR])) {
        @file_put_contents(__DIR__ . '/callback_erreurs.log', date('[Y-m-d H:i:s] ') . $e['message'] . ' | ' . $e['file'] . ':' . $e['line'] . PHP_EOL, FILE_APPEND);
    }
});

// Initialisation des variables de lecture globale
$payload = null;

// ========================================================
// MODE A : RECEPTION ASYNCHRONE D'ASSIIN PAY (ROBOT POST)
// ========================================================
$raw_json = file_get_contents('php://input');

if (!function_exists('getallheaders')) {
    function getallheaders() {
        $headers = [];
        foreach ($_SERVER as $k => $v) {
            if (strpos($k, 'HTTP_') === 0) {
                $headers[strtolower(substr($k, 5))] = $v;
            }
        }
        if (isset($_SERVER['CONTENT_TYPE'])) { $headers['content-type'] = $_SERVER['CONTENT_TYPE']; }
        if (isset($_SERVER['CONTENT_LENGTH'])) { $headers['content-length'] = $_SERVER['CONTENT_LENGTH']; }
        return $headers;
    }
}

$headers = array_change_key_case(getallheaders(), CASE_LOWER);
$received_signature = $headers['http_x_assiin_signature'] ?? $headers['x-assiin-signature'] ?? '';

if (!empty($raw_json) && !empty($received_signature)) {
    $computed_signature = hash_hmac('sha256', $raw_json, API_SECRET);
    if (!hash_equals($computed_signature, $received_signature)) {
        header('HTTP/1.1 403 Forbidden');
        die("Signature IPN invalide.");
    }
    $payload = json_decode($raw_json, true);
}

// ========================================================
// MODE B : RETOUR DU NAVIGATEUR CLIENT (REDIRECTION GET)
// ========================================================
if (isset($_GET['data']) && isset($_GET['sig'])) {
    $raw_data = $_GET['data'];
    $received_sig = $_GET['sig'];

    $decoded_json = base64_decode($raw_data);
    $computed_signature = hash_hmac('sha256', $decoded_json, API_SECRET);

    if (hash_equals($computed_signature, $received_sig)) {
        $payload = json_decode($decoded_json, true);
    } else {
        header('HTTP/1.1 403 Forbidden');
        die("Signature de redirection invalide.");
    }
}

// ========================================================
// VALIDATION ET EXTRACTION SECURISEE DES DONNEES
// ========================================================
if (!$payload || ($payload['status'] ?? '') !== 'SUCCESS') {
    header('HTTP/1.1 400 Bad Request');
    die("Donnees de transaction invalides ou non payees.");
}

$transaction_ref = $payload['transaction_ref'] ?? $payload['trx'] ?? '';
    $external_reference = $payload['external_reference'] ?? $payload['ref_commande'] ?? $payload['ref'] ?? '';
    $amount = (float)($payload['amount'] ?? 0);
    $etab_id = isset($payload['user_id']) ? (int)$payload['user_id'] : 0;
    $tarif = isset($payload['forfait']) ? strtolower(trim($payload['forfait'])) : '';

if ($etab_id === 0 || empty($tarif)) {
    header('HTTP/1.1 400 Bad Request');
    die("Donnees de commande incompletes.");
}

try {
    $database = new Database();
    $db = $database->getConnection();
    $etab = new Etablissement($db);

    $etablissement = $etab->parId($etab_id);
    $activation_reussie = false;

    if ($etablissement
        && $etablissement['statut'] === 'actif'
        && $etablissement['licence_key'] !== null
        && strtotime($etablissement['fin_licence']) >= time()) {
        $activation_reussie = true;
    } else {
        // Emission de la licence : 12 mois, signature asymetrique par la cle privee INOFIB
        $cle = $etab->finaliserPaiement($etab_id, $tarif, (int)$amount, $transaction_ref, $external_reference);
        $activation_reussie = ($cle !== null);
    }

    if (!$activation_reussie) {
        throw new Exception("Echec de finalisation de la licence.");
    }

    $produit_cb = $etablissement ? ($etablissement['produit'] ?? 'GESCO-APC') : 'GESCO-APC';
    $tarifs_cb = produit_tarifs($produit_cb);
    $nom_tarif = isset($tarifs_cb[$tarif]) ? $tarifs_cb[$tarif]['libelle'] : $tarif;

    // Journalisation locale
    $log_message = date('[Y-m-d H:i:s]') . " Succes - Licence {$nom_tarif} activee pour l'etablissement id {$etab_id} (Montant: {$amount} XAF, Commande: {$external_reference})" . PHP_EOL;
    file_put_contents('log_paiement.txt', $log_message, FILE_APPEND);

    // Si c'est le robot IPN qui appelle, on renvoie OK et on coupe le HTML
    if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'POST') {
        header('HTTP/1.1 200 OK');
        echo "OK";
        exit;
    }

    $cle_finale = $etablissement && $etablissement['statut'] === 'actif' ? $etablissement['licence_key'] : ($cle ?? '');

} catch (Exception $e) {
    $log_error = date('[Y-m-d H:i:s]') . " ERREUR - ID ETABLISSEMENT {$etab_id} : " . $e->getMessage() . PHP_EOL;
    file_put_contents('erreurs_paiement.txt', $log_error, FILE_APPEND);

    if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'POST') {
        header('HTTP/1.1 500 Internal Server Error');
        exit;
    }
    die("Erreur lors de la mise a jour automatique de votre licence.");
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Licence Generee - Licences INOFIB</title>
     <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body { background: #0a0a0f; display: flex; align-items: center; justify-content: center; min-height: 100vh; font-family: 'Segoe UI', sans-serif; color: #fff; padding: 20px; }
        .card-success { background: #1e1e2f; padding: 40px; border-radius: 24px; box-shadow: 0 15px 35px rgba(0,0,0,0.5); text-align: center; max-width: 520px; border: 1px solid #2d2d44; }
        .icon-box { width: 80px; height: 80px; background: rgba(25, 135, 84, 0.15); border-radius: 50%; display: flex; align-items: center; justify-content: center; margin: 0 auto 20px; color: #198754; }
        .licence-preview { background: #151522; border: 1px dashed #ffc107; border-radius: 12px; padding: 14px; font-size: .72rem; word-break: break-all; color: #ffc107; max-height: 110px; overflow: auto; }
    </style>
</head>
<body>

<div class="card-success">
    <div class="icon-box"><i class="fa-solid fa-circle-check fa-4x"></i></div>
    <h3 class="fw-bold text-white mb-2">Paiement Valide !</h3>
    <p class="text-light opacity-75 small">Votre licence GESCO-APC a ete generee et signee avec succes. Elle est valable <strong class="text-white">12 mois</strong> a compter d'aujourd'hui.</p>

    <div class="bg-dark p-3 rounded-3 text-start mb-4 border border-secondary small text-light">
        <div class="d-flex justify-content-between mb-1">
            <span class="opacity-75">Offre :</span>
            <span class="fw-bold text-warning"><?= htmlspecialchars($nom_tarif) ?></span>
        </div>
        <div class="d-flex justify-content-between mb-1">
            <span class="opacity-75">Commande :</span>
            <span class="fw-bold text-white"><?= htmlspecialchars($external_reference) ?></span>
        </div>
        <div class="d-flex justify-content-between mb-1">
            <span class="opacity-75">Ref. Passerelle :</span>
            <span class="fw-bold text-white"><?= htmlspecialchars($transaction_ref) ?></span>
        </div>
        <div class="d-flex justify-content-between">
            <span class="opacity-75">Montant regle :</span>
            <span class="fw-bold text-success"><?= number_format($amount, 0, '.', ' ') ?> XAF</span>
        </div>
    </div>

    <?php if (!empty($cle_finale)): ?>
    <div class="licence-preview mb-4"><?= htmlspecialchars($cle_finale) ?></div>
    <?php endif; ?>

    <div class="d-grid gap-2">
        <a href="../telecharger_cle.php?etab_id=<?= $etab_id ?>&type=licence" class="btn btn-warning w-100 rounded-pill py-2 text-dark fw-bold">
            <i class="fa-solid fa-download me-2"></i>Telecharger ma cle de licence
        </a>
        <a href="../index.php" class="btn btn-outline-secondary rounded-pill py-2 fw-bold border-0">
            <i class="fa-solid fa-house me-2"></i>Retour a l'accueil
        </a>
    </div>
</div>

</body>
</html>