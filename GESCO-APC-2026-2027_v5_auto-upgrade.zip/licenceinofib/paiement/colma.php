<?php
// /paiement/colma.php (Sur le serveur du Marchand - VERSION FINALE PROD)
require_once 'config.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('HTTP/1.1 405 Method Not Allowed');
    die("Accès interdit.");
}

$amount  = floatval($_POST['amount'] ?? 0);
$ref     = strip_tags($_POST['ref'] ?? 'CMD-' . time());
$details = $_POST['details'] ?? json_encode(['info' => 'Aucun détail']);

if ($amount <= 0) {
    die("Erreur : Montant invalide.");
}

$data_to_sign = [
    'api_key'      => API_KEY,
    'api_name'     => API_NAME,
    'amount'       => $amount,
    'ref'          => $ref,
    'details'      => $details,
    'callback_url' => CALLBACK_URL 
];

$signature = hash_hmac('sha256', json_encode($data_to_sign), API_SECRET);

$payload = $data_to_sign;
$payload['signature'] = $signature;

$ch = curl_init(ENDPOINT);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($payload));
curl_setopt($ch, CURLOPT_TIMEOUT, 30);
curl_setopt($ch, CURLOPT_HTTPHEADER, [
    'Content-Type: application/json',
    'Accept: application/json'
]);

$response = curl_exec($ch);
$http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
$curl_error = curl_error($ch);
curl_close($ch);

$resultat = json_decode($response, true);

$log_ligne = date('[Y-m-d H:i:s]') . " ref={$ref} http={$http_code} curl=" . ($curl_error !== '' ? $curl_error : '-') . " reponse=" . substr((string)$response, 0, 500) . PHP_EOL;
@file_put_contents(__DIR__ . '/init_paiement.log', $log_ligne, FILE_APPEND);

if ($http_code === 200 && is_array($resultat) && isset($resultat['url']) && is_string($resultat['url']) && $resultat['url'] !== '') {
    header('Location: ' . $resultat['url']);
    exit();
} else {
    if (isset($_GET['debug'])) {
        http_response_code(200);
        echo "<pre>HTTP {$http_code}\ncurl: {$curl_error}\n" . htmlspecialchars((string)$response) . "</pre>";
        exit;
    }
    echo "<div style='font-family:sans-serif; padding:20px; text-align:center;'>";
    echo "<h2>Une erreur est survenue lors de l'initialisation du paiement.</h2>";
    echo "<a href='test.php'>Retourner à la boutique</a>";
    echo "</div>";
}
?>
