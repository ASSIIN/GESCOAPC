<?php
// /paiement/test.php - Simulateur de paiement (developpement / tests)
require_once 'config.php';
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Simulation de Paiement - Licences INOFIB</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

    <style>
        body { background: #0a0a0f; padding-top: 50px; color: #fff; font-family: 'Segoe UI', sans-serif; }
        .test-card { max-width: 520px; margin: auto; background: #1e1e2f; padding: 30px; border-radius: 16px; border: 1px solid #2d2d44; }
        .form-control, .form-select { background: #151522; border-color: #2d2d44; color: #fff; }
        .form-select option { color: #fff; }
    </style>
</head>
<body>

<div class="container">
    <div class="test-card">
        <h3 class="mb-4 text-center"><i class="fa-solid fa-money-check-dollar text-warning"></i> Simulation de Paiement</h3>

        <form action="colma.php" method="POST">
            <!-- 1. Montant du panier -->
            <div class="mb-4">
                <label class="form-label fw-bold">Tarif licence GESCO-APC</label>
                <select name="amount" class="form-select form-select-lg fw-bold">
                    <option value="1000">Tarif test economique (1000 XAF)</option>
                    <option value="50000">1 a 200 eleves (50 000 XAF)</option>
                    <option value="100000">201 a 500 eleves (100 000 XAF)</option>
                    <option value="200000">501 a 1000 eleves (200 000 XAF)</option>
                    <option value="300000">Plus de 1000 eleves (300 000 XAF)</option>
                </select>
            </div>

            <!-- 2. Generation automatique de la reference de commande -->
            <input type="hidden" name="ref" value="LI-TEST-<?php echo time(); ?>">

            <!-- 3. Details de la commande au format JSON -->
            <input type="hidden" name="details" value='<?php echo json_encode(["item" => "Licence GESCO-APC", "user_id" => 1, "forfait" => "t1"], JSON_HEX_APOS | JSON_HEX_QUOT); ?>'>

            <!-- 4. Bouton de redirection vers la passerelle -->
            <div class="d-grid">
                <button type="submit" class="btn btn-warning btn-lg rounded-pill fw-bold text-dark">
                    <i class="fa-solid fa-shield-halved me-2"></i>Aller au paiement securise
                </button>
            </div>
        </form>

        <hr class="my-4" style="border-color:#2d2d44;">
        <div class="alert alert-warning small mb-0" style="background:rgba(255,193,7,.08);border:1px solid rgba(255,193,7,.35);color:#ffc107;">
            <i class="fa-solid fa-circle-info me-1"></i> Le numero de telephone sera collecte directement sur la passerelle securisee d'<strong>Assiin Pay</strong>.
        </div>
        <div class="mt-3 text-center">
            <a href="../index.php" class="small text-white-50 text-decoration-none">Retour au portail Licences INOFIB</a>
        </div>
    </div>
</div>

</body>
</html>