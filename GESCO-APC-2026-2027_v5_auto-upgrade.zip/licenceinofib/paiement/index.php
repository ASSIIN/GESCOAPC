<?php
// /paiement/index.php - Adapte pour la plateforme Licences INOFIB
// La logique de la passerelle (verrou des prix cote serveur, redirection vers colma.php)
// est conservee a l'identique du projet d'origine.
require_once 'config.php';
require_once '../Model/connexion.php';
require_once '../classes/Etablissement.php';

$db = Base::connexion();
$etab = new Etablissement($db);

$ref = isset($_GET['ref']) ? trim($_GET['ref']) : '';
$etab_id = isset($_GET['etab_id']) ? (int)$_GET['etab_id'] : 0;
$tarif_get = isset($_GET['tarif']) ? strtolower(trim($_GET['tarif'])) : '';

if ($ref === '' || $etab_id === 0) {
    header('Location: ../service_gescoapc.php?err=commande');
    exit;
}

$commandes = $etab->commandesDe($etab_id);
$commande = null;
foreach ($commandes as $c) {
    if ($c['ref_commande'] === $ref && $c['statut'] === 'en_attente') {
        $commande = $c;
        break;
    }
}
if (!$commande) {
    header('Location: ../service_gescoapc.php?err=commande');
    exit;
}

// Verrou de securite : le tarif officiel est recalcule cote serveur.
// Impossible de modifier le prix en bidouillant l'URL.
$tarif = $commande['tarif_code'];
$etablissement = $etab->parId($etab_id);
$produit = ($etablissement['produit'] ?? 'GESCO-APC');
$tarifs = produit_tarifs($produit);
if (!isset($tarifs[$tarif])) {
    header('Location: ../service.php?err=tarif');
    exit;
}
$montant = $tarifs[$tarif]['prix'];

$info_produit = produit_info($produit);
$titre_produit = $info_produit ? $info_produit['titre'] : $produit;

$reference_commande = $commande['ref_commande'];

$details_panier = [
    "item"     => "Licence " . $titre_produit . " " . strtoupper($tarif),
    "user_id"  => $etab_id,
    "forfait"  => $tarif,
    "produit"  => $produit,
    "ref_commande" => $reference_commande
];
$json_details = json_encode($details_panier, JSON_HEX_APOS | JSON_HEX_QUOT);
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Connexion Passerelle - Assiin Pay</title>
     <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

    <style>
        body { background: #0a0a0f; color: #fff; padding-top: 100px; font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; }
        .redirect-box { max-width: 450px; margin: auto; background: #1e1e2f; padding: 40px; border-radius: 16px; box-shadow: 0 10px 30px rgba(0,0,0,0.5); text-align: center; border: 1px solid #2d2d44; }
        .loader { border: 4px solid #f3f3f3; border-top: 4px solid #ffc107; border-radius: 50%; width: 40px; height: 40px; animation: spin 1s linear infinite; margin: 20px auto; }
        @keyframes spin { 0% { transform: rotate(0deg); } 100% { transform: rotate(360deg); } }
    </style>
</head>
<body>

<div class="container">
    <div class="redirect-box">
        <h4 class="mb-3 fw-bold text-warning"><i class="fa-solid fa-lock"></i> Connexion securisee</h4>
        <p class="text-light opacity-75 mb-4">Initialisation du paiement de la licence <br><strong class="text-white"><?= htmlspecialchars($titre_produit) ?> - <?= $tarifs[$tarif]['libelle'] ?> (<?= number_format($montant, 0, ',', ' ') ?> XAF)</strong><br><span class="small opacity-75">Année scolaire <?= htmlspecialchars($commande['annee_scolaire'] ?? ($etablissement['annee_scolaire'] ?? '—')) ?></span>...</p>

        <div class="loader"></div>

        <p class="small text-muted mt-3">Veuillez patienter, redirection vers Assiin Pay en cours.</p>

        <!-- Formulaire masque envoye automatiquement en JavaScript -->
        <form id="payForm" action="colma.php" method="POST" style="display: none;">
            <!-- 1. Montant dynamique securise -->
            <input type="number" name="amount" value="<?= $montant ?>">

            <!-- 2. Reference de commande avec ID utilisateur inclus pour le traitement de retour -->
            <input type="text" name="ref" value="<?= $reference_commande ?>">

            <!-- 3. Details au format JSON incluant l'ID de l'etablissement pour activation -->
            <input type="hidden" name="details" value='<?= $json_details ?>'>
        </form>
    </div>
</div>

<script src="https://code.jquery.com/jquery-3.7.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
    $(document).ready(function() {
        // Redirection automatique immediate apres chargement du DOM
        setTimeout(function() {
            $('#payForm').submit();
        }, 1200); // Leger delai visuel de 1.2s pour l'effet professionnel du loader
    });
</script>

</body>
</html>