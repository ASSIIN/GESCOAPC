<?php
/**
 * /paiement/success.php (Serveur du marchand : Licences INOFIB)
 * Interface de remerciement et de confirmation d'achat client
 * La logique de verification de signature est conservee a l'identique.
 */
require_once 'config.php';
require_once '../Model/connexion.php';
require_once '../classes/Etablissement.php';

// 1. Initialisation des variables par defaut
$reference = 'Inconnue';
$amount = 0;
$verified = false;
$etab_id = 0;

// 2. Traitement du payload crypte renvoye par la passerelle Assiin Pay
if (isset($_GET['data']) && isset($_GET['sig'])) {
    $raw_data = $_GET['data'];
    $received_sig = $_GET['sig'];

    // Verification locale de l'integrite du retour
    $decoded_json = base64_decode($raw_data);
    $computed_sig = hash_hmac('sha256', $decoded_json, API_SECRET);

    if (hash_equals($computed_sig, $received_sig)) {
        $payload = json_decode($decoded_json, true);
        if ($payload && ($payload['status'] ?? '') === 'SUCCESS') {
            $reference = $payload['transaction_ref'] ?? 'Inconnue';
            $amount = $payload['amount'] ?? 0;
            $etab_id = isset($payload['user_id']) ? (int)$payload['user_id'] : 0;
            $verified = true;
        }
    }
} else {
    // Mode de secours par parametre simple
    $reference = isset($_GET['ref']) ? htmlspecialchars($_GET['ref']) : 'Inconnue';
    $etab_id = isset($_GET['etab_id']) ? (int)$_GET['etab_id'] : 0;
}

$extra = isset($payload) ? $payload : null;
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Paiement Reussi | Licences INOFIB</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body { background: #0a0a0f; display: flex; align-items: center; justify-content: center; min-height: 100vh; font-family: 'Segoe UI', system-ui, sans-serif; color:#fff; }
        .success-card { background: #1e1e2f; padding: 40px; border-radius: 20px; text-align: center; max-width: 480px; border: 1px solid #2d2d44; }
        .icon-success { font-size: 70px; color: #198754; margin-bottom: 20px; }
    </style>
</head>
<body>

<div class="success-card">
    <div class="icon-success">
        <i class="fa-solid fa-circle-check"></i>
    </div>
    <h2 class="fw-bold mb-3">Paiement confirme !</h2>
    <p class="text-white-50 mb-4">Votre licence GESCO-APC est en cours d'activation. Vous pouvez des a present telecharger et installer votre cle de licence.</p>

        <div class="bg-dark p-3 rounded-3 mb-4 text-start border border-secondary">
        <?php if ($extra && isset($extra['external_reference'])): ?>
        <div class="d-flex justify-content-between mb-2">
            <span class="text-muted small">Reference commande :</span>
            <span class="fw-bold small text-white"><?= htmlspecialchars($extra['external_reference']) ?></span>
        </div>
        <?php endif; ?>

        <div class="d-flex justify-content-between mb-2">
            <span class="text-muted small">Reference Assiin :</span>
            <span class="fw-bold small text-white"><?= htmlspecialchars($reference) ?></span>
        </div>
        <?php if ($amount > 0): ?>
        <div class="d-flex justify-content-between mb-2">
            <span class="text-muted small">Montant paye :</span>
            <span class="fw-bold small text-success"><?= number_format($amount, 0, '.', ' ') ?> XAF</span>
        </div>
        <?php endif; ?>
        <div class="d-flex justify-content-between">
            <span class="text-muted small">Origine du signal :</span>
            <span>
                <?php if ($verified): ?>
                    <span class="badge bg-success-subtle text-success border border-success-subtle"><i class="fa-solid fa-shield me-1"></i>Verifie par Assiin</span>
                <?php else: ?>
                    <span class="badge bg-warning-subtle text-warning border border-warning-subtle"><i class="fa-solid fa-circle-info me-1"></i>Non signe</span>
                <?php endif; ?>
            </span>
        </div>
    </div>

    <div class="d-grid gap-2">
        <?php if ($etab_id > 0): ?>
        <a href="../telecharger_cle.php?etab_id=<?= $etab_id ?>&type=licence" class="btn btn-warning btn-lg rounded-pill fw-bold py-2 fs-6 text-dark">
            <i class="fa-solid fa-download me-2"></i>Telecharger ma cle de licence
        </a>
        <?php endif; ?>
        <a href="../index.php" class="btn btn-outline-secondary btn-lg rounded-pill fw-bold py-2 fs-6 border-0">
            <i class="fa-solid fa-house me-2"></i>Retour a l'accueil
        </a>
    </div>
</div>

</body>
</html>