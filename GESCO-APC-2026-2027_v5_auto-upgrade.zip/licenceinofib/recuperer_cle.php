<?php
require_once 'config.php';
require_once 'Model/connexion.php';
require_once 'classes/Etablissement.php';
require_once 'classes/Mailer.php';

session_start();

$db = Base::connexion();
$etab = new Etablissement($db);

$action = $_POST['action'] ?? ($_GET['action'] ?? '');
$resultats = null;
$recherche_ok = false;
$email_envoye = null;   // info de l'envoi
$lien_fourni = null;    // lien de secours affiche a l'ecran
$erreur = null;

// ------------------------------------------------------------
// ENVOI DU LIEN PAR EMAIL
// ------------------------------------------------------------
if ($action === 'envoyer' && ($etab_id = (int)($_POST['etab_id'] ?? 0))) {
    $row = $etab->parId($etab_id);
    if ($row) {
        $produit = $row['produit'] ?? 'GESCO-APC';
        $info = produit_info($produit);
        $token = $etab->creerTokenRecup($etab_id, $produit, 'telecharger');
        $lien = url_portail('/telecharger_cle.php?token=' . rawurlencode($token));
        $lien_fourni = $lien;

        $expire_texte = date('d/m/Y H:i', time() + RECUP_TOKEN_VALIDITE_H * 3600);
        $objet = "Votre licence " . ($info['titre'] ?? $produit) . " INOFIB - lien de telechargement";
        $corps = '<html><body style="font-family:Arial;color:#222">'
            . '<h2 style="color:#0764a8">Bonjour ' . htmlspecialchars($row['nom_etab']) . ',</h2>'
            . '<p>Suite a votre demande, voici le lien pour <b>telecharger a nouveau votre clé de licence</b> déjà payée :</p>'
            . '<p style="text-align:center"><a href="' . htmlspecialchars($lien) . '" style="background:#19784f;color:#fff;padding:10px 22px;border-radius:6px;text-decoration:none">Telecharger ma clé de licence</a></p>'
            . '<p>Ce lien expire le <b>' . $expire_texte . '</b> et ne fonctionne qu\'une seule fois.</p>'
            . '<p>Votre identifiant d\'installation (a saisir dans le logiciel en cas de panne ou de changement d\'ordinateur) :</p>'
            . '<p style="background:#f0f7ff;border:1px solid #0764a8;padding:10px;font-family:monospace;letter-spacing:1px">' . htmlspecialchars($row['install_id']) . '</p>'
            . '<p>Après téléchargement, ouvrez le logiciel sur l\'ordinateur concerné, ecran d\'activation : saisissez ou collez cet install_id, puis la clé.</p>'
            . '<hr><p style="color:#888;font-size:12px">INOFIB - Gestion des licences. Contact : ' . htmlspecialchars(EMAIL_CONTACT) . '</p>'
            . '</body></html>';
        $ok = Mailer::envoyer($row['email'], $objet, $corps);
        $email_envoye = $ok;
    }
}

// ------------------------------------------------------------
// RECHERCHE PAR NOM + EMAIL (+ abreviation / NIU en aide)
// ------------------------------------------------------------
if ($action === 'recherche') {
    $nom = trim($_POST['nom_etab'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $abrege = trim($_POST['abrege'] ?? '');
    $niu = trim($_POST['niu'] ?? '');
    if ($nom === '' || $email === '') {
        $erreur = 'Indiquez le nom de votre etablissement et l\'adresse email utilisee lors de l\'achat.';
    } else {
        $resultats = $etab->rechercherParNomEmail($nom, $email, $abrege !== '' ? $abrege : null, $niu !== '' ? $niu : null);
        $recherche_ok = true;
    }
}

// Pour re-afficher les resultats apres un envoi
if ($action === 'envoyer') {
    $resultats = $etab->rechercherParNomEmail(
        $_POST['nom_cache'] ?? '',
        $_POST['email_cache'] ?? '',
        ($_POST['abrege_cache'] ?? '') !== '' ? $_POST['abrege_cache'] : null,
        ($_POST['niu_cache'] ?? '') !== '' ? $_POST['niu_cache'] : null
    );
    if (empty($resultats)) {
        $resultats = null;
    }
    $recherche_ok = true;
}

function statut_rang($row)
{
    if (empty($row['licence_key'])) {
        return 'attente';
    }
    return strtotime($row['fin_licence']) >= time() ? 'valide' : 'expire';
}
function badge_statut($s)
{
    return [
        'valide' => '<span class="badge bg-success-subtle text-success border border-success-subtle">VALIDE</span>',
        'expire' => '<span class="badge bg-warning-subtle text-warning border border-warning-subtle">EXPIREE</span>',
        'attente' => '<span class="badge bg-secondary-subtle text-secondary border border-secondary-subtle">NON PAYEE</span>',
    ][$s] ?? '';
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Recuperer ma licence - INOFIB</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body { background: #0a0a0f; color: #fff; font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; padding-bottom: 60px; }
        .topbar { padding: 24px 0; }
        .card-dark { background: #1e1e2f; border: 1px solid #2d2d44; border-radius: 20px; padding: 28px; }
        .form-control, .form-select { background: #151522; border-color: #2d2d44; color: #fff; }
        .form-control:focus { background: #151522; color: #fff; border-color: #0d6efd; box-shadow: 0 0 0 .2rem rgba(13,110,253,.15); }
        .form-label { color: #b9bfd4; font-size: .85rem; font-weight: 600; }
        .row-result { background: #151522; border: 1px solid #2d2d44; border-radius: 14px; padding: 18px 20px; }
        .install-mono { font-family: Consolas, monospace; letter-spacing: 1px; color: #6ea8fe; font-size: .83rem; word-break: break-all; }
        .badge-produit { background: rgba(255,193,7,.12); color: #ffc107; border: 1px solid rgba(255,193,7,.35); border-radius: 50rem; padding: 3px 10px; font-size: .7rem; }
    </style>
</head>
<body>

<div class="container">
    <div class="topbar d-flex justify-content-between align-items-center">
        <a href="index.php" class="text-white-50 text-decoration-none"><i class="fa-solid fa-arrow-left me-2"></i>Retour</a>
        <span class="text-white-50 small"><i class="fa-solid fa-shield-halved me-1 text-warning"></i>INOFIB</span>
    </div>

    <div class="row justify-content-center">
        <div class="col-lg-7">
            <div class="card-dark mb-4">
                <h3 class="fw-bold mb-1"><i class="fa-solid fa-key me-2 text-warning"></i>Recuperer une licence deja payee</h3>
                <p class="text-white-50 small mb-1">Clé perdue, email perdu ou ordinateur en panne / remplacé en cours d'année : retrouvez votre licence en indiquant le nom exact de votre établissement et l'adresse email utilisée à l'achat.</p>

                <?php if ($erreur): ?>
                <div class="alert alert-danger py-2 small mt-3"><?= e($erreur) ?></div>
                <?php endif; ?>

                <?php if ($email_envoye !== null): ?>
                <div class="alert <?= $email_envoye ? 'alert-success' : 'alert-warning' ?> py-2 small mt-3">
                    <?= $email_envoye
                        ? '<i class="fa-solid fa-check me-1"></i>Le lien de téléchargement a été envoyé par email. Il expirera dans 48h et ne sera valable qu\'une seule fois.'
                        : 'Envoi email impossible sur ce serveur (SMTP non configuré). Utilisez le lien de secours ci-dessous.' ?>
                </div>
                <?php endif; ?>

                <?php if ($lien_fourni): ?>
                <div class="alert alert-info py-2 small mt-2">
                    Lien de secours (une seule utilisation, 48h) :
                    <div class="break-word mt-1" style="word-break:break-all;"><code style="color:#0dcaf0;"><?= e($lien_fourni) ?></code></div>
                </div>
                <?php endif; ?>

                <form method="POST" class="row g-2 mt-2">
                    <input type="hidden" name="action" value="recherche">
                    <div class="col-md-7">
                        <label class="form-label">Nom de l'etablissement *</label>
                        <input type="text" name="nom_etab" class="form-control" required value="<?= e($_POST['nom_etab'] ?? '') ?>" placeholder="Ex : Lycee Bilingue de Yaounde">
                    </div>
                    <div class="col-md-5">
                        <label class="form-label">Email utilise a l'achat *</label>
                        <input type="email" name="email" class="form-control" required value="<?= e($_POST['email'] ?? '') ?>" placeholder="direction@ecole.cm">
                    </div>
                    <div class="col-md-6">
                        <label class="form-label">Abreviation (optionnel)</label>
                        <input type="text" name="abrege" class="form-control" value="<?= e($_POST['abrege'] ?? '') ?>" placeholder="Ex : LB-YDE">
                    </div>
                    <div class="col-md-6">
                        <label class="form-label">NIU / matricule (optionnel)</label>
                        <input type="text" name="niu" class="form-control" value="<?= e($_POST['niu'] ?? '') ?>" placeholder="Ex : M02#####">
                    </div>
                    <div class="col-12 mt-3">
                        <button class="btn btn-primary w-100 rounded-pill fw-bold py-2"><i class="fa-solid fa-magnifying-glass me-2"></i>Rechercher ma licence</button>
                    </div>
                </form>
            </div>

            <?php if ($recherche_ok && empty($resultats)): ?>
            <div class="alert alert-warning py-2 small"><i class="fa-solid fa-circle-exclamation me-1"></i>Aucun établissement ne correspond à ce nom et à cet email<?= (($_POST['abrege'] ?? '') !== '' || ($_POST['niu'] ?? '') !== '') ? ' (ni à l\'abréviation / NIU fournis)' : '' ?>. Vérifiez l'orthographe ou contactez <?= e(EMAIL_CONTACT) ?>.</div>
            <?php elseif ($recherche_ok && !empty($resultats)): ?>
            <h6 class="fw-bold text-white-50 small text-uppercase mb-3"><?= count($resultats) ?> établissement(s) trouvé(s)</h6>
            <?php foreach ($resultats as $row): $statut = statut_rang($row); $info = produit_info($row['produit'] ?? 'GESCO-APC'); $type_lic = $etab->derniereTypeLicence((int)$row['id']); ?>
            <div class="row-result mb-3">
                <div class="d-flex flex-wrap justify-content-between align-items-start gap-2">
                    <div>
                        <h6 class="mb-1 text-white"><?= e($row['nom_etab']) ?><?= $info ? ' <span class="badge-produit">' . e($info['titre']) . '</span>' : '' ?>
                            <?php if ($type_lic === 'essai'): ?><span class="badge bg-info-subtle text-info border border-info-subtle" style="font-size:.62rem;">ESSAI GRATUIT</span><?php endif; ?></h6>
                        <div class="small text-white-50 mb-1"><?= e($row['ville']) ?><?= !empty($row['abrege']) ? ' · ' . e($row['abrege']) : '' ?><?= !empty($row['niu']) ? ' · NIU ' . e($row['niu']) : '' ?> · Année <?= e($row['annee_scolaire'] ?? '-') ?> · Tarif <?= e(strtoupper($row['tarif_code'] ?? '-')) ?> · Effectif <?= (int)$row['nb_eleves'] ?> élèves
                            <?= isset($row['nb_eleves_reel']) && (int)$row['nb_eleves_reel'] > 0 ? '(réel constaté : ' . (int)$row['nb_eleves_reel'] . ')' : '' ?></div>
                        <div class="install-mono"><?= e($row['install_id']) ?></div>
                        <div class="small text-white-50 mt-1">Licence du <?= e($row['debut_licence'] ?? '-') ?> au <?= e($row['fin_licence'] ?? '-') ?> <?= badge_statut($statut) ?></div>
                    </div>
                    <div class="d-flex flex-column gap-2" style="min-width:220px;">
                        <?php if ($statut === 'valide'): ?>
                            <form method="POST">
                                <input type="hidden" name="action" value="envoyer">
                                <input type="hidden" name="etab_id" value="<?= (int)$row['id'] ?>">
                                <input type="hidden" name="nom_cache" value="<?= e($_POST['nom_etab'] ?? '') ?>">
                                <input type="hidden" name="email_cache" value="<?= e($_POST['email'] ?? '') ?>">
                                <input type="hidden" name="abrege_cache" value="<?= e($_POST['abrege'] ?? '') ?>">
                                <input type="hidden" name="niu_cache" value="<?= e($_POST['niu'] ?? '') ?>">
                                <button class="btn btn-warning btn-sm w-100 rounded-pill fw-bold text-dark"><i class="fa-solid fa-envelope me-1"></i>Envoyer le lien par email</button>
                            </form>
                            <a href="telecharger_cle.php?etab_id=<?= (int)$row['id'] ?>&type=licence" class="btn btn-outline-warning btn-sm w-100 rounded-pill fw-bold"><i class="fa-solid fa-download me-1"></i>Telecharger maintenant</a>
                        <?php elseif ($statut === 'expire'): ?>
                            <a href="service.php?produit=<?= rawurlencode($row['produit'] ?? 'GESCO-APC') ?>&mode=renouvellement&install_id=<?= rawurlencode($row['install_id']) ?>&nom_etab=<?= rawurlencode($row['nom_etab']) ?>&email=<?= rawurlencode($row['email'] ?? '') ?>&nb_eleves=<?= max((int)($row['nb_eleves_reel'] ?? 0), (int)$row['nb_eleves']) ?><?= !empty($row['annee_scolaire']) ? '&annee_scolaire=' . rawurlencode($row['annee_scolaire']) : '' ?>" class="btn btn-primary btn-sm w-100 rounded-pill fw-bold"><i class="fa-solid fa-arrow-rotate-right me-1"></i>Renouveler (effectif modifiable)</a>
                        <?php else: ?>
                            <a href="service.php?produit=<?= rawurlencode($row['produit'] ?? 'GESCO-APC') ?>&install_id=<?= rawurlencode($row['install_id']) ?>&nom_etab=<?= rawurlencode($row['nom_etab']) ?>&email=<?= rawurlencode($row['email'] ?? '') ?><?= !empty($row['annee_scolaire']) ? '&annee_scolaire=' . rawurlencode($row['annee_scolaire']) : '' ?>" class="btn btn-primary btn-sm w-100 rounded-pill fw-bold"><i class="fa-solid fa-credit-card me-1"></i>Procéder au paiement</a>
                        <?php endif; ?>
                    </div>
                </div>

                <?php if ($statut === 'valide'): ?>
                <div class="small text-white-50 mt-2 pt-2" style="border-top:1px dashed #2d2d44;">
                    <i class="fa-solid fa-circle-info me-1 text-info"></i>
                    <?php if ($type_lic === 'essai'): ?>
                        <b>Licence d'evaluation gratuite.</b> Elle expire le <b><?= e($row['fin_licence']) ?></b>. Après expiration, abonnez-vous : vous payez uniquement les <?= DUREE_PAYEE_MOIS ?> mois restants, et la clé d'abonnement remplacera l'essai.
                    <?php else: ?>
                        <b>Ordinateur en panne ou remplacé ?</b> Téléchargez la clé ci-dessus, puis sur la nouvelle installation, à l'écran d'activation, saisissez l'identifiant <code class="install-mono"><?= e($row['install_id']) ?></code> (ou collez-le), collez la clé : votre licence fonctionne immédiatement.
                    <?php endif; ?>
                </div>
                <?php endif; ?>
            </div>
            <?php endforeach; ?>
            <?php endif; ?>

            <div class="small text-white-50 mt-3">
                <i class="fa-solid fa-lock me-1 text-warning"></i> Pour votre sécurité, seule une clé <b>signée par INOFIB</b>, valide et correspondant à votre identifiant d'installation, peut être activée sur votre ordinateur.
            </div>
        </div>
    </div>
</div>

</body>
</html>