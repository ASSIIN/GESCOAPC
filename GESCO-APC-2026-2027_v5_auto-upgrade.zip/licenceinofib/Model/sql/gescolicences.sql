-- ============================================================
--  LICENCES INOFIB - Base de donnees complete
--  Gestion des licences annuelles (GESCO-APC et services)
-- ============================================================

CREATE DATABASE IF NOT EXISTS `licenceinofib`
  CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE `licenceinofib`;

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ------------------------------------------------------------
-- Tarifs officiels du service GESCO-APC (par produit et tranche)
-- Plafond de 500 000 XAF/an par etablissement.
-- Nouveau en 2026 : tranches 300 / 700 / 1500 / 2000 eleves.
-- ------------------------------------------------------------
DROP TABLE IF EXISTS `tarifs`;
CREATE TABLE `tarifs` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `code` VARCHAR(10) NOT NULL,
  `libelle` VARCHAR(160) NOT NULL,
  `min_eleves` INT NOT NULL DEFAULT 1,
  `max_eleves` INT DEFAULT NULL,
  `prix_xaf` INT NOT NULL,
  `produit` VARCHAR(40) NOT NULL DEFAULT 'GESCO-APC',
  KEY `idx_tarif_code` (`code`),
  UNIQUE KEY `unq_tarif_produit_code` (`produit`, `code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `tarifs` (`code`, `libelle`, `min_eleves`, `max_eleves`, `prix_xaf`, `produit`) VALUES
('t1', 'Licence annuelle (1 a 300 eleves)',         1,   300,  50000, 'GESCO-APC'),
('t2', 'Licence annuelle (301 a 700 eleves)',      301,   700, 100000, 'GESCO-APC'),
('t3', 'Licence annuelle (701 a 1500 eleves)',     701,  1500, 200000, 'GESCO-APC'),
('t4', 'Licence annuelle (1501 a 2000 eleves)',   1501,  2000, 350000, 'GESCO-APC'),
('t5', 'Licence annuelle (plus de 2000 eleves)',  2001,  NULL, 500000, 'GESCO-APC'),
('t1', 'Licence annuelle (1 a 300 eleves)',         1,   300,  35000, 'NDALERE-PRIM'),
('t2', 'Licence annuelle (301 a 700 eleves)',      301,   700,  70000, 'NDALERE-PRIM'),
('t3', 'Licence annuelle (701 a 1500 eleves)',     701,  1500, 140000, 'NDALERE-PRIM'),
('t4', 'Licence annuelle (1501 a 2000 eleves)',   1501,  2000, 250000, 'NDALERE-PRIM'),
('t5', 'Licence annuelle (plus de 2000 eleves)',  2001,  NULL, 500000, 'NDALERE-PRIM');

-- ------------------------------------------------------------
-- Etablissements clients et leurs licences
-- ------------------------------------------------------------
DROP TABLE IF EXISTS `etablissements`;
CREATE TABLE `etablissements` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `nom_etab` VARCHAR(255) NOT NULL,
  `install_id` VARCHAR(64) NOT NULL UNIQUE,
  `ville` VARCHAR(120) DEFAULT NULL,
  `email` VARCHAR(120) DEFAULT NULL,
  `telephone` VARCHAR(40) DEFAULT NULL,
  `nb_eleves` INT NOT NULL DEFAULT 0,
  `tarif_code` VARCHAR(10) DEFAULT NULL,
  `licence_key` LONGTEXT DEFAULT NULL,
  `cle_priv_etab` LONGTEXT DEFAULT NULL,
  `cle_pub_etab` LONGTEXT DEFAULT NULL,
  `debut_licence` DATE DEFAULT NULL,
  `fin_licence` DATE DEFAULT NULL,
  `nb_poste` INT NOT NULL DEFAULT 1,
  `statut` VARCHAR(20) NOT NULL DEFAULT 'en_attente',
  `cree_le` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `produit` VARCHAR(40) NOT NULL DEFAULT 'GESCO-APC',
  `abrege` VARCHAR(80) DEFAULT NULL,
  `niu` VARCHAR(40) DEFAULT NULL,
  `annee_scolaire` VARCHAR(20) DEFAULT NULL,
  `nb_eleves_reel` INT NOT NULL DEFAULT 0,
  `version_logiciel` VARCHAR(120) DEFAULT NULL,
  `derniere_sync` DATETIME DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ------------------------------------------------------------
-- Historique des licences par etablissement
-- ------------------------------------------------------------
DROP TABLE IF EXISTS `licences`;
CREATE TABLE `licences` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `etab_id` INT NOT NULL,
  `produit` VARCHAR(40) NOT NULL DEFAULT 'GESCO-APC',
  `tarif_code` VARCHAR(10) DEFAULT NULL,
  `montant` INT NOT NULL DEFAULT 0,
  `licence_key` LONGTEXT DEFAULT NULL,
  `debut` DATE DEFAULT NULL,
  `fin` DATE DEFAULT NULL,
  `statut` VARCHAR(20) NOT NULL DEFAULT 'active',
  `type` VARCHAR(20) NOT NULL DEFAULT 'abo',
  `annee_scolaire` VARCHAR(20) DEFAULT NULL,
  `cree_le` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  KEY `fk_licence_etab` (`etab_id`),
  CONSTRAINT `fk_licence_etab` FOREIGN KEY (`etab_id`) REFERENCES `etablissements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ------------------------------------------------------------
-- Commandes de paiement (trace de la passerelle Assiin Pay)
-- ------------------------------------------------------------
DROP TABLE IF EXISTS `commandes`;
CREATE TABLE `commandes` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `ref_commande` VARCHAR(64) NOT NULL UNIQUE,
  `etab_id` INT NOT NULL,
  `tarif_code` VARCHAR(10) DEFAULT NULL,
  `montant` INT NOT NULL DEFAULT 0,
  `statut` VARCHAR(20) NOT NULL DEFAULT 'en_attente',
  `ref_passerelle` VARCHAR(64) DEFAULT NULL,
  `external_reference` VARCHAR(64) DEFAULT NULL,
  `cree_le` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `paye_le` DATETIME DEFAULT NULL,
  `produit` VARCHAR(40) NOT NULL DEFAULT 'GESCO-APC',
  `annee_scolaire` VARCHAR(20) DEFAULT NULL,
  KEY `fk_commande_etab` (`etab_id`),
  CONSTRAINT `fk_commande_etab` FOREIGN KEY (`etab_id`) REFERENCES `etablissements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ------------------------------------------------------------
-- Comptes super administrateurs
-- ------------------------------------------------------------
DROP TABLE IF EXISTS `admins`;
CREATE TABLE `admins` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `login` VARCHAR(60) NOT NULL UNIQUE,
  `password` VARCHAR(255) NOT NULL,
  `role` VARCHAR(20) NOT NULL DEFAULT 'super_admin',
  `cree_le` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Mot de passe par defaut du super admin : InofibMaster2026
-- A changer apres la premiere connexion (espace admin).
INSERT INTO `admins` (`login`, `password`, `role`) VALUES
('superadmin', '$2y$10$wiRFZJ0IBAhXqxUQckpB9e.weXvTPfT5DqBz/0yoEIimzTIN4DkL6', 'super_admin');

-- ------------------------------------------------------------
-- Configuration generale
-- ------------------------------------------------------------
DROP TABLE IF EXISTS `config`;
CREATE TABLE `config` (
  `id` INT PRIMARY KEY,
  `nom_site` VARCHAR(120) DEFAULT 'Licences INOFIB',
  `email_contact` VARCHAR(120) DEFAULT 'licences@inofib.com',
  `cle_publique` LONGTEXT DEFAULT NULL,
  `updated_at` DATETIME DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `config` (`id`, `nom_site`, `email_contact`, `updated_at`) VALUES
(1, 'Licences INOFIB', 'licences@inofib.com', NOW());

-- ------------------------------------------------------------
-- Jetons de recuperation d'une licence deja payee (par email)
-- ------------------------------------------------------------
DROP TABLE IF EXISTS `recup_tokens`;
CREATE TABLE `recup_tokens` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `token` VARCHAR(64) NOT NULL UNIQUE,
  `etab_id` INT NOT NULL,
  `produit` VARCHAR(40) NOT NULL,
  `type` VARCHAR(20) NOT NULL DEFAULT 'telecharger',
  `expire_le` DATETIME NOT NULL,
  `consomme` TINYINT NOT NULL DEFAULT 0,
  `cree_le` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  KEY `fk_recup_etab` (`etab_id`),
  CONSTRAINT `fk_recup_etab` FOREIGN KEY (`etab_id`) REFERENCES `etablissements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ------------------------------------------------------------
-- Remontee telemetrique des clients (sauvegarde auto + controle effectif)
-- ------------------------------------------------------------
DROP TABLE IF EXISTS `telemetrie`;
CREATE TABLE `telemetrie` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `etab_id` INT NOT NULL,
  `produit` VARCHAR(40) NOT NULL DEFAULT 'GESCO-APC',
  `install_id` VARCHAR(64) DEFAULT NULL,
  `version_logiciel` VARCHAR(120) DEFAULT NULL,
  `nb_eleves` INT NOT NULL DEFAULT 0,
  `par_niveau` LONGTEXT,
  `tarif_code` VARCHAR(10) DEFAULT NULL,
  `depassement` TINYINT NOT NULL DEFAULT 0,
  `payload` LONGTEXT,
  `cree_le` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  KEY `fk_telemetrie_etab` (`etab_id`),
  CONSTRAINT `fk_telemetrie_etab` FOREIGN KEY (`etab_id`) REFERENCES `etablissements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

SET FOREIGN_KEY_CHECKS = 1;