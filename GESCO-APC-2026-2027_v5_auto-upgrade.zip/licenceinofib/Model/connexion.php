<?php
require_once __DIR__ . '/../config.php';

class Base
{
    private static $pdo = null;

    public static function connexion()
    {
        if (self::$pdo !== null) {
            return self::$pdo;
        }

        // Securite deploiement : ne jamais creer de "fatal error" si une constante
        // DB_* manque au serveur (config locale vs production). Fallback getenv,
        // puis valeurs locales de developpement.
        if (!defined('DB_HOST')) { define('DB_HOST', getenv('DB_HOST') ?: 'localhost'); }
        if (!defined('DB_NAME')) { define('DB_NAME', getenv('DB_NAME') ?: 'licenceinofib'); }
        if (!defined('DB_USER')) { define('DB_USER', getenv('DB_USER') ?: 'root'); }
        if (!defined('DB_PASS')) { define('DB_PASS', getenv('DB_PASS') ?: ''); }

        $opts = [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false,
        ];

        try {
            $pdo = new PDO('mysql:host=' . DB_HOST . ';charset=utf8mb4', DB_USER, DB_PASS, $opts);
        } catch (PDOException $e) {
            die('Connexion base de donnees impossible : ' . $e->getMessage());
        }

        $pdo->exec("CREATE DATABASE IF NOT EXISTS `" . DB_NAME . "` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");
        $pdo->exec("USE `" . DB_NAME . "`");

        self::verifierTables($pdo);

        self::$pdo = $pdo;
        return $pdo;
    }

    private static function ajoutColonne($pdo, $table, $col, $def)
    {
        $rs = $pdo->query("SELECT COUNT(*) FROM information_schema.COLUMNS
            WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = " . $pdo->quote($table)
            . " AND COLUMN_NAME = " . $pdo->quote($col));
        if ((int)$rs->fetchColumn() === 0) {
            $pdo->exec("ALTER TABLE `$table` ADD COLUMN `$col` $def");
        }
    }

    private static function verifierTables($pdo)
    {
        $pdo->exec("CREATE TABLE IF NOT EXISTS tarifs (
            id INT AUTO_INCREMENT PRIMARY KEY,
            code VARCHAR(10) NOT NULL UNIQUE,
            libelle VARCHAR(160) NOT NULL,
            min_eleves INT NOT NULL DEFAULT 1,
            max_eleves INT DEFAULT NULL,
            prix_xaf INT NOT NULL
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

        $pdo->exec("CREATE TABLE IF NOT EXISTS etablissements (
            id INT AUTO_INCREMENT PRIMARY KEY,
            nom_etab VARCHAR(255) NOT NULL,
            install_id VARCHAR(64) NOT NULL UNIQUE,
            ville VARCHAR(120) DEFAULT NULL,
            email VARCHAR(120) DEFAULT NULL,
            telephone VARCHAR(40) DEFAULT NULL,
            nb_eleves INT NOT NULL DEFAULT 0,
            tarif_code VARCHAR(10) DEFAULT NULL,
            licence_key LONGTEXT DEFAULT NULL,
            cle_priv_etab LONGTEXT DEFAULT NULL,
            cle_pub_etab LONGTEXT DEFAULT NULL,
            debut_licence DATE DEFAULT NULL,
            fin_licence DATE DEFAULT NULL,
            nb_poste INT NOT NULL DEFAULT 1,
            statut VARCHAR(20) NOT NULL DEFAULT 'en_attente',
            cree_le DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

        // Evolution du schema : multi-produits + telemetrie
        self::ajoutColonne($pdo, 'etablissements', 'produit', "VARCHAR(40) NOT NULL DEFAULT 'GESCO-APC'");
        self::ajoutColonne($pdo, 'etablissements', 'nb_eleves_reel', 'INT NOT NULL DEFAULT 0');
        self::ajoutColonne($pdo, 'etablissements', 'version_logiciel', 'VARCHAR(120) DEFAULT NULL');
        self::ajoutColonne($pdo, 'etablissements', 'derniere_sync', 'DATETIME DEFAULT NULL');

        // Identification complementaire (doublons de noms entre etablissements)
        self::ajoutColonne($pdo, 'etablissements', 'abrege', 'VARCHAR(80) DEFAULT NULL');
        self::ajoutColonne($pdo, 'etablissements', 'niu', 'VARCHAR(40) DEFAULT NULL');

        // Une licence couvre une annee scolaire (ex : "26_27")
        self::ajoutColonne($pdo, 'etablissements', 'annee_scolaire', "VARCHAR(20) DEFAULT NULL");

        $pdo->exec("CREATE TABLE IF NOT EXISTS licences (
            id INT AUTO_INCREMENT PRIMARY KEY,
            etab_id INT NOT NULL,
            tarif_code VARCHAR(10) DEFAULT NULL,
            montant INT NOT NULL DEFAULT 0,
            licence_key LONGTEXT DEFAULT NULL,
            debut DATE DEFAULT NULL,
            fin DATE DEFAULT NULL,
            statut VARCHAR(20) NOT NULL DEFAULT 'active',
            cree_le DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            KEY fk_licence_etab (etab_id),
            CONSTRAINT fk_licence_etab FOREIGN KEY (etab_id) REFERENCES etablissements (id) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
        self::ajoutColonne($pdo, 'licences', 'produit', "VARCHAR(40) NOT NULL DEFAULT 'GESCO-APC'");
        self::ajoutColonne($pdo, 'licences', 'type', "VARCHAR(20) NOT NULL DEFAULT 'payee'");
        self::ajoutColonne($pdo, 'licences', 'annee_scolaire', 'VARCHAR(20) DEFAULT NULL');

        $pdo->exec("CREATE TABLE IF NOT EXISTS commandes (
            id INT AUTO_INCREMENT PRIMARY KEY,
            ref_commande VARCHAR(64) NOT NULL UNIQUE,
            etab_id INT NOT NULL,
            tarif_code VARCHAR(10) DEFAULT NULL,
            montant INT NOT NULL DEFAULT 0,
            statut VARCHAR(20) NOT NULL DEFAULT 'en_attente',
            ref_passerelle VARCHAR(64) DEFAULT NULL,
            external_reference VARCHAR(64) DEFAULT NULL,
            cree_le DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            paye_le DATETIME DEFAULT NULL,
            KEY fk_commande_etab (etab_id),
            CONSTRAINT fk_commande_etab FOREIGN KEY (etab_id) REFERENCES etablissements (id) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
        self::ajoutColonne($pdo, 'commandes', 'produit', "VARCHAR(40) NOT NULL DEFAULT 'GESCO-APC'");
        self::ajoutColonne($pdo, 'commandes', 'annee_scolaire', 'VARCHAR(20) DEFAULT NULL');

        $pdo->exec("CREATE TABLE IF NOT EXISTS admins (
            id INT AUTO_INCREMENT PRIMARY KEY,
            login VARCHAR(60) NOT NULL UNIQUE,
            password VARCHAR(255) NOT NULL,
            role VARCHAR(20) NOT NULL DEFAULT 'super_admin',
            cree_le DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

        $pdo->exec("CREATE TABLE IF NOT EXISTS config (
            id INT PRIMARY KEY,
            nom_site VARCHAR(120) DEFAULT 'Licences INOFIB',
            email_contact VARCHAR(120) DEFAULT 'licences@inofib.com',
            cle_publique LONGTEXT DEFAULT NULL,
            updated_at DATETIME DEFAULT NULL
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

        // Jeton(s) de telechargement d'une licence deja payee (recuperation)
        $pdo->exec("CREATE TABLE IF NOT EXISTS recup_tokens (
            id INT AUTO_INCREMENT PRIMARY KEY,
            token VARCHAR(64) NOT NULL UNIQUE,
            etab_id INT NOT NULL,
            produit VARCHAR(40) NOT NULL,
            type VARCHAR(20) NOT NULL DEFAULT 'telecharger',
            expire_le DATETIME NOT NULL,
            consomme TINYINT NOT NULL DEFAULT 0,
            cree_le DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            KEY fk_recup_etab (etab_id),
            CONSTRAINT fk_recup_etab FOREIGN KEY (etab_id) REFERENCES etablissements (id) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

        // Remontee telemetrique des clients (sauvegarde/archive + controle effectif)
        $pdo->exec("CREATE TABLE IF NOT EXISTS telemetrie (
            id INT AUTO_INCREMENT PRIMARY KEY,
            etab_id INT NOT NULL,
            produit VARCHAR(40) NOT NULL DEFAULT 'GESCO-APC',
            install_id VARCHAR(64) DEFAULT NULL,
            version_logiciel VARCHAR(120) DEFAULT NULL,
            nb_eleves INT NOT NULL DEFAULT 0,
            par_niveau LONGTEXT,
            tarif_code VARCHAR(10) DEFAULT NULL,
            depassement TINYINT NOT NULL DEFAULT 0,
            payload LONGTEXT,
            cree_le DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            KEY fk_telemetrie_etab (etab_id),
            CONSTRAINT fk_telemetrie_etab FOREIGN KEY (etab_id) REFERENCES etablissements (id) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

        // Grille tarifaire par produit (t1..t5, plafond 500 000 XAF/an)
        self::ajoutColonne($pdo, 'tarifs', 'produit', "VARCHAR(40) NOT NULL DEFAULT 'GESCO-APC'");
        // Supprimer l'ancien unique sur `code` seul (incompatible produit + code)
        $idxCode = $pdo->query("SELECT COUNT(*) FROM information_schema.STATISTICS
            WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'tarifs' AND INDEX_NAME = 'code'")->fetchColumn();
        if ((int)$idxCode > 0) {
            $pdo->exec("ALTER TABLE tarifs DROP INDEX code");
        }
        $uniqueTarifs = $pdo->query("SELECT COUNT(*) FROM information_schema.STATISTICS
            WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'tarifs' AND INDEX_NAME = 'unq_tarif_produit_code'")->fetchColumn();
        if ((int)$uniqueTarifs === 0) {
            $pdo->exec("ALTER TABLE tarifs ADD UNIQUE KEY unq_tarif_produit_code (produit, code)");
        }
        $stmt = $pdo->prepare("INSERT INTO tarifs (produit, code, libelle, min_eleves, max_eleves, prix_xaf) VALUES (?, ?, ?, ?, ?, ?)
            ON DUPLICATE KEY UPDATE libelle = VALUES(libelle), min_eleves = VALUES(min_eleves), max_eleves = VALUES(max_eleves), prix_xaf = VALUES(prix_xaf)");
        $lignes = [
            ['GESCO-APC', 't1', 'Licence annuelle (1 a 300 eleves)', 1, 300, 50000],
            ['GESCO-APC', 't2', 'Licence annuelle (301 a 700 eleves)', 301, 700, 100000],
            ['GESCO-APC', 't3', 'Licence annuelle (701 a 1500 eleves)', 701, 1500, 200000],
            ['GESCO-APC', 't4', 'Licence annuelle (1501 a 2000 eleves)', 1501, 2000, 350000],
            ['GESCO-APC', 't5', 'Licence annuelle (plus de 2000 eleves)', 2001, null, 500000],
            ['NDALERE-PRIM', 't1', 'Licence annuelle (1 a 300 eleves)', 1, 300, 35000],
            ['NDALERE-PRIM', 't2', 'Licence annuelle (301 a 700 eleves)', 301, 700, 70000],
            ['NDALERE-PRIM', 't3', 'Licence annuelle (701 a 1500 eleves)', 701, 1500, 140000],
            ['NDALERE-PRIM', 't4', 'Licence annuelle (1501 a 2000 eleves)', 1501, 2000, 250000],
            ['NDALERE-PRIM', 't5', 'Licence annuelle (plus de 2000 eleves)', 2001, null, 500000],
        ];
        foreach ($lignes as $l) {
            $stmt->execute($l);
        }

        $nbAdmins = $pdo->query("SELECT COUNT(*) AS n FROM admins")->fetch()['n'];
        if ((int)$nbAdmins === 0) {
            $hash = password_hash('InofibMaster2026', PASSWORD_BCRYPT);
            $stmt = $pdo->prepare("INSERT INTO admins (login, password, role) VALUES (?, ?, 'super_admin')");
            $stmt->execute(['superadmin', $hash]);
        }

        $nbCfg = $pdo->query("SELECT COUNT(*) AS n FROM config")->fetch()['n'];
        if ((int)$nbCfg === 0) {
            $pdo->exec("INSERT INTO config (id, nom_site, email_contact, updated_at) VALUES (1, 'Licences INOFIB', 'licences@inofib.com', NOW())");
        }
    }
}