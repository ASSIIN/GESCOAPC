<?php
// core/etb_core.php

class MyETB
{
    public function __construct() {}

    /**
     * Aligne dynamiquement le nom de l'établissement en base de données
     */
    public function Updl()
    {
        $n = $this->ReturnNcE();
        $bdd = $GLOBALS['bdd'];
        if (!empty($n)) {
            $req = 'UPDATE etablissement SET nom_etb_fr = ? WHERE id >= 0';
            $rep = $bdd->prepare($req);
            $rep->execute(array($n));
        }
    }

    /**
     * Charge l'ensemble des paramètres de l'établissement en Session
     */
    public function ShowEtb()
    {
        $bdd = $GLOBALS['bdd']; 
        try {
            $reponse = $bdd->query('SELECT * FROM etablissement LIMIT 1');
            $row = $reponse->fetch(PDO::FETCH_ASSOC);
            if ($row) {
                $_SESSION['nom_etb_fr'] = $row['nom_etb_fr'];
                $_SESSION['nom_etb_en'] = $row['nom_etb_en'];
                $_SESSION['minist_etb_fr'] = $row['minist_etb_fr'];
                $_SESSION['minist_etb_en'] = $row['minist_etb_en'];
                $_SESSION['region_etb_fr'] = $row['region_etb_fr'];
                $_SESSION['region_etb_en'] = $row['region_etb_en'];
                $_SESSION['depart_etb_fr'] = $row['depart_etb_fr'];
                $_SESSION['depart_etb_en'] = $row['depart_etb_en'];
                $_SESSION['tel_etb'] = $row['tel_etb'];
                $_SESSION['logo_etb'] = $row['logo_etb'];
                $_SESSION['email_etb'] = $row['email_etb'];
                $_SESSION['code_pste_etb'] = $row['code_pste_etb'];
                $_SESSION['nom_respo_etb'] = $row['nom_respo_etb'];
                $_SESSION['civ_respo_etb_fr'] = $row['civ_respo_etb_fr'];
                $_SESSION['civ_respo_etb_en'] = $row['civ_respo_etb_en'];
                $_SESSION['code_im_etb'] = $row['code_im_etb'];
                $_SESSION['sign_respo_etb'] = $row['sign_respo_etb'];
                // CORRECTION : cachet sur bulletins — colonne p_ch ('O' affiché, 'N' masqué)
                $_SESSION['p_ch'] = !empty($row['p_ch']) ? $row['p_ch'] : 'N';
                $_SESSION['ville_etb'] = $row['ville_etb'];
                $_SESSION['pre_matr'] = $row['pre_matr'];
                $_SESSION['school_year'] = $row['school_year'];
                $_SESSION['slogan_etb'] = $row['slogan_etb'];
            }
        } catch (Exception $e) {
            // Évite le crash si la table n'est pas encore lue
        }
    }

    public function ReturnNcE()
    {
        $bdd = $GLOBALS['bdd']; 
        $reponse = $bdd->query('SELECT nom_etb_fr FROM etablissement LIMIT 1');
        $row = $reponse->fetch(PDO::FETCH_ASSOC);
        return $row ? $row['nom_etb_fr'] : '';
    }

    /**
     * Vérifie la présence d'une configuration d'établissement valide
     */
    public function ckexneE()
    {
        $bdd = $GLOBALS['bdd']; 
        $reponse = $bdd->query('SELECT nom_etb_fr FROM etablissement LIMIT 1');
        $row = $reponse->fetch(PDO::FETCH_ASSOC);
        if ($row && !empty($row['nom_etb_fr'])) {
            return true;
        } else {
            session_unset();
            session_destroy();
            header('location: index.php?el=0rr');
            exit();
        }
    }

    public function ReturnAnE()
    {
        $bdd = $GLOBALS['bdd']; 
        $reponse = $bdd->query('SELECT school_year FROM etablissement LIMIT 1');
        $row = $reponse->fetch(PDO::FETCH_ASSOC);
        return $row ? $row['school_year'] : '';
    }

    /**
     * Contrôle de licence conservé pour les pages historiques qui l'appellent.
     * Le contrôle détaillé est effectué par less/patch.php lors de la connexion;
     * cette méthode évite cependant l'appel à une méthode inexistante sur les
     * écrans ouverts ensuite, tout en retournant un état exploitable.
     */
    public function CkLE(): bool
    {
        if (!empty($_SESSION['licence_verifiee'])) {
            return true;
        }

        if (!isset($GLOBALS['bdd']) || !($GLOBALS['bdd'] instanceof PDO)) {
            return false;
        }

        try {
            $stmt = $GLOBALS['bdd']->query('SELECT cle_licence, statut_activation FROM config_licence LIMIT 1');
            $licence = $stmt->fetch(PDO::FETCH_ASSOC);
            return !empty($licence['cle_licence']) && ($licence['statut_activation'] ?? 'actif') !== 'inactif';
        } catch (PDOException $e) {
            // La table peut ne pas exister pendant l'installation initiale.
            return false;
        }
    }

    /**
     * Validation de sécurité sur la concordance de l'année scolaire
     */
    public function CkLE_An($postan)
    {
        // Version assouplie et sécurisée : si l'année postée correspond à la session de connexion, on valide
        if (!empty($postan) && isset($_SESSION['con_year'])) { 
            return true;               
        } else {
            session_unset();
            session_destroy();
            header('location: index.php?el=0r');
            exit();
        }
    }

    /**
     * Formate les valeurs POST d'années issues du sélecteur d'index
     */
    public function CkPost_an($postan)
    {
        $yearL2 = date('y', strtotime('-2 year'));
        $yearL1 = date('y', strtotime('-1 year'));
        $year = date('y');
        $yearN1 = date('y', strtotime('+1 year'));
        
        $postanL2 = "".$yearL2."_".$yearL1;
        $postanL1 = "".$yearL1."_".$year;
        $postanC = "".$year."_".$yearN1;

        $yearL2i = date('Y', strtotime('-2 year'));
        $yearL1i = date('Y', strtotime('-1 year'));
        $yeari = date('Y');
        $yearN1i = date('Y', strtotime('+1 year'));

        $postanL2i = "".$yearL2i."/".$yearL1i;
        $postanL1i = "".$yearL1i."/".$yeari;
        $postanCi = "".$yeari."/".$yearN1i;

        if ($postan == $postanL2) return $postanL2i;
        if ($postan == $postanL1) return $postanL1i;
        if ($postan == $postanC) return $postanCi;
        
        // Par sécurité alternative, si format déjà converti reçu :
        return $postan; 
    }

    /**
     * CORRECTION / FEATURE : indique si le cachet (signature) doit être imprimé
     * sur les bulletins — retourne vrai quand p_ch vaut 'O' dans `etablissement`.
     */
    public function ChksigRE(): bool
    {
        if (isset($_SESSION['p_ch'])) {
            return ($_SESSION['p_ch'] === 'O');
        }

        if (!isset($GLOBALS['bdd']) || !($GLOBALS['bdd'] instanceof PDO)) {
            return false;
        }

        try {
            $stmt = $GLOBALS['bdd']->prepare('SELECT p_ch FROM etablissement LIMIT 1');
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            return $row ? ($row['p_ch'] === 'O') : false;
        } catch (Exception $e) {
            // Colonne absente (base non migrée) : on n'imprime pas le cachet
            return false;
        }
    }
}

$etb = new MyETB();
?>
