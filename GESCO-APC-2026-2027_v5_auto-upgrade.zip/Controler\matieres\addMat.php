<?php
	session_start();
	require_once '../../Model/connexion.php';
	require_once '../../core/require.php'; 	
	$ref_depart= htmlspecialchars($_POST['ref_dep']);
	$abr_mat= htmlspecialchars($_POST['abr_mat']);
	$nom_mat= htmlspecialchars($_POST['nom_mat']);
	
	
  		
  		if (isset($ref_depart)) 
  		{
  			//echo 'Nom: '.$nom_classe.' <br> Niveau : '.$niveau.' <br> Session: '.$session.' <br> code : '.$codeswift.' ';

  			/* conversion*/
		$nom_mat=mb_strtoupper($nom_mat);
		$abr_mat=mb_strtoupper($abr_mat);

			$mat->setNom_mat($nom_mat);
			$mat->setAbr_mat($abr_mat);
			$mat->setRef_depart($ref_depart);
		
			if ($mat->AddMat())
				{
				header('location: ../../menu_matieres.php');
				}

				else  
			{
					echo "Erreur2";
				}
		}

		else  {
			echo "Erreur1";
		}
		
		
?>