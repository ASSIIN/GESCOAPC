<?php
	session_start();
	require_once '../../Model/connexion.php';
	require_once '../../core/require.php'; 
	$id=htmlspecialchars($_POST['iddep']);
	$nom_dep= htmlspecialchars($_POST['nom_dep']);
	$abr_dep= htmlspecialchars($_POST['abr_dep']);
	$session= htmlspecialchars($_POST['session']);
	
	if (isset($id)) 
	{
		
		$id=(int)$id;
		$nom_dep=strtoupper($nom_dep);
		$abr_dep=strtoupper($abr_dep);
		$elt= array(
			'nom_dep' =>$nom_dep , 
			'abr_dep' =>$abr_dep, 
			'ref_session' =>$session
		);
		
		foreach ($elt as $key => $value) {
			if ($value!="") {

			$bdd = $GLOBALS['bdd'];	
			$req ='UPDATE departements SET '.$key.'=? where id='.$id.'';
			$rep = $bdd->prepare($req);
			$rep->execute(array($value));
				
			}
			
		}
		
		header('location: ../../menu_departements.php');
	}
	else
	{
		echo "Error 1";
	
	}
  		
?>