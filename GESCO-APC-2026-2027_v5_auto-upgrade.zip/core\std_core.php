<?php 
/**
 * Classe de Gestion des Élèves (Modèle & Composants HTML)
 * Projet: GESCO-APC
 * Optimisation Sécurité & Rendu Responsive - INOFIB 2026
 */
class MyStds
{
    private $nom_std, $prenom_std, $lieu_nais, $sexe_std, $mat_std, $ref_class, $cni_std;
    private $date_nais, $statut, $pere_std, $mere_std, $adresse_std, $localite_std, $handicap, $contenu_std;
    
    function __construct() {}

    public function setNom_std($value) { $this->nom_std = $value; }
    public function getNom_std() { return $this->nom_std; }

    public function setCni_std($value) { $this->cni_std = $value; }
    public function getCni_std() { return $this->cni_std; }

    public function setPrenom_std($value) { $this->prenom_std = $value; }
    public function getPrenom_std() { return $this->prenom_std; }

    public function setDate_nais($value) { $this->date_nais = $value; }
    public function getDate_nais() { return $this->date_nais; }

    public function setLieu_nais($value) { $this->lieu_nais = $value; }
    public function getLieu_nais() { return $this->lieu_nais; }

    public function setSexe_std($value) { $this->sexe_std = $value; }
    public function getSexe_std() { return $this->sexe_std; }

    public function setMat_std($value) { $this->mat_std = $value; }
    public function getMat_std() { return $this->mat_std; }

    public function setRef_class($value) { $this->ref_class = $value; }
    public function getRef_class() { return $this->ref_class; }

    // ==============================================================
    // GESTION DES FICHIERS ET DOSSIERS (VÉRIFICATIONS LOCALES)
    // ==============================================================

    public function controlSupp($file, $cls)
    {
        $file_nom = basename($file['name']);
        $file_ext = strtolower(strrchr($file_nom, '.'));
        $tab_ext = array('.xls', '.xlsx', '.xlt');

        if (!in_array($file_ext, $tab_ext)) {
            return false;
        }
        return 'list' . $cls . $file_ext;
    }

    public function controlPhoto($file, $mat)
    {
        $file_nom = basename($file['name']);
        $file_ext = strtolower(strrchr($file_nom, '.'));
        $tab_ext = array('.jpg', '.jpeg', '.png');

        if (!in_array($file_ext, $tab_ext)) {
            return false;
        }
        return 'img' . $mat . $file_ext;
    }

    public function dossier() { return '../../Controler/Students/'; }
    public function dossierPhoto() { return 'plugins/images/imgstd/'; }
    public function dossierList() { return '../../Controler/Students/ListImport/'; }
    public function dossierImportFile() { return '../plugins/ListImport/'; }
    public function PathImportFile($file) { return '../plugins/ListImport/' . $file; }

    // ==============================================================
    // MÉTHODES D'INSERTION SÉCURISÉES (REQUÊTES PRÉPARÉES)
    // ==============================================================

    public function AddSTD()
    {
        $bdd = $GLOBALS['bdd'];
        $req = "INSERT INTO eleves (nom_std, date_nais, lieu_nais, sexe_std, mat_std, ref_class) VALUES(?, ?, ?, ?, ?, ?)";
        $rep = $bdd->prepare($req);
        return $rep->execute(array($this->nom_std, $this->date_nais, $this->lieu_nais, $this->sexe_std, $this->mat_std, $this->ref_class));
    }

    public function AddStdExcelList($cls)
    {
        $bdd = $GLOBALS['bdd'];
        $support = $GLOBALS['support'];
        $req = "INSERT INTO listsexcel (ref_cls, contenu) VALUES(?, ?)";

        $fichier = $this->controlSupp($support, $cls);
        $dossier = $this->dossierImportFile();

        if ($fichier && isset($dossier)) {
            $file = $dossier . $fichier;
            if (file_exists($file) && is_file($file)) {
                unlink($file);
            }
            if (move_uploaded_file($support['tmp_name'], $file)) {
                $rep = $bdd->prepare($req);
                return $rep->execute(array($cls, $fichier));
            }
        }
        return false;
    }

    public function AddExcelList($cls)
    {
        $bdd = $GLOBALS['bdd'];
        $support = $GLOBALS['support'];
        $req = "INSERT INTO listsexcel (ref_cls, contenu) VALUES(?, ?)";

        $fichier = $this->controlSupp($support, $cls);
        $dossier = $this->dossierList();

        if ($fichier && isset($dossier)) {
            $file = $dossier . $fichier;
            if (file_exists($file) && is_file($file)) {
                unlink($file);
            }
            if (move_uploaded_file($support['tmp_name'], $file)) {
                $rep = $bdd->prepare($req);
                return $rep->execute(array($cls, $fichier));
            }
        }
        return false;
    }

    // ==============================================================
    // COMPOSANTS HTML CONSTRUITS (SÉLECTEURS ET DROPDOWNS)
    // ==============================================================

    public function ShowClassesNames()
    {
        $bdd = $GLOBALS['bdd'];
        $reponse = $bdd->query('SELECT code_class, nom_class FROM classes ORDER BY ref_class_niveau ASC, nom_class ASC');
        $i = 0;
        while ($row = $reponse->fetch(PDO::FETCH_ASSOC)) {
            $i++;
            echo '<option value="' . $row['code_class'] . '">' . $i . ' - ' . $row['nom_class'] . '</option>';
        }
    }

    public function ShowOptionStdByCls($cls)
    {
        $bdd = $GLOBALS['bdd'];
        $stmt = $bdd->prepare('SELECT mat_std, nom_std FROM eleves WHERE ref_class = ? ORDER BY nom_std ASC');
        $stmt->execute(array($cls));
        $i = 0;
        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            $i++;
            echo '<option value="' . $row['mat_std'] . '">' . $i . ' - ' . $row['nom_std'] . '</option>';
        }
    }

    public function LinkClassesNames()
    {
        $bdd = $GLOBALS['bdd'];
        $reponse = $bdd->query('SELECT code_class, nom_class FROM classes ORDER BY ref_class_niveau ASC, nom_class ASC');
        $i = 0;
        while ($row = $reponse->fetch(PDO::FETCH_ASSOC)) {
            $i++;
            echo '<li><a class="dropdown-item py-2 fw-bold" href="home.php?cls=' . $row['code_class'] . '">' . $i . ' - ' . $row['nom_class'] . '</a></li>';
        }
    }

    public function SelectClassesNames()
    {
        $bdd = $GLOBALS['bdd'];
        $reponse = $bdd->query('SELECT code_class, nom_class FROM classes ORDER BY ref_class_niveau ASC, nom_class ASC');
        $i = 0;
        while ($row = $reponse->fetch(PDO::FETCH_ASSOC)) {
            $i++;
            echo '<option value="' . $row['code_class'] . '">' . $i . ' - ' . $row['nom_class'] . '</option>';
        }
    }

    public function Select_Link_ClassesNames()
    {
        $bdd = $GLOBALS['bdd'];
        $reponse = $bdd->query('SELECT code_class, nom_class FROM classes ORDER BY ref_class_niveau ASC, nom_class ASC');
        $i = 0;
        while ($row = $reponse->fetch(PDO::FETCH_ASSOC)) {
            $i++;
            echo '<option value="' . $row['code_class'] . '">' . $i . ' - ' . $row['nom_class'] . '</option>';
        }
    }

    public function SelectClassesNames_For_Change($cls)
    {
        $bdd = $GLOBALS['bdd'];
        $nv = $this->ReturnNv_by_ClsCode($cls);
        $ss = $this->ReturnSess_by_ClsCode($cls);
        
        $stmt = $bdd->prepare('SELECT code_class, nom_class FROM classes WHERE ref_class_niveau = ? AND class_session = ? AND code_class != ? ORDER BY nom_class ASC');
        $stmt->execute(array($nv, $ss, $cls));
        $i = 0;
        $output = '';
        while ($rowi = $stmt->fetch(PDO::FETCH_ASSOC)) {
            $i++;
            $output .= '<option value="' . $rowi['code_class'] . '">' . $i . ' - ' . $rowi['nom_class'] . '</option>';
        }
        return $output;
    }

        // ==============================================================
    // RENDU DES TABLEAUX (REWRITING RESPONSIVE MOBILE COMPATIBLE)
    // ==============================================================

    public function ShowAllStd()
    {
        $bdd = $GLOBALS['bdd'];
        $reponse = $bdd->query('SELECT * FROM eleves ORDER BY nom_std ASC');
        $i = 0;
        while ($row = $reponse->fetch(PDO::FETCH_ASSOC)) {
            $i++;
            $cls = $this->ShowClasseNameByCode($row['ref_class']);
            $date_nais = date('d/m/Y', strtotime($row['date_nais']));
            $pre_matr = isset($_SESSION['pre_matr']) ? $_SESSION['pre_matr'] : '';

            echo '
            <tr>
                <td>' . $i . '</td>
                <td class="fw-bold text-primary">' . $pre_matr . $row['mat_std'] . '</td>
                <td class="mobile-hide font-monospace">' . $row['cni_std'] . '</td>
                <td class="text-start fw-bold" style="padding-left:15px;">' . $row['nom_std'] . '</td>
                <td class="mobile-hide">' . $row['sexe_std'] . '</td>
                <td class="mobile-hide">' . $date_nais . '</td>
                <td><span class="badge bg-secondary px-2 py-1">' . $cls . '</span></td>
                <td>
                    <button class="btn btn-sm btn-outline-primary py-0 px-2" data-bs-toggle="modal" data-bs-target="#editstd_' . $row['id'] . '"><i class="fa fa-edit"></i></button>
                </td>
                <td>
                    <button class="btn btn-sm btn-outline-danger py-0 px-2" data-bs-toggle="modal" data-bs-target="#mod_del' . $row['id'] . '"><i class="fa fa-trash"></i></button>
                </td>
            </tr>';
            
            $this->renderInlineModals($row, $cls, $date_nais);
        }
    }

    public function ShowAllStdByCls_for_Notes($cls, $ua)
    {
        $bdd = $GLOBALS['bdd'];
        $stmt = $bdd->prepare('SELECT * FROM eleves WHERE ref_class = ? ORDER BY nom_std ASC');
        $stmt->execute(array($cls));
        $i = 0;
        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            $i++;
            $pre_matr = isset($_SESSION['pre_matr']) ? $_SESSION['pre_matr'] : '';
            echo '
            <tr>
                <td>' . $i . '</td>
                <td class="fw-bold text-primary">' . $pre_matr . $row['mat_std'] . '</td>
                <td class="text-start fw-bold">' . $row['nom_std'] . '</td>
                <td><a class="btn btn-outline-primary btn-sm py-0 px-2" href="poste_de_saisie_std.php?trim=t1&ref_class=' . urlencode($row['ref_class']) . '"><i class="fa fa-edit"></i></a></td>
            </tr>';
        }
    }

    public function ShowAllStdByCls($cls)
    {
        $bdd = $GLOBALS['bdd'];
        $stmt = $bdd->prepare('SELECT * FROM eleves WHERE ref_class = ? ORDER BY nom_std ASC');
        $stmt->execute(array($cls));
        $i = 0;
        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            $i++;
            $clsName = $this->ShowClasseNameByCode($row['ref_class']);
            $date_nais = date('d/m/Y', strtotime($row['date_nais']));
            $pre_matr = isset($_SESSION['pre_matr']) ? $_SESSION['pre_matr'] : '';

            echo '
            <tr>
                <td>' . $i . '</td>
                <td class="fw-bold text-primary">' . $pre_matr . $row['mat_std'] . '</td>
                <td class="mobile-hide font-monospace">' . $row['cni_std'] . '</td>
                <td class="text-start fw-bold" style="padding-left:15px;">' . $row['nom_std'] . '</td>
                <td class="mobile-hide">' . $row['sexe_std'] . '</td>
                <td class="mobile-hide">' . $date_nais . '</td>
                <td><span class="badge bg-secondary px-2 py-1">' . $clsName . '</span></td>
                <td>
                    <button class="btn btn-sm btn-outline-primary py-0 px-2" data-bs-toggle="modal" data-bs-target="#editstd_' . $row['id'] . '"><i class="fa fa-edit"></i></button>
                </td>
                <td>
                    <button class="btn btn-sm btn-outline-danger py-0 px-2" data-bs-toggle="modal" data-bs-target="#mod_del' . $row['id'] . '"><i class="fa fa-trash"></i></button>
                </td>
            </tr>';
            
            $this->renderInlineModals($row, $clsName, $date_nais);
        }
    }

    // ==============================================================
    // REFACTORING DES FENÊTRES MODALES D'ÉDITION SÉCURISÉES (BOOTSTRAP 5)
    // ==============================================================

    private function renderInlineModals($row, $cls, $date_nais)
    {
        $pre_matr = isset($_SESSION['pre_matr']) ? $_SESSION['pre_matr'] : '';
        $img_src = !empty($row['contenu_std']) && file_exists($this->dossierPhoto().$row['contenu_std']) ? $this->dossierPhoto().$row['contenu_std'] : 'assets/img/avatar.png';
        
        // Modal de Suppression Épuré
        echo '
        <div class="modal fade" id="mod_del' . $row['id'] . '" tabindex="-1" aria-hidden="true">
          <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header bg-danger text-white border-0 py-2">
                    <h5 class="modal-title fw-bold small"><i class="fa fa-warning me-2"></i>Supprimer l\'Élève</h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body text-center p-4">
                    <p class="mb-1 text-muted small">Êtes-vous certain de vouloir radier définitivement l\'élève :</p>
                    <h5 class="text-danger fw-bolder mb-3">' . $row['nom_std'] . ' (' . $pre_matr . $row['mat_std'] . ')</h5>
                    <p class="text-secondary font-monospace bg-light p-2 rounded small" style="font-size:0.8em;"><i class="fa fa-info-circle me-1"></i>Cette action détruira ses notes, versements et historiques associés de manière définitive.</p>
                </div>
                <div class="modal-footer border-top-0 pt-0 justify-content-center">
                    <button type="button" class="btn btn-secondary btn-sm px-3" data-bs-dismiss="modal">Annuler</button>
                    <a href="Controler/Students/delstd.php?id=' . $row['id'] . '&cls=' . $row['ref_class'] . '" class="btn btn-sm btn-danger px-4 fw-bold">Confirmer la radiation</a>
                </div>
            </div>
          </div>
        </div>';

        // Modal d'Édition / Modification Responsive (Compatible Thème Sombre)
        echo '
        <div class="modal fade" id="editstd_' . $row['id'] . '" tabindex="-1" aria-hidden="true">
          <div class="modal-dialog modal-dialog-centered modal-lg">
            <div class="modal-content border-0">
              <div class="modal-header text-white border-0 py-2" style="background-color: #0764a8;">
                <h6 class="modal-title fw-bold"><i class="fa fa-edit me-2"></i>Fiche de mise à jour : ' . $pre_matr . $row['mat_std'] . '</h6>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
              </div>
              <form action="Controler/Students/updstd.php" method="post" enctype="multipart/form-data">
                <div class="modal-body p-4" style="background-color: var(--bg-main);">
                  <div class="container-fluid p-0">
                    <input type="hidden" name="idstd" value="' . $row['id'] . '">
                    <input type="hidden" name="refcls" value="' . $row['ref_class'] . '">

                    <div class="row g-2 mb-3">
                        <div class="col-12 col-md-4">
                            <label class="form-label text-secondary small fw-bold">Classe actuelle : <i class="text-primary">' . $cls . '</i></label>
                            <select class="form-select form-select-sm" name="ref_cls">
                                <option value="">Conserver la classe...</option>
                                ' . $this->SelectClassesNames_For_Change($row['ref_class']) . '
                            </select>
                        </div>
                        <div class="col-12 col-md-5">
                            <label class="form-label text-secondary small fw-bold">Nom de l\'Élève</label>
                            <input type="text" class="form-control form-control-sm text-uppercase fw-bold" name="nom_std" placeholder="' . $row['nom_std'] . '">
                        </div>
                        <div class="col-12 col-md-3">
                            <label class="form-label text-secondary small fw-bold">Matricule national</label>
                            <input type="text" class="form-control form-control-sm text-uppercase" name="cni_std" placeholder="' . $row['cni_std'] . '">
                        </div>
                    </div>

                    <div class="row g-2 mb-3">
                        <div class="col-6 col-md-2">
                            <label class="form-label text-secondary small fw-bold">Sexe (<i class="text-primary">' . $row['sexe_std'] . '</i>)</label>
                            <select class="form-select form-select-sm" name="sexe">
                                <option value="">Inchangé...</option>
                                <option value="M">MASCULIN</option>
                                <option value="F">FEMININ</option>
                            </select>
                        </div>
                        <div class="col-6 col-md-3">
                            <label class="form-label text-secondary small fw-bold">Né(e) le</label>
                            <input type="date" class="form-control form-control-sm text-center" id="date_naiss_std1" name="date_naiss_std">
                        </div>
                                                <div class="col-12 col-md-5">
                            <label class="form-label text-secondary small fw-bold">À (Lieu)</label>
                            <input type="text" class="form-control form-control-sm text-uppercase" name="lieu_naiss_std" placeholder="' . $row['lieu_nais'] . '">
                        </div>
                        <div class="col-12 col-md-2">
                            <label class="form-label text-secondary small fw-bold">RED (<i class="text-primary">' . $row['statut'] . '</i>)</label>
                            <select class="form-select form-select-sm" name="statut">
                                <option value="">Choisir...</option>
                                <option value="N">NON</option>
                                <option value="O">OUI</option>
                            </select>
                        </div>
                    </div>

                    <div class="row g-2 mb-3">
                        <div class="col-12 col-md-6">
                            <label class="form-label text-secondary small fw-bold">Filiation: Nom du Père</label>
                            <input type="text" class="form-control form-control-sm text-uppercase" name="pere_std" placeholder="' . (isset($row['pere_std']) ? $row['pere_std'] : '') . '">
                        </div>
                        <div class="col-12 col-md-6">
                            <label class="form-label text-secondary small fw-bold">Filiation: Nom de la Mère</label>
                            <input type="text" class="form-control form-control-sm text-uppercase" name="mere_std" placeholder="' . (isset($row['mere_std']) ? $row['mere_std'] : '') . '">
                        </div>
                    </div>

                    <div class="row g-2 mb-3">
                        <div class="col-6 col-md-4">
                            <label class="form-label text-secondary small fw-bold">Téléphone</label>
                            <input type="number" class="form-control form-control-sm" name="adresse_std" placeholder="' . (isset($row['adresse_std']) ? $row['adresse_std'] : '') . '">
                        </div>
                        <div class="col-6 col-md-4">
                            <label class="form-label text-secondary small fw-bold">Résidence / Quartier</label>
                            <input type="text" class="form-control form-control-sm text-uppercase" name="localite_std" placeholder="' . (isset($row['localite_std']) ? $row['localite_std'] : '') . '">
                        </div>
                        <div class="col-12 col-md-4">
                            <label class="form-label text-secondary small fw-bold">Spécificité / Handicap</label>
                            <select class="form-select form-select-sm" name="handicap">
                                <option value="">Conserver (' . (isset($row['handicap']) ? $row['handicap'] : 'RAS') . ')...</option>
                                <option value="RAS">R.A.S</option>
                                <option value="TROUBLE DE VUE">TROUBLE DE VUE</option>
                                <option value="TROUBLE MENTAL">TROUBLE MENTAL</option>
                                <option value="ELEVE DEPLACE">ELEVE DEPLACE</option>
                                <option value="ORPHELIN(E)">ORPHELIN(E)</option>
                            </select>
                        </div>
                    </div>

                    <div class="row g-2 align-items-center">
                        <div class="col-4 col-sm-3 text-center">
                            <img src="' . $img_src . '" class="img-thumbnail rounded shadow-sm" style="max-height: 80px;" alt="Photo">
                        </div>
                        <div class="col-8 col-sm-9">
                            <label class="form-label text-secondary small fw-bold">Changer la Photo d\'identité (4x4)</label>
                            <input type="file" class="form-control form-control-sm" name="support" accept=".jpg,.jpeg,.png">
                        </div>
                    </div>

                  </div>
                </div>
                <div class="modal-footer border-top-0 pt-0">
                  <button type="button" class="btn btn-sm btn-secondary px-3" data-bs-dismiss="modal">Annuler</button>
                  <button type="submit" class="btn btn-sm text-white fw-bold px-4" style="background-color: #19784f; border:none;"><i class="fa fa-save me-2"></i>Sauvegarder</button>
                </div>
              </form>
            </div>
          </div>
        </div>';
    }

        // ==============================================================
    // REQUÊTES UNITAIRES DE LECTURE (SÉCURISÉES, SANS BOUCLE WHILE)
    // ==============================================================

    public function ShowClasseNameByCode($code)
    {
        $bdd = $GLOBALS['bdd'];
        $stmt = $bdd->prepare('SELECT nom_class FROM classes WHERE code_class = ? LIMIT 1');
        $stmt->execute(array($code));
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        return $row ? $row['nom_class'] : 'Inconnue';
    }

    public function ReturnNv_by_ClsCode($code)
    {
        $bdd = $GLOBALS['bdd'];
        $stmt = $bdd->prepare('SELECT ref_class_niveau FROM classes WHERE code_class = ? LIMIT 1');
        $stmt->execute(array($code));
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        return $row ? $row['ref_class_niveau'] : 0;
    }

    public function ReturnSess_by_ClsCode($code)
    {
        $bdd = $GLOBALS['bdd'];
        $stmt = $bdd->prepare('SELECT class_session FROM classes WHERE code_class = ? LIMIT 1');
        $stmt->execute(array($code));
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        return $row ? $row['class_session'] : '';
    }

    public function CkExistingCode($code)
    {
        $bdd = $GLOBALS['bdd'];
        $stmt = $bdd->prepare('SELECT id FROM classes WHERE code_class = ? LIMIT 1');
        $stmt->execute(array($code));
        return (bool)$stmt->fetch();
    }

    public function ShowSearchLisStd()
    {
        $bdd = $GLOBALS['bdd'];
        $reponse = $bdd->query('SELECT id, nom_std, mat_std, ref_class FROM eleves ORDER BY nom_std ASC');
        while ($row = $reponse->fetch(PDO::FETCH_ASSOC)) {
            $cls = $this->ShowClasseNameByCode($row['ref_class']); 
            $pre_matr = isset($_SESSION['pre_matr']) ? $_SESSION['pre_matr'] : '';
            echo '<a class="link my-3" data-bs-toggle="modal" data-bs-target="#editstd_' . $row['id'] . '"> ' . $pre_matr . $row['mat_std'] . ' - ' . $row['nom_std'] . ' (<i style="color:#f33155;"> ' . $cls . ' </i>) <i class="ml-2 fa fa-edit"></i></a>';
        }
    }

    public function ShowSearchLisStd_by_Cls($cls)
    {
        $bdd = $GLOBALS['bdd'];
        $stmt = $bdd->prepare('SELECT mat_std, nom_std FROM eleves WHERE ref_class = ? ORDER BY nom_std ASC');
        $stmt->execute(array($cls));
        $i = 0;
        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            $i++;
            echo '<option value="' . $row['mat_std'] . '">' . $i . ' (' . $row['mat_std'] . ') - ' . $row['nom_std'] . ' </option>';        
        }
    }

    public function NombreSTD()
    {
        $bdd = $GLOBALS['bdd'];
        $res = $bdd->query('SELECT COUNT(id) AS total FROM eleves');
        $row = $res->fetch(PDO::FETCH_ASSOC);
        return $row ? (int)$row['total'] : 0;
    }

    public function NombreNotesStd($ev)
    {
        $bdd = $GLOBALS['bdd'];
        $table = 'table_note_par_mat_eval' . preg_replace('/[^0-9]/', '', $ev);
        try {
            $res = $bdd->query("SELECT COUNT(id) AS total FROM $table");
            $row = $res->fetch(PDO::FETCH_ASSOC);
            return $row ? (int)$row['total'] : 0;
        } catch (Exception $e) { return 0; }
    }

    public function NombreVsmtsStd()
    {
        $bdd = $GLOBALS['bdd'];
        $res = $bdd->query('SELECT COUNT(id) AS total FROM versements');
        $row = $res->fetch(PDO::FETCH_ASSOC);
        return $row ? (int)$row['total'] : 0;
    }

    public function UDPNbreNotesStd($ev, $v)
    {
        $bdd = $GLOBALS['bdd'];
        $table = 'table_note_par_mat_eval' . preg_replace('/[^0-9]/', '', $ev);
        $bdd->query('ALTER TABLE ' . $table . ' AUTO_INCREMENT=' . (int)$v);
    }

    public function UDPNbVsmts($v)
    {
        $bdd = $GLOBALS['bdd'];
        $bdd->query('ALTER TABLE versements AUTO_INCREMENT=' . (int)$v);
    }

    public function CkExistingMatr($code)
    {
        $bdd = $GLOBALS['bdd'];
        $stmt = $bdd->prepare('SELECT id FROM eleves WHERE mat_std = ? LIMIT 1');
        $stmt->execute(array($code));
        return (bool)$stmt->fetch();
    }

    public function CkExistingMatricule($code)
    {
        $bdd = $GLOBALS['bdd'];
        $stmt = $bdd->prepare('SELECT id FROM eleves WHERE cni_std = ? LIMIT 1');
        $stmt->execute(array($code));
        return (bool)$stmt->fetch();
    }

    public function ReturnCNI_by_matr($code)
    {
        $bdd = $GLOBALS['bdd'];
        $stmt = $bdd->prepare('SELECT cni_std FROM eleves WHERE mat_std = ? LIMIT 1');
        $stmt->execute(array($code));
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        return $row ? $row['cni_std'] : '';
    }

    // CORRECTION : charge en session les informations d'un élève (appelé par les bulletins fpdf185)
    public function CkStdByCode_for_Bul($code)
    {
        $bdd = $GLOBALS['bdd'];
        try {
            $stmt = $bdd->prepare("SELECT nom_std, contenu_std, lieu_nais, sexe_std, mat_std, statut, DATE_FORMAT(date_nais, '%d/%m/%Y') AS date_fr FROM eleves WHERE mat_std = ? LIMIT 1");
            $stmt->execute(array($code));
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            if ($row) {
                $_SESSION['mat_std']     = $row['mat_std'];
                $_SESSION['nom_std']     = $row['nom_std'];
                $_SESSION['sexe_std']    = $row['sexe_std'];
                $_SESSION['date_fr']     = $row['date_fr'];
                $_SESSION['lieu_nais']   = $row['lieu_nais'];
                $_SESSION['statut']      = $row['statut'];
                $_SESSION['contenu_std'] = !empty($row['contenu_std']) ? $row['contenu_std'] : 'icon.png';
            }
        } catch (Exception $e) {
            // Silencieux : évite le crash d'impression si l'élève n'existe plus
        }
    }

    public function CkExtAllStd()
    {
        $bdd = $GLOBALS['bdd'];
        $res = $bdd->query('SELECT id FROM eleves LIMIT 1');
        return (bool)$res->fetch();
    }

    public function SelectMatrbyID($id)
    {
        $bdd = $GLOBALS['bdd'];
        $stmt = $bdd->prepare('SELECT mat_std FROM eleves WHERE id = ? LIMIT 1');
        $stmt->execute(array($id));
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        return $row ? $row['mat_std'] : '';
    }

    public function SelectPostMatrbyCls($cls)
    {
        $bdd = $GLOBALS['bdd'];
        $stmt = $bdd->prepare('SELECT mat_std FROM eleves WHERE ref_class = ?');
        $stmt->execute(array($cls));
        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            echo '$note_' . $row['mat_std'] . ' = htmlspecialchars($_POST[\'' . $row['mat_std'] . '\']);';
        }
    }

    public function SelectNombyID($id)
    {
        $bdd = $GLOBALS['bdd'];
        $stmt = $bdd->prepare('SELECT nom_std FROM eleves WHERE id = ? LIMIT 1');
        $stmt->execute(array($id));
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        return $row ? $row['nom_std'] : '';
    }

    public function SelectFullNombyMat($mat)
    {
        $bdd = $GLOBALS['bdd'];
        $stmt = $bdd->prepare('SELECT nom_std FROM eleves WHERE mat_std = ? LIMIT 1');
        $stmt->execute(array($mat));
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        return $row ? $row['nom_std'] : '';
    }

    public function SelectCnibyID($id)
    {
        $bdd = $GLOBALS['bdd'];
        $stmt = $bdd->prepare('SELECT cni_std FROM eleves WHERE id = ? LIMIT 1');
        $stmt->execute(array($id));
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        return $row ? $row['cni_std'] : '';
    }

    public function IncrimValMatr()
    {
        $bdd = $GLOBALS['bdd'];
        $res = $bdd->query('SELECT id FROM eleves ORDER BY id DESC LIMIT 1');
        $row = $res->fetch(PDO::FETCH_ASSOC);
        return $row ? $row['id'] : 0;
    }

    public function delSTD($id)
    {
        $bdd = $GLOBALS['bdd'];
        $stmt = $bdd->prepare('DELETE FROM eleves WHERE id = ?');
        return $stmt->execute(array($id));
    }

    public function Full_delSTD($id)
    {
        $bdd = $GLOBALS['bdd'];
        $mat = $this->SelectMatrbyID($id);
        if (!empty($mat)) {
            $stmt = $bdd->prepare('DELETE FROM versements WHERE ref_std = ?');
            if ($stmt->execute(array($mat))) {
                $nbvs = $this->NombreVsmtsStd() + 1;
                $this->UDPNbVsmts($nbvs);
            }

            foreach (['table_note_par_trim1', 'table_note_par_trim2', 'table_note_par_trim3', 'remises', 'absences', 'exclusions'] as $table) {
                $stmt = $bdd->prepare("DELETE FROM $table WHERE ref_std = ?");
                $stmt->execute(array($mat));
            }

            for ($i = 1; $i <= 6; $i++) {
                $stmt = $bdd->prepare("DELETE FROM table_note_par_mat_eval{$i} WHERE ref_std = ?");
                $stmt->execute(array($mat));
                $nbnt = $this->NombreNotesStd($i) + 1;
                $this->UDPNbreNotesStd($i, $nbnt);
            }

            $stmt = $bdd->prepare('DELETE FROM eleves WHERE id = ?');
            return $stmt->execute(array($id));
        }
        return false;
    }
}

$std = new MyStds();
?>

