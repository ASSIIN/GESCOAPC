<?php 
	session_start();
	require_once '../../Model/connexion.php';
	require_once '../../core/require.php';
	$id = htmlspecialchars($_GET['id']);
	$refcls = htmlspecialchars($_GET['cls']);
	if (isset($id)) 
	{
		$bdd = $GLOBALS['bdd'];
			$mat=$std->SelectMatrbyID($id);
			if(isset($id))
			{
				$req1 = 'DELETE FROM versements WHERE ref_std=?';
				$rep1 = $bdd->prepare($req1);
				$rep1->execute(array($mat));
				$nbvs=$std->NombreVsmtsStd();
				$nbvs=(int)$nbvs;
				$nbvs++;
				$std->UDPNbVsmts($nbvs);
				$req1 = 'DELETE FROM table_note_par_trim1 WHERE ref_std=?';
			
				$rep1 = $bdd->prepare($req1);
				$rep1->execute(array($mat));

				$req1 = 'DELETE FROM table_note_par_trim2 WHERE ref_std=?';
				$rep1 = $bdd->prepare($req1);
				$rep1->execute(array($mat));

				$req1 = 'DELETE FROM table_note_par_trim3 WHERE ref_std=?';
				
				$rep1 = $bdd->prepare($req1);
				$rep1->execute(array($mat));

				$req1 = 'DELETE FROM remises WHERE ref_std=?';
				
				$rep1 = $bdd->prepare($req1);
				$rep1->execute(array($mat));

				for ($i=1; $i <7 ; $i++) {
					$ev=(string)$i;
					$req1 = 'DELETE FROM table_note_par_mat_eval'.$ev.' WHERE ref_std=?';
	
					$rep1 = $bdd->prepare($req1);
					$rep1->execute(array($mat));
					$nbnt=$std->NombreNotesStd($ev);
					$nbnt=(int)$nbnt;
					$nbnt++;
					$std->UDPNbreNotesStd($ev,$nbnt);
				}
					
				$req1 = 'DELETE FROM absences WHERE ref_std=?';
				
				$rep1 = $bdd->prepare($req1);
				$rep1->execute(array($mat));

				$req1 = 'DELETE FROM exclusions WHERE ref_std=?';
				
				$rep1 = $bdd->prepare($req1);
				$rep1->execute(array($mat));

				$req = 'DELETE FROM eleves WHERE id=?';
			    $rep = $bdd->prepare($req);
			    $rep->execute(array($id));
			    header('location: ../../home.php?cls='.$refcls.'');
	
		}
		else{
			echo "Error 1";
		
		}
		
	}
	else{
		echo "Error 2"; 
		
	}
?>