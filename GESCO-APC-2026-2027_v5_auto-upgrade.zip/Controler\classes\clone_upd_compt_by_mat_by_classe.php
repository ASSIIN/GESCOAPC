<?php
// Controler/classes/clone_upd_compt_by_mat_by_classe.php
session_start();
// Désactivation des affichages d'erreurs pour éviter de bloquer les redirections de Laragon
ini_set('display_errors', 0);
error_reporting(0);

require_once '../../Model/connexion.php';
require_once '../../core/require.php';

$bdd = $GLOBALS['bdd'];

if (isset($_POST['ref_class']) && isset($_POST['ref_mat'])) {
    
    $refclass = htmlspecialchars($_POST['ref_class']);
    $ref_mat = htmlspecialchars($_POST['ref_mat']);		
    $type = htmlspecialchars($_POST['type'] ?? 'nv');

    $cls_nv = $class->ReturnClasseNvByCode($refclass);
    $cls_ss = $class->ReturnClasseSessionByCode($refclass);

    // 1. Identification de la liste des classes cibles
    if ($type == 'nv') {
        $stmt_targets = $bdd->prepare('SELECT code_class FROM classes WHERE ref_class_niveau = ? AND class_session = ? AND code_class != ?');
        $stmt_targets->execute(array($cls_nv, $cls_ss, $refclass));
    } else {
        $stmt_targets = $bdd->prepare('SELECT code_class FROM classes WHERE class_session = ? AND code_class != ?');
        $stmt_targets->execute(array($cls_ss, $refclass));
    }

    // 2. Lancement d'une transaction PDO pour une exécution en masse instantanée
    $bdd->beginTransaction();

    try {
        // Requête préparée de remplacement : suppression des anciennes compétences de la
        // matière dans chaque classe cible, puis recopie intégrale de celles de la source.
        $stmt_del = $bdd->prepare('DELETE FROM competences_matieres WHERE ref_class = ? AND ref_mat = ?');

        $sql = "INSERT INTO competences_matieres (ref_class, ref_mat, num_compt, nom_compt)
                SELECT ?, ?, num_compt, nom_compt
                FROM competences_matieres
                WHERE ref_class = ? AND ref_mat = ?";

        $stmt = $bdd->prepare($sql);

        while ($row = $stmt_targets->fetch(PDO::FETCH_ASSOC)) {
            $classe_cible = $row['code_class'];

            // 1. Purge des anciennes compétences de la classe cible pour cette matière
            $stmt_del->execute(array($classe_cible, $ref_mat));

            // 2. Copie complète des compétences de la classe source vers la classe cible
            $stmt->execute(array($classe_cible, $ref_mat, $refclass, $ref_mat));
        }

        // Validation et écriture finale sur le disque dur local
        $bdd->commit();
        header('location: ../../config_competences.php?id=' . urlencode($refclass) . '&ref_mat=' . urlencode($ref_mat) . '&clone_success=1');
        exit();

    } catch (PDOException $e) {
        // En cas de panne de base de données, annulation complète
        $bdd->rollBack();
        echo "Erreur système lors du clonage des compétences : " . $e->getMessage();
    }
} else {
    header('location: ../../menu_classes.php');
    exit();
}
?>
