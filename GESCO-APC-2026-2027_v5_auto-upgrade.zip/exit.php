<?php
session_start();    
    require_once 'core/require.php';
    require_once 'Model/connexion.php';
    session_unset();
    session_destroy();
    header('location: index.php');
 ?>



