<?php
session_start();
require_once '../Model/connexion.php';
require_once '../core/require.php';
 if (!isset($_SESSION['user'])) {
    session_unset();
    session_destroy();
    header('location: ../index.php');    
    }
 $etb->ShowEtb();

 if (!isset($_GET['cls']) and !isset($_GET['type'])) {
	header('location: ../impression.php');
	exit;
 }
 // CORRECTION : suppression du renvoi vers card_ps.php / card_pb.php (fichiers inexistants) —
 // la carte scolaire générique ci-dessous couvre les deux cas
 $refcls=$_GET['cls'] ?? '';
 $mdl=$_GET['mdl'] ?? '1';
 $nbstd=$class->NbrStudentByClass($refcls);
 $nbstd=(int)$nbstd;
 if ($class->CkExistingCode($refcls)) {

   $nomCls=$class->ShowCls_namebyID($refcls);
 }
 else
  {
      $nomCls='TOUS_LES_ELEVES';
  }

require('fpdf.php');
$pdf = new FPDF();

class PDF extends FPDF
{
// En-tête
function Header()
{
	 $this->SetY(15);
    // Logo
    //$this->Image('../plugins/images/'.$_SESSION['logo_etb'].'',10,6,30);
    // Police Arial gras 15
    $this->SetFont('Arial','B',15);
    // Décalage à droite
    $this->Cell(80);
    // Titre
    $this->Cell(30,10,'Titre',1,0,'C');
    // Saut de ligne
    $this->Ln(20);
}

// Pied de page
function Footer()
{
    // Positionnement à 1,5 cm du bas
    $this->SetY(-15);
    // Police Arial italique 8
    $this->SetFont('Arial','I',8);
    // Numéro de page
    $this->Cell(0,10,'Page '.$this->PageNo().'/{nb}',0,0,'C');
}
}

//code for print data
	 $bdd = $GLOBALS['bdd'];

	 if ($refcls=='all') {
	 $reponse = $bdd->query('SELECT * FROM eleves where ref_class!="" order by nom_std asc ');
	 }
	 else{

	 	$reponse = $bdd->query('SELECT * FROM eleves where ref_class="'.$refcls.'" order by nom_std asc ');

	 }
		

	$i=0;
	$i1=0;

	// Définition des dimensions des cartes
	$carte_width = 90; // Largeur de la carte
	$carte_height = 56.5; // Hauteur de la carte

	// Définition des marges
	$marge_gauche = 10; // Marge gauche
	$marge_haut = 3; // Marge haute
	$x=0;
	$y=0;
	$pximg=48;
	$pyimg=15;
	$nbc=1;
	while($row = $reponse->fetch(PDO::FETCH_ASSOC)) 
	{	

    $date_nais_fr= date('d/m/Y ',strtotime($row['date_nais']));
	
	if ($i%10==0) 
	{
		$pdf->AddPage();
		$i1=0;		
		$marge_gauche = 10; // Marge gauche
		$marge_haut = 5; // Marge haute	
	}
  // Positionnement de la carte
  $x = $marge_gauche + ($i1 % 2) * ($carte_width + 10);
  $y = $marge_haut + floor($i1 / 2) * ($carte_height + 2);

  // Création de la carte
  if ($mdl=='1') {
     $pdf->SetFillColor(216,136,239);
  }
  elseif($mdl=='2'){
     $pdf->SetFillColor(235,232,118);
  }
  else{
     $pdf->SetFillColor(85,213,255);
  }
 

  $pdf->Rect($x, $y, $carte_width, $carte_height, 'F');
  $pdf->SetFont('Times','',4);
  $pdf->Text($x + 8, $y + 5, 'REPUBLIQUE DU CAMEROUN');
  $pdf->Text($x + 62, $y + 5, 'REPUBLIC OF CAMEROON');
  $pdf->SetFont('Times','I',5);
  $pdf->Text($x + 10, $y + 7, 'Paix-Travail-Patrie','J');
  $pdf->Text($x + 62, $y + 7, 'Peace-Work-Fatherland','J');
  $pdf->SetFont('Times','',4);
  $pdf->Text($x + 4, $y + 9, utf8_to_cp1252(''.$_SESSION['minist_etb_fr'].''),'J');
  $pdf->Text($x + 57, $y + 9, utf8_to_cp1252(''.$_SESSION['minist_etb_en'].''),'J');
  $pdf->SetFont('Times','B',5);
  $lg_nom_etb_fr=strlen($_SESSION['nom_etb_fr']);
  $lg_nom_etb_en=strlen($_SESSION['nom_etb_en']);
  if ($lg_nom_etb_fr<24) {
  	 $pdf->Text($x + 8, $y + 12, utf8_to_cp1252(substr(''.$_SESSION['nom_etb_fr'].'',0,25)),'J');
  }
  else{
  	  $pdf->Text($x + 4, $y + 12, utf8_to_cp1252(substr(''.$_SESSION['nom_etb_fr'].'',0,30)),'J');
  }

  if ($lg_nom_etb_fr<24) {
  	 $pdf->Text($x + 60, $y + 12, utf8_to_cp1252(substr(''.$_SESSION['nom_etb_en'].'',0,25)),'J');
  }
  else{
  	  $pdf->Text($x + 54, $y + 12, utf8_to_cp1252(substr(''.$_SESSION['nom_etb_en'].'',0,32)),'J');
  }
 
  $pdf->Image('../plugins/images/'.$_SESSION['logo_etb'].'',$x + 39,$y + 4,12);

    $pdf->SetFont('Times','I',6);
  $pdf->Text($x + 10, $y + 15, utf8_to_cp1252(''.$_SESSION['code_pste_etb'].''),'J');
  $pdf->Text($x + 62, $y + 15, utf8_to_cp1252('Tel: '.$_SESSION['tel_etb'].''),'J');
  // Titre 
   $pdf->SetFont('Times','BU',12);
  
if ($mdl=='1') {
      $pdf->SetTextColor(1,107,163);
   }
   elseif($mdl=='2'){
      $pdf->SetTextColor(0,80,140);
   }
   else{
      $pdf->SetTextColor(240,38,86);
   }
  $pdf->Text($x + 5, $y + 20, 'CARTE SCOLAIRE / SCHOOL ID CARD','J');
  $pdf->Image('../plugins/images/imgstd/'.$row['contenu_std'].'',$x + 70,$y + 30,15);

  // ll

  $Nom=htmlspecialchars($row['nom_std']);
	$nom_std=substr($Nom, 0, 33);
	$sub_nom_std=substr($Nom, -5, 23);
   $pdf->SetFont('Times','i',7);
    $pdf->SetTextColor(0,0,0);
  $pdf->Text($x + 3, $y + 27, 'Nom/Name:','J');
   $pdf->SetFont('Times','B',9);
  $pdf->Text($x + 17, $y + 27, utf8_to_cp1252($nom_std),'J');

  $pdf->SetFont('Times','i',7);
   $pdf->Text($x + 3, $y + 32, utf8_to_cp1252('Né(e)/Born:'),'J');
   $pdf->SetFont('Times','',8);
   $pdf->Text($x + 17, $y + 32, utf8_to_cp1252($date_nais_fr),'J');

 	$pdf->SetFont('Times','i',7);
    $pdf->Text($x + 38, $y + 32, utf8_to_cp1252('A/At:'),'J');
   $pdf->SetFont('Times','',8);
   $lieu_nais=substr($row['lieu_nais'], 0, 25);
   $pdf->Text($x + 45, $y + 32, utf8_to_cp1252($lieu_nais),'J');

   $pdf->SetFont('Times','i',7);
    $pdf->Text($x + 3, $y + 37, utf8_to_cp1252('Sexe/Sex:'),'J');
   $pdf->SetFont('Times','',8);
   $lieu_nais=substr($row['lieu_nais'], 0, 25);
   $pdf->Text($x + 17, $y + 37, utf8_to_cp1252($row['sexe_std']),'J');

   $pdf->SetFont('Times','i',7);
    $pdf->Text($x + 38, $y + 37, utf8_to_cp1252('Matricule:'),'J');
   $pdf->SetFont('Times','',8);
   $lieu_nais=substr($row['lieu_nais'], 0, 25);
   $pdf->Text($x + 49, $y + 37, utf8_to_cp1252($row['cni_std']),'J');

    $pdf->SetFont('Times','i',7);
    $pdf->Text($x + 3, $y + 42, utf8_to_cp1252('Classe/Class:'),'J');
   $pdf->SetFont('Times','',8);
    $nomCls_std=$class->ShowCls_namebyID($row['ref_class']);
   $pdf->Text($x + 17, $y + 42, utf8_to_cp1252( $nomCls_std),'J');

   $pdf->SetFont('Times','i',7);
    $pdf->Text($x + 38, $y + 42, utf8_to_cp1252('Année/Year:'),'J');
   $pdf->SetFont('Times','',8);
   $pdf->Text($x + 51, $y + 42, utf8_to_cp1252($_SESSION['school_year']),'J');
    $pdf->Image('../plugins/images/qrcode.png',$x + 5,$y + 44,9);
     $pdf->SetFont('Times','i',5);
      $pdf->Text($x + 15, $y + 48, utf8_to_cp1252('< < < '.$_SESSION['pre_matr'].$row['mat_std'].$sub_nom_std.' < < < < < < < < < < < < < < < < < < < < < < < < < < < < < < < < '),'J');
      $pdf->SetFont('Times','i',7);
     $pdf->Text($x + 15, $y + 52, utf8_to_cp1252('Encodé et géréné par le logiciel GESCOAPC'),'J');
    // CORRECTION : impression conditionnelle du cachet de l'établissement (paramètre p_ch)
    if ($etb->ChksigRE() && !empty($_SESSION['sign_respo_etb'])) {
        $pdf->Image('../plugins/images/'.$_SESSION['sign_respo_etb'],$x + 68,$y + 42,20);
    }

	$i++;
	$i1++;
	$nbc++;
}

/*while($row = $reponse->fetch(PDO::FETCH_ASSOC)) 
		{
			$i++;
			$i1++;
			$st++;
	
			$pdf->Image('../plugins/images/'.$_SESSION['logo_etb'].'',$pximg,$pyimg,15);
			$pximg+=95;
			 $px+=100;
			if ($nbc%2==0) 
			{
				$pyimg+=58;
				$py+=55;
				$lpx=$px;
				$px=10;
				$pximg=48;
				$pdf->Ln();
				$pdf->SetY($pyimg);	
			}*/
									
$pdf->Output('CARTE_CARTE_'.$nomCls.'.pdf','I');
$pdf->Close();
?>
