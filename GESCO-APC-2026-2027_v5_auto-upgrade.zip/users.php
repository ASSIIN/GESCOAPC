<?php
    session_start();   
    require_once 'core/require.php'; 
    require_once 'Model/connexion.php';

    if (!isset($_SESSION['user'])) {
        session_unset();
        session_destroy();
        header('location: index.php');    
        exit();
    }

    // Filtrage strict des rôles d'administration autorisés
    if (($_SESSION['user_role'] != "admin") && ($_SESSION['user_role'] != "pcpl") && ($_SESSION['user_role'] != "cs")) {
        header('location: poste_de_saisie.php?trim=t1');   
        exit();
    }

    $etb->ShowEtb();
    $etb->ckexneE(); // Protection et intégrité de la structure scolaire
    $nbuser = $user->NombreUsers();
?>
<!DOCTYPE html>
<html lang="fr">
  <head>
     <script>
         // Script d'interception immédiate pour empêcher le flash blanc au chargement
         document.documentElement.setAttribute("data-theme", localStorage.getItem("theme") || "light");
     </script>
     <?php Config::head(); ?>
     <title>GESCOAPC | Gestion Utilisateurs</title>
     
     <style>
         @media (max-width: 768px) {
             .fixed-top-mobile {
                 position: relative !important;
                 top: 0 !important;
                 margin-left: 0 !important;
                 width: 100% !important;
                 padding: 10px !important;
             }
             .main-content-wrapper {
                 margin-left: 0 !important;
                 padding: 15px !important;
                 padding-top: 80px !important;
             }
             .btn-mobile-full {
                 width: 100% !important;
             }
         }
         .table-responsive {
             border-radius: 8px;
             overflow: hidden;
         }
     </style>
  </head>
  <body>
    <div class="wrapper">
      
      <!-- Inclusion de la barre latérale externe réutilisable -->
      <?php include 'core/sidebar.php'; ?>  
       
      <div class="main-content-wrapper">
        
        <!-- Barre supérieure d'outils et de filtres (Sticky Mobile) -->
        <div class="mobile-navbar-fixed p-3 mb-4 rounded shadow-sm border">
            <div class="row align-items-center g-2">
                
                <!-- Bouton d'ouverture du menu tiroir sur smartphone -->
                <div class="col-auto d-md-none">
                    <button class="btn btn-outline-dark btn-sm" id="toggleMobileMenu"><i class="fa fa-bars fa-lg"></i></button>
                </div>
                
                <div class="col col-md-6">
                    <h4 class="m-0 fw-bold text-primary" style="font-size: 1.1rem;">
                        <i class="fa fa-street-view me-2"></i>Registre du Personnel 
                        <span class="badge bg-danger ms-2 font-monospace"><?php echo $nbuser; ?></span>
                    </h4>
                </div>

                <div class="col-12 col-md-6 d-flex justify-content-md-end justify-content-start">
                    <button type="button" class="btn btn-sm btn-success text-white px-4 fw-bold btn-mobile-full" data-bs-toggle="modal" data-bs-target="#adduser">
                        <i class="fa fa-plus-circle me-1"></i>Enregistrer un agent
                    </button>
                </div>

            </div>
        </div>

        <!-- Zone d'affichage des messages de retour d'opérations -->
        <?php if (isset($_GET['success'])): ?>
            <div class="alert alert-success alert-dismissible fade show small py-2 shadow-sm" role="alert">
                <i class="fa fa-check-circle me-2"></i>Compte utilisateur créé avec succès. Le matricule généré sert d'identifiant.
                <button type="button" class="btn-close py-2" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>

        <!-- Section Tableau Responsive Filtré des Utilisateurs -->
        <div class="card border-0 shadow-sm">
            <div class="table-responsive w-100">
                <table class="table table-striped table-hover align-middle text-center mb-0">
                    <thead class="text-white table-dark-custom">
                        <tr style="font-size: 0.9em; letter-spacing: 0.3px;">
                            <th style="width: 50px;">#</th>
                            <th style="width: 110px;">IDENTIFIANT</th>
                            <th class="mobile-hide" style="width: 140px;">CODE ACCÈS</th>
                            <th class="text-start" style="padding-left:15px;">NOM DU PERSONNEL</th>
                            <th style="width: 140px;">FONCTION</th>
                            <th class="mobile-hide text-start">DÉPARTEMENT</th>
                            <th style="width: 60px;">EDIT</th>
                            <th style="width: 60px;">DEL</th>
                        </tr>
                    </thead>
                    <tbody id="tab-users" style="font-size: 0.88em; font-weight: 500;">
                        <?php $user->ShowAllUser(); ?>
                    </tbody>
                </table>
            </div>
        </div>

      </div>
    </div>

    <!-- ============================================================== -->
    <!-- MODAL D'AJOUT D'UN COMPTE DE PERSONNEL                         -->
    <!-- ============================================================== -->
    <div class="modal fade" id="adduser" tabindex="-1" aria-labelledby="addUserModalLabel" aria-hidden="true">
      <div class="modal-dialog modal-dialog-centered modal-lg">
        <div class="modal-content border-0">
          
          <div class="modal-header text-white border-0 py-2" style="background-color: #0764a8; border-top-left-radius: 12px; border-top-right-radius: 12px;">
            <h5 class="modal-title fw-bold" id="addUserModalLabel"><i class="fa fa-user-plus me-2"></i>Créer un compte d'accès personnel</h5>
            <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
          </div>
          
          <form action="Controler/admins/adduser.php" method="post">
            <div class="modal-body p-4" style="background-color: var(--bg-main);">
              <div class="container-fluid p-0">                               
                
                <div class="row g-3 mb-3">
                    <div class="col-12 col-md-4">
                        <label for="user_role" class="form-label fw-bold text-secondary small">Rôle d'administration / Fonction</label>
                        <select id="user_role" class="form-select" name="user_role" required>
                             <option value="ens" selected>Enseignant / Corps Professoral</option>
                             <option value="sc">Censeur des Études (SC)</option>
                             <option value="sg">Surveillant Général (SG)</option>
                             <option value="pcpl">Proviseur / Principal d'Établissement</option>
                             <option value="admin">Administrateur Technique Système</option>
                             <option value="caisse">Économe / Responsable Caisse</option>                          
                        </select>
                    </div>

                    <div class="col-12 col-md-8">
                        <label for="user_dep" class="form-label fw-bold text-secondary small">Département d'affectation pédagogique</label>
                        <select id="user_dep" class="form-select" name="user_dep" required>
                             <?php $dep->SelectDep(); ?>                           
                        </select>
                    </div>
                </div>

                <div class="row g-3">
                    <div class="col-12 col-sm-4 col-md-3">
                        <label for="user_civ" class="form-label fw-bold text-secondary small">Civilité / Grade</label>
                        <select id="user_civ" class="form-select" name="user_civ" required>
                            <option value="Mr" selected>M. (Monsieur)</option>
                            <option value="Mme">Mme (Madame)</option>
                            <option value="doc">Dr. (Docteur / Professeur)</option>
                        </select>
                    </div>                           
                    <div class="col-12 col-sm-8 col-md-9">
                        <label for="user_name" class="form-label fw-bold text-secondary small">Nom complet de l'agent</label>
                        <input type="text" class="form-control text-uppercase fw-bold" id="user_name" name="user_name" maxlength="150" required placeholder="EX: KAMGA BERTRAND" style="letter-spacing:0.3px;">
                    </div>
                </div>

              </div>
            </div>
            
            <div class="modal-footer border-top-0 pt-0">
                <button type="button" class="btn btn-secondary px-4 fw-bold" data-bs-dismiss="modal">Annuler</button>
                <button type="submit" class="btn text-white fw-bold px-4" style="background-color: #19784f; border: none; box-shadow: 0 4px 10px rgba(25, 120, 79, 0.2);">
                    <i class="fa fa-save me-2"></i>Créer le compte
                </button>
            </div>
          </form>

        </div>
      </div>
    </div>

    <?php Config::scriptJs(); ?>

    <!-- Scripts de contrôle dynamique et navigation -->
    <script type="text/javascript">
      $(document).ready(function() {
        // Activation visuelle de la page courante dans la Sidebar
        $(".sidebar-menu li").removeClass("active");
        $(".sidebar-menu li[data-page='personnels']").addClass("active");

        // Gestion du menu burger mobile coulissant tactile
        $("#toggleMobileMenu").on("click", function(e) {
            e.stopPropagation();
                        $("#sidebarMenu").toggleClass("active");
        });

        $(document).on("click", function() {
            $("#sidebarMenu").removeClass("active");
        });
      });
    </script>
  </body>
</html>


