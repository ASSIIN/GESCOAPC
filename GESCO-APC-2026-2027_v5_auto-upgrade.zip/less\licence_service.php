<?php
// less/licence_service.php
// Service de licence GESCO-APC : validation HORS-LIGNE par signature asymetrique
// (cle privee INOFIB sur le portail licences.inofib.com, cle publique embarquee ici).

if (!defined('INOFIB_CLE_PUBLIQUE_DEFAUT')) {
    define('INOFIB_CLE_PUBLIQUE_DEFAUT', trim('
-----BEGIN PUBLIC KEY-----
MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAvR4div6YGGtr0LfdcGRB
yrd3F7yzgoKZu3vEXYJ6Q98qAXNDFsc46JUF9ws5H2sUMknZnKOjZ50qCc0iCiHD
6Q3oTQ6zMD2CFXOB4tK5g7ztf4JwDBhGez3+s6AEngyW5Ufzq5coB/EnhnesvWHc
4c1PeDirZDu+Pzs82vbOruRMEyBgvIVjgVBeRK9UsbnS/svIN7rAgaYYbJqiEbM3
ZV8Lz2JMJgqrN3HttfbEy/E+Y+7CPfQx5Yz2/Hg6mZZEPCV6HzqPuyZBvJ5p9SA7
dA1ELw7aeh6iZsy/qSHKdilJRl2DhI99/W2wJyK+XXtDt5D2a9aC5cUfAnFyJyjS
zwIDAQAB
-----END PUBLIC KEY-----
'));
}

if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}

// Portail de remontee periodique (sauvegarde automatique + controle effectif)
if (!defined('INOFIB_API_URL')) {
    define('INOFIB_API_URL', 'https://licences.inofib.com/api/telemetrie.php');
}
if (!defined('INOFIB_TELEMETRIE')) {
    define('INOFIB_TELEMETRIE', true);
}
// Intervalle minimal (jours) entre deux remontees
if (!defined('INOFIB_TELEMETRIE_INTERVAL_JOURS')) {
    define('INOFIB_TELEMETRIE_INTERVAL_JOURS', 6);
}

if (!function_exists('licence_b64u')) {
    function licence_b64u($data)
    {
        return rtrim(strtr(base64_encode($data), '+/', '-_'), '=');
    }

    function licence_from_b64u($data)
    {
        return base64_decode(strtr($data, '-_', '+/'));
    }

    function licence_uuid_v4()
    {
        $data = random_bytes(16);
        $data[6] = chr((ord($data[6]) & 0x0f) | 0x40);
        $data[8] = chr((ord($data[8]) & 0x3f) | 0x80);
        return strtoupper(bin2hex(substr($data, 0, 4)) . '-' . bin2hex(substr($data, 4, 2)) . '-' . bin2hex(substr($data, 6, 2)) . '-' . bin2hex(substr($data, 8, 2)) . '-' . bin2hex(substr($data, 10, 6)));
    }
}

function licence_creer_table()
{
    static $fait = false;
    if ($fait) {
        return;
    }
    $bdd = $GLOBALS['bdd'];
    $bdd->exec("CREATE TABLE IF NOT EXISTS `config_licence` (
        `id` int NOT NULL AUTO_INCREMENT,
        `cle_licence` LONGTEXT NOT NULL,
        `statut_activation` varchar(50) DEFAULT 'inactif',
        `install_id` varchar(64) DEFAULT NULL,
        `cle_publique` LONGTEXT DEFAULT NULL,
        `debut_licence` date DEFAULT NULL,
        `fin_licence` date DEFAULT NULL,
        `nb_poste` int NOT NULL DEFAULT 1,
        `dernier_controle` datetime DEFAULT CURRENT_TIMESTAMP,
        `dernier_sync` datetime DEFAULT NULL,
        `dernier_sync_essai` datetime DEFAULT NULL,
        PRIMARY KEY (`id`),
        UNIQUE KEY `unq_install_id` (`install_id`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;");

    // Migration des installations existantes : ajout des colonnes manquantes
    $cols = [
        ['install_id', "varchar(64) DEFAULT NULL"],
        ['cle_publique', "LONGTEXT DEFAULT NULL"],
        ['debut_licence', "date DEFAULT NULL"],
        ['fin_licence', "date DEFAULT NULL"],
        ['nb_poste', "int NOT NULL DEFAULT 1"],
        ['dernier_sync', "datetime DEFAULT NULL"],
        ['dernier_sync_essai', "datetime DEFAULT NULL"],
        ['historique_licences', "LONGTEXT DEFAULT NULL"],
    ];
    foreach ($cols as $c) {
        $rs = $bdd->query("SELECT COUNT(*) FROM information_schema.COLUMNS
            WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'config_licence' AND COLUMN_NAME = " . $bdd->quote($c[0]));
        if ((int)$rs->fetchColumn() === 0) {
            $bdd->exec("ALTER TABLE `config_licence` ADD COLUMN `{$c[0]}` {$c[1]}");
        }
    }
    // La cle signee depasse 255 caracteres : passage en LONGTEXT si la table est ancienne
    $rs = $bdd->query("SELECT DATA_TYPE FROM information_schema.COLUMNS
        WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'config_licence' AND COLUMN_NAME = 'cle_licence'");
    $tp = $rs->fetchColumn();
    if ($tp !== 'longtext' && $tp !== 'text') {
        $bdd->exec("ALTER TABLE `config_licence` MODIFY `cle_licence` LONGTEXT NOT NULL");
    }
    // Index unique sur install_id (idempotent pour les anciennes bases migrees)
    $rs = $bdd->query("SELECT COUNT(*) FROM information_schema.STATISTICS
        WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'config_licence' AND INDEX_NAME = 'unq_install_id'");
    if ((int)$rs->fetchColumn() === 0) {
        $bdd->exec("ALTER TABLE `config_licence` ADD UNIQUE KEY `unq_install_id` (`install_id`)");
    }
    $fait = true;
}

function licence_lire()
{
    licence_creer_table();
    $stmt = $GLOBALS['bdd']->query('SELECT id, cle_licence, statut_activation, install_id, cle_publique, debut_licence, fin_licence, nb_poste, dernier_controle, dernier_sync, dernier_sync_essai, historique_licences FROM config_licence LIMIT 1');
    return $stmt->fetch(PDO::FETCH_ASSOC) ?: null;
}

// ---- Historique des licences (changement d'établissement / de machine) ----

// Decode le contenu signe d'une cle de licence (sans verifier la signature)
function licence_payload($cle)
{
    $parts = explode('.', trim((string)$cle), 2);
    if (count($parts) !== 2) {
        return null;
    }
    $p = licence_from_b64u($parts[0]);
    if ($p === false) {
        return null;
    }
    $d = json_decode($p, true);
    return is_array($d) ? $d : null;
}

function licence_historique_lire()
{
    $lic = licence_lire();
    $j = $lic['historique_licences'] ?? '';
    $arr = json_decode((string)$j, true);
    return is_array($arr) ? array_values($arr) : [];
}

function licence_historique_ajouter($cle, $cle_publique = '')
{
    $d = licence_payload($cle);
    if (!$d) {
        return;
    }
    $cle = trim($cle);
    $items = licence_historique_lire();
    foreach ($items as $it) {
        if (isset($it['cle']) && $it['cle'] === $cle) {
            return;
        }
    }
    $items[] = [
        'cle' => $cle,
        'cle_publique' => trim((string)$cle_publique) ?: '',
        'etab' => $d['etab'] ?? '',
        'annee' => $d['annee'] ?? '',
        'debut' => $d['debut'] ?? '',
        'fin' => $d['fin'] ?? '',
    ];
    $items = array_slice($items, -8);
    $lic = licence_lire();
    if ($lic) {
        $GLOBALS['bdd']->prepare("UPDATE config_licence SET historique_licences = ? WHERE id = ?")
            ->execute([json_encode(array_values($items), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES), (int)$lic['id']]);
    }
}

// Restaure automatiquement une licence archivee dont le nom correspond au nom
// actuel de l'etablissement (changement de nom legitime deja acte avec une
// nouvelle licence : l'ancienne reste disponible pour revenir en arriere).
function licence_restaurer_licence_par_nom()
{
    $nom_local = licence_nom_etablissement_local();
    if ($nom_local === '') {
        return false;
    }
    $items = licence_historique_lire();
    if (!$items) {
        return false;
    }
    $norme_local = licence_texte_normalise($nom_local);
    foreach ($items as $i => $it) {
        $etab = trim((string)($it['etab'] ?? ''));
        if ($etab === '' || licence_texte_normalise($etab) !== $norme_local) {
            continue;
        }
        $fin = !empty($it['fin']) ? DateTime::createFromFormat('Y-m-d', (string)$it['fin']) : false;
        if ($fin === false || (new DateTime()) > $fin) {
            continue;
        }
        $lic = licence_lire();
        if (!$lic) {
            return false;
        }
        $GLOBALS['bdd']->prepare("UPDATE config_licence SET cle_licence = ?, cle_publique = ?, statut_activation = 'actif', debut_licence = ?, fin_licence = ?, dernier_controle = NOW() WHERE id = ?")
            ->execute([
                (string)$it['cle'],
                !empty($it['cle_publique']) ? (string)$it['cle_publique'] : null,
                !empty($it['debut']) ? (string)$it['debut'] : null,
                !empty($it['fin']) ? (string)$it['fin'] : null,
                (int)$lic['id'],
            ]);
        unset($items[$i]);
        $GLOBALS['bdd']->prepare("UPDATE config_licence SET historique_licences = ? WHERE id = ?")
            ->execute([json_encode(array_values($items), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES), (int)$lic['id']]);
        return true;
    }
    return false;
}

// Nom d'etablissement auquel est liee la cle actuellement enregistree ('' si aucune)
function licence_nom_licence_actuelle()
{
    try {
        $lic = licence_lire();
        if (!$lic || empty($lic['cle_licence'])) {
            return '';
        }
        $d = licence_payload($lic['cle_licence']);
        return $d ? trim((string)($d['etab'] ?? '')) : '';
    } catch (Throwable $e) {
        return '';
    }
}

function licence_set_install_id($install_id)
{
    $stmt = $GLOBALS['bdd']->prepare("UPDATE config_licence SET install_id = ?, dernier_controle = NOW() WHERE id = ?");
    $stmt->execute([$install_id, (int)licence_lire()['id']]);
}

// Normalisation "sans casse ni accents" pour comparer des textes (noms, libelles)
function licence_texte_normalise($s)
{
    $s = mb_strtolower((string)$s, 'UTF-8');
    $s = strtr($s, [
        'à' => 'a', 'â' => 'a', 'ä' => 'a', 'á' => 'a', 'ã' => 'a',
        'é' => 'e', 'è' => 'e', 'ê' => 'e', 'ë' => 'e',
        'î' => 'i', 'ï' => 'i', 'ì' => 'i',
        'ô' => 'o', 'ö' => 'o', 'ò' => 'o',
        'ù' => 'u', 'û' => 'u', 'ü' => 'u',
        'ç' => 'c', 'ñ' => 'n',
    ]);
    return preg_replace('/[^a-z0-9]+/u', '', $s);
}

// Annee scolaire locale : deduite du NOM DE LA BASE (gescoapc_26_27 -> 2026_2027),
// sinon retombe sur la colonne etablissement.school_year ("2026/2027").
// C'est cette reference (et non la cle fraudeuse) qui determine l'annee de travail.
function licence_annee_locale()
{
    $bdd = $GLOBALS['bdd'];
    try {
        $base = (string)$bdd->query('SELECT DATABASE()')->fetchColumn();
        if (preg_match('/_(\d{2})_(\d{2})$/', $base, $m)) {
            return '20' . $m[1] . '_20' . $m[2];
        }
    } catch (Throwable $e) {
    }
    try {
        $annee = (string)$bdd->query("SELECT school_year FROM etablissement LIMIT 1")->fetchColumn();
        $annee = trim($annee);
        if (preg_match('/^(\d{4})[_\/-](\d{4})$/', $annee, $m)) {
            return $m[1] . '_' . $m[2];
        }
        if (preg_match('/^(\d{2})[_\/-](\d{2})$/', $annee, $m)) {
            return '20' . $m[1] . '_20' . $m[2];
        }
    } catch (Throwable $e) {
    }
    return '';
}

function licence_nom_etablissement_local()
{
    try {
        $nom = $GLOBALS['bdd']->query("SELECT nom_etb_fr FROM etablissement LIMIT 1")->fetchColumn();
        return trim((string)$nom);
    } catch (Throwable $e) {
        return '';
    }
}

// Verrouillage anti-fraude. Compatible avec les anciennes cles (sans 'annee') :
// les controles ne s'appliquent que si les champs sont presents dans la clé signee.
// Les clefs signees ne pouvant etre forgees, toute divergence => verrouillage
// des fonctionnalites (meme hors-ligne).
function licence_verifier_fraude(array $data)
{
    if (!isset($data['annee']) && !isset($data['etab'])) {
        return null;
    }
    if (isset($data['annee']) && $data['annee'] !== '') {
        $annee_cle = preg_replace('/\D+/', '', (string)$data['annee']);
        $annee_local = preg_replace('/\D+/', '', licence_annee_locale());
        if ($annee_local !== '' && $annee_local !== $annee_cle && $annee_cle !== '') {
            return ['valide' => false, 'motif' => 'annee'];
        }
    }
    if (!empty($data['etab'])) {
        $nom_local = licence_nom_etablissement_local();
        if ($nom_local !== '') {
            $a = licence_texte_normalise($data['etab']);
            $b = licence_texte_normalise($nom_local);
            if ($a !== '' && $b !== '' && $a !== $b) {
                return ['valide' => false, 'motif' => 'etab'];
            }
        }
    }
    return null;
}

// Controle annuel de la licence signee, avec restauration automatique de
// l'ancienne licence quand le nom de l'etablissement correspond a une licence
// archivee (changement de nom legitime deja acte).
function licence_verifier()
{
    static $profondeur = 0;
    $resultat = licence_verifier_interne();
    if ($profondeur === 0 && isset($resultat['motif']) && $resultat['motif'] === 'etab') {
        if (licence_restaurer_licence_par_nom()) {
            $profondeur = 1;
            try {
                return licence_verifier_interne();
            } finally {
                $profondeur = 0;
            }
        }
    }
    return $resultat;
}

function licence_verifier_interne()
{
    licence_creer_table();
    $bdd = $GLOBALS['bdd'];

    try {
        $licence = licence_lire();
    } catch (Exception $e) {
        return ['valide' => false, 'motif' => 'base'];
    }
    if (!$licence || empty($licence['cle_licence'])) {
        return ['valide' => false, 'motif' => 'vide'];
    }

    $cle = trim($licence['cle_licence']);
    $parts = explode('.', $cle, 2);
    if (count($parts) !== 2) {
        return ['valide' => false, 'motif' => 'format'];
    }
    $payload_json = licence_from_b64u($parts[0]);
    $sig = licence_from_b64u($parts[1]);
    if ($payload_json === false || $sig === false || strlen($sig) < 64) {
        return ['valide' => false, 'motif' => 'format'];
    }

    $cle_publique = trim($licence['cle_publique'] ?? '');
    if ($cle_publique === '') {
        $cle_publique = INOFIB_CLE_PUBLIQUE_DEFAUT;
    }
    if ($cle_publique === '') {
        return ['valide' => false, 'motif' => 'clepublique'];
    }

    $pub = @openssl_pkey_get_public($cle_publique);
    if ($pub === false) {
        return ['valide' => false, 'motif' => 'clepublique_invalide'];
    }
    if (openssl_verify($payload_json, $sig, $pub, OPENSSL_ALGO_SHA256) !== 1) {
        return ['valide' => false, 'motif' => 'signature'];
    }

    $data = json_decode($payload_json, true);
    if (!is_array($data)) {
        return ['valide' => false, 'motif' => 'payload'];
    }
    if (($data['produit'] ?? '') !== 'GESCO-APC') {
        return ['valide' => false, 'motif' => 'produit'];
    }

    // Verrouillage ANTI-FRAUDE : toute cle signee liee a l'etablissement et a
    // l'annee scolaire bloque les fonctionnalites en cas de modification manuelle
    // du nom d'etablissement ou de l'annee scolaire dans la base locale.
    // Controle hors-ligne (signature + champs), actif meme sans connexion internet.
    $fraude = licence_verifier_fraude($data);
    if ($fraude !== null) {
        $fraude['etab_licence'] = $data['etab'] ?? '';
        $fraude['nom_local'] = licence_nom_etablissement_local();
        return $fraude;
    }

    $install_id = $licence['install_id'] ?? '';
    if ($install_id === '' && !empty($data['iid'])) {
        $install_id = trim($data['iid']);
        licence_set_install_id($install_id);
    }
    if ($install_id !== '' && !empty($data['iid']) && $install_id !== trim($data['iid'])) {
        return ['valide' => false, 'motif' => 'appareil'];
    }

    $fin = !empty($data['fin']) ? DateTime::createFromFormat('Y-m-d', $data['fin']) : false;
    if (!$fin) {
        return ['valide' => false, 'motif' => 'date'];
    }
    if ((new DateTime()) > $fin) {
        return ['valide' => false, 'motif' => 'expire'];
    }

    $debut = !empty($data['debut']) ? DateTime::createFromFormat('Y-m-d', $data['debut']) : false;
    if ($debut !== false && (new DateTime()) < $debut) {
        return ['valide' => false, 'motif' => 'pas_encore'];
    }

    $debut_str = $debut ? $debut->format('Y-m-d') : null;
    $nb_poste = (int)($data['nb_poste'] ?? 1);

    $stmt = $bdd->prepare("UPDATE config_licence
        SET statut_activation = 'actif', debut_licence = ?, fin_licence = ?, nb_poste = ?, dernier_controle = NOW()
        WHERE id = ?");
    $stmt->execute([$debut_str, $data['fin'], $nb_poste, (int)$licence['id']]);

    // Remontee periodique (sauvegarde automatique + controle effectif), tres tolérante aux pannes
    if (INOFIB_TELEMETRIE) {
        try {
            licence_telemetrie_envoyer();
        } catch (Throwable $e) {
            // jamais bloquant
        }
    }

    $jours_restants = (int)(new DateTime())->diff($fin)->format('%r%a');

    return [
        'valide' => true,
        'etab' => $data['etab'] ?? '',
        'iid' => $data['iid'] ?? $install_id,
        'annee' => $data['annee'] ?? '',
        'debut' => $debut_str,
        'fin' => $data['fin'],
        'tarif' => $data['tarif'] ?? '',
        'nb_poste' => $nb_poste,
        'email' => $data['email'] ?? '',
        'jours_restants' => $jours_restants,
        'etab_licence' => $data['etab'] ?? '',
        'nom_local' => licence_nom_etablissement_local(),
    ];
}

function licence_verifier_cle_saisie($cle, $cle_publique = '')
{
    licence_creer_table();
    $bdd = $GLOBALS['bdd'];
    $licence = licence_lire();

    $parts = explode('.', trim($cle), 2);
    if (count($parts) !== 2) {
        return ['valide' => false, 'motif' => 'format'];
    }
    $payload_json = licence_from_b64u($parts[0]);
    $sig = licence_from_b64u($parts[1]);
    if ($payload_json === false || $sig === false) {
        return ['valide' => false, 'motif' => 'format'];
    }

    $cle_publique = trim($cle_publique);
    if ($cle_publique === '') {
        $cle_publique = trim($licence['cle_publique'] ?? '');
    }
    if ($cle_publique === '') {
        $cle_publique = INOFIB_CLE_PUBLIQUE_DEFAUT;
    }
    $pub = @openssl_pkey_get_public($cle_publique);
    if ($pub === false) {
        return ['valide' => false, 'motif' => 'clepublique_invalide'];
    }
    if (openssl_verify($payload_json, $sig, $pub, OPENSSL_ALGO_SHA256) !== 1) {
        return ['valide' => false, 'motif' => 'signature'];
    }

    $data = json_decode($payload_json, true);
    if (!is_array($data) || ($data['produit'] ?? '') !== 'GESCO-APC') {
        return ['valide' => false, 'motif' => 'produit'];
    }

    $fraude = licence_verifier_fraude($data);
    if ($fraude !== null) {
        $fraude['etab_licence'] = $data['etab'] ?? '';
        $fraude['nom_local'] = licence_nom_etablissement_local();
        return $fraude;
    }

    $install_id = $licence['install_id'] ?? '';
    if ($install_id !== '' && !empty($data['iid']) && $install_id !== trim($data['iid'])) {
        return ['valide' => false, 'motif' => 'appareil'];
    }

    $fin = !empty($data['fin']) ? DateTime::createFromFormat('Y-m-d', $data['fin']) : false;
    if (!$fin) {
        return ['valide' => false, 'motif' => 'date'];
    }
    if ((new DateTime()) > $fin) {
        return ['valide' => false, 'motif' => 'expire'];
    }

    $debut = !empty($data['debut']) ? DateTime::createFromFormat('Y-m-d', $data['debut']) : false;
    if ($debut !== false && (new DateTime()) < $debut) {
        return ['valide' => false, 'motif' => 'pas_encore'];
    }

    return [
        'valide' => true,
        'data' => $data,
        'etab' => $data['etab'] ?? '',
        'iid' => $data['iid'] ?? '',
        'annee' => $data['annee'] ?? '',
        'debut' => $debut ? $debut->format('Y-m-d') : null,
        'fin' => $data['fin'],
        'tarif' => $data['tarif'] ?? '',
        'nb_poste' => (int)($data['nb_poste'] ?? 1),
    ];
}

function licence_enregistrer($cle, $cle_publique = '', $install_id = '')
{
    $bdd = $GLOBALS['bdd'];
    $licence = licence_lire();

    // Une licence differente est activee : on conserve l'ancienne dans
    // l'historique pour permettre un retour (changement de nom / de machine).
    if ($licence && !empty($licence['cle_licence']) && trim($licence['cle_licence']) !== trim($cle)) {
        licence_historique_ajouter($licence['cle_licence'], $licence['cle_publique'] ?? '');
    }

    $install_id = trim($install_id);
    if ($install_id === '' && $licence) {
        $install_id = trim($licence['install_id'] ?? '');
    }
    if ($install_id === '') {
        $install_id = licence_uuid_v4();
    }

    $stmt = $bdd->prepare("INSERT INTO config_licence (cle_licence, statut_activation, install_id, cle_publique, dernier_controle)
        VALUES (?, 'actif', ?, ?, NOW())
        ON DUPLICATE KEY UPDATE
            cle_licence = VALUES(cle_licence),
            statut_activation = 'actif',
            install_id = VALUES(install_id),
            cle_publique = VALUES(cle_publique),
            dernier_controle = NOW()");
    $stmt->execute([trim($cle), $install_id, trim($cle_publique) ?: null]);
    return $install_id;
}

function licence_motif_message($motif)
{
    $messages = [
        'base' => 'La table de licence est inaccessible.',
        'vide' => 'Aucune licence enregistree sur cet ordinateur.',
        'format' => 'Format de cle de licence incorrect.',
        'clepublique' => 'La cle publique INOFIB n\'est pas configuree.',
        'clepublique_invalide' => 'La cle publique INOFIB fournie est invalide.',
        'signature' => 'Signature de licence invalide : cette cle n\'a pas ete emise par INOFIB.',
        'payload' => 'Contenu de licence illisible.',
        'produit' => 'Cette cle ne correspond pas au produit GESCO-APC.',
        'appareil' => 'Cette cle ne correspond pas a l\'identifiant d\'installation de cet ordinateur. En cas de panne ou de changement d\'ordinateur, saisissez l\'install_id d\'origine (voir portail licences.inofib.com - Recuperer ma cle).',
        'date' => 'Date fin de licence invalide.',
        'expire' => 'La licence est arrivee a expiration. Merci de la renouveler sur le portail licences.inofib.com.',
        'pas_encore' => 'Cette licence prend effet a la rentree de l\'annee scolaire indiquee (date de debut). Utilisez encore la licence de l\'annee en cours pour le moment.',
        'annee' => 'Verrouillage anti-fraude : la base active ne correspond pas a l\'annee scolaire de cette cle de licence. Toute modification manuelle de l\'annee scolaire dans la base est bloquee. Connectez-vous avec la bonne annee scolaire ou contactez le support INOFIB.',
        'etab' => 'Verrouillage anti-fraude : le nom de l\'etablissement a ete modifie depuis l\'emission de la cle. La cle est liee au nom d\'origine ; toute modification manuelle verrouille l\'application. Recuperez une nouvelle cle sur le portail licences.inofib.com (Recuperer ma cle).',
    ];
    return $messages[$motif] ?? 'Licence invalide.';
}

function licence_version_logiciel()
{
    return defined('INOFIB_VERSION') ? INOFIB_VERSION : '2026';
}

function licence_effectif_local()
{
    $bdd = $GLOBALS['bdd'];
    $total = 0;
    foreach (['eleves', 'matr', 'insc'] as $t) {
        try {
            $chk = (int)$bdd->query("SELECT COUNT(*) FROM information_schema.TABLES
                WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = " . $bdd->quote($t))->fetchColumn();
            if ($chk > 0) {
                $total = (int)$bdd->query("SELECT COUNT(*) FROM `$t`")->fetchColumn();
                if ($total > 0) {
                    break;
                }
            }
        } catch (Throwable $e) {
            continue;
        }
    }
    return $total;
}

function licence_snapshots()
{
    $bdd = $GLOBALS['bdd'];
    $exclues = ['eleves', 'matr', 'insc', 'notes', 'notes_trim', 'absences', 'paiements', 'config_licence'];
    $tables = [];
    try {
        foreach ($bdd->query('SHOW TABLES')->fetchAll(PDO::FETCH_COLUMN) as $t) {
            if (in_array(strtolower($t), $exclues, true)) {
                continue;
            }
            try {
                $c = (int)$bdd->query("SELECT COUNT(*) FROM `$t`")->fetchColumn();
            } catch (Throwable $e) {
                continue;
            }
            if ($c > 2000) {
                $tables[$t] = ['lignes' => [], 'total' => $c, 'tronque' => true];
                continue;
            }
            try {
                $tables[$t] = ['lignes' => $bdd->query("SELECT * FROM `$t` LIMIT 2000")->fetchAll(PDO::FETCH_ASSOC)];
            } catch (Throwable $e) {
                $tables[$t] = ['lignes' => []];
            }
        }
    } catch (Throwable $e) {
    }
    return $tables;
}

function licence_http_post_json($url, $json, $bearer)
{
    $ua = 'INOFIB-GESCO-APC/' . licence_version_logiciel();
    if (function_exists('curl_init')) {
        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_POST => true,
            CURLOPT_POSTFIELDS => $json,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_HTTPHEADER => [
                'Content-Type: application/json',
                'Authorization: Bearer ' . $bearer,
                'User-Agent: ' . $ua,
            ],
            CURLOPT_CONNECTTIMEOUT => 3,
            CURLOPT_TIMEOUT => 6,
        ]);
        $body = curl_exec($ch);
        $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        $ok = $code >= 200 && $code < 300;
    } else {
        $ctx = stream_context_create(['http' => [
            'method' => 'POST',
            'header' => "Content-Type: application/json\r\nAuthorization: Bearer " . $bearer . "\r\nUser-Agent: " . $ua . "\r\nContent-Length: " . strlen($json),
            'content' => $json,
            'timeout' => 6,
            'ignore_errors' => true,
        ]]);
        $body = @file_get_contents($url, false, $ctx);
        $ok = $body !== false;
    }
    $data = json_decode((string)$body, true);
    return $ok && is_array($data) && !empty($data['ok']);
}

function licence_telemetrie_envoyer()
{
    $licence = licence_lire();
    if (!$licence || empty($licence['cle_licence']) || empty($licence['install_id'])
        || $licence['statut_activation'] !== 'actif') {
        return false;
    }
    $now = new DateTime();
    if ($licence['dernier_sync']) {
        $sync = new DateTime($licence['dernier_sync']);
        if ($sync->modify('+' . ((int)INOFIB_TELEMETRIE_INTERVAL_JOURS - 1) . ' days') > $now) {
            return false;
        }
    }
    if ($licence['dernier_sync_essai']) {
        $essai = new DateTime($licence['dernier_sync_essai']);
        if ($essai->modify('+24 hours') > $now) {
            return false;
        }
    }
    $bdd = $GLOBALS['bdd'];
    $bdd->prepare("UPDATE config_licence SET dernier_sync_essai = NOW() WHERE id = ?")
        ->execute([(int)$licence['id']]);

    $nom_etab = '';
    try {
        $r = $bdd->query("SELECT nom_etb_fr FROM etablissement LIMIT 1")->fetch(PDO::FETCH_COLUMN);
        $nom_etab = $r !== false ? (string)$r : '';
    } catch (Throwable $e) {
    }

    $learn = ['produit' => 'GESCO-APC', 'version' => licence_version_logiciel(), 'install_id' => $licence['install_id'], 'nom_etab' => $nom_etab, 'nb_eleves' => licence_effectif_local()];
    $dump = $learn + ['export_le' => date('Y-m-d H:i:s'), 'tables' => licence_snapshots()];
    $gz = gzencode(json_encode($dump, JSON_UNESCAPED_UNICODE), 6);
    $sauvegarde = $gz !== false ? base64_encode($gz) : null;
    if (strlen((string)$sauvegarde) > 3900000) {
        $sauvegarde = base64_encode(gzencode(json_encode($learn), 6));
    }

    $corps = json_encode(['version' => $learn['version'], 'nb_eleves' => $learn['nb_eleves'], 'sauvegarde' => $sauvegarde], JSON_UNESCAPED_UNICODE);
    $ok = licence_http_post_json(INOFIB_API_URL, $corps, $licence['cle_licence']);

    if ($ok) {
        $bdd->prepare("UPDATE config_licence SET dernier_sync = NOW(), dernier_sync_essai = NULL WHERE id = ?")
            ->execute([(int)$licence['id']]);
    }
    return $ok;
}