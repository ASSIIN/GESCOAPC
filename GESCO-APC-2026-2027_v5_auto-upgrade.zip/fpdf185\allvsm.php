<?php
session_start();
require_once '../Model/connexion.php';
require_once '../core/require.php';
 if (!isset($_SESSION['user'])) {
    session_unset();
    session_destroy();
    header('location: ../index.php');    
    }
 $etb->ShowEtb();
 if (!isset($_POST['prd']) and !isset($_POST['prd0']) and !isset($_POST['prd1'])) {
   	header('location: ../gestion_fin.php');    
    }
$prd = isset($_POST['prd']) ? htmlspecialchars($_POST['prd']) : '';
$in0 = isset($_POST['prd0']) ? htmlspecialchars($_POST['prd0']) : '';
$in1 = isset($_POST['prd1']) ? htmlspecialchars($_POST['prd1']) : '';
$p0 = '1900-01-01';
$p1 = date('Y-m-d', strtotime('+1 day'));
if ($prd == '0' or $prd == 'today') {
	$p0 = date('Y-m-d');
	$p1 = date('Y-m-d', strtotime($p0.'+1 day'));
}
else if ($prd == 'week') {
	$p0 = date('Y-m-d', strtotime('monday this week'));
	$p1 = date('Y-m-d', strtotime('monday this week +7 days'));
}
else if ($prd == 'month') {
	$p0 = date('Y-m-01');
	$p1 = date('Y-m-d', strtotime(date('Y-m-01').' +1 month'));
}
else if ($prd == 'pr' or $prd == 'custom') {
	if ($in0 !== '') { $p0 = $in0; }
	if ($in1 !== '') { $p1 = date('Y-m-d', strtotime($in1.'+1 day')); }
}
require('fpdf.php');
$pdf = new FPDF();

class PDF extends FPDF
{
// En-tête
function Header()
{
	 $this->SetY(15);
    // Logo
    $this->Image('../plugins/images/'.$_SESSION['logo_etb'].'',10,6,30);
    // Police Arial gras 15
    $this->SetFont('Arial','B',15);
    // Décalage à droite
    $this->Cell(80);
    // Titre
    $this->Cell(30,10,'Titre',1,0,'C');
    // Saut de ligne
    $this->Ln(20);
}

// Pied de page
function Footer()
{
    // Positionnement à 1,5 cm du bas
    $this->SetY(-15);
    // Police Arial italique 8
    $this->SetFont('Arial','I',8);
    // Numéro de page
    $this->Cell(0,10,'Page '.$this->PageNo().'/{nb}',0,0,'C');
}
}
$pdf->AliasNBPages();
$pdf->AddPage();
//code for print data

		 $bdd = $GLOBALS['bdd'];


			$reponse = $bdd->query('SELECT id, ref_std, prix_vsm, id_vsm, DATE_FORMAT(post_on, \'%d/%m/%Y %H:%i:%s\') AS date_fr FROM versements where post_on BETWEEN "'.$p0.'" and "'.$p1.'" order by post_on desc ');

			$i=0;
			/*En-tête*/
				$pdf->SetFont('Times','',8);
				$pdf->Image('../plugins/images/'.$_SESSION['logo_etb'].'',90,15,30);
				$pdf->Cell(70,4,'REPUBLIQUE DU CAMEROUN',0,0,'C');
				$pdf->Cell(50,4,'',0,0);
				$pdf->Cell(70,4,'REPUBLIC OF CAMEROON',0,1,'C');

				$pdf->Cell(70,4,'Paix-Travail-Patrie',0,0,'C');
				$pdf->Cell(50,4,'',0,0);
				$pdf->Cell(70,4,'Peace-Work-Fatherland',0,1,'C');

				$pdf->Cell(70,4, utf8_to_cp1252("".$_SESSION['minist_etb_fr'].""),0,0,'C');
				$pdf->Cell(50,4,'',0,0);
				$pdf->Cell(70,4,utf8_to_cp1252(''.$_SESSION['minist_etb_en'].''),0,1,'C');

				$pdf->Cell(70,4,utf8_to_cp1252("".$_SESSION['region_etb_fr'].""),0,0,'C');
				$pdf->Cell(50,4,'',0,0);
				$pdf->Cell(70,4,utf8_to_cp1252(''.$_SESSION['region_etb_en'].''),0,1,'C');

				$pdf->Cell(70,4,utf8_to_cp1252(''.$_SESSION['depart_etb_fr'].''),0,0,'C');
				$pdf->Cell(50,4,'',0,0);
				$pdf->Cell(70,4,utf8_to_cp1252(''.$_SESSION['depart_etb_en'].''),0,1,'C');
				$pdf->SetFont('Times','B',10);
				$pdf->Cell(70,6,utf8_to_cp1252(''.$_SESSION['nom_etb_fr'].''),0,0,'C');
				$pdf->Cell(50,6,'',0,0);
				$pdf->Cell(70,6,utf8_to_cp1252(''.$_SESSION['nom_etb_en'].''),0,1,'C');
				$pdf->SetFont('Times','',8);
				$pdf->Cell(70,5,utf8_to_cp1252(''.$_SESSION['code_pste_etb'].' / '.$_SESSION['tel_etb'].''),0,0,'C');
				$pdf->Cell(50,5,'',0,0);
				$pdf->Cell(70,5,utf8_to_cp1252(''.$_SESSION['code_pste_etb'].'/ '.$_SESSION['tel_etb'].''),0,1,'C');
				$pdf->SetFont('Times','',8);
				$pdf->Cell(70,4,utf8_to_cp1252(''.$_SESSION['email_etb'].''),0,0,'C');
				$pdf->Cell(50,4,'',0,0);
				$pdf->Cell(70,4,utf8_to_cp1252(''.$_SESSION['email_etb'].''),0,1,'C');
					$pdf->Ln();
					$pdf->SetFont('Times','I',12);
					$pdf->Cell(65,5,'',0,0);
					$pdf->Cell(60,5,utf8_to_cp1252(''.$_SESSION['code_im_etb'].''),0,0,'C');
					$pdf->Ln();
					$pdf->Ln();
			/*FIN En-tête*/
						$today= date('d/m/Y');
					$pdf->SetFont('Times','B',12);
					$pdf->SetFillColor(171,177,186);
					$pdf->Cell(20,6,'',0,0,'C');
					$pdf->Cell(150,6,'HISTORIQUE DES VERSEMENTS ',1,0,'C',1);
					$pdf->Ln();
					$pdf->SetTextColor(255,2,2);
					$pdf->SetFont('Times','B',11);
					$pdf->Cell(60,6,'',0,0,'C');
					$pdf->Cell(70,6,utf8_to_cp1252('imprimé le /Printed on  '.$today.''),0,1,'C');
					$pdf->Cell(60,6,'',0,0,'C');
					$pdf->Ln();
					$pdf->SetTextColor(0,0,0);
					$pdf->SetFont('Times','B',12);

			
			$pdf->SetFont('Times','B',10);
				$pdf->Ln();
					$pdf->Cell(10,6,utf8_to_cp1252('N°'),1,0, 'C');
					$pdf->Cell(22,6,'Matricule',1,0, 'C');
					$pdf->Cell(70,6,utf8_to_cp1252('Noms_et_Prénoms/Full_Name'),1,0, 'C');
					$pdf->Cell(26,6,utf8_to_cp1252('VERSEMENTS'),1,0, 'C');
					$pdf->Cell(26,6,utf8_to_cp1252('REMISES'),1,0, 'C');
					$pdf->Cell(32,6,utf8_to_cp1252('DATE DE VERSEM.'),1,0, 'C');
					$t_vsm=0;
					$t_rms=0;
					$n=0;
					
			while($row = $reponse->fetch(PDO::FETCH_ASSOC)) 
			{
				$i++;
			    $nomstd=$fin->SelectFullNombyMat($row['ref_std']);
			    $rms=$fin->ReturnRemisebyVsmID_and_Std($row['id_vsm'],$row['ref_std']);
			    if ($rms!=0) {
			     $frms= number_format($rms,0,",",".");	
			    }
			    else{
			    	$frms=0;
			    }
				$vsm= number_format($row['prix_vsm'],0,",",".");

					$pdf->SetFont('Arial','',9);
					$pdf->Ln();
					$pdf->Cell(10,5,$i,1,0);
					$pdf->Cell(22,5,utf8_to_cp1252(''.$_SESSION['pre_matr'].''.$row['ref_std'].''),1,0,'C');
					$pdf->Cell(70,5,utf8_to_cp1252(''.$nomstd.''),1,0,'L');
					$pdf->Cell(26,5,utf8_to_cp1252($vsm),1,0,'C');
					$pdf->Cell(26,5,utf8_to_cp1252($frms),1,0,'C');
					$pdf->Cell(32,5,utf8_to_cp1252($row['date_fr']),1,0,'C');
					$t_vsm+=$row['prix_vsm'];
					$t_rms+=$rms;
				}

				$t_vsm= number_format($t_vsm,0,",",".");
				$t_rms= number_format($t_rms,0,",",".");
				

				 
				 $pdf->SetFont('Arial','B',10);
					$pdf->Ln();
						
				
				$pdf->Cell(102,5,utf8_to_cp1252('MONTANT TOTAL DES VERSEMENTS '),1,0,'L');
				$pdf->Cell(26,5,utf8_to_cp1252($t_vsm),1,0,'C');
				$pdf->Cell(26,5,utf8_to_cp1252($t_rms),1,0,'C');
				$pdf->Cell(32,5,utf8_to_cp1252('-------'),1,0,'C');
				$pdf->SetXY(125,272);
			$pdf->Cell(0,3,'Page '.$pdf->PageNo().'/{nb}',0,1,'C');
			$pdf->Output('ETATS_PAIEMENTS_CLASS.pdf','I');
			$pdf->Close();
?>
