<?php
    session_start();   
  require_once 'core/require.php'; 
  require_once 'Model/connexion.php';
     if (!isset($_SESSION['user'])) {
    session_unset();
    session_destroy();
    header('location: index.php');    
    }
    $admin->ShowAdmin($_SESSION['login']);
    $nbclasses=$class->NombreClasses();
    $etb->ShowEtb();
    $etb->CkLE();
    $etb->ckexneE();
    
?>

<!DOCTYPE html>
<html>
  <head>
   <?php Config::head_b462(); ?>
    <title>Ndalère Tools|NOTES</title>
    <style type="text/css">
      .tabte-n{
        border-collapse:collapse;
      }
      .tab-notes{  
        border-collapse:collapse;
        border-color: #c2be02; 
        border: 2px solid;
      }
    
      .tab-notes>tr,th,td{
        border: 1px solid;
       line-height:20px;
        border-color: #c2be02;
        border-collapse:collapse;

      }

       .slimscrollsidebar>ul,li{
        font-size: 0.9em;
      }
     
      
    </style>
    
  </head>


<body class="fix-header" data-imprimable="1">
     <!-- #header -->
    <?php Head::SimpleHead($_SESSION['user_role']); ?>  
        <!-- Page Content -->
        <!-- ============================================================== -->
        <div id="page-wrapper">
            <div class="container-fluid">

              <div class="row">
                <div class="col-md-10 col-lg-10 col-sm-10">
                  <h3 class="box-title">
                    <a href="gestion_notes_by_mat.php"> <button type="button" class="btn btn-primary btn-sm ml-2 mx-2" style="font-size: 0.8em;">Saisir Notes <i class="fa fa-edit" ></i></button></a>

                    <a href="gestion_import_notes.php"> <button type="button" class="btn btn-primary btn-sm ml-2 mx-2" style="font-size: 0.8em; background-color: #6b6900">Importer <i class="fa fa-file-excel-o"  style="background-color: #1f7246"></i></button></a>
                   

                   <button type="button" class="btn btn-info btn-sm ml-2 mx-2" data-toggle="modal" data-target="#importstd" data-whatever="@mdo"  style="font-size: 0.8em">Notes Elève<i class="fa  fa-update" aria-hidden="true"></i>
                   </button>

                   <button type="button" class="btn btn-info btn-sm ml-2 mx-2" data-toggle="modal" data-target="#reconN" data-whatever="@mdo"  style="font-size: 0.8em">Reconduire<i class="fa  fa-update" aria-hidden="true"></i>
                   </button>
                </h3>
                   </div>
                <div class="col-md-2 col-sm-2 col-xs-2 pull-right">
                   <div class="dropdown" tabindex="-2">
                      <button class="btn btn-danger btn-sm btn-primarydropdown-toggle" type="button" data-toggle="dropdown" aria-expanded="false" style="font-size: 0.9em;">
                      Model Excel<i class="fa  fa-export" aria-hidden="true"></i>
                      </button>
                      <div class="dropdown-menu">
                        <?php $class->ExportSheetNotes_Ens($_SESSION['login']); ?> 
                      </div>
                    </div>
                  </div>
                 </div>        
                <div class="row mb-5">
                 <div class="col-md-12 col-lg-12 col-sm-12">
                  <h3 class="fw-bolder text-center" >Poste de Saisie des notes</h3> 
              <?php  if ( (isset($_GET['cls'])) and (isset($_GET['mat'])) and (isset($_GET['seq'])) ) 
                {
                     echo '   
                   
                  <div class=" my-custom-scrollbar mb-5" style="font-size: 1em; height: 5px ; display:none">';
                  }
                  else{
                   echo '   
                   
                  <div class=" my-custom-scrollbar mb-5" style="font-size: 1em; ">';

                }
                 ?> 
                
                <div class="accordion col-12 col-md-12 mb-3" id="accordionExample">
                <?php 
                    $bdd = $GLOBALS['bdd'];
                    $i=0;
                    $nt=0;
                    $reponse = $bdd->query('SELECT distinct(ref_class) as tref_class FROM config_bull where ref_ens="'.$_SESSION['login'].'" ');
                    while($row = $reponse->fetch(PDO::FETCH_ASSOC)) 
                    {
                      $i++;
                      $nom_cls=$class->ShowCls_namebyID($row['tref_class']);
                      echo '

                      <div class="card ">
                        <div class="card-header" id="heading'.$row['tref_class'].'">
                          <h2 class="mb-2">
                            <button class="btn btn-link btn-block text-left" type="button" data-toggle="collapse" data-target="#collapse'.$row['tref_class'].'" aria-expanded="true" aria-controls="collapse'.$row['tref_class'].'"> NOTES ** '.$nom_cls.' ( '.$row['tref_class'].' )</button>
                          </h2>
                        </div>
                        <div id="collapse'.$row['tref_class'].'" class="collapse pb-5" aria-labelledby="heading'.$row['tref_class'].'" data-parent="#accordionExample">
                          <div class="card-body  pb-5" tabindex="-1">
                           <div class="row " style="font-size:0.9em">';
                           $class->ShowMat_Note_and_Eval_Ens($row['tref_class'],$_SESSION['login']);
                          //$class->ShowCls_Note_by_admin2($row['code_class']);
                       echo '
                          
                              </div>
                            </div>
                            </div>
                          </div>';

                    }
               ?> 
                
               </div> 
                                     
              </div>  
              <div class="row mb-5">

                  <?php  if ( (isset($_GET['cls'])) and (isset($_GET['mat'])) and (isset($_GET['seq'])) )  {

                    if ($_GET['seq']=='12') {
                      $e1="1";
                      $e2="2";
                      }
                      if ($_GET['seq']=='34') {
                      $e1="3";
                      $e2="4";
                      }
                      if ($_GET['seq']=='56') {
                      $e1="5";
                      $e2="6";
                      }

                    if ($_GET['seq']=='12' or $_GET['seq']=='34' or $_GET['seq']=='56') {

                      echo '
                       <div class="col-md-8">
                       <div class="table-responsive table-wrapper-scroll-y my-custom-scrollbar " style="font-size: 0.9em;">
                              <table class="tab-notes" >
                                  <thead class="table-info">
                                      <tr>
                                          <th style="width:4%">#</th>
                                          <th style="width:11%">Mat</th>
                                          <th style="width:58%">Nom et Pérenom</th>
                                          <th style="width:13%">EVAL'.$e1.'</th>
                                          <th style="width:13%">EVAL'.$e2.'</th>
                          
                                      </tr>
                                  </thead>
                                  <tbody  style="font-size:0.9em;">';
                                  $class->ShowStd_for_Notes_by_Mat($_GET['cls'],$_GET['mat'],$_GET['seq']);
                           $class->ShowInfosStd_for_Notes_by_Mat($_GET['cls'],$_GET['mat'],$_GET['seq']);

                    }
                    else{
                       echo '
                       <div class="col-md-8">
                       <div class="table-responsive table-wrapper-scroll-y my-custom-scrollbar " style="font-size: 0.9em;">
                              <table class="tab-notes" >
                                  <thead class="table-info">
                                      <tr>
                                          <th style="width:5%">#</th>
                                          <th style="width:12%">Mat</th>
                                          <th style="width:68%">Nom et Pérenom</th>
                                          <th style="width:15%">NOTE/20</th>
                                      </tr>
                                  </thead>
                                  <tbody  style="font-size:0.9em; line-height:2px">';
                                  $class->ShowStd_for_Note_by_Mat($_GET['cls'],$_GET['mat'],$_GET['seq']);
                           $class->ShowInfosStd_for_Note_by_Mat($_GET['cls'],$_GET['mat'],$_GET['seq']);
                  }
                  }
                   ?> 
           
                                  
                  </div>

      <div class="row">     
          <div class="modal fade" id="addNoteExcel" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true" style="background-color: rgba(107,105,0,0.5);">
            <div class="modal-dialog modal-lg" role="document">
              <div class="modal-content mx-1 " >
                <div class="modal-header">
                  <h5 class="modal-title" id="exampleModalLabel">IMPORTER UN FICHER EXCEL</h5>
                  <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                  </button>
                </div>
                <div class="modal-body" style=""> 
                 <div class="container-fluid">                               
                  

                  <div class=" my-custom-scrollbar" style="font-size: 1em;">
                    <div class="row">
                      <div class="accordion col-12 col-md-12" id="accordionExample2">
                        <?php 
                        if($_SESSION['user_role']=="admin")
                        {
                            $bdd = $GLOBALS['bdd'];
                            $i=0;
                            $nt=0;
                            $reponse = $bdd->query('SELECT * FROM classes where id>=0 order by ref_class_niveau asc');
                            while($row = $reponse->fetch(PDO::FETCH_ASSOC)) 
                            {
                              $i++;
                              $nom_cls=$class->ShowCls_namebyID($row['code_class']);
                              echo '

                              <div class="card">
                                <div class="card-header" id="heading'.$row['code_class'].'">
                                  <h2 class="mb-0">
                                    <button class="btn btn-link btn-block text-left" type="button" data-toggle="collapse" data-target="#collapsei'.$row['code_class'].'" aria-expanded="true" aria-controls="collapsei'.$row['code_class'].'"> NOTES ** '.$nom_cls.' ( '.$row['code_class'].' )</button>
                                  </h2>
                                </div>
                                <div id="collapsei'.$row['code_class'].'" class="collapse" aria-labelledby="heading'.$row['code_class'].'" data-parent="#accordionExample2">
                                  <div class="card-body">
                                   <div class="row " style="font-size:0.9em">';
                                   $class->ShowMat_Note_and_Eval_adminImpExcel($row['code_class']);
                                  //$class->ShowCls_Note_by_admin2($row['code_class']);
                               echo '
                                  
                                      </div>
                                    </div>
                                    </div>
                                  </div>';

                                  }
                              }
                              else{
                                 $class->ShowCls_Note_by_User($_SESSION['login']);
                             }
                             ?> 
                              
                             </div> 
                              
                              </div>                       
                            </div>
                                      
                        </div>
                      </div>
                    </div>
                  </div>
          </div>                
      </div>
    </div>
          
         
      <?php 
          Footers::TDfoot();
      ?>
      </div>
      <!-- ============================================================== -->
      <!-- End Page Content -->
      <!-- ============================================================== -->
  </div>


  <?php 
    Config::scriptJ_b462();
  ?>
      <script type="text/javascript">

    //$('.collapse').collapse(''); 
    //$('.dropdown-toggle').dropdown('hide'); 
      </script>

  </body>
</html>
