<?php
session_start();
require_once '../Model/connexion.php';
require_once '../core/require.php';
 if (!isset($_SESSION['user'])) {
    session_unset();
    session_destroy();
    header('location: ../index.php');    
    }
 $etb->ShowEtb();
 
$refcls=$_SESSION['notelist_refcls'];
require('fpdf.php');
$pdf = new FPDF();

class PDF extends FPDF
{
// En-tête
function Header()
{
	 $this->SetY(15);
    // Logo
    $this->Image('../plugins/images/'.$_SESSION['logo_etb'].'',10,6,30);
    // Police Arial gras 15
    $this->SetFont('Arial','B',15);
    // Décalage à droite
    $this->Cell(80);
    // Titre
    $this->Cell(30,10,'Titre',1,0,'C');
    // Saut de ligne
    $this->Ln(20);
}

// Pied de page
function Footer()
{
    // Positionnement à 1,5 cm du bas
    $this->SetY(10);
    // Police Arial italique 8
    $this->SetFont('Arial','I',8);
    // Numéro de page
    $this->Cell(100,10,'Page '.$this->PageNo().'/{nb}',0,1,'C');
}
}

$pdf->AddPage();
//code for print data

		 $bdd = $GLOBALS['bdd'];
			$reponse = $bdd->query('SELECT * FROM eleves where ref_class="'.$refcls.'" order by nom_std asc');

			$i=1;
			$eff=0;
			/*En-tête*/
				$pdf->SetFont('Times','',8);
				$pdf->Image('../plugins/images/'.$_SESSION['logo_etb'].'',90,15,30);
				$pdf->Cell(70,4,'REPUBLIQUE DU CAMEROUN',0,0,'C');
				$pdf->Cell(50,4,'',0,0);
				$pdf->Cell(70,4,'REPUBLIC OF CAMEROON',0,1,'C');

				$pdf->Cell(70,4,'Paix-Travail-Patrie',0,0,'C');
				$pdf->Cell(50,4,'',0,0);
				$pdf->Cell(70,4,'Peace-Work-Fatherland',0,1,'C');

				$pdf->Cell(70,4, utf8_to_cp1252("".$_SESSION['minist_etb_fr'].""),0,0,'C');
				$pdf->Cell(50,4,'',0,0);
				$pdf->Cell(70,4,utf8_to_cp1252(''.$_SESSION['minist_etb_en'].''),0,1,'C');

				$pdf->Cell(70,4,utf8_to_cp1252("".$_SESSION['region_etb_fr'].""),0,0,'C');
				$pdf->Cell(50,4,'',0,0);
				$pdf->Cell(70,4,utf8_to_cp1252(''.$_SESSION['region_etb_en'].''),0,1,'C');

				$pdf->Cell(70,4,utf8_to_cp1252(''.$_SESSION['depart_etb_fr'].''),0,0,'C');
				$pdf->Cell(50,4,'',0,0);
				$pdf->Cell(70,4,utf8_to_cp1252(''.$_SESSION['depart_etb_en'].''),0,1,'C');
				$pdf->SetFont('Times','B',10);
				$pdf->Cell(70,6,utf8_to_cp1252(''.$_SESSION['nom_etb_fr'].''),0,0,'C');
				$pdf->Cell(50,6,'',0,0);
				$pdf->Cell(70,6,utf8_to_cp1252(''.$_SESSION['nom_etb_en'].''),0,1,'C');
				$pdf->SetFont('Times','',8);
				$pdf->Cell(70,5,utf8_to_cp1252(''.$_SESSION['code_pste_etb'].' / '.$_SESSION['tel_etb'].''),0,0,'C');
				$pdf->Cell(50,5,'',0,0);
				$pdf->Cell(70,5,utf8_to_cp1252(''.$_SESSION['code_pste_etb'].'/ '.$_SESSION['tel_etb'].''),0,1,'C');
				$pdf->SetFont('Times','',8);
				$pdf->Cell(70,4,utf8_to_cp1252(''.$_SESSION['email_etb'].''),0,0,'C');
				$pdf->Cell(50,4,'',0,0);
				$pdf->Cell(70,4,utf8_to_cp1252(''.$_SESSION['email_etb'].''),0,1,'C');
					$pdf->Ln();
					$pdf->SetFont('Times','I',12);
					$pdf->Cell(65,5,'',0,0);
					$pdf->Cell(60,5,utf8_to_cp1252(''.$_SESSION['code_im_etb'].''),0,0,'C');
					$pdf->Ln();
					$pdf->Ln();
			/*FIN En-tête*/
				//Titre 
				$pdf->SetFont('Times','I',10);
				$pdf->Cell(50,5,'',0,0,'C');
				$pdf->Cell(60,5,'ANNEE SCOLAIRE/SCHOOL ',0,0,'R');
				$pdf->SetFont('Times','B',12);
				$pdf->Cell(40,5,''.$_SESSION['school_year'].'',0,0,'L');
				$pdf->Cell(40,5,'',0,1,'C');
				
				$pdf->SetFont('Times','B',12);
				$pdf->SetFillColor(171,177,186);
				$pdf->SetFillColor(217,245,254);
				$pdf->Cell(20,6,'',0,0,'C');
				$pdf->Cell(150,6,'FICHE DE RELEVE DE NOTES/MARKS SHEET',1,0,'C',1);
				$pdf->Cell(20,6,'',0,1,'C');
				$pdf->Ln();

				$class->CkClasseByCode($refcls);
				$nbstd=$class->NbrStudentByClass($refcls);
				$nbM=$class->NbrBySexeByClass($refcls,'M');
				$nbF=$class->NbrBySexeByClass($refcls,'F');
				$nomcls=$_SESSION['nom_class'];
				$niveaucls=$_SESSION['ref_class_niveau'];

				$pdf->Cell(70,5,"Classe: $nomcls",1,0,'L');
				$pdf->Cell(40,5,"Niveau: $niveaucls",1,0,'C');
				$pdf->Cell(44,5,"Eff: $nbstd",1,0,'C');
				$pdf->Cell(20,5,"M: $nbM",1,0,'C');
				$pdf->Cell(20,5,"F: $nbF",1,0,'C');
				$pdf->Ln();
				$pdf->Cell(40,5,"Enseignant/Teacher:",1,0,'L');
				$pdf->Cell(72,5,"",1,0,'C');
				$pdf->Cell(34,5,utf8_to_cp1252("Matière/Subject:"),1,0,'C');
				$pdf->Cell(48,5,"",1,0,'C');
				
			
			
			$pdf->SetFont('Times','B',8);
				$pdf->Ln();
					$pdf->Cell(10,6,utf8_to_cp1252('N°'),1,0);
					$pdf->Cell(20,6, utf8_to_cp1252('N° INSCRIPT'),1,0);
					$pdf->Cell(22,6,'MATRICULE',1,0);
					$pdf->Cell(60,6,utf8_to_cp1252('NOMS ET PRENOM/FULL_NAME'),1,0);
					$pdf->Cell(10,6,'SEXE',1,0);
					$pdf->Cell(12,6,'CPT 1',1,0);
					$pdf->Cell(12,6,'CPT 2',1,0);
					$pdf->Cell(12,6,'CPT 3',1,0);
					$pdf->Cell(12,6,'CPT 4',1,0);
					$pdf->Cell(12,6,'CPT 5',1,0);
					$pdf->Cell(12,6,'CPT 6',1,0);
			 
			while($row = $reponse->fetch(PDO::FETCH_ASSOC)) 
			{
				$Nom=htmlspecialchars($row['nom_std']);
				$Nom=strtoupper($Nom);
				$Nom=substr($Nom, 0,36);
				$Nom = str_replace("&#039;", "'", $Nom);


				$date_nais_fr= date('d/m/Y ',strtotime($row['date_nais']));
				/*$row['mat_std'];
				$row['nom_prenom_std']
				$row['sexe_std']
				$row['date_nais']
				$row['lieu_nais']*/
				$pdf->SetFont('Arial','',8);
				$pdf->Ln();
					$pdf->Cell(10,5,$i,1,0);
					$pdf->Cell(20,5,utf8_to_cp1252(''.$_SESSION['pre_matr'].''.$row['mat_std'].''),1,0,'C');
					$pdf->Cell(22,5,utf8_to_cp1252(''.$row['cni_std'].''),1,0,'C');
					$pdf->SetFont('Arial','',7);
					$pdf->Cell(60,5,utf8_to_cp1252($Nom),1,0);
					$pdf->SetFont('Arial','',8);
					$pdf->Cell(10,5,utf8_to_cp1252($row['sexe_std']),1,0,'C');
					$pdf->Cell(12,5,'',1,0);
					$pdf->Cell(12,5,'',1,0);
					$pdf->Cell(12,5,'',1,0);
					$pdf->Cell(12,5,'',1,0);
					$pdf->Cell(12,5,'',1,0);
					$pdf->Cell(12,5,'',1,0);
					$i++;
				}
				 $eff=$i;
		$pdf->Footer();

$pdf->Output('CLASS_LIST_ '.$nomcls.'.pdf','I');
?>
