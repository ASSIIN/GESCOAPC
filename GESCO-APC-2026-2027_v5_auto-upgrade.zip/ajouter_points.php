<?php
// --- Étape 2: Masquer les erreurs d'affichage pour ne pas casser le JSON ---
// Configure PHP pour ne pas afficher les erreurs à l'écran, 
// mais les enregistrer dans les logs du serveur (bonne pratique).
ini_set('display_errors', 0);
error_reporting(E_ALL);

 session_start();   
    // Assurez-vous que les chemins d'accès à vos fichiers de configuration sont corrects
    require_once 'core/require.php'; 
    require_once 'Model/connexion.php';
     if (!isset($_SESSION['user'])) {
    session_unset();
    session_destroy();
    header('location: index.php');    
    exit; // Toujours sortir après une redirection d'en-tête
    }

// Fonction utilitaire pour envoyer une réponse JSON et arrêter le script
function sendJsonResponse($status, $message) {
    // S'assure que l'en-tête JSON est envoyé avant d'écrire la réponse
    if (!headers_sent()) {
        header('Content-Type: application/json');
    }
    echo json_encode(['status' => $status, 'message' => $message]);
    exit;
}

// =====================================================================
// NOUVEAU: Récupérer les données envoyées par POST (JSON)
// Le JavaScript envoie les données en format JSON dans le corps de la requête.
// =====================================================================
$input = json_decode(file_get_contents('php://input'), true);

if ($input === null) {
    sendJsonResponse('error', 'Aucune donnée reçue ou données invalides au format JSON.');
}

// =====================================================================
// NOUVEAU: Gestion du jeton anti double-soumission 
// =====================================================================
$token_recu = $input['token'] ?? null;

if (!$token_recu || !isset($_SESSION['last_token']) || $token_recu !== $_SESSION['last_token']) {
    // Si le jeton est manquant, incorrect ou déjà utilisé
    sendJsonResponse('error', 'Opération invalide ou déjà effectuée. Veuillez rafraîchir la page et réessayer.');
}

// CONSOMMATION DU JETON : Le supprimer après sa première utilisation réussie
unset($_SESSION['last_token']);
// =====================================================================

// Vérifier si toutes les données nécessaires sont présentes dans le tableau $input
$required_params = ['ref_class', 'ref_mat', 'ref_eval', 'point_a_ajouter'];
foreach ($required_params as $param) {
    if (!isset($input[$param])) {
        sendJsonResponse('error', 'Paramètre manquant : ' . $param);
    }
}

// Récupération et validation des données depuis $input
$ref_class = filter_var($input['ref_class'], FILTER_UNSAFE_RAW);
$ref_mat = filter_var($input['ref_mat'], FILTER_UNSAFE_RAW);
$ref_eval = filter_var($input['ref_eval'], FILTER_VALIDATE_INT);
$points_a_ajouter = filter_var($input['point_a_ajouter'], FILTER_VALIDATE_FLOAT);

// CORRECTION SÉCURITÉ : on limite l'évaluation aux 6 tables existantes (1-6) pour
// empêcher tout accès à une table inventée par manipulation du paramètre.
if ($ref_eval === false || $ref_eval < 1 || $ref_eval > 6 || $points_a_ajouter === false || $points_a_ajouter <= 0) {
    sendJsonResponse('error', 'Les valeurs de référence d\'évaluation ou de points à ajouter sont invalides.');
}

// =====================================================================
// CORRECTION SÉCURITÉ : contrôle d'accès sur la classe / matière.
// Un enseignant (role "ens") ne peut ajouter des points que sur les matières
// qui lui sont attribuées dans config_bull (ref_ens = login connecté).
// =====================================================================
$bdd = $GLOBALS['bdd'];
if (($_SESSION['user_role'] ?? '') !== 'admin' && ($_SESSION['user_role'] ?? '') !== 'pcpl'
    && ($_SESSION['user_role'] ?? '') !== 'cs' && ($_SESSION['user_role'] ?? '') !== 'sg'
    && ($_SESSION['user_role'] ?? '') !== 'caisse') {
    $stmt_ens = $bdd->prepare('SELECT ref_ens FROM config_bull WHERE ref_class = ? AND ref_mat = ? LIMIT 1');
    $stmt_ens->execute(array($ref_class, $ref_mat));
    $row_ens = $stmt_ens->fetch(PDO::FETCH_ASSOC);
    if (!$row_ens || $row_ens['ref_ens'] !== $_SESSION['login']) {
        sendJsonResponse('error', 'Accès refusé : cette matière ne vous est pas attribuée.');
    }
}

// Le reste de votre code qui interagit avec la BDD...
header('Content-Type: application/json'); 

// Assurez-vous que $bdd est accessible globalement via votre fichier connexion.php
$bdd = $GLOBALS['bdd']; 
$table_name = 'table_note_par_mat_eval' . $ref_eval; // Nom de table dynamique (ref_eval borné 1-6)

try {
    $bdd->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // 1. Sélectionner tous les élèves et leurs notes existantes pour cette classe/matière
    $sql_select = "SELECT ref_std, note, coef FROM $table_name WHERE ref_cls = :ref_class AND ref_mat = :ref_mat AND note IS NOT NULL";
    $stmt_select = $bdd->prepare($sql_select);
    $stmt_select->bindParam(':ref_class', $ref_class);
    $stmt_select->bindParam(':ref_mat', $ref_mat);
    $stmt_select->execute();
    $notes_existantes = $stmt_select->fetchAll(PDO::FETCH_ASSOC);

    if (empty($notes_existantes)) {
        sendJsonResponse('info', 'Aucune note existante (non-NULL) trouvée pour cette évaluation.');
    }

    $bdd->beginTransaction();
    $updates_count = 0;

    foreach ($notes_existantes as $row) {
        $id_eleve = $row['ref_std'];
        $ancienne_note = (float)$row['note'];
        $coef = (float)$row['coef'];

        // Calculer la nouvelle note brute
        $nouvelle_note = $ancienne_note + $points_a_ajouter;

        // 2. Appliquer la règle de plafonnement à 20/20
        if ($nouvelle_note > 20) {
            $nouvelle_note = 20.0;
        }

        // Si la note n'a pas changé (par exemple, elle était déjà 20 et on ajoute 1 point), on passe.
        if ($nouvelle_note == $ancienne_note) {
            continue;
        }

        // 3. Recalculer note_x_coeff
        $note_x_coeff = $nouvelle_note * $coef;

        // 4. Mettre à jour la base de données
        $sql_update = "UPDATE $table_name SET note = :nouvelle_note, note_x_coeff = :note_x_coeff WHERE ref_cls = :ref_class AND ref_mat = :ref_mat AND ref_std = :ref_std";
        $stmt_update = $bdd->prepare($sql_update);
        
        $stmt_update->bindParam(':nouvelle_note', $nouvelle_note);
        $stmt_update->bindParam(':note_x_coeff', $note_x_coeff);
        $stmt_update->bindParam(':ref_class', $ref_class);
        $stmt_update->bindParam(':ref_mat', $ref_mat);
        $stmt_update->bindParam(':ref_std', $id_eleve);
        $stmt_update->execute();
        
        $updates_count++;
    }

    $bdd->commit();
    sendJsonResponse('success', $updates_count . ' notes mises à jour avec succès. ' . $points_a_ajouter . ' points ajoutés (plafonnement à 20 appliqué).');

} catch (PDOException $e) {
    $bdd->rollBack();
    // L'erreur sera enregistrée dans les logs grâce à ini_set ci-dessus
    error_log('Erreur PDO lors de l\'ajout de points : ' . $e->getMessage()); 
    sendJsonResponse('error', 'Erreur serveur lors de la mise à jour des notes. Veuillez réessayer.');
}
?>
