<?php
// core/modals_home.php
if (!isset($_SESSION['user'])) { exit(); }
?>

<!-- ============================================================== -->
<!-- MODAL 1 : INSCRIPTION MANUELLE D'UN ÉLÈVE                      -->
<!-- ============================================================== -->
<div class="modal fade" id="addstd" tabindex="-1" aria-labelledby="addStdModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered modal-lg">
    <div class="modal-content border-0 shadow-lg" style="border-radius: 12px;">
      
      <!-- En-tête : Harmonisé avec le Bleu Nuit du logo (#0764a8) -->
      <div class="modal-header text-white" style="background-color: #0764a8; border-top-left-radius: 12px; border-top-right-radius: 12px;">
        <h5 class="modal-title fw-bold" id="addStdModalLabel">
          <i class="fa fa-user-plus me-2"></i>Inscrire un nouvel élève
        </h5>
        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      
      <form action="Controler/Students/addstd.php" method="post">  
        <div class="modal-body p-4" style="background-color: #f8f9fa;">
          <div class="container-fluid p-0">                               
            
            <div class="row g-3 mb-3">
              <div class="col-12 col-md-4">                        
                  <label for="classe_std" class="form-label fw-bold text-secondary small">Classe d'affectation</label>
                  <select id="classe_std" class="form-select" name="classe_std" required>
                       <option value="">Choisir la classe...</option>
                       <?php $std->SelectClassesNames(); ?>                           
                  </select>
              </div>
              <div class="col-12 col-md-8">
                  <label for="nom_std" class="form-label fw-bold text-secondary small">Nom complet (Nom et Prénom)</label>
                  <input type="text" class="form-control text-uppercase font-weight-bold" id="nom_std" name="nom_std" maxlength="150" required style="letter-spacing: 0.5px;">
              </div>
            </div>

            <div class="row g-3 mb-3">
              <div class="col-12 col-sm-6 col-md-4">
                    <label for="cni_std" class="form-label fw-bold text-secondary small">Matricule national / Interne</label>
                    <input type="text" class="form-control text-uppercase" id="cni_std" name="cni_std" maxlength="9" placeholder="Ex: AX1234">
              </div>
              <div class="col-12 col-sm-6 col-md-4">
                    <label for="sexe" class="form-label fw-bold text-secondary small">Sexe</label>
                    <select id="sexe" class="form-select" name="sexe" required>
                        <option value="M" selected>MASCULIN (M)</option>
                        <option value="F">FEMININ (F)</option>
                    </select>
              </div> 
              <div class="col-12 col-md-4">
                    <label for="handicap" class="form-label fw-bold text-secondary small">Option spécifique / Vulnérabilité</label>
                    <select id="handicap" class="form-select" name="handicap">
                      <option value="RAS" selected>R.A.S (Aucun handicap)</option>
                      <option value="TROUBLE DE VUE">TROUBLE DE VUE</option>
                      <option value="TROUBLE MENTAL">TROUBLE MENTAL</option>
                      <option value="ELEVE DEPLACE">ÉLÈVE DÉPLACÉ DE GUERRE</option>
                      <option value="ORPHELIN(E)">ORPHELIN(E)</option>
                      <option value="DEFORMATION PHYSIQUE">DÉFORMATION PHYSIQUE</option>
                      <option value="MALADIE CHRONIQUE">MALADIE CHRONIQUE</option>
                      <option value="AUTRE CAS">AUTRE CAS SPÉCIFIQUE</option>                    
                    </select>                          
              </div>
            </div>

            <div class="row g-3">                    
                <div class="col-12 col-sm-5 col-md-4">
                    <label for="date_naiss_std" class="form-label fw-bold text-secondary small">Date de naissance</label>
                    <!-- Ce champ est automatiquement bridé à max 7 ans par le script JS principal -->
                    <input type="date" class="form-control text-center" id="date_naiss_std" name="date_naiss_std" required>
                </div>
                <div class="col-12 col-sm-7 col-md-8">
                    <label for="lieu_naiss_std" class="form-label fw-bold text-secondary small">Lieu de naissance</label>
                    <input type="text" class="form-control text-uppercase" id="lieu_naiss_std" name="lieu_naiss_std" maxlength="100" required placeholder="Ex: BAFOUSSAM">
                </div>
            </div>

          </div>
        </div>
        
        <!-- Pied de page : Bouton d'action principal Vert Émeraude (#19784f) -->
        <div class="modal-footer border-top-0" style="background-color: #f8f9fa; border-bottom-left-radius: 12px; border-bottom-right-radius: 12px;">
          <button type="button" class="btn btn-secondary px-4 fw-bold" data-bs-dismiss="modal">Annuler</button>
          <button type="submit" class="btn text-white fw-bold px-4" style="background-color: #19784f; border: none; box-shadow: 0 4px 10px rgba(25, 120, 79, 0.2);">
            <i class="fa fa-save me-2"></i>Inscrire l'élève
          </button>
        </div>
      </form>

    </div>
  </div>
</div>

<!-- ============================================================== -->
<!-- MODAL 2 : IMPORTATION EN MASSE VIA FICHIER EXCEL               -->
<!-- ============================================================== -->
<div class="modal fade" id="importstd" tabindex="-1" aria-labelledby="importStdModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered modal-lg">
    <div class="modal-content border-0 shadow-lg" style="border-radius: 12px;">
      
      <!-- En-tête : Harmonisé avec le Vert Émeraude du logo (#19784f) -->
      <div class="modal-header text-white" style="background-color: #19784f; border-top-left-radius: 12px; border-top-right-radius: 12px;">
        <h5 class="modal-title fw-bold" id="importStdModalLabel">
          <i class="fa fa-file-excel-o me-2"></i>Importer des élèves par lot Excel
        </h5>
        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      
      <form action="excelReader/insertExel.php" method="post" enctype="multipart/form-data">  
        <div class="modal-body p-4" style="background-color: #f8f9fa;">
            <div class="container-fluid p-0"> 
              
              <!-- Alerte de consignes techniques de formatage -->
              <div class="alert alert-info py-3 small mb-3 border-0 shadow-sm" role="alert" style="background-color: rgba(7, 100, 168, 0.08); color: #0764a8; border-left: 4px solid #0764a8 !important;">
                  <div class="d-flex align-items-start">
                      <i class="fa fa-info-circle fa-lg me-2 mt-1"></i>
                      <div>
                          <span class="fw-bold d-block mb-1">Directives importantes d'intégration :</span>
                          Fichiers supportés : extension <b>.xls</b> ou <b>.xlsx</b>. La ligne 1 doit impérativement rester dédiée aux en-têtes de colonnes. Les inscriptions effectives doivent commencer dès la ligne 2.
                          <div class="mt-2">
                              <a href="assets/doc/Import_Model.xlsx" class="btn btn-sm btn-white font-weight-bold text-success border border-success px-3 py-1 bg-white rounded-pill" style="font-size: 0.9em;">
                                  <i class="fa fa-download me-1"></i>Télécharger le modèle Excel type
                              </a>
                          </div>
                      </div>
                  </div>
              </div>

              <!-- Aperçu visuel de la structure du tableau à respecter -->
              <div class="table-responsive w-100 mb-4 rounded border shadow-sm">
                <table class="table table-bordered table-sm table-striped text-center mb-0" style="font-size: 0.85em; min-width: 550px; background-color: #fff;">
                  <thead class="table-dark">
                    <tr>
                      <th class="py-2">NOM COMPLET</th>
                      <th class="py-2">MATRICULE</th>
                      <th class="py-2">SEXE</th>
                      <th class="py-2">DATE_DE_NAISS</th>
                      <th class="py-2">LIEU_DE_NAISS</th>              
                    </tr>
                  </thead>
                  <tbody>
                    <tr class="font-monospace text-secondary">
                      <td class="py-2">KAMGA BERTRAND</td>
                      <td class="py-2" style="background-color: #fff8e1;">(Optionnel)</td>
                      <td class="py-2">M <i>(ou F)</i></td>
                      <td class="py-2">12/04/2015</td>
                      <td class="py-2">BAFOUSSAM</td>
                    </tr>
                  </tbody>
                </table>
              </div>

              <div class="row g-3">
                <div class="col-12 col-md-5">
                  <label for="classe_import" class="form-label fw-bold text-secondary small">Classe de destination des élèves</label>
                  <select id="classe_import" class="form-select" name="classe" required>
                      <option value="">Sélectionner la classe cible...</option>
                      <?php $std->SelectClassesNames(); ?>                           
                  </select>
                </div>
                <div class="col-12 col-md-7">
                    <label for="file_excel" class="form-label fw-bold text-secondary small">Fichier Excel (.xls, .xlsx)</label>
                                        <input class="form-control" type="file" id="file_excel" name="excel" accept=".xls,.xlsx" required>
                </div>
              </div>

            </div>
        </div>
        
        <!-- Pied de page : Bouton d'action principal Bleu Nuit (#0764a8) -->
        <div class="modal-footer border-top-0" style="background-color: #f8f9fa; border-bottom-left-radius: 12px; border-bottom-right-radius: 12px;">
          <button type="button" class="btn btn-secondary px-4 fw-bold" data-bs-dismiss="modal">Fermer</button>
          <button type="submit" class="btn text-white fw-bold px-4" style="background-color: #0764a8; border: none; box-shadow: 0 4px 10px rgba(7, 100, 168, 0.2);">
            <i class="fa fa-upload me-2"></i>Lancer l'importation
          </button>
        </div>
      </form>

    </div>
  </div>
</div>

