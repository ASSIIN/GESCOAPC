<?php
// moyenne_an.php (Calcul Annuel avec gestion trimestres manquants)
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
set_time_limit(300); // Évite le timeout si la classe est grande

session_start();

// 1. Vérification des fichiers et inclusions
if (!file_exists('../../Model/connexion.php')) die("Erreur : connexion.php introuvable");
if (!file_exists('../../core/require.php')) die("Erreur : require.php introuvable");

require_once '../../Model/connexion.php';
require_once '../../core/require.php';  

// 2. Vérification des paramètres URL
$cls = filter_input(INPUT_GET, 'cls', FILTER_SANITIZE_SPECIAL_CHARS);
$trim = filter_input(INPUT_GET, 'trim', FILTER_SANITIZE_SPECIAL_CHARS); // Généralement '4' ou 'an'

if ($cls && $trim) {
    $bdd = $GLOBALS['bdd'];
    $table_an = "table_note_par_trim" . $trim;

    // Vérification des objets core (évite le crash silencieux)
    if (!isset($class) || !isset($opt)) {
        die("Erreur : Les objets \$class ou \$opt ne sont pas définis dans require.php");
    }

    // 3. Sélection des élèves de la classe
    $stmt0 = $bdd->prepare('SELECT mat_std FROM eleves WHERE ref_class = ?');
    $stmt0->execute([$cls]);

    while ($row0 = $stmt0->fetch(PDO::FETCH_ASSOC)) {
        $std_id = $row0['mat_std'];
        
        $moyennes_trimestrielles = [];
        $total_points_cumul = 0;
        $total_coeffs_cumul = 0;

        // 4. Boucle sur les 3 trimestres pour composer l'année
        for ($t = 1; $t <= 3; $t++) {
            $eval1 = ($t == 1) ? '1' : (($t == 2) ? '3' : '5');
            $eval2 = ($t == 1) ? '2' : (($t == 2) ? '4' : '6');
            
            $TotalpointT = 0;
            $TotalcoeffT = 0;

            // Récupération des matières de la classe
            $stmt1 = $bdd->prepare('SELECT ref_mat, coeff_mat FROM config_bull WHERE ref_class = ?');
            $stmt1->execute([$cls]);

            while ($row1 = $stmt1->fetch(PDO::FETCH_ASSOC)) {
                $cknote1 = $class->SelectNoteStd_by_MatCls($cls, $row1['ref_mat'], $eval1, $std_id);
                $cknote2 = $class->SelectNoteStd_by_MatCls($cls, $row1['ref_mat'], $eval2, $std_id);
                $coeff_matiere_brut = $row1['coeff_mat'];

                // --- LOGIQUE DE CALCUL INDIVIDUELLE (Ta logique validée) ---
                $notes_valides_numeriques = array_filter([$cknote1, $cknote2], fn($v) => is_numeric($v));
                $nombre_notes = count($notes_valides_numeriques);
                $coeff_num = is_numeric($coeff_matiere_brut) ? (float)$coeff_matiere_brut : NULL;

                if ($nombre_notes > 0 && is_numeric($coeff_num)) {
                    $coeff = round($coeff_num, 2);
                    $moy_mat = array_sum($notes_valides_numeriques) / $nombre_notes;
                    $total_mat = round($moy_mat * $coeff, 2);

                    $TotalcoeffT += $coeff;
                    $TotalpointT += $total_mat;
                }
            }

            // Si le trimestre a des notes, on l'ajoute au calcul annuel
            if ($TotalcoeffT > 0) {
                $moyennes_trimestrielles[] = $TotalpointT / $TotalcoeffT;
                $total_points_cumul += $TotalpointT;
                $total_coeffs_cumul += $TotalcoeffT;
            }
        }

        // 5. Calcul Final Annuel
        $nb_trim_valides = count($moyennes_trimestrielles);
        // Moyenne Annuelle = Somme des moyennes trimestrielles / Nombre de trimestres présents
        $moy_std = ($nb_trim_valides > 0) ? round(array_sum($moyennes_trimestrielles) / $nb_trim_valides, 2) : 0;

        // 6. Insertion ou Mise à jour dans la table annuelle
        $check = $bdd->prepare("SELECT COUNT(*) FROM $table_an WHERE ref_std = ?");
        $check->execute([$std_id]);
        
        if ($check->fetchColumn() > 0) {
            $req = "UPDATE $table_an SET total_note = ?, total_coef = ?, moy = ? WHERE ref_std = ?";
            $bdd->prepare($req)->execute([$total_points_cumul, $total_coeffs_cumul, $moy_std, $std_id]);
        } else {
            $req = "INSERT INTO $table_an (ref_trim, ref_cls, ref_std, total_note, total_coef, moy) VALUES (?, ?, ?, ?, ?, ?)";
            $bdd->prepare($req)->execute([$trim, $cls, $std_id, $total_points_cumul, $total_coeffs_cumul, $moy_std]);
        }

        // 7. Statut Classer (Marge de 85% des coeffs)
        $t_coef_base = (float)$opt->NombreCoeffbyStd_Cls($cls, '1', $std_id); 
        // On compare au coeff moyen par trimestre
        $moy_coeff_reel = ($nb_trim_valides > 0) ? ($total_coeffs_cumul / $nb_trim_valides) : 0;
        
        $classer = ($moy_coeff_reel > 0 && ($t_coef_base / $moy_coeff_reel) <= 1.15) ? 'Y' : 'N'; 
        // Note: Ajuste la formule ci-dessus selon ta "MargeCoeff" exacte (ici exemple 0.85 inversé)
        
        $bdd->prepare("UPDATE $table_an SET classer = ? WHERE ref_std = ?")->execute([$classer, $std_id]);
    }

    // 8. CALCUL DES RANGS ANNUELS (Optimisé en une seule passe)
    $stmtRank = $bdd->prepare("SELECT ref_std FROM $table_an WHERE ref_cls = ? ORDER BY CAST(moy AS DECIMAL(10,2)) DESC");
    $stmtRank->execute([$cls]);
    $rang = 1;
    while ($rowR = $stmtRank->fetch(PDO::FETCH_ASSOC)) {
        $bdd->prepare("UPDATE $table_an SET rang = ? WHERE ref_std = ? AND ref_cls = ?")
            ->execute([$rang++, $rowR['ref_std'], $cls]);
    }

    header('location: ../../calculs_notes.php?msg=success');
    exit();

} else {
    echo "Erreur : Paramètres cls ou trim manquants.";
}
?>
