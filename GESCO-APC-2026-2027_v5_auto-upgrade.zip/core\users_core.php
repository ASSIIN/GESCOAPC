<?php 
	/**
	 * 
	 */
	class MyUsers
	{
		private $username, $login, $pass, $role, $last_con, $ref_dep, $master_cls;
		
		function __construct()
		{
			# code...
		}

		public function setCivilite($value)
		{
			$this->civilite = $value;
		}
		public function getCivilite()
		{
			return $this->civilite;
		}

		public function setUsername($value)
		{
			$this->username = $value;
		}
		public function getUsername()
		{
			return $this->username;
		}

		public function setLogin($value)
		{
			$this->login = $value;
		}
		public function getLogin()
		{
			return $this->login;
		}

		
		public function setPass($value)
		{
			$this->pass = $value;
		}
		public function getPass()
		{
			return $this->pass;
		}

		public function setLast_con($value)
		{
			$this->last_con = $value;
		}
		public function getLast_con()
		{
			return $this->last_con;
		}

		public function setRole($value)
		{
			$this->role = $value;
		}
		public function getRole()
		{
			return $this->role;
		}

		public function setRef_dep($value)
		{
			$this->ref_dep = $value;
		}
		public function getRef_dep()
		{
			return $this->ref_dep;
		}


		public function setMaster_cls($value)
		{
			$this->master_cls = $value;
		}
		public function getMaster_cls()
		{
			return $this->master_cls;
		}



	
		public function AddUser()
		{
			$bdd = $GLOBALS['bdd'];
	

			$req = "INSERT INTO admins (civilite, username, login, password, role, ref_dep) VALUES(?, ?, ?, ?, ?, ?)" ;

				$rep = $bdd->prepare($req);
				if ($rep->execute( array($this->civilite, $this->username, $this->login, $this->pass, $this->role, $this->ref_dep))) {
					return true;
				}
				else{
					return false;
				}
		}

		public function ckconM($login)
		{

			$bdd = $GLOBALS['bdd'];	

			// SÉCURISÉ : requête préparée anti-injection SQL
			$rep = $bdd->prepare('SELECT * FROM admins where login=?');
			$rep->execute(array($login));
			$reponse = $rep;
			if(($row = $reponse->fetch(PDO::FETCH_ASSOC)))
			{
				$_SESSION['user'] =$row['id'];
				$_SESSION['login'] =$row['login'];
				$_SESSION['user_role'] =$row['role'];
				$_SESSION['username'] =$row['username'];
				$_SESSION['password'] =$row['password'];

		       return true;
			}
			else{
				session_unset();
				session_destroy();
	 			header('location: index.php');

				return false;
			}

		}

		public function ckconP($pw)
		{

			$bdd = $GLOBALS['bdd'];	

			// SÉCURISÉ : requête préparée anti-injection SQL
			$rep = $bdd->prepare('SELECT * FROM admins where password=?');
			$rep->execute(array($pw));
			$reponse = $rep;
			if(($row = $reponse->fetch(PDO::FETCH_ASSOC)))
			{	
		       return true;
			}
			else{
				session_unset();
				session_destroy();
	 			header('location: index.php');

				return false;
			}

		}

			public function ShowClassesNames()
		{
			$bdd = $GLOBALS['bdd'];
			$i=0;
			$nt=0;
			$reponse = $bdd->query('SELECT * FROM classes where id>1 order by ref_class_niveau asc');
			while($row = $reponse->fetch(PDO::FETCH_ASSOC)) 
			{
				$i++;

				echo '<option value="'.$row['nom_class'].'">'.$i.' - '.$row['nom_class'].'</option>';
				}
		}

		public function ShowClassesCode()
		{
			$bdd = $GLOBALS['bdd'];
			$i=0;
			$nt=0;
			$reponse = $bdd->query('SELECT * FROM classes where id>1 order by ref_class_niveau asc');
			while($row = $reponse->fetch(PDO::FETCH_ASSOC)) 
			{
				$i++;

				echo '<option value="'.$row['code_class'].'">'.$i.' - '.$row['nom_class'].'</option>';
				}
		}
			public function ShowClasseNameByCode($code)
		{
			$bdd = $GLOBALS['bdd'];
			$i=0;
			$nt=0;
			// SÉCURISÉ : requête préparée anti-injection SQL
			$rep = $bdd->prepare('SELECT * FROM classes where code_class=?');
			$rep->execute(array($code));
			$reponse = $rep;
			while($row = $reponse->fetch(PDO::FETCH_ASSOC)) 
			{
				return $row['nom_class'];
			}
		}

			public function ShowDepartNameByCode($code)
		{
			$bdd = $GLOBALS['bdd'];
			$i=0;
			$nt=0;
			// SÉCURISÉ : requête préparée anti-injection SQL
			$rep = $bdd->prepare('SELECT * FROM departements where id=?');
			$rep->execute(array($code));
			$reponse = $rep;
			while($row = $reponse->fetch(PDO::FETCH_ASSOC)) 
			{
				return $row['nom_dep'];
			}
		}

		public function SelectUserDep()
		{
			$bdd = $GLOBALS['bdd'];
			$i=0;
			$nt=0;
			$reponse = $bdd->query('SELECT * FROM departements where id>=1 order by nom_dep asc');
			while($row = $reponse->fetch(PDO::FETCH_ASSOC)) 
			{
				$i++;

				echo '<option value="'.$row['id'].'">'.$i.' - '.$row['nom_dep'].' - ('.$row['ref_session'].')</option>';
				}
		}

		public function SelectTeacher()
		{
			$bdd = $GLOBALS['bdd'];
			$i=0;
			$nt=0;
			$reponse = $bdd->query('SELECT * FROM admins where id>=1 order by username asc');
			while($row = $reponse->fetch(PDO::FETCH_ASSOC)) 
			{
				$i++;

				echo '<option value="'.$row['login'].'" id="'.$row['login'].'">'.$i.' - '.$row['civilite'].' '.$row['username'].'</option>';
				}
		}

		public function SelectTeacherName_by_mat_by_cls($ens)
		{
			$bdd = $GLOBALS['bdd'];
			$i=0;
			$nt=0;
			// SÉCURISÉ : requête préparée anti-injection SQL
			$rep = $bdd->prepare('SELECT * FROM admins where login=? order by username asc');
			$rep->execute(array($ens));
			$reponse = $rep;
			while($row = $reponse->fetch(PDO::FETCH_ASSOC)) 
			{

				return $row['civilite'].' '.$row['username'].'';
			}
		}

		public function SelectTeacherAndRole()
		{
			$bdd = $GLOBALS['bdd'];
			$i=0;
			$nt=0;
			$reponse = $bdd->query('SELECT * FROM admins where id>=1 order by username asc');
			while($row = $reponse->fetch(PDO::FETCH_ASSOC)) 
			{
				$i++;

				echo '<option value="'.$row['login'].'" id="'.$row['login'].'">'.$i.' - '.$row['civilite'].' '.$row['username'].' - ('.$row['role'].')</option>';
				}
		}

		
		public function ShowAllUser()
		{
			$bdd = $GLOBALS['bdd'];
			$i=0;
			$nt=0;
			$reponse = $bdd->query('SELECT * FROM admins where id>=1 order by username asc');
			while($row = $reponse->fetch(PDO::FETCH_ASSOC)) 
			{
				/*nom_std`, `prenom_std`, `nom_prenom_std`, `date_nais`, `lieu_nais`, `sexe_std`, `ref_classe`, `mat_std`, `pere_std`, `mere_std`, `adress_std`, `localite_std`, `contenu_std`, `versement_std`, `register_std_on*/
				$i++;
				$iddep=(int)$row['ref_dep'];
				$nom_dep=$this->ShowDepartNameByCode($iddep);
				$nom_cls_pp=$this->ShowClasseNameByCode($row['master_cls']);
			
		

				echo '
				<tr>
				<td id="id">'.$i.'</td>
				<td class="" height="1px">'.$row['login'].'</td>
                <td class="">'.$row['password'].'</td>
                <td>'.$row['civilite'].' '.$row['username'].'</td>
                <td>'.$row['role'].'</td>
                <td>'.$nom_dep.'</td>
                 <td><a style="background-color:#26bded" class="btn btn-light btn-sm ml-2 mx-2" data-bs-toggle="modal" data-bs-target="#edituser_'.$row['id'].'" data-whatever="@mdo"><i class="fa  fa-edit" aria-hidden="true"></i></a>
                 </td>
                 <td><a  class="btn btn-danger btn-sm ml-2" data-bs-toggle="modal" data-bs-target="#mod_del'.$row['id'].'" data-whatever="@mdo"><i class="fa fa-user fa-remove" aria-hidden="true"></i></a>
                  
					<div class="modal fade" id="mod_del'.$row['id'].'" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                      <div class="modal-dialog" role="document">
                        <div class="modal-content">
                          	<div class="modal-header">
	                            <h5 class="modal-title" id="exampleModalLabel">SUPPRIMER LE PERSONNEL</h5>
														<button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Fermer"></button>
                          	</div>
                          	<div class="modal-body">
                          		<h5 class="modal-title" id="exampleModalLabel">Voulez-vous supprimmer l\'utilsateur : <b style="color:#e63f32"> '.$row['username'].' ('.$row['login'].')</b> ?<br>Cette action est irréversible.</h5>
                          		<a href="Controler/admins/deluser.php?id='.$row['id'].'" ><button  class="btn btn-primary">Oui</button></a>                  
                                       
	                        </div>
	                        <div class="modal-footer">              
	                        	<button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Annuler</button>
	                  		</div>
                        </div>
                        </div>
					</div>
                 </td>

                <div class="modal fade" id="edituser_'.$row['id'].'" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                      <div class="modal-dialog modal-lg" role="document">
                        <div class="modal-content mx-2 " >
                          <div class="modal-header">
                            <h3 class="modal-title" id="exampleModalLabel">MODIFIER LE PERSONNEL de Matr:<i style="color:#e63f32">'.$row['login'].'</i></h3>
														<button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Fermer"></button>
                          </div>
                          <div class="modal-body" style=""> 
                           <div class="container-fluid">                               
                                <div class="row">
	                                  <div class="col-md-3">
		                                    <form action="Controler/admins/upduser.php" method="post" enctype=multipart/form-data >  
		                                    <input type="text" class="form-control " id="iduser" name="iduser"  value="'.$row['id'].'" hidden="true" >
		                                    <label for="inputState">Civ: <i style="color:#e63f32">'.$row['civilite'].'</i></label>
		                                    <select id="inputState" class="form-control" name="user_civ" >
		                                    	<option value="" >Choisir...</option>
		                                        <option value="M">M</option>
		                                        <option value="Mme">Mme</option>
		                                        <option value="Mme">Dr</option>
		                                    </select>
		                                  </div>
                                   		<div class="col-md-4">                       
	                                        <label for="inputState">Fonction: <i style="color:#e63f32">'.$row['role'].'</i></label>
	                                       <select id="inputState" class="form-control" name="user_role" >
	                                       	<option value="" >Choisir...</option>
	                                         <option value="ens">Enseignant</option>
                                         <option value="sc">Censeur</option>
                                         <option value="sg">Surveillant Général</option>
                                        <option value="pcpl">Provisieur/Principal</option>
                                        <option value="admin">Administrateur</option>
                                        <option value="caisse">L\'économme</option>                          
	                                      	</select>
	                                     </div>                        
                                    
	                                    <div class="col-md-5">
		                                      <label for="inputState">Departement: <i style="color:#e63f32">'.$nom_dep.'</i></label>
		                                       <select id="inputState" class="form-control" name="user_dep" >
		                                       <option value="" >Choisir...</option>';
		                                         $this->SelectUserDep();
                                 echo '                       
		                                      </select>
			                                  </div>
	                                     </div>
                                 	<div class="row">
	                                                            
	                                  <div class="col-md-8 ">
	                                        <label for="inputEmail4">Nom complet: <i style="color:#e63f32">'.$row['username'].'</i></label>
	                                        <input type="text" class="form-control col-4 text-uppercase" id="prenom_std" name="user_name"  maxlength="50"  >
	                                  </div>

	                                  <div class="col-md-4 ">
                                        <label for="inputEmail4">Téléphone: <i style="color:#e63f32">'.$row['user_tel'].'</i></label>
                                        <input type="text" class="form-control text-uppercase" id="user_tel" name="user_tel"  maxlength="50"  >
                                    </div>
                                  </div>
                                  <div class="row mb-3">                  
	                                    <div class="col-md-4 ">
	                                        <label for="inputEmail4">Mot de passe:<i style="color:#e63f32">'.$row['password'].'</i></label>
	                                        <input type="text" class="form-control" id="pass" name="pass"  >
	                                    </div>
	                                    <div class="col-md-8">
	                                        <label for="inputEmail4">PP classe :<i style="color:#e63f32">'.$nom_cls_pp.'</i></label>
	                                    
	                                        <select id="inputState" class="form-control" name="master_cls" >
	                                         <option value="" >Choisir...</option>';
			                                         $this->ShowClassesCode();
	                                 echo '                       
		                                      </select>
	                                    </div>
                                	</div>          

                                <div class="modal-footer"> 
                                    <button type="submit" class="btn btn-primary"><i class="fa fa-save" aria-hidden="true"></i></button>
                                     <button type="button" class="btn btn-danger" data-bs-toggle="modal" data-bs-target="#mod_del'.$row['id'].'" data-whatever="@mdo"><i class="fa fa-trash" aria-hidden="true"></i></boutton>
                                    <button type="button" class="btn btn-info" data-bs-dismiss="modal"><i class="fa fa-remove" aria-hidden="true"></i></button>
                                  </form>
                                  </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
				'
				;
					
			}
			$nt=$i;
			$i=0;
				
		}

	
		

		public function SelectUser()
		{
			$bdd = $GLOBALS['bdd'];
			$i=0;
			$nt=0;
			$reponse = $bdd->query('SELECT * FROM admins where id>=1 order by username asc');
			while($row = $reponse->fetch(PDO::FETCH_ASSOC)) 
			{
				$i++;

				echo '<option value="'.$row['login'].'">'.$row['username'].'</option>';
				}
		}

		public function ShowUsernamebyID($id)
		{
			$bdd = $GLOBALS['bdd'];
			$i=0;
			$nt=0;
			// CORRECTION : ref_ens n'existe pas sur admins ; l'enseignant est référencé par son LOGIN (config_bull.ref_ens = login)
			// SÉCURISÉ : requête préparée anti-injection SQL
			$rep = $bdd->prepare('SELECT * FROM admins where login=?');
			$rep->execute(array($id));
			$reponse = $rep;
			while($row = $reponse->fetch(PDO::FETCH_ASSOC)) 
			{
				$nom_std= ''.$row['civilite'].' '.$row['username'].'';
				return $nom_std;
				}
		}

				public function UpdConUser($id)
		{
						/* Generation du code*//* Generation du code*/
					$codeswift="";
					$password1=str_shuffle('0123456789212222233560654');
					$pass1=substr($password1,0,10);
					$chaine1=str_shuffle('0123456789212222233560654');
					$pass1.=$chaine1;
					$pass2=substr($pass1,0,6);
					$codeswift.=$pass2;
					$codeswift=mb_strtoupper($codeswift); 
					while($this->CkExistingOptUser($codeswift)) 
					{
					 	$codeswift="";
					 	$password1=str_shuffle('0123456789212222233560654');
						$pass1=substr($password1,0,10);
						$chaine1=str_shuffle('0123456789212222233560654');
						$pass1.=$chaine1;
						$pass2=substr($pass1,0,6);
						$codeswift.=$pass2;
						$codeswift=mb_strtoupper($codeswift);
			        }
			$bdd = $GLOBALS['bdd'];
		    $data_cm=date('Y-m-d H:i:s', strtotime('+1 hour'));
			$req = "INSERT INTO his_con (user_session, ref_user, ref_nom, ref_role) VALUES(?, ?, ?, ?)" ;

				$rep = $bdd->prepare($req);
				if ($rep->execute( array($codeswift,$_SESSION['login'], $_SESSION['username'], $_SESSION['user_role']))) {
					$_SESSION['user_session']=$codeswift;
					return true;
				}
				else{
					return false;
				}
		}

		public function CkExistingOptUser($code)
		{

			$bdd = $GLOBALS['bdd'];	
			// SÉCURISÉ : requête préparée anti-injection SQL
			$rep = $bdd->prepare('SELECT * FROM his_con where user_session=?');
			$rep->execute(array($code));
			$reponse = $rep;
			while (($row = $reponse->fetch(PDO::FETCH_ASSOC))) 
			{
				return true;
			}
		}
	

		
		
		public function CkExistingUser($code)
		{

			$bdd = $GLOBALS['bdd'];	
			// SÉCURISÉ : requête préparée anti-injection SQL
			$rep = $bdd->prepare('SELECT * FROM admins where login=?');
			$rep->execute(array($code));
			$reponse = $rep;
			while (($row = $reponse->fetch(PDO::FETCH_ASSOC))) 
			{
				return true;
			}
		}

		public function CkExistingMatr($code)
		{

			$bdd = $GLOBALS['bdd'];	
			// SÉCURISÉ : requête préparée anti-injection SQL
			$rep = $bdd->prepare('SELECT * FROM eleves where mat_std=?');
			$rep->execute(array($code));
			$reponse = $rep;
			while (($row = $reponse->fetch(PDO::FETCH_ASSOC))) 
			{
				return true;
			}
		}

		public function SelectMatrbyID($id)
		{

			$bdd = $GLOBALS['bdd'];	
			// SÉCURISÉ : requête préparée anti-injection SQL
			$rep = $bdd->prepare('SELECT * FROM eleves where id=?');
			$rep->execute(array($id));
			$reponse = $rep;
			while (($row = $reponse->fetch(PDO::FETCH_ASSOC))) 
			{
				return $row['mat_std'];
			}
		}

		public function IncrimValMatr()
		{

			$bdd = $GLOBALS['bdd'];	

			$reponse = $bdd->query('SELECT * FROM eleves order by id desc limit 1');
			while(($row = $reponse->fetch(PDO::FETCH_ASSOC))) 
			{
				return $row['id'];
			}
		}

		public function NombreUsers()
		{
			$n=0;
			$ntotal=0;
			$bdd = $GLOBALS['bdd'];
			$reponse = $bdd->query("SELECT * FROM admins where id>=1 ");

			while($row = $reponse->fetch(PDO::FETCH_ASSOC)) 
			{ 
					$n++;
			}
				$ntotal= $n;
				return $ntotal;
		}

		public function delUser($id)
		{
			$bdd = $GLOBALS['bdd'];

			$req = 'DELETE FROM admins WHERE id=?';
			$rep = $bdd->prepare($req);
			if($rep->execute(array($id)))
			{
				return true;
			}else{
				return false;
			}
		}


}
	$user= new MyUsers();

?>