<?php
	require_once __DIR__ . '/config.php';
	require_once __DIR__ . '/admin.php';
	require_once __DIR__ . '/etb_core.php';
	require_once __DIR__ . '/users_core.php';
	require_once __DIR__ . '/classes_core.php';
	require_once __DIR__ . '/depart_core.php';
	require_once __DIR__ . '/matieres_core.php';
	require_once __DIR__ . '/std_core.php';
	require_once __DIR__ . '/opt_core.php';
	require_once __DIR__ . '/finance_core.php';
	require_once __DIR__ . '/config_moy.php';
	require_once __DIR__ . '/header.php';
	require_once __DIR__ . '/footer.php';
?>