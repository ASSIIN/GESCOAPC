<?php
	session_start();
	require_once '../../Model/connexion.php';
	require_once '../../core/require.php'; 
	$nom_cls= htmlspecialchars($_POST['new_ncls']);
	$ref_cls= htmlspecialchars($_POST['ref_cls']);
	/*`id`, `nom_class`, `ref_class_niveau`, `class_session`, `code_class*/
	if (isset($ref_cls)) 
	{
		$nom_cls=mb_strtoupper($nom_cls);
		
			$bdd = $GLOBALS['bdd'];	
			$req ='UPDATE  classes SET nom_class= ? where code_class="'.$ref_cls.'"';
			$rep = $bdd->prepare($req);
			$rep->execute(array($nom_cls));
				
		header('location: ../../edit_classe.php?id='.$ref_cls.'');
	}
	else
	{
		header('location: ../../menu_classes.php?e0');
	
	}
		
?>