<?php
/**
 * Footer moderne GESCOAPC
 * Rendu cohérent avec le thème sombre/clair
 */
class Footers
{
    public static function TDfoot(): void
    {
        echo '
        <footer class="footer py-3 mt-auto">
            <div class="container-fluid d-flex flex-wrap justify-content-between align-items-center">
                <div class="d-flex align-items-center gap-3">
                    <span class="text-muted small fw-semibold"><i class="fa-solid fa-school me-1"></i>GESCOAPC</span>
                    <span class="text-muted small">&copy; 2026 INOFIB</span>
                </div>
                <div class="d-flex align-items-center gap-2">
                    <span class="badge bg-primary-subtle text-primary-emphasis small">GESCOAPC v2.0</span>
                </div>
            </div>
        </footer>';
    }
}