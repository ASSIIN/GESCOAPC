<?php
session_start();
require_once '../Model/connexion.php';
require_once '../core/require.php';
 if (!isset($_SESSION['user'])) {
    session_unset();
    session_destroy();
    header('location: ../index.php');    
    }
 $etb->ShowEtb();
 if (!isset($_SESSION['all_list']) ) {
	header('location: ../impression.php');
 }
 $refcls=$_SESSION['all_list'];
require('fpdf.php');


class PDF extends FPDF
{
// En-tête


// Pied de page
function Footer()
{
    // Positionnement à 1,5 cm du bas
    $this->SetY(-15);
    // Police Arial italique 8
    $this->SetFont('Arial','I',8);
    // Numéro de page
    $this->Cell(0,10,'Page '.$this->PageNo().'/{nb}',0,0,'C');
}
}
$pdf = new FPDF();
$pdf->AliasNBPages();
$pdf->AddPage();

//code for print data

		 $bdd = $GLOBALS['bdd'];
			$reponse = $bdd->query('SELECT * FROM eleves where id>=0 order by nom_std asc');

			$i=1;
			$eff=0;
			/*En-tête*/
				$pdf->SetFont('Times','',8);
				$logo='../plugins/images/'.$_SESSION['logo_etb'].'';
				if (file_exists($logo)) {
				$pdf->Image('../plugins/images/'.$_SESSION['logo_etb'].'',90,15,30);
				}
				else{
					$pdf->Image('../plugins/images/logo0.png',90,15,30);
				}
				
				$pdf->Cell(70,4,'REPUBLIQUE DU CAMEROUN',0,0,'C');
				$pdf->Cell(50,4,'',0,0);
				$pdf->Cell(70,4,'REPUBLIC OF CAMEROON',0,1,'C');

				$pdf->Cell(70,4,'Paix-Travail-Patrie',0,0,'C');
				$pdf->Cell(50,4,'',0,0);
				$pdf->Cell(70,4,'Peace-Work-Fatherland',0,1,'C');

				$pdf->Cell(70,4, utf8_to_cp1252("".$_SESSION['minist_etb_fr'].""),0,0,'C');
				$pdf->Cell(50,4,'',0,0);
				$pdf->Cell(70,4,utf8_to_cp1252(''.$_SESSION['minist_etb_en'].''),0,1,'C');

				$pdf->Cell(70,4,utf8_to_cp1252("".$_SESSION['region_etb_fr'].""),0,0,'C');
				$pdf->Cell(50,4,'',0,0);
				$pdf->Cell(70,4,utf8_to_cp1252(''.$_SESSION['region_etb_en'].''),0,1,'C');

				$pdf->Cell(70,4,utf8_to_cp1252(''.$_SESSION['depart_etb_fr'].''),0,0,'C');
				$pdf->Cell(50,4,'',0,0);
				$pdf->Cell(70,4,utf8_to_cp1252(''.$_SESSION['depart_etb_en'].''),0,1,'C');
				$pdf->SetFont('Times','B',10);
				$pdf->Cell(70,6,utf8_to_cp1252(''.$_SESSION['nom_etb_fr'].''),0,0,'C');
				$pdf->Cell(50,6,'',0,0);
				$pdf->Cell(70,6,utf8_to_cp1252(''.$_SESSION['nom_etb_en'].''),0,1,'C');
				$pdf->SetFont('Times','',8);
				$pdf->Cell(70,5,utf8_to_cp1252(''.$_SESSION['code_pste_etb'].' / '.$_SESSION['tel_etb'].''),0,0,'C');
				$pdf->Cell(50,5,'',0,0);
				$pdf->Cell(70,5,utf8_to_cp1252(''.$_SESSION['code_pste_etb'].'/ '.$_SESSION['tel_etb'].''),0,1,'C');
				$pdf->SetFont('Times','',8);
				$pdf->Cell(70,4,utf8_to_cp1252(''.$_SESSION['email_etb'].''),0,0,'C');
				$pdf->Cell(50,4,'',0,0);
				$pdf->Cell(70,4,utf8_to_cp1252(''.$_SESSION['email_etb'].''),0,1,'C');
					$pdf->Ln();
					$pdf->SetFont('Times','I',12);
					$pdf->Cell(65,5,'',0,0);
					$pdf->Cell(60,5,utf8_to_cp1252(''.$_SESSION['code_im_etb'].''),0,0,'C');
					$pdf->Ln();
				
			/*FIN En-tête*/

			//Titre 
				$pdf->SetFont('Times','I',9);
				$pdf->Cell(50,5,'',0,0,'C');
				$pdf->Cell(60,5,'ANNEE SCOLAIRE/SCHOOL ',0,0,'R');
				$pdf->SetFont('Times','B',12);
				$pdf->Cell(40,5,''.$_SESSION['school_year'].'',0,0,'L');
				$pdf->Cell(40,5,'',0,1,'C');
				
					$pdf->SetFont('Times','B',11);
					$pdf->SetFillColor(171,177,186);
					$pdf->Cell(20,6,'',0,0,'C');
					$pdf->Cell(150,6,'LISTE DE TOUS LES ELEVES / FULL LIST',1,0,'C',1);
					$pdf->Cell(20,6,'',0,1,'C');
					$pdf->Ln();


				$nbstd=$class->NbrStudentByAll();
				$nbM=$class->NbrBySexeByAll('M');
				$nbF=$class->NbrBySexeByAll('F');
				$pdf->Cell(60,5,"",0,0,'L');
				$pdf->Cell(43,5,"Effectif: $nbstd",1,0,'C');
				$pdf->Cell(20,5,"M: $nbM",1,0,'C');
				$pdf->Cell(20,5,"F: $nbF",1,0,'C');
				$pdf->Ln();
			
			$pdf->SetFont('Times','B',9);
				$pdf->Ln();
					$pdf->Cell(8,6,utf8_to_cp1252('N°'),1,0);
					$pdf->Cell(18,6,utf8_to_cp1252('N° Inscipt'),1,0);
					$pdf->Cell(22,6,'Matricule',1,0);
					$pdf->Cell(72,6,utf8_to_cp1252('Noms_et_Prénoms/Full_Name'),1,0);
					$pdf->Cell(9,6,'Sexe',1,0);
					$pdf->Cell(10,6,'Red',1,0);
					$pdf->Cell(20,6,utf8_to_cp1252('Né(e)le/Born'),1,0);
					$pdf->Cell(32,6,'Lieu_de_nais/Place',1,0);
			 
			while($row = $reponse->fetch(PDO::FETCH_ASSOC)) 
			{

				$date_nais= date('d/m/Y',strtotime($row['date_nais']));
				$Nom=htmlspecialchars($row['nom_std']);
				$Nom=strtoupper($Nom);
				$Nom=substr($Nom, 0,38);

				$Nom= str_replace("&#039;", "'", $Nom);
				

				$lieu_nais = str_replace("&#039;", "'", $row['lieu_nais']);
				/*$row['mat_std'];
				$row['nom_prenom_std']
				$row['sexe_std']
				$row['date_nais']
				$row['lieu_nais']*/
				$pdf->SetFont('Arial','',8);
				$pdf->Ln();
					$pdf->Cell(8,5,$i,1,0);
					$pdf->Cell(18,5,utf8_to_cp1252(''.$_SESSION['pre_matr'].''.$row['mat_std'].''),1,0,'C');
						$pdf->Cell(22,5,utf8_to_cp1252($row['cni_std']),1,0,'C');
					$pdf->Cell(72,5,utf8_to_cp1252($Nom),1,0);
					$pdf->SetFont('Arial','',8);
					$pdf->Cell(9,5,utf8_to_cp1252($row['sexe_std']),1,0,'C');
					$pdf->Cell(10,5,utf8_to_cp1252($row['statut']),1,0,'C');
					$pdf->Cell(20,5,utf8_to_cp1252($date_nais),1,0,'C');
					$pdf->SetFont('Arial','',7);
					$pdf->Cell(32,5,utf8_to_cp1252(substr($lieu_nais, 0,19)),1,0);
					$i++;
				}
				 $eff=$i;
				$pdf->SetXY(123,271);
$pdf->Cell(0,3,'Page '.$pdf->PageNo().'/{nb}',0,1,'C');
$pdf->Output(utf8_to_cp1252('Liste_de_Tous_les_élèves_.pdf'),'I');
$pdf->Close();
?>
