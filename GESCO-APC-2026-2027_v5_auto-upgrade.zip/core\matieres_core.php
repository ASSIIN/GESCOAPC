<?php 
	/**
	 * 
	 */
	class MyMatieres
	{
		private $abr_mat, $nom_mat, $ref_depart, $coeff_mat, $group_mat;
		
		function __construct()
		{
			# code...
		}

		public function setNom_mat($value)
		{
			$this->nom_mat = $value;
		}
		public function getNom_mat()
		{
			return $this->nom_mat;
		}

		
		public function setRef_depart($value)
		{
			$this->ref_depart = $value;
		}
		public function getRef_session()
		{
			return $this->ref_depart;
		}

		public function setAbr_mat($value)
		{
			$this->abr_mat = $value;
		}
		public function getAbr_mat()
		{
			return $this->abr_mat;
		}

		public function AddMat()
		{
			$bdd = $GLOBALS['bdd'];
	

			$req = "INSERT INTO matieres (abr_mat, nom_mat, ref_depart) VALUES(?, ?, ?)" ;

				$rep = $bdd->prepare($req);
				if ($rep->execute( array($this->abr_mat, $this->nom_mat, $this->ref_depart))) {
					return true;
				}
				else{
					return false;
				}
			}

		public function CkClasseByCode($code)
		{

			$bdd = $GLOBALS['bdd'];	

			$reponse = $bdd->prepare('SELECT * FROM classes WHERE code_class = ?');
			$reponse->execute(array($code));
			$row = $reponse->fetch(PDO::FETCH_ASSOC);
			if ($row)
			{
				$_SESSION['id_cls'] = $row['id'];
				$_SESSION['nom_class'] = $row['nom_class'];
				$_SESSION['ref_class_niveau'] = $row['ref_class_niveau'];
				$_SESSION['class_session'] = $row['class_session'];
				$_SESSION['code_class'] = $row['code_class'];
			}
		}

			public function SelectDep()
		{
			$bdd = $GLOBALS['bdd'];
			$i=0;
			$nt=0;
			$reponse = $bdd->query('SELECT * FROM departements where id>=1 order by nom_dep asc');
			while($row = $reponse->fetch(PDO::FETCH_ASSOC)) 
			{
				$i++;

				echo '<option value="'.$row['id'].'">'.$i.' - '.$row['nom_dep'].' - ('.$row['ref_session'].')</option>';
				}
		}

		
		
		public function ShowAllMat()
		{
			$bdd = $GLOBALS['bdd'];
			$i=0;
			$nt=0;
			$reponse = $bdd->query('SELECT * FROM matieres where id>=1 order by nom_mat asc');
			while($row = $reponse->fetch(PDO::FETCH_ASSOC)) 
			{
				$i++;
				$nom_dep=$this->ReturnNom_DepByIdname($row['ref_depart']);
				$lib_dep=$this->ReturnLib_DepByIdname($row['ref_depart']);

				echo '
				<tr>
				<td >'.$i.'</td>
                <td >'.$row['nom_mat'].'</td>
                <td>'.$row['abr_mat'].'</td>
                <td>'.$lib_dep.'</td>
                <td>
                 <button type="button" class="btn btn-primary btn-sm ml-2" data-bs-toggle="modal" data-bs-target="#mod_edit'.$row['id'].'" data-whatever="@mdo"><i class="fa fa-edit fa-1x" aria-hidden="true"></i></button>
                  
					<div class="modal fade" id="mod_edit'.$row['id'].'" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                      <div class="modal-dialog modal-lg" role="document">
                        <div class="modal-content">
                          <div class="modal-header">
                            <h5 class="modal-title" id="exampleModalLabel">MODIFIER LA CLASSE</h5>
														<button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Fermer"></button>
                          </div>
                          <div class="modal-body">
                          		<div class="container-fluid">
                                <div class="row">
                                    <div class="col-md-12">
                                        <form action="Controler/matieres/updMat.php" method="post" > 
                                         <input type="text" class="form-control" id="ref_mat" name="ref_mat"  value="'.$row['id'].'" hidden="true" >                          
                                          <label for="inputState">Département: <b style="color:red">'.$nom_dep.'( '.$lib_dep.') </b></label>
                                             <select id="inputState" class="form-control" name="ref_dep">
                                             <option value="">Choisir...</option>';
                                              $this->SelectDep();
                                              echo '                           
                                            </select>
                                    </div>
                                </div>
                                <div class="row mb-3"> 
                                    <div class="col-md-8">
                                        <label for="inputEmail4">Nom: <b style="color:red">'.$nom_mat.' </b></label>
                                        <input type="text" class="form-control" id="nom_mat" name="nom_mat"  maxlength="50"   >
                                    </div>                           
                                    <div class="col-md-4 ">
                                          <label for="inputEmail4">Libele: <b style="color:red">'.$row['abr_mat'].' </b></label>
                                          <input type="text" class="form-control" id="abr_mat" name="abr_mat"  maxlength="25" >
                                    </div>
                                </div>              
                                       
                                </div>
                                <div class="modal-footer">
                                 
                               		 <button type="submit" class="btn btn-primary">Enrégistrer</button>
                                	<button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Annuler</button>
                                	</form>
                          		</div>
                        </div>
					</div></td>
					<td>
                 <button type="button" class="btn btn-danger btn-sm ml-2" data-bs-toggle="modal" data-bs-target="#mod_del'.$row['id'].'" data-whatever="@mdo"><i class="fa fa-remove fa-1x" aria-hidden="true"></i></button>
                  
					<div class="modal fade" id="mod_del'.$row['id'].'" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                      <div class="modal-dialog modal-lg" role="document">
                        <div class="modal-content">
                          <div class="modal-header">
                            <h5 class="modal-title" id="exampleModalLabel">SUPPRIMER LA MATIERE</h5>
														<button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Fermer"></button>
                          </div>
                          <div class="modal-body">
                          		<h5 class="modal-title" id="exampleModalLabel">Nom de la matière: <b style="color:red"> '.$row['nom_mat'].'</b> <br>Voulez-vous supprimmer cette matière y compris les paramètres de configuration des bulletins pour toutes les classes liées à cette matière? 
                          		<br> Cette action est irréversible.</h5>                   
                                       
                                </div>
                                <div class="modal-footer">
                                 
								<a href="Controler/matieres/delMat.php?id='.$row['id'].'" class="btn btn-primary">Oui</a>
                                	<button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Non</button>
                          		</div>
                        </div>
					</div></td>
                </tr>
				';
					
			}
			$nt=$i;
			$i=0;
				
		}

		

		public function SelectMatieres()
		{
			$bdd = $GLOBALS['bdd'];
			$i=0;
			$nt=0;
			$reponse = $bdd->query('SELECT * FROM matieres where id>=1 order by nom_mat asc');
			while($row = $reponse->fetch(PDO::FETCH_ASSOC)) 
			{
				$i++;

				echo '<option value="'.$row['id'].'" id="'.$row['ref_depart'].'">'.$i.' - '.$row['nom_mat'].'</option>';
				}
		}


		public function SelectNom_matByIdname($id)
		{
			$bdd = $GLOBALS['bdd'];
			$reponse = $bdd->query('SELECT abr_mat FROM matieres where id='.$id.'');
			while($row = $reponse->fetch(PDO::FETCH_ASSOC)) 
			{
				$_SESSION['abr_mat'] =$row['abr_mat'];
			}
		}

		public function ReturnNom_matByIdname($id)
		{
			$bdd = $GLOBALS['bdd'];
			$reponse = $bdd->query('SELECT * FROM matieres where id='.$id.'');
			while($row = $reponse->fetch(PDO::FETCH_ASSOC)) 
			{
				return $row['nom_mat'];
			}
		}

		public function ReturnNom_ComptMatByClsByEval($cls,$mat,$ev)
		{
			$bdd = $GLOBALS['bdd'];
			$reponse = $bdd->prepare('SELECT nom_compt FROM competences_matieres WHERE ref_class = :cls AND ref_mat = :mat AND num_compt = :ev LIMIT 1');
			$reponse->execute(array('cls'=>$cls, 'mat'=>$mat, 'ev'=>$ev));
			$row = $reponse->fetch(PDO::FETCH_ASSOC);
			if ($row && $row['nom_compt'] !== '') {
				return $row['nom_compt'];
			}
			return 'Competence'.$ev;
		}

		public function ReturnLib_matByIdname($id)
		{
			$bdd = $GLOBALS['bdd'];
			$reponse = $bdd->query('SELECT * FROM matieres where id='.$id.'');
			while($row = $reponse->fetch(PDO::FETCH_ASSOC)) 
			{
				return $row['abr_mat'];
			}
		}

		public function ReturnNom_DepByIdname($id)
		{
			$bdd = $GLOBALS['bdd'];
			$reponse = $bdd->query('SELECT * FROM departements where id='.$id.'');
			while($row = $reponse->fetch(PDO::FETCH_ASSOC)) 
			{
				return $row['nom_dep'];
			}
		}

		public function ReturnLib_DepByIdname($id)
		{
			$bdd = $GLOBALS['bdd'];
			$reponse = $bdd->query('SELECT * FROM departements where id='.$id.'');
			while($row = $reponse->fetch(PDO::FETCH_ASSOC)) 
			{
				return $row['abr_dep'];
			}
		}
		

		public function NombreMat()
		{
			$n=0;
			$ntotal=0;
			$bdd = $GLOBALS['bdd'];
			$reponse = $bdd->query("SELECT * FROM matieres where id>=1 ");

			while($row = $reponse->fetch(PDO::FETCH_ASSOC)) 
			{ 
					$n++;
			}
				$ntotal= $n;
				return $ntotal;
		}

		public function CkExistingCode($code)
		{

			$bdd = $GLOBALS['bdd'];	

			$reponse = $bdd->query('SELECT * FROM classes where code_class="'.$code.'" ');
			while (($row = $reponse->fetch(PDO::FETCH_ASSOC))) 
			{
				return true;
			}
		}

		public function delMat($code)
		{
			$bdd = $GLOBALS['bdd'];

			$bdd->beginTransaction();
			try {
				// Nettoyage des compétences d'évaluation liées à cette matière dans toutes les classes
				$req_comp = 'DELETE FROM competences_matieres WHERE ref_mat = ?';
				$rep_comp = $bdd->prepare($req_comp);
				$rep_comp->execute(array($code));

				// Nettoyage des associations matière/classe du bulletin
				$req_cfg = 'DELETE FROM config_bull WHERE ref_mat = ?';
				$rep_cfg = $bdd->prepare($req_cfg);
				$rep_cfg->execute(array($code));

				// Suppression physique de la matière
				$req = 'DELETE FROM matieres WHERE id=?';
				$rep = $bdd->prepare($req);
				if (!$rep->execute(array($code))) {
					throw new Exception('echec_suppression');
				}
				$bdd->commit();
				return true;
			} catch (Exception $e) {
				$bdd->rollBack();
				return false;
			}
		}
}
	$mat= new MyMatieres();

?>