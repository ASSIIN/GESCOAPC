<?php
// Controler/classes/add_mat_classe.php
session_start();
// Désactivation des affichages d'erreurs pour éviter de bloquer les redirections de Laragon
ini_set('display_errors', 0);
error_reporting(0);

require_once '../../Model/connexion.php';
require_once '../../core/require.php';

$bdd = $GLOBALS['bdd'];

if (isset($_POST['ref_class']) && isset($_POST['mat'])) {
    
    $refcls = htmlspecialchars($_POST['ref_class']);	
    $refmat = htmlspecialchars($_POST['mat']);
    $ens = htmlspecialchars($_POST['ens']);
    $coeff = htmlspecialchars($_POST['coeff']);
    $groupe = htmlspecialchars($_POST['groupe']);

    // SÉCURITÉ 1 : Requête préparée pour extraire l'abréviation sans boucle while
    $stmt_mat = $bdd->prepare("SELECT abr_mat FROM matieres WHERE id = ? LIMIT 1");
    $stmt_mat->execute(array($refmat));
    $row_mat = $stmt_mat->fetch(PDO::FETCH_ASSOC);

    if ($row_mat) {
        $nom_mat = $row_mat['abr_mat'];

        // SÉCURITÉ 2 : Vérification stricte anti-doublon (Empêche d'ajouter 2 fois la même matière dans la classe)
        $stmt_check = $bdd->prepare("SELECT id FROM config_bull WHERE ref_class = ? AND ref_mat = ? LIMIT 1");
        $stmt_check->execute(array($refcls, $refmat));
        
        if ($stmt_check->fetch()) {
            // Redirection avec un code d'erreur si la matière est déjà configurée pour cette classe
            header('location: ../../config_bull.php?id=' . urlencode($refcls) . '&duplicate=1');
            exit();
        }

        // SÉCURITÉ 3 : Insertion de la matière dans la configuration du bulletin
        $req = "INSERT INTO config_bull (ref_class, ref_mat, nom_mat, coeff_mat, group_mat, ref_ens) VALUES(?, ?, ?, ?, ?, ?)";
        $rep = $bdd->prepare($req);
        
        if ($rep->execute(array($refcls, $refmat, $nom_mat, $coeff, $groupe, $ens))) {

            // SÉCURITÉ 4 : Initialisation automatisée et préparée des 6 compétences d'évaluation par défaut
            $sql_comp = "INSERT INTO competences_matieres (ref_class, ref_mat, num_compt, nom_compt) VALUES (?, ?, ?, ?)";
            $stmt_comp = $bdd->prepare($sql_comp);

            for ($i = 1; $i <= 6; $i++) {
                $nom_compt = 'Competence ' . $i;
                $stmt_comp->execute(array($refcls, $refmat, $i, $nom_compt));
            }

            // Redirection vers le panneau de paramétrage du bulletin avec succès
            header('location: ../../config_bull.php?id=' . urlencode($refcls) . '&success=1');
            exit();
        } else {
            echo "Erreur lors de l'enregistrement de la matière dans la classe.";
        }
    } else {
        echo "La matière sélectionnée est introuvable ou inexistante.";
    }
} else {
    header('location: ../../menu_classes.php');
    exit();
}
?>
