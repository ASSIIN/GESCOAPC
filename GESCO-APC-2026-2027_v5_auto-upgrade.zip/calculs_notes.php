﻿<?php
    session_start();   
	require_once 'core/require.php'; 
	require_once 'Model/connexion.php';
     if (!isset($_SESSION['user'])) {
    session_unset();
    session_destroy();
    header('location: index.php');    
    }

    if (($_SESSION['user_role']!="admin") and ($_SESSION['user_role']!="pcpl")) {

      if ( ($_SESSION['user_role']=="caisse")) {
         header('location: menu_classes.php');    
      } 
      else{
          header('location: poste_de_saisie.php?trim=t1');   
        }
      
    }
    $etb->ShowEtb();
    $etb->CkLE();
    $etb->ckexneE();
    $nbclasses=$class->NombreClasses();
?>

<!DOCTYPE html>
<html>
  <head>
   <?php Config::head(); ?>
    <title>GESCOAPC| CALCUL BULLETIN</title>
    <style>
        .section-card { border-left: 4px solid #0764a8; }
        .section-card .card-header h5 { font-weight: 700; }
    </style>
  </head>

<body data-imprimable="1">
    <div class="wrapper">
      <!-- Sidebar -->

      <!-- Inclusion du menu de navigation externe réutilisable -->
      <?php include 'core/sidebar.php'; ?>  
       
<div class="main-content-wrapper">
        <!-- Barre supérieure de navigation adaptative -->
        <div class="mobile-navbar-fixed p-3 mb-4 rounded shadow-sm border">
            <div class="row align-items-center g-2">
                <div class="col-auto d-md-none">
                    <button class="btn btn-outline-dark btn-sm" id="toggleMobileMenu"><i class="fa fa-bars fa-lg"></i></button>
                </div>
                <div class="col-12 col-md">
                    <h4 class="m-0 fw-bold text-primary text-uppercase">Calcul des moyennes & statistiques</h4>
                </div>
                <div class="col-12 col-md-auto d-flex justify-content-md-end">
                    <button type="button" class="btn btn-sm btn-primary" data-bs-toggle="modal" data-bs-target="#addclasse">Vérification</button>
                </div>
            </div>
        </div>

        <div class="container-fluid mt-3">

            <!-- ===== MODAL VERIFICATION ===== -->
            <div class="modal fade" id="addclasse" tabindex="-1" role="dialog" aria-labelledby="addclasseLabel" aria-hidden="true">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="addclasseLabel">Choisir une section...</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Fermer"></button>
                        </div>
                        <form action="fpdf185/etatremp.php" method="GET">
                            <div class="modal-body">
                                <div class="row g-3">
                                    <div class="col-12 col-sm-6">
                                        <label for="inputState" class="form-label">SECTION</label>
                                        <select id="inputState" class="form-select form-select-lg" name="ss" required>
                                            <option value="">Choisir...</option>
                                            <option value="SFG">SF E.Général</option>
                                            <option value="SAG">SA E.Général</option>
                                            <option value="SFT">SF E.Technique</option>
                                            <option value="SAT">SA E.Technique</option>
                                        </select>
                                    </div>
                                    <div class="col-12 col-sm-6">
                                        <label for="inputTrim" class="form-label">TRIMESTRE</label>
                                        <select id="inputTrim" class="form-select form-select-lg" name="trim" required>
                                            <option value="">...</option>
                                            <option value="1">TRIM 1</option>
                                            <option value="2">TRIM 2</option>
                                            <option value="3">TRIM 3</option>
                                        </select>
                                    </div>
                                </div>
                            </div>
                            <div class="modal-footer">
                                <button type="submit" class="btn btn-primary">Afficher</button>
                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Annuler</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>

            <div class="row mb-4">
                <div class="col-12 text-center">
                    <h3 class="fw-bold text-primary">CALCUL AUTOMATIQUE DES MOYENNES</h3>
                    <p class="text-muted small mb-0">Sélectionnez une classe pour saisir et calculer les moyennes par matière et par séquence.</p>
                </div>
            </div>

            <?php
            $sections = [
                ['SFG', 'SECTION FR-ESG', 'primary'],
                ['SAG', 'SECTION AN-ESG', 'success'],
                ['SFT', 'SECTION FR-EST', 'info'],
                ['SAT', 'SECTION AN-EST', 'warning'],
            ];
            foreach ($sections as $sec):
                list($code, $titre, $couleur) = $sec;
            ?>
            <div class="card shadow-sm section-card mb-4">
                <div class="card-header bg-<?= $couleur ?> text-white py-2">
                    <h5 class="m-0">CALCUL AUTOMATIQUE DES MOYENNES : <?= $titre ?> <span class="badge bg-light text-dark ms-1"><?= htmlspecialchars($code) ?></span></h5>
                </div>
                <div class="card-body">
                    <div class="row">
                        <?php $opt->SelectClsbySession($code); ?>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>

            <?php if ((isset($_GET['cls'])) and (isset($_GET['mat'])) and (isset($_GET['seq']))): ?>
            <div class="card shadow-sm mb-5">
                <div class="card-header bg-dark text-white py-2">
                    <h5 class="m-0"><i class="fa-solid fa-table-list me-2"></i>Saisie des notes</h5>
                </div>
                <div class="card-body">
                    <div class="row">
                    <?php
                        echo '<div class="col-md-8">
                        <div class="table-responsive table-wrapper-scroll-y my-custom-scrollbar" style="font-size: 1em;">
                              <table class="table" cellspacing="0" cellpadding="0">
                                  <thead class="table-dark">
                                      <tr>
                                          <th>#</th>
                                          <th>Mat</th>
                                          <th>Nom et Pérenom</th>
                                          <th>NOTE/20</th>
                                          <th></th>
                                      </tr>
                                  </thead>
                                  <tbody class="table-hover">';
                        $class->ShowStd_for_Note_by_Mat($_GET['cls'], $_GET['mat'], $_GET['seq']);
                        $class->ShowInfosStd_for_Note_by_Mat($_GET['cls'], $_GET['mat'], $_GET['seq']);
                    ?>
                    </div>
                </div>
            </div>
            <?php endif; ?>

        </div>
        <!-- ============================================================== -->
        <!-- End Page Content -->
        <!-- ============================================================== -->
    </div>
</div>

		<?php 
		 	Config::scriptJs();
		?>
	</body>
</html>

