 <?php
    
$currentDate = new DateTime();
$School_year1="";
$School_year2="";
$currentDate = new DateTime();
$currentMonth = $currentDate->format('m'); // obtenir le mois actuel (ex: 05 pour mai)

if ($currentMonth >= 6) {
    $year = date('y', strtotime('+1 year'));
    $year1 = date('Y', strtotime('+1 year'));
    $year0 = date('Y', strtotime('-1 year'));
    $year00 = date('y', strtotime('-1 year')); // obtenir les deux derniers chiffres de l'année prochaine (ex: 26 pour 2026)
    $previousYear = date('y');
    $previousYear1 = date('Y');
    $School_year2="".$previousYear1."/".$year1;
    $School_year1="".$year0."/".$previousYear1;
    $_SESSION['School_year2']=$School_year2;
    $_SESSION['School_year1']=$School_year1;
    $dbLastY="".$year00."_".$previousYear;
    $dbcurrentY="".$previousYear."_".$year;
 
} else {
    $year = date('y');
    $year1 = date('Y');
    $year0 = date('Y', strtotime('-2 year'));
    $year00 = date('y', strtotime('-2 year'));

    $previousYear = date('y', strtotime('-1 year'));
    $previousYear1 = date('Y', strtotime('-1 year'));
   
    $School_year2="".$previousYear1."/".$year1;
    $School_year1="".$year0."/".$previousYear1;
   	$dbLastY="".$year00."_".$previousYear;
   	$dbcurrentY="".$previousYear."_".$year;
   	 $_SESSION['School_year2']=$School_year2;
    $_SESSION['School_year1']=$School_year1;
}

$dbName = "gescoapc_".$previousYear."_".$year."";
$dbName_last = "gescoapc_".$dbLastY."";

// Connexion au serveur MySQL
$conn = new mysqli("localhost", "root", "");

// Vérifier la connexion
if ($conn->connect_error) {
    die("Connexion échouée : " . $conn->connect_error);
}

// Vérifier si la base de données existe déjà
$sql = "SHOW DATABASES LIKE '$dbName'";
$result = $conn->query($sql);

if ($result->num_rows > 0) 
{
   // echo "La base de données $dbName existe déjà.";
}
else 
{
    // Créer la base de données
    $sql = "CREATE DATABASE IF NOT EXISTS $dbName DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci";
    if ($conn->query($sql) === TRUE) 
    {
    	// L'année scolaire précédente existe-t-elle ? (elle sert de source à la mise à jour annuelle)
		$sourceExiste = false;
		$resSrc = $conn->query("SHOW DATABASES LIKE '$dbName_last'");
		if ($resSrc && $resSrc->num_rows > 0) { $sourceExiste = true; }

		if ($sourceExiste) {
	    	// Créer la table cible si elle n'existe pas
			$conn->select_db($dbName);
			$sql0 = "CREATE TABLE IF NOT EXISTS admins LIKE $dbName_last.admins";
		if ($conn->query($sql0) === TRUE) 
		{
		   // echo "Table eleves créée avec succès";
		    $sqli = "INSERT INTO admins SELECT * FROM $dbName_last.admins";
			if ($conn->query($sqli) === TRUE) 
			{
			    //echo "Données copiées avec succès";
			}
		}

		$sql1 = "CREATE TABLE IF NOT EXISTS etablissement LIKE $dbName_last.etablissement";
		if ($conn->query($sql1) === TRUE) 
		{
		   // echo "Table eleves créée avec succès";
		    $sqli = "INSERT INTO etablissement SELECT * FROM $dbName_last.etablissement";
			if ($conn->query($sqli) === TRUE) 
			{
			    //echo "Données copiées avec succès";
			}
		}

		$sql2 = "CREATE TABLE IF NOT EXISTS sess LIKE $dbName_last.sess";
		if ($conn->query($sql2) === TRUE) 
		{
		   // echo "Table eleves créée avec succès";
		    $sqli = "INSERT INTO sess SELECT * FROM $dbName_last.sess";
			if ($conn->query($sqli) === TRUE) 
			{
			    //echo "Données copiées avec succès";
			}
		}

		$sql3 = "CREATE TABLE IF NOT EXISTS niveaux LIKE $dbName_last.niveaux";
		if ($conn->query($sql3) === TRUE) 
		{
		   // echo "Table eleves créée avec succès";
		    $sqli = "INSERT INTO niveaux SELECT * FROM $dbName_last.niveaux";
			if ($conn->query($sqli) === TRUE) 
			{
			    //echo "Données copiées avec succès";
			}
		}

		$sql4 = "CREATE TABLE IF NOT EXISTS config_bull LIKE $dbName_last.config_bull";
		if ($conn->query($sql4) === TRUE) 
		{
		   // echo "Table eleves créée avec succès";
		    $sqli = "INSERT INTO config_bull SELECT * FROM $dbName_last.config_bull";
			if ($conn->query($sqli) === TRUE) 
			{
			    //echo "Données copiées avec succès";
			}
		}

		$sql4i = "CREATE TABLE IF NOT EXISTS competences_matieres LIKE $dbName_last.competences_matieres";
		if ($conn->query($sql4i) === TRUE) 
		{
		   // echo "Table eleves créée avec succès";
		    $sqli = "INSERT INTO competences_matieres SELECT * FROM $dbName_last.competences_matieres";
			if ($conn->query($sqli) === TRUE) 
			{
			    //echo "Données copiées avec succès";
			}
		}

		

		$sql5 = "CREATE TABLE IF NOT EXISTS departements LIKE $dbName_last.departements";
		if ($conn->query($sql5) === TRUE) 
		{
		   // echo "Table eleves créée avec succès";
		    $sqli = "INSERT INTO departements SELECT * FROM $dbName_last.departements";
			if ($conn->query($sqli) === TRUE) 
			{
			    //echo "Données copiées avec succès";
			}
		}

		$sql7 = "CREATE TABLE IF NOT EXISTS matieres LIKE $dbName_last.matieres";
		if ($conn->query($sql7) === TRUE) 
		{
		   // echo "Table eleves créée avec succès";
		    $sqli = "INSERT INTO matieres SELECT * FROM $dbName_last.matieres";
			if ($conn->query($sqli) === TRUE) 
			{
			    //echo "Données copiées avec succès";
			}
		}

		$sql8 = "CREATE TABLE IF NOT EXISTS evaluations LIKE $dbName_last.evaluations";
		if ($conn->query($sql8) === TRUE) 
		{
		   // echo "Table eleves créée avec succès";
		    $sqli = "INSERT INTO evaluations SELECT * FROM $dbName_last.evaluations";
			if ($conn->query($sqli) === TRUE) 
			{
			    //echo "Données copiées avec succès";
			}
		}

		$sql9 = "CREATE TABLE IF NOT EXISTS pensions LIKE $dbName_last.pensions";
		if ($conn->query($sql9) === TRUE) 
		{
		   // echo "Table eleves créée avec succès";
		    $sqli = "INSERT INTO pensions SELECT * FROM $dbName_last.pensions";
			if ($conn->query($sqli) === TRUE) 
			{
			    //echo "Données copiées avec succès";
			}
		}
		// Copier les tables sans donnees 

		 // Sélectionner la base de données source
		$conn->select_db($dbName_last);

		// Récupérer la liste des tables
		$sql = "SHOW TABLES";
		$result = $conn->query($sql);

		if ($result->num_rows > 0) 
		{
		    // Sélectionner la base de données cible
		    $conn->select_db($dbName);

		    while($row = $result->fetch_array()) {
		        $tableName = $row[0];

		        // Exclure les tables users et établissements
		        if ($tableName != "admins" && $tableName != "etablissement" && strpos($tableName, "unite_a_ua")!==0 )  
		        {
		            // Créer la table si elle n'existe pas
		            $sql = "CREATE TABLE IF NOT EXISTS $tableName LIKE $dbName_last.$tableName";
		            if ($conn->query($sql) === TRUE) {
		                //echo "Table $tableName créée avec succès<br>";
		            } else {
		                //echo "Erreur lors de la création de la table $tableName : " . $conn->error . "<br>";
		            }
		        }
		    }
		} 
		else 
		{
		    //echo "Aucune table trouvée";
		}

		} // fin mise à jour (base de l'année précédente présente)
		else 
		{
		    // NOUVELLE INSTALLATION : aucune base antérieure.
		    // La base est créée et remplie automatiquement à partir du modèle SQL du pack.
		    $conn->select_db($dbName);
		    $fichModele = '';
		    $candidat = __DIR__ . '/gescoapc_' . $dbcurrentY . '.sql';
		    if (file_exists($candidat)) { $fichModele = $candidat; }
		    else {
		        $globs = glob(__DIR__ . '/gescoapc_*.sql');
		        if ($globs) { $fichModele = $globs[0]; }
		    }
		    if ($fichModele !== '' && file_exists($fichModele)) {
		        $sqlModele = file_get_contents($fichModele);
		        if ($sqlModele !== false && $conn->multi_query($sqlModele)) {
		            do {
		                if ($resu = $conn->store_result()) { $resu->free(); }
		            } while ($conn->more_results() && $conn->next_result());
		            if (!empty($conn->error)) {
		                // Import en échec : on supprime la base pour permettre un nouvel essai au prochain chargement
		                $conn->query("DROP DATABASE IF EXISTS $dbName");
		            } else {
		                // Année scolaire courante reportée dans l'établissement de démarrage
		                $conn->query("UPDATE etablissement SET school_year = '" . $conn->real_escape_string(strip_tags($School_year2)) . "' WHERE id = 1");
		                $_SESSION['fresh_install'] = 1;
		            }
		        } else {
		            $conn->query("DROP DATABASE IF EXISTS $dbName");
		        }
		    } else {
		        // Modèle introuvable : message clair plutôt qu'une base vide
		        die("GESCO-APC : fichier modèle de base introuvable (Model/gescoapc_*.sql). Réinstallez le pack complet.");
		    }
		}

	} 
	else 
	{
		    //echo "Erreur lors de la création de la table : " . $conn->error;
	}
	
} 
   
// Fermer la connexion
$conn->close();

?>
