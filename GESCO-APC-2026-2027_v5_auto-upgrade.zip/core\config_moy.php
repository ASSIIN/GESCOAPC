<?php 

 $MargeCoeff_trim=0.78;
 $MargeCoeff_an=0.8;
 // utilisation partout $GLOBALS['MargeCoeff_trim']
?>