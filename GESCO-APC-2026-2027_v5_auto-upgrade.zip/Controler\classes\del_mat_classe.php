<?php
// Controler/classes/del_mat_classe.php
session_start();
// Désactivation des affichages d'erreurs pour éviter de bloquer les redirections de Laragon
ini_set('display_errors', 0);
error_reporting(0);

require_once '../../Model/connexion.php';
require_once '../../core/require.php';

$bdd = $GLOBALS['bdd'];

if (isset($_GET['id']) && isset($_GET['refcls'])) {
    
    // Récupération et sécurisation des paramètres d'URL
    $id_config = (int)$_GET['id'];
    $refcls = htmlspecialchars($_GET['refcls']);

    // Activation d'une transaction PDO pour un nettoyage étanche et sécurisé
    $bdd->beginTransaction();

    try {
        // 1. Récupération du code exact de la matière associée avant suppression
        $stmt_find = $bdd->prepare("SELECT ref_mat FROM config_bull WHERE id = ? LIMIT 1");
        $stmt_find->execute(array($id_config));
        $row_config = $stmt_find->fetch(PDO::FETCH_ASSOC);

        if ($row_config) {
            $ref_mat = $row_config['ref_mat'];

            // 2. Suppression en cascade des compétences liées à cette matière dans cette classe
            $stmt_comp = $bdd->prepare("DELETE FROM competences_matieres WHERE ref_class = ? AND ref_mat = ?");
            $stmt_comp->execute(array($refcls, $ref_mat));

            // 3. Suppression de la matière de la configuration du bulletin de cette classe
            $stmt_del = $bdd->prepare("DELETE FROM config_bull WHERE id = ?");
            $success = $stmt_del->execute(array($id_config));

            if ($success) {
                // Validation de la transaction globale
                $bdd->commit();
                header('location: ../../config_bull.php?id=' . urlencode($refcls) . '&del_success=1');
                exit();
            } else {
                throw new Exception("Échec de la suppression de la ligne de configuration.");
            }
        } else {
            // Si la ligne n'existe déjà plus en base de données
            $bdd->rollBack();
            header('location: ../../config_bull.php?id=' . urlencode($refcls));
            exit();
        }

    } catch (Exception $e) {
        // En cas de coupure ou d'erreur, on annule tout pour ne pas corrompre le bulletin
        $bdd->rollBack();
        echo "Erreur système lors du retrait de la matière de la classe.";
    }

} else {
    header('location: ../../menu_classes.php');
    exit();
}
?>
