-- ====================================================================
-- GESCO-APC 2026-2027 - BASE DE DEMARRAGE NEUTRE
-- Aucune donnee reelle : structure complete + configuration generique.
-- IMPORT : creez la base `gescoapc_26_27` puis importez ce fichier.
-- Apres import, SUPPRIMEZ ce fichier du serveur (securite).
-- ====================================================================

-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Sep 12, 2026 at 05:03 PM
-- Server version: 8.0.30
-- PHP Version: 8.1.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database cible : `gescoapc_26_27`
--

-- --------------------------------------------------------

--
-- Table structure for table `absences`
--

CREATE TABLE `absences` (
  `id` int NOT NULL,
  `ref_cls` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ref_std` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ref_trim` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `heure` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `post_on` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `admins`
--

CREATE TABLE `admins` (
  `id` int NOT NULL,
  `civilite` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `username` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `login` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `role` varchar(50) NOT NULL,
  `last_con` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `ref_dep` varchar(50) DEFAULT NULL,
  `master_cls` varchar(50) DEFAULT NULL,
  `user_tel` varchar(50) DEFAULT NULL,
  `user_grade` varchar(50) DEFAULT NULL,
  `user_matricule` varchar(50) DEFAULT NULL,
  `user_date_1prise_etb` datetime DEFAULT CURRENT_TIMESTAMP,
  `user_date_1prise_adm` datetime DEFAULT CURRENT_TIMESTAMP,
  `user_date_prise_etb` datetime DEFAULT CURRENT_TIMESTAMP,
  `user_diplome` varchar(50) DEFAULT NULL,
  `user_specialite` varchar(50) DEFAULT NULL,
  `user_note_aff` varchar(50) DEFAULT NULL,
  `user_situa_matri` varchar(50) DEFAULT NULL,
  `user_post_ant` varchar(50) DEFAULT NULL,
  `user_etb_ant` varchar(50) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3;

--
-- Dumping data for table `admins`
--

INSERT INTO `admins` (`id`, `civilite`, `username`, `login`, `password`, `role`, `last_con`, `ref_dep`, `master_cls`, `user_tel`, `user_grade`, `user_matricule`, `user_date_1prise_etb`, `user_date_1prise_adm`, `user_date_prise_etb`, `user_diplome`, `user_specialite`, `user_note_aff`, `user_situa_matri`, `user_post_ant`, `user_etb_ant`) VALUES
(1, 'Mr', 'ADMINISTRATEUR', '1275', '1275', 'admin', CURRENT_TIMESTAMP, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `classes`
--

CREATE TABLE `classes` (
  `id` int NOT NULL,
  `nom_class` varchar(50) NOT NULL,
  `ref_class_niveau` varchar(200) NOT NULL,
  `class_session` varchar(50) NOT NULL,
  `code_class` varchar(50) NOT NULL,
  `cls_master` varchar(50) DEFAULT 'non'
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3;

--
-- Dumping data for table `classes`
--


-- --------------------------------------------------------

--
-- Table structure for table `competences_matieres`
--

CREATE TABLE `competences_matieres` (
  `id` int NOT NULL,
  `ref_class` varchar(50) NOT NULL,
  `ref_mat` varchar(50) NOT NULL,
  `num_compt` int NOT NULL,
  `nom_compt` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `competences_matieres`
--


-- --------------------------------------------------------

--
-- Table structure for table `config_bull`
--

CREATE TABLE `config_bull` (
  `id` int NOT NULL,
  `ref_class` varchar(50) NOT NULL,
  `ref_mat` varchar(50) NOT NULL,
  `nom_mat` varchar(50) NOT NULL,
  `coeff_mat` varchar(50) NOT NULL,
  `group_mat` varchar(50) NOT NULL,
  `ref_ens` varchar(50) DEFAULT NULL,
  `ref_niveau_class` varchar(50) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3;

--
-- Dumping data for table `config_bull`
--


-- --------------------------------------------------------

--
-- Table structure for table `config_licence`
--

CREATE TABLE `config_licence` (
  `id` int NOT NULL,
  `cle_licence` LONGTEXT COLLATE utf8mb4_unicode_ci NOT NULL,
  `statut_activation` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT 'inactif',
  `install_id` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cle_publique` LONGTEXT COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `debut_licence` date DEFAULT NULL,
  `fin_licence` date DEFAULT NULL,
  `nb_poste` int NOT NULL DEFAULT 1,
  `dernier_controle` datetime DEFAULT CURRENT_TIMESTAMP,
  `dernier_sync` datetime DEFAULT NULL,
  `dernier_sync_essai` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `config_licence`
--


-- --------------------------------------------------------

--
-- Table structure for table `departements`
--

CREATE TABLE `departements` (
  `id` int NOT NULL,
  `nom_dep` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `ref_session` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `abr_dep` varchar(25) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `departements`
--

INSERT INTO `departements` (`id`, `nom_dep`, `ref_session`, `abr_dep`) VALUES
(1, 'FRANCAIS', 'SFG', 'FR'),
(3, 'MATHEMATIQUE', 'SFG', 'MATHS'),
(4, 'HIST-GEO-ECM', 'SFG', 'HGE'),
(5, 'ANGLAIS', 'SFG', 'ANGLAIS'),
(6, 'SVTEEHB', 'SFG', 'SVTEEHB'),
(7, 'PHYSIQUE-CHIMIE-TECHNO', 'SFG', 'PCT'),
(9, 'ALLEMAND', 'SFG', 'ALL'),
(10, 'ESPAGNOL', 'SFG', 'ESP'),
(11, 'EPS', 'SFG', 'EPS'),
(12, 'PHILOSOPHIE', 'SFG', 'PHILO'),
(14, 'DISCIPLINE', 'SFG', 'DISCIPLINE'),
(15, 'INFORMATIQUE', 'SFG', 'INFO'),
(17, 'LANG-CULT_NAT', 'SFG', 'LCN'),
(19, 'ARABE', 'SFG', 'ARA'),
(20, 'CHINOIS', 'SFG', 'CHIN'),
(21, 'COMPUTER SCIENCES', 'SAG', 'CS'),
(22, 'ENGLISH', 'SAG', 'ENG'),
(23, 'ARTS', 'SAG', 'ARTS'),
(24, 'SCIENCES', 'SAG', 'SC'),
(25, 'DISCIPLINE', 'SAG', 'DISCIPLINE'),
(26, 'TECHNICAL', 'SAG', 'TECHNICAL'),
(27, 'PHILO', 'SFG', 'PHILO');

-- --------------------------------------------------------

--
-- Table structure for table `eleves`
--

CREATE TABLE `eleves` (
  `id` int NOT NULL,
  `nom_std` varchar(255) NOT NULL,
  `date_nais` datetime NOT NULL,
  `lieu_nais` varchar(255) NOT NULL,
  `sexe_std` varchar(20) NOT NULL,
  `mat_std` varchar(255) NOT NULL,
  `cni_std` varchar(25) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT '',
  `ref_class` varchar(100) NOT NULL,
  `pere_std` varchar(100) DEFAULT NULL,
  `mere_std` varchar(100) DEFAULT NULL,
  `adresse_std` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `localite_std` varchar(50) DEFAULT NULL,
  `contenu_std` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL DEFAULT 'icon.png',
  `register_std_on` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `statut` varchar(50) DEFAULT 'N',
  `handicap` varchar(100) NOT NULL DEFAULT 'RAS'
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `eleves`
--


-- --------------------------------------------------------

--
-- Table structure for table `etablissement`
--

CREATE TABLE `etablissement` (
  `id` int NOT NULL,
  `nom_etb_fr` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `nom_etb_en` varchar(255) DEFAULT NULL,
  `minist_etb_fr` varchar(255) NOT NULL,
  `minist_etb_en` varchar(255) NOT NULL,
  `region_etb_fr` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL DEFAULT '',
  `region_etb_en` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL DEFAULT '',
  `depart_etb_fr` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL DEFAULT '',
  `depart_etb_en` varchar(255) DEFAULT NULL,
  `tel_etb` varchar(100) NOT NULL,
  `logo_etb` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `sign_respo_etb` varchar(100) NOT NULL,
  `p_ch` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT 'N',
  `email_etb` varchar(100) NOT NULL,
  `code_pste_etb` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `nom_respo_etb` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `civ_respo_etb_fr` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `civ_respo_etb_en` varchar(100) NOT NULL,
  `code_im_etb` varchar(100) NOT NULL DEFAULT '',
  `ville_etb` varchar(50) DEFAULT NULL,
  `pre_matr` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT 'CO24',
  `slogan_etb` varchar(150) DEFAULT NULL,
  `school_year` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `etablissement`
--

INSERT INTO `etablissement` (`id`, `nom_etb_fr`, `nom_etb_en`, `minist_etb_fr`, `minist_etb_en`, `region_etb_fr`, `region_etb_en`, `depart_etb_fr`, `depart_etb_en`, `tel_etb`, `logo_etb`, `sign_respo_etb`, `p_ch`, `email_etb`, `code_pste_etb`, `nom_respo_etb`, `civ_respo_etb_fr`, `civ_respo_etb_en`, `code_im_etb`, `ville_etb`, `pre_matr`, `slogan_etb`, `school_year`) VALUES
(1, 'ETABLISSEMENT', 'SCHOOL', 'MINISTERE DES ENSEIGNEMENTS SECONDAIRE', 'MINISTRY OF SECONDARY EDUCATION', 'REGION', 'REGION', 'DEPARTEMENT', 'DIVISION', '000000000', 'logo.png', 'signature.png', 'N', 'contact@etablissement.edu', 'VILLE', 'LE RESPONSABLE', 'Mr', 'Mr', '', 'VILLE', 'CO', 'Travailler pour reussir', '2026/2027');

-- --------------------------------------------------------

--
-- Table structure for table `evaluations`
--

CREATE TABLE `evaluations` (
  `id` int NOT NULL,
  `nom_seq` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ref_trim` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `statut` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `evaluations`
--

INSERT INTO `evaluations` (`id`, `nom_seq`, `ref_trim`, `statut`) VALUES
(1, 'COMPT 1', '1', 'O'),
(2, 'COMPT 2', '1', 'O'),
(3, 'COMPT 3', '2', 'O'),
(4, 'COMPT 4', '2', 'O'),
(5, 'COMPT 5', '3', 'O'),
(6, 'COMPT 6', '3', 'O');

-- --------------------------------------------------------

--
-- Table structure for table `exclusions`
--

CREATE TABLE `exclusions` (
  `id` int NOT NULL,
  `ref_cls` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ref_std` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ref_trim` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `jour` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `his_con`
--

CREATE TABLE `his_con` (
  `id` int NOT NULL,
  `user_session` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `ref_user` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ref_nom` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ref_role` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_con` datetime DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `his_con`
--


-- --------------------------------------------------------

--
-- Table structure for table `listsexcel`
--

CREATE TABLE `listsexcel` (
  `id` int NOT NULL,
  `ref_cls` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `contenu` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `matieres`
--

CREATE TABLE `matieres` (
  `id` int NOT NULL,
  `abr_mat` varchar(50) NOT NULL,
  `nom_mat` varchar(50) NOT NULL,
  `ref_depart` varchar(50) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3;

--
-- Dumping data for table `matieres`
--

INSERT INTO `matieres` (`id`, `abr_mat`, `nom_mat`, `ref_depart`) VALUES
(3, 'ALL', 'ALLEMAND', '9'),
(2, 'LITTERATURE', 'LITTERATURE', '1'),
(4, 'ENG', 'ANGLAIS', '5'),
(5, 'LANGUE', 'LANGUE', '1'),
(6, 'TM', 'TRAVAIL MANUEL', '14'),
(7, 'CDT', 'CONDUITE', '14'),
(8, 'INFO', 'INFORMATIQUE', '15'),
(9, 'MATHS', 'MATHEMATIQUES', '3'),
(10, 'C. ORTH', 'CORR. ORTHO', '1'),
(11, 'EXP. E', 'EXP. ECRITE', '1'),
(12, 'E. TEXTE', 'ETUDE DE TEXTE', '15'),
(13, 'SVT', 'SVTEEHB', '6'),
(14, 'EPS', 'EPS', '11'),
(15, 'ESP', 'ESPAGNOL', '10'),
(16, 'HIST', 'HISTOIRE', '4'),
(17, 'GEO', 'GEOGRAPHIE', '4'),
(18, 'HG', 'HIST-GEO', '4'),
(19, 'ECM', 'ECM', '4'),
(20, 'ARA', 'ARABE', '19'),
(21, 'PHYS', 'PHYSIQUE', '7'),
(22, 'CHIM', 'CHIMIE', '7'),
(23, 'PCT', 'PCT', '7'),
(24, 'LN', 'LANG. NAT', '17'),
(25, 'CT', 'CULT. NAT', '17'),
(26, 'LCN', 'LANG/CUL. NAT', '17'),
(27, 'FR', 'FRENCH', '23'),
(28, 'CS', 'COMPUTER SC', '24'),
(29, 'ACN', 'ART AND CULTURE', '23'),
(30, 'LIT IN ENG', 'LIT. IN ENGLISH', '23'),
(31, 'ENG. LANG', 'ENGLISH LANG.', '23'),
(32, 'CIT.', 'CITIZENSHIP', '23'),
(33, 'GEO', 'GEOGRAPHY', '23'),
(34, 'HIST.', 'HISTORY', '23'),
(35, 'ECON.', 'ECONOMICS', '23'),
(36, 'LOGIC', 'LOGIC', '23'),
(37, 'BIO', 'BIOLOGY', '24'),
(38, 'CHE', 'CHEMISTRY', '24'),
(39, 'FAN', 'FOOD AND NUTR.', '26'),
(40, 'MATHS.', 'MATHEMATICS', '24'),
(41, 'PHYS', 'PHYSICS', '24'),
(42, 'SPORTS', 'SPORTS &AMP; PHYS. EDU.', '26'),
(43, 'ML', 'MANUAL LABOUR', '26'),
(44, 'H.BIO', 'HUMAN BIOLOGY', '24'),
(45, 'GLG', 'GEOLOGY', '24'),
(46, 'ADD.MATHS', 'ADDITIONAL MATHS.', '24'),
(47, 'ACC', 'ACCOUNTING', '23'),
(48, 'COM', 'COMMERCE', '24'),
(49, 'LIT IN FR', 'LIT. IN FRENCH', '23'),
(50, 'BEHV', 'BEHAVIOR', '26'),
(51, 'SC', 'SCIENCE', '7'),
(52, 'PHILO', 'PHILO', '27');

-- --------------------------------------------------------

--
-- Table structure for table `moy_trim`
--

CREATE TABLE `moy_trim` (
  `id` int NOT NULL,
  `ref_std` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ref_cls` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `moy_trim1` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `moy_trim2` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `moy_trim3` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `rang_trim1` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `rang_trim2` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `rang_trim3` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `moy_an` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `rang_an` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `niveaux`
--

CREATE TABLE `niveaux` (
  `id` int NOT NULL,
  `nom_niveau` varchar(50) NOT NULL,
  `ref_niveau` varchar(10) NOT NULL,
  `nb_classes` int NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3;

--
-- Dumping data for table `niveaux`
--

INSERT INTO `niveaux` (`id`, `nom_niveau`, `ref_niveau`, `nb_classes`) VALUES
(1, '6E / F1 / 1E_AN', '1', 0),
(2, '5E / F2 / 2E_AN', '2', 0),
(3, '4E / F3 / 3E_AN', '3', 0),
(4, '3E / F5 / 4E_AN', '4', 0),
(5, '2NDE / F6', '5', 0),
(6, '1ERE / L6', '6', 0),
(7, 'TLE / UP6', '7', 0);

-- --------------------------------------------------------

--
-- Table structure for table `pensions`
--

CREATE TABLE `pensions` (
  `id` int NOT NULL,
  `ref_s` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ref_n` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `prix` float DEFAULT '0',
  `ps_bull` float DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `remises`
--

CREATE TABLE `remises` (
  `id` int NOT NULL,
  `ref_std` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `prix_rms` float DEFAULT '0',
  `post_on` datetime DEFAULT CURRENT_TIMESTAMP,
  `ref_vsm` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `sess`
--

CREATE TABLE `sess` (
  `id` int NOT NULL,
  `nom_sess` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `abr_sess` varchar(25) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `nb_class_par_sess` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `sess`
--

INSERT INTO `sess` (`id`, `nom_sess`, `abr_sess`, `nb_class_par_sess`) VALUES
(1, 'SF E.Général', 'SFG', '7'),
(2, 'SA E.Général', 'SAG', '2'),
(3, 'SF E.Technique', 'SFT', '0'),
(4, 'SA E.Technique', 'SAT', '0');

-- --------------------------------------------------------

--
-- Table structure for table `students`
--

CREATE TABLE `students` (
  `id` int NOT NULL,
  `nom_std` varchar(255) NOT NULL,
  `prenom_std` varchar(255) NOT NULL,
  `nom_prenom_std` varchar(255) NOT NULL,
  `date_nais` varchar(100) NOT NULL,
  `lieu_nais` varchar(255) NOT NULL,
  `sexe_std` varchar(20) NOT NULL,
  `mat_std` varchar(20) NOT NULL,
  `ref_class` varchar(100) NOT NULL,
  `register_std_on` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3;

-- --------------------------------------------------------

--
-- Table structure for table `table_note_par_mat`
--

CREATE TABLE `table_note_par_mat` (
  `id` int NOT NULL,
  `ref_mat` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ref_cls` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ref_std` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ref_eval` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `note` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `coef` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `note_x_coeff` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `table_note_par_mat_eval1`
--

CREATE TABLE `table_note_par_mat_eval1` (
  `id` int NOT NULL,
  `ref_mat` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ref_cls` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ref_std` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ref_eval` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `note` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `coef` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `note_x_coeff` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `table_note_par_mat_eval1`
--


-- --------------------------------------------------------

--
-- Table structure for table `table_note_par_mat_eval2`
--

CREATE TABLE `table_note_par_mat_eval2` (
  `id` int NOT NULL,
  `ref_mat` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ref_cls` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ref_std` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ref_eval` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `note` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `coef` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `note_x_coeff` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `table_note_par_mat_eval2`
--


-- --------------------------------------------------------

--
-- Table structure for table `table_note_par_mat_eval3`
--

CREATE TABLE `table_note_par_mat_eval3` (
  `id` int NOT NULL,
  `ref_mat` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ref_cls` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ref_std` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ref_eval` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `note` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `coef` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `note_x_coeff` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `table_note_par_mat_eval3`
--


-- --------------------------------------------------------

--
-- Table structure for table `table_note_par_mat_eval4`
--

CREATE TABLE `table_note_par_mat_eval4` (
  `id` int NOT NULL,
  `ref_mat` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ref_cls` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ref_std` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ref_eval` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `note` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `coef` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `note_x_coeff` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `table_note_par_mat_eval4`
--


-- --------------------------------------------------------

--
-- Table structure for table `table_note_par_mat_eval5`
--

CREATE TABLE `table_note_par_mat_eval5` (
  `id` int NOT NULL,
  `ref_mat` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ref_cls` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ref_std` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ref_eval` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `note` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `coef` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `note_x_coeff` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `table_note_par_mat_eval6`
--

CREATE TABLE `table_note_par_mat_eval6` (
  `id` int NOT NULL,
  `ref_mat` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ref_cls` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ref_std` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ref_eval` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `note` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `coef` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `note_x_coeff` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `table_note_par_trim1`
--

CREATE TABLE `table_note_par_trim1` (
  `id` int NOT NULL,
  `ref_trim` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ref_cls` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ref_std` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `total_note` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `total_coef` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `moy` float DEFAULT NULL,
  `classer` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'N',
  `rang` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '  '
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `table_note_par_trim1`
--


-- --------------------------------------------------------

--
-- Table structure for table `table_note_par_trim2`
--

CREATE TABLE `table_note_par_trim2` (
  `id` int NOT NULL,
  `ref_trim` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ref_cls` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ref_std` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `total_note` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `total_coef` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `moy` float DEFAULT NULL,
  `classer` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'N',
  `rang` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '  '
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `table_note_par_trim2`
--


-- --------------------------------------------------------

--
-- Table structure for table `table_note_par_trim3`
--

CREATE TABLE `table_note_par_trim3` (
  `id` int NOT NULL,
  `ref_trim` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ref_cls` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ref_std` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `total_note` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `total_coef` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `moy` float DEFAULT NULL,
  `classer` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'N',
  `rang` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '  '
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `table_note_par_triman`
--

CREATE TABLE `table_note_par_triman` (
  `id` int NOT NULL,
  `ref_trim` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ref_cls` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ref_std` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `total_note` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `total_coef` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `moy` float DEFAULT NULL,
  `classer` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'N',
  `rang` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '  '
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `versements`
--

CREATE TABLE `versements` (
  `id` int NOT NULL,
  `ref_std` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `prix_vsm` float DEFAULT '0',
  `id_vsm` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `post_on` datetime DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `absences`
--
ALTER TABLE `absences`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `admins`
--
ALTER TABLE `admins`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `classes`
--
ALTER TABLE `classes`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `competences_matieres`
--
ALTER TABLE `competences_matieres`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `config_bull`
--
ALTER TABLE `config_bull`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `config_licence`
--
ALTER TABLE `config_licence`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unq_install_id` (`install_id`);

--
-- Indexes for table `departements`
--
ALTER TABLE `departements`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `eleves`
--
ALTER TABLE `eleves`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `etablissement`
--
ALTER TABLE `etablissement`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `evaluations`
--
ALTER TABLE `evaluations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `exclusions`
--
ALTER TABLE `exclusions`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `his_con`
--
ALTER TABLE `his_con`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `listsexcel`
--
ALTER TABLE `listsexcel`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `matieres`
--
ALTER TABLE `matieres`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `moy_trim`
--
ALTER TABLE `moy_trim`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `niveaux`
--
ALTER TABLE `niveaux`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pensions`
--
ALTER TABLE `pensions`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `remises`
--
ALTER TABLE `remises`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sess`
--
ALTER TABLE `sess`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `table_note_par_mat`
--
ALTER TABLE `table_note_par_mat`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `table_note_par_mat_eval1`
--
ALTER TABLE `table_note_par_mat_eval1`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `table_note_par_mat_eval2`
--
ALTER TABLE `table_note_par_mat_eval2`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `table_note_par_mat_eval3`
--
ALTER TABLE `table_note_par_mat_eval3`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `table_note_par_mat_eval4`
--
ALTER TABLE `table_note_par_mat_eval4`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `table_note_par_mat_eval5`
--
ALTER TABLE `table_note_par_mat_eval5`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `table_note_par_mat_eval6`
--
ALTER TABLE `table_note_par_mat_eval6`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `table_note_par_trim1`
--
ALTER TABLE `table_note_par_trim1`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `table_note_par_trim2`
--
ALTER TABLE `table_note_par_trim2`
  ADD PRIMARY KEY (`id`) USING BTREE;

--
-- Indexes for table `table_note_par_trim3`
--
ALTER TABLE `table_note_par_trim3`
  ADD PRIMARY KEY (`id`) USING BTREE;

--
-- Indexes for table `table_note_par_triman`
--
ALTER TABLE `table_note_par_triman`
  ADD PRIMARY KEY (`id`) USING BTREE;

--
-- Indexes for table `versements`
--
ALTER TABLE `versements`
  ADD PRIMARY KEY (`id`) USING BTREE;

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `absences`
--
ALTER TABLE `absences`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `admins`
--
ALTER TABLE `admins`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `classes`
--
ALTER TABLE `classes`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1;

--
-- AUTO_INCREMENT for table `competences_matieres`
--
ALTER TABLE `competences_matieres`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1;

--
-- AUTO_INCREMENT for table `config_bull`
--
ALTER TABLE `config_bull`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1;

--
-- AUTO_INCREMENT for table `config_licence`
--
ALTER TABLE `config_licence`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1;

--
-- AUTO_INCREMENT for table `departements`
--
ALTER TABLE `departements`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;

--
-- AUTO_INCREMENT for table `eleves`
--
ALTER TABLE `eleves`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1;

--
-- AUTO_INCREMENT for table `etablissement`
--
ALTER TABLE `etablissement`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `evaluations`
--
ALTER TABLE `evaluations`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `exclusions`
--
ALTER TABLE `exclusions`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `his_con`
--
ALTER TABLE `his_con`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1;

--
-- AUTO_INCREMENT for table `listsexcel`
--
ALTER TABLE `listsexcel`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `matieres`
--
ALTER TABLE `matieres`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=53;

--
-- AUTO_INCREMENT for table `moy_trim`
--
ALTER TABLE `moy_trim`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `niveaux`
--
ALTER TABLE `niveaux`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `pensions`
--
ALTER TABLE `pensions`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `remises`
--
ALTER TABLE `remises`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `sess`
--
ALTER TABLE `sess`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `table_note_par_mat`
--
ALTER TABLE `table_note_par_mat`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `table_note_par_mat_eval1`
--
ALTER TABLE `table_note_par_mat_eval1`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1;

--
-- AUTO_INCREMENT for table `table_note_par_mat_eval2`
--
ALTER TABLE `table_note_par_mat_eval2`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1;

--
-- AUTO_INCREMENT for table `table_note_par_mat_eval3`
--
ALTER TABLE `table_note_par_mat_eval3`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1;

--
-- AUTO_INCREMENT for table `table_note_par_mat_eval4`
--
ALTER TABLE `table_note_par_mat_eval4`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1;

--
-- AUTO_INCREMENT for table `table_note_par_mat_eval5`
--
ALTER TABLE `table_note_par_mat_eval5`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `table_note_par_mat_eval6`
--
ALTER TABLE `table_note_par_mat_eval6`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `table_note_par_trim1`
--
ALTER TABLE `table_note_par_trim1`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1;

--
-- AUTO_INCREMENT for table `table_note_par_trim2`
--
ALTER TABLE `table_note_par_trim2`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1;

--
-- AUTO_INCREMENT for table `table_note_par_trim3`
--
ALTER TABLE `table_note_par_trim3`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `table_note_par_triman`
--
ALTER TABLE `table_note_par_triman`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `versements`
--
ALTER TABLE `versements`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
