<?php
	session_start();
	require_once '../../Model/connexion.php';
	require_once '../../core/require.php'; 

	// Sécurité : seuls les rôles admin, pcpl et cs sont autorisés à changer un rôle
	if (!isset($_SESSION['user']) || !in_array($_SESSION['user_role'], array('admin', 'pcpl', 'cs'))) {
		header('location: ../../index.php');
		exit;
	}

	$user= htmlspecialchars($_POST['user']);
	$role= htmlspecialchars($_POST['user_role']);


	if (isset($role)) 
	{
		if ($role!="") {

				$bdd = $GLOBALS['bdd'];	
				// SÉCURISÉ : requête préparée anti-injection SQL (login lié par paramètre)
				$req ='UPDATE admins SET role= ? where login=?';
				$rep = $bdd->prepare($req);
				$rep->execute(array($role, $user));
			}

		
		header('location: ../../general_setting.php');
	 }
	
		
?>