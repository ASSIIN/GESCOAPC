<?php
/**
 * Fichier : bul_an.php
 * Description : Génération du Bulletin Scolaire Annuel (Format A4)
 * Système : GESCOAPC
 */

session_start();
require_once '../Model/connexion.php';
require_once '../core/require.php';

// --- SÉCURITÉ ---
if (!isset($_SESSION['user'])) {
    session_unset();
    session_destroy();
    header('location: ../index.php');
    exit();
}

$refcls = $_GET['cls'];
$refstd = $_GET['std'];
$refbul = "an"; // Identifiant pour les calculs annuels
$today  = date('d-m-Y');
$bdd    = $GLOBALS['bdd'];

/* 1. VÉRIFICATION DE LA DISPONIBILITÉ DES DONNÉES (Au moins 2 trimestres) */
$count = 0;
// On utilise ta fonction Ck_ExistMoy_by_Cls sans la modifier
$m1 = $opt->Ck_ExistMoy_by_Cls($refcls, '1');
$m2 = $opt->Ck_ExistMoy_by_Cls($refcls, '2');
$m3 = $opt->Ck_ExistMoy_by_Cls($refcls, '3');

if ($m1 == true) { $count++; }
if ($m2 == true) { $count++; }
if ($m3 == true) { $count++; }

if ($count < 2) {
    // Redirection si les données sont insuffisantes pour un bilan annuel
    header('location: ../calculs_notes.php?error=insuffisant');
    exit();
}

// Initialisation des données établissement
$etb->ShowEtb();
$titreB = 'BULLETIN SCOLAIRE ANNUEL / ANNUAL REPORT CARD';

require('fpdf.php');

// --- EXTENSION DE LA CLASSE FPDF POUR LE FOOTER AUTOMATIQUE ---
class PDF extends FPDF {
    function Footer() {
        $today  = date('d-m-Y');
        $this->SetY(-15);
        $this->SetFont('Arial','I',7);
        $this->Cell(0,10,utf8_to_cp1252('GESCOAPC - by INOFIB - 2025          --    imprimé le '.$today),0,0,'C');
    }
}

$pdf = new PDF('P', 'mm', 'A4');
$pdf->AliasNbPages();
$pdf->SetAutoPageBreak(true, 10);

// --- RÉCUPÉRATION DES ÉLÈVES DE LA CLASSE ---
$reponse0 = $bdd->query('SELECT * FROM eleves WHERE (ref_class="'.$refcls.'" and mat_std="'.$refstd.'") limit 1');

while($row0 = $reponse0->fetch(PDO::FETCH_ASSOC)) 
{
    $refstd = $row0['mat_std'];
    $pdf->AddPage();

    /* --- SECTION 1 : EN-TÊTE RÉPUBLIQUE (TA STRUCTURE) --- */
    /*En-tête*/
        $pdf->SetFont('Times','',6);
        $pdf->Image('../plugins/images/'.$_SESSION['logo_etb'].'',92,10,25);
        $pdf->Cell(70,3,'REPUBLIQUE DU CAMEROUN',0,0,'C');
        $pdf->Cell(50,3,'',0,0);
        $pdf->Cell(70,3,'REPUBLIC OF CAMEROON',0,1,'C');

        $pdf->Cell(70,3,'Paix-Travail-Patrie',0,0,'C');
        $pdf->Cell(50,3,'',0,0);
        $pdf->Cell(70,3,'Peace-Work-Fatherland',0,1,'C');

        $pdf->Cell(70,3, utf8_to_cp1252("".$_SESSION['minist_etb_fr'].""),0,0,'C');
        $pdf->Cell(50,3,'',0,0);
        $pdf->Cell(70,3,utf8_to_cp1252(''.$_SESSION['minist_etb_en'].''),0,1,'C');

        $pdf->Cell(70,3,utf8_to_cp1252("".$_SESSION['region_etb_fr'].""),0,0,'C');
        $pdf->Cell(50,3,'',0,0);
        $pdf->Cell(70,3,utf8_to_cp1252(''.$_SESSION['region_etb_en'].''),0,1,'C');

        $pdf->Cell(70,3,utf8_to_cp1252(''.$_SESSION['depart_etb_fr'].''),0,0,'C');
        $pdf->Cell(50,3,'',0,0);
        $pdf->Cell(70,3,utf8_to_cp1252(''.$_SESSION['depart_etb_en'].''),0,1,'C');
        $pdf->SetFont('Times','B',8);
        $pdf->Cell(70,4,utf8_to_cp1252(''.$_SESSION['nom_etb_fr'].''),0,0,'C');
        $pdf->Cell(50,3,'',0,0);
        $pdf->Cell(70,4,utf8_to_cp1252(''.$_SESSION['nom_etb_en'].''),0,1,'C');
        $pdf->SetFont('Times','',6);
        $pdf->Cell(70,4,utf8_to_cp1252(''.$_SESSION['code_pste_etb'].' / '.$_SESSION['tel_etb'].''),0,0,'C');
        $pdf->Cell(50,3,'',0,0);
        $pdf->Cell(70,3,utf8_to_cp1252(''.$_SESSION['code_pste_etb'].'/ '.$_SESSION['tel_etb'].''),0,1,'C');
        $pdf->SetFont('Times','',6);
        $pdf->Cell(70,3,utf8_to_cp1252(''.$_SESSION['email_etb'].''),0,0,'C');
        $pdf->SetFont('Times','I',10);
        $pdf->Cell(50,5,utf8_to_cp1252(''.$_SESSION['code_im_etb'].''),0,0,'C');
        $pdf->SetFont('Times','',6);
        $pdf->Cell(70,3,utf8_to_cp1252(''.$_SESSION['email_etb'].''),0,1,'C');
            $pdf->Ln();
            

            
                $pdf->SetFont('Times','I',6);
                $pdf->Cell(40,3,'',0,0,'C');
                $pdf->Cell(60,3,'ANNEE SCOLAIRE ',0,0,'R');
                $pdf->SetFont('Times','B',10);
                $pdf->Cell(40,3,''.$_SESSION['school_year'].'',0,0,'L');
                $pdf->Cell(40,3,'',0,1,'C');
    
    $pdf->SetFont('Times','B',12);

    $pdf->SetFillColor(214,223,236);
    $pdf->Cell(37,5,'',0,0,'C');
    $pdf->Cell(120,8,utf8_to_cp1252($titreB),1,0,'C',0);
    $pdf->Cell(20,5,'',0,1,'C');
    $pdf->Ln();
    //les information sur la classe

    $class->CkClasseByCode($refcls);
    $nbstd=$class->NbrStudentByClass($refcls);
    $nbstdclasser=$opt->NbrStudentClasserByClass($refcls,$refbul);
    $nbstdclasser=(float)$nbstdclasser;
    $nbM=$class->NbrBySexeByClass($refcls,'M');
    $nbF=$class->NbrBySexeByClass($refcls,'F');
    $moy_1er=$opt->ShowMoy_1er_Cls($refcls,$refbul);
    $moy_dern=$opt->ShowMoy_dern_Cls($refcls,$refbul);
    $nomcls=$_SESSION['nom_class'];
    $niveaucls=$_SESSION['ref_class_niveau'];
    $pdf->SetFont('Times','',10);

    $pdf->Cell(50,4,"Classe: $nomcls",0,0,'L');
    $pdf->Cell(30,4,"Code: ($refcls)",0,0,'C');
    $pdf->Cell(20,4,"Niveau: $niveaucls",0,0,'C');
    $pdf->Cell(20,4,"Eff: $nbstd",0,0,'C');
    $pdf->Cell(10,4,"M: $nbM",0,0,'C');
    $pdf->Cell(10,4,"F: $nbF",0,0,'C');
    $pdf->Ln();
    $pdf->Cell(190,4,'',2,0,'C',0);
    $pdf->Ln();
        //les information de l'eleve
    $std->CkStdByCode_for_Bul($refstd);
    $num=$class->NumStudentByClass($refcls,$refstd);
    $rangstd=$opt->ShowRang_Std($refcls,$refstd,$refbul);
    $classer_std=$opt->ShowClasser_Std($refcls,$refstd,$refbul);
    $HeureAbs=$opt->ShowAbsStd_by_Cls($refcls,$refstd,$refbul);
    $nomstd=$_SESSION['nom_std'];


    $matstd=$_SESSION['mat_std'];
    $sexestd=$_SESSION['sexe_std'];
    $naissstd=$_SESSION['date_fr'];
    $lieu_nais=$_SESSION['lieu_nais'];
    $statut=$_SESSION['statut'];

    $nomstd=substr($nomstd, 0,42);
    $nomstd= str_replace("&#039;", "'", $nomstd);
    $lieu_nais=mb_strtoupper($lieu_nais);
    $lieu_nais=substr($lieu_nais, 0,34);
    $lieu_nais = str_replace("&#039;", "'", $lieu_nais);

    $rangstd=(string)$rangstd;
    $strrangstd='';
    if (($rangstd=='1') or ($rangstd=='21') or ($rangstd=='31') or ($rangstd=='41') or ($rangstd=='51') or ($rangstd=='61') or ($rangstd=='71') or ($rangstd=='81') or ($rangstd=='91') or ($rangstd=='101') or ($rangstd=='121') or ($rangstd=='131') or ($rangstd=='141') or ($rangstd=='151') or ($rangstd=='161') or ($rangstd=='171') or ($rangstd=='181') or ($rangstd=='191') or $rangstd=='201' or $rangstd=='221' or $rangstd=='231' or $rangstd=='241' or $rangstd=='251' or $rangstd=='261' or $rangstd=='271' or $rangstd=='281' or $rangstd=='291') {
        if ($sexestd=='M') {
            $strrangstd='er';
        }else{
            $strrangstd='ere';
        }
        
    }
    elseif ($rangstd=='2' or $rangstd=='22' or $rangstd=='32' or $rangstd=='42' or $rangstd=='52' or $rangstd=='62' or $rangstd=='72' or $rangstd=='82' or $rangstd=='92' or $rangstd=='102' or $rangstd=='122' or $rangstd=='132' or $rangstd=='142' or $rangstd=='152' or $rangstd=='162' or $rangstd=='172' or $rangstd=='182' or $rangstd=='192' or $rangstd=='202' or $rangstd=='222' or $rangstd=='232' or $rangstd=='242' or $rangstd=='252' or $rangstd=='262' or $rangstd=='272' or $rangstd=='282' or $rangstd=='292') {
        $strrangstd='e';
    }
    elseif ($rangstd=='3' or $rangstd=='23' or $rangstd=='33' or $rangstd=='43' or $rangstd=='53' or $rangstd=='63' or $rangstd=='73' or $rangstd=='83' or $rangstd=='93' or $rangstd=='103' or $rangstd=='123' or $rangstd=='133' or $rangstd=='143' or $rangstd=='153' or $rangstd=='163' or $rangstd=='173' or $rangstd=='183' or $rangstd=='193' or  $rangstd=='203' or $rangstd=='223' or $rangstd=='233' or $rangstd=='243' or $rangstd=='253' or $rangstd=='263' or $rangstd=='273' or $rangstd=='283' or $rangstd=='293') {
        $strrangstd='e';
    }else
    {
        if ($classer_std=='Y') {
            $strrangstd='e';
        }else{
            $strrangstd='';
            
        }

        
    }
                
    $pdf->Image('../plugins/images/imgstd/'.$_SESSION['contenu_std'].'',168,32,18);
    $pdf->SetFont('Times','',10);
    $pdf->Cell(15,5,"Noms",1,0,'L',1);
    $pdf->SetFont('Courier','B',10);
    $pdf->Cell(92,5,utf8_to_cp1252("$nomstd"),1,0,'L');
    $pdf->SetFont('Times','',10);
    $pdf->Cell(10,5,"Red: ",1,0,'L',1);
    $pdf->Cell(8,5,utf8_to_cp1252($statut),1,0,'C');
    $pdf->Cell(18,5,utf8_to_cp1252("N° classe:"),1,0,'L',1);
    $pdf->Cell(10,5,utf8_to_cp1252($num),1,0,'C');
    $pdf->Cell(12,5,utf8_to_cp1252("Matr"),1,0,'L',1);
    $pdf->Cell(25,5,utf8_to_cp1252($row0['cni_std']),1,0,'C');
    
    $pdf->Ln();
    $pdf->Cell(15,5,utf8_to_cp1252("Né(e) le:"),1,0,'L',1);
    $pdf->Cell(20,5,utf8_to_cp1252($naissstd),1,0,'L');
    $pdf->Cell(5,5,utf8_to_cp1252("A:"),1,0,'L',1);
    $pdf->SetFont('Times','',9);
    $pdf->Cell(67,5,utf8_to_cp1252($lieu_nais),1,0,'L');
    $pdf->SetFont('Times','',10);
    $pdf->Cell(10,5,"Sexe:",1,0,'C',1);
    $pdf->Cell(8,5,utf8_to_cp1252($sexestd),1,0,'C');
    $pdf->Cell(10,5,utf8_to_cp1252('Tel:'),1,0,'L',1);
    if ($row0['adresse_std']==NULL) {
        $nutel="";
    }
    else{
        $nutel=$row0['adresse_std'];
    }
    $pdf->Cell(20,5,utf8_to_cp1252($nutel),1,0,'C');
    $pdf->Cell(15,5,utf8_to_cp1252('N° Inscr:'),1,0,'L',1);
        $pdf->Cell(20,5,utf8_to_cp1252($_SESSION['pre_matr'].''.$matstd.''),1,0,'C');
    
    

    $pdf->SetFont('Times','B',9);
    $pdf->Ln(8);
    // En-têtes : 190mm total
    $header = array('MATIÈRES ', 'T1', 'T2', 'T3', 'Moy', 'Coef', 'Total', 'Cote', '[m-M]', 'ENSEIGNANTS / VISA');
    $w = array(46, 11, 11, 11, 11, 8, 13, 9, 16, 54);
    
    $pdf->SetFillColor(230,230,230);
    $pdf->SetFont('Times','B',7);
    for($i=0;$i<count($header);$i++) $pdf->Cell($w[$i],7,utf8_to_cp1252($header[$i]),1,0,'C',1);
    $pdf->Ln(8);

    $Totalcoeff = 0; $Totalpoint = 0; $faibles_mat = '';
    
    // Requête préparée pour la configuration des matières
    $stmt_config = $bdd->prepare('SELECT * FROM config_bull WHERE ref_class = ? ORDER BY nom_mat ASC');
    $stmt_config->execute([$refcls]);

    while($rowM = $stmt_config->fetch(PDO::FETCH_ASSOC)) {
        $rmat = $rowM['ref_mat'];
        $nmat=$mat->ReturnNom_matByIdname($rowM['ref_mat']);
        $teacher = $user->SelectTeacherName_by_mat_by_cls($rowM['ref_ens']);
        
               /* 1. RÉCUPÉRATION DU COEFFICIENT */
        $coef = (float)($rowM['coeff_mat'] ?? 0);

        /* 2. RÉCUPÉRATION DES NOTES DE L'ÉLÈVE */
        $n1 = $class->SelectNoteStd_by_MatCls_an($refcls, $rmat, '1', $refstd);
        $n2 = $class->SelectNoteStd_by_MatCls_an($refcls, $rmat, '2', $refstd);
        $n3 = $class->SelectNoteStd_by_MatCls_an($refcls, $rmat, '3', $refstd);

        /* 3. CALCUL DE LA MOYENNE (Diviseur dynamique par élève) */
        $notes_eleve = [];
        // On n'ajoute au tableau que si c'est un chiffre (0 inclus) et pas '--'
        if (is_numeric($n1) && $n1 !== '--') $notes_eleve[] = (float)$n1;
        if (is_numeric($n2) && $n2 !== '--') $notes_eleve[] = (float)$n2;
        if (is_numeric($n3) && $n3 !== '--') $notes_eleve[] = (float)$n3;

        $nbNotesEleve = count($notes_eleve);

        if ($nbNotesEleve > 0) {
            // Calcul correct : (15+10)/2 = 12.50
            $moyMat = round(array_sum($notes_eleve) / $nbNotesEleve, 2);
            $totalM = $moyMat * $coef;
            
            // Cumul pour la moyenne générale annuelle
            $Totalcoeff += $coef; 
            $Totalpoint += $totalM;

            $displayMoy = number_format($moyMat, 2);
            $displayTotal = number_format($totalM, 2);
        } else {
            // Cas "Dispensé" ou "Pas de note"
            $moyMat = -1; // Valeur technique pour ignorer la cote
            $totalM = 0;
            $displayMoy = '--';
            $displayTotal = '--';
        }

        // Récupération du Min et Max réels de l'année pour la matière
        $statsAnnuelle = $class->SelectMinMaxAnnuel($refcls, $rmat);
        $min = $statsAnnuelle['min'];
        $max = $statsAnnuelle['max'];

        // Détermination de la cote (uniquement si l'élève a des notes)
        if($moyMat === -1) { 
            $c = "--"; 
        } else {
            if($moyMat < 10) { $c="D"; $faibles_mat .= $rowM['nom_mat'].', '; }
            elseif($moyMat < 12) $c="C"; 
            elseif($moyMat < 14) $c="C+"; 
            elseif($moyMat < 16) $c="B"; 
            else $c="A";
        }

        /* 4. AFFICHAGE DE LA LIGNE PDF */
        $pdf->SetFont('Times','B',7);
        $pdf->Cell($w[0], 7.5, utf8_to_cp1252($nmat), 1, 0, 'L');
        $pdf->SetFont('Times','',8);

        // Notes trimestrielles : affiche la note ou vide si '--'
        $pdf->Cell($w[1], 7.5, (is_numeric($n1) && $n1 !== '--' ? $n1 : ''), 1, 0, 'C');
        $pdf->Cell($w[2], 7.5, (is_numeric($n2) && $n2 !== '--' ? $n2 : ''), 1, 0, 'C');
        $pdf->Cell($w[3], 7.5, (is_numeric($n3) && $n3 !== '--' ? $n3 : ''), 1, 0, 'C');

        $pdf->SetFont('Times','B',9);
        $pdf->Cell($w[4], 7.5, $displayMoy, 1, 0, 'C'); // Affiche 12.50 ou --

        $pdf->SetFont('Times','',9);
        $pdf->Cell($w[5], 7.5, $coef, 1, 0, 'C');
        $pdf->Cell($w[6], 7.5, $displayTotal, 1, 0, 'C'); // Affiche le total ou --

        $pdf->Cell($w[7], 7.5, $c, 1, 0, 'C');
        $pdf->SetFont('Times','',8);
        $pdf->Cell($w[8], 7.5, $min.'-'.$max, 1, 0, 'C');
        $pdf->Cell($w[9], 7.5, utf8_to_cp1252($teacher." / "), 1, 1, 'LT'); 
        $pdf->SetFont('Times','',9);
        $pdf->Ln(1);


    }

    /* --- SECTION 4 : CALCULS FINAUX ET APPRÉCIATIONS (TA GRILLE) --- */
    //$moyAn = ($Totalcoeff > 0) ? round($Totalpoint / $Totalcoeff, 2) : 0;
     $moyAn=$opt->ShowMoy_std_Cls_trim($refcls,$refbul,$refstd);

    if (($moyAn>=0) and ($moyAn<10)) { $coteT="D"; $aprT="CNA"; }
    elseif (($moyAn>=10) and ($moyAn<12)) { $coteT="C"; $aprT="CMA"; }
    elseif (($moyAn>=12) and ($moyAn<14)) { $coteT="C+"; $aprT="CA"; }
    elseif (($moyAn>=14) and ($moyAn<15)) { $coteT="B"; $aprT="CBA"; }
    elseif (($moyAn>=15) and ($moyAn<16)) { $coteT="B+"; $aprT="CBA"; }
    elseif (($moyAn>=16) and ($moyAn<18)) { $coteT="A"; $aprT="CTBA"; }
    else { $coteT="A+"; $aprT="CTBA"; }

    $th = ($moyAn >= 12) ? "X" : "--";
    $sblmwk = ($moyAn < 7) ? "X" : "--";
    $avertmwk = ($moyAn >= 7 && $moyAn < 10) ? "X" : "--";

    // Récupération des statistiques annuelles
    $moy_General = round($opt->ShowMoy_by_Cls($refcls, $refbul), 2);
    $moy_1er     = round($opt->ShowMoy_1er_Cls($refcls, $refbul), 2);
    $moy_dern    = round($opt->ShowMoy_dern_Cls($refcls, $refbul), 2);
    $nbclasser   = (float)$opt->NbrStudentClasserByClass($refcls, $refbul);
    $NbPass      = $opt->ShowNbStd_for_TauxR_by_Cls($refcls, $refbul, 10);
    $taux_R      = ($nbclasser > 0) ? round(($NbPass*100)/$nbclasser, 2) : 0;
    $rangstd     = $opt->ShowRang_Std($refcls, $refstd, $refbul);

    $moyT1=$opt->ShowMoy_std_Cls_trim($refcls,'1',$refstd);
   
    $moyT2=$opt->ShowMoy_std_Cls_trim($refcls,'2',$refstd);
     if ($moyT2==NULL) {
       $moyT2='';
    }
    $moyT3=$opt->ShowMoy_std_Cls_trim($refcls,'3',$refstd);
     if ($moyT3==NULL) {
       $moyT3='';
    }
$pdf->Ln(3);
    /* --- SECTION 5 : PIED DE PAGE (BLOC VERT : TOTAUX) --- */
   $pdf->SetFont('Arial','B',8);

        $pdf->Cell(13,5,utf8_to_cp1252('TRIM 1:'),1,0,'C',1);
        if ($moyT1==NULL) 
        {
           $pdf->Cell(12,5,'- -',1,0,'C',0);
        }
        else
        {
            $pdf->Cell(12,5,number_format($moyT1,2),1,0,'C',0);
        }
      
        $pdf->Cell(13,5,utf8_to_cp1252('TRIM 2:'),1,0,'C',1);
        if ($moyT2==NULL) 
        {
           $pdf->Cell(12,5,'- -',1,0,'C',0);
        }
        else
        {
            $pdf->Cell(12,5,number_format($moyT2,2),1,0,'C',0);
        }

         $pdf->Cell(13,5,utf8_to_cp1252('TRIM 3:'),1,0,'C',1);
       if ($moyT3==NULL) 
        {
           $pdf->Cell(12,5,' - -',1,0,'C',0);
        }
        else
        {
            $pdf->Cell(12,5,number_format($moyT3,2),1,0,'C',0);
        }
        
        $pdf->Cell(5,5,'',0,0,'C',0);
        $pdf->Cell(14,5,'TOTAL ',1,0,'C',1);
        $pdf->Cell(8,5,$Totalcoeff,1,0,'C',0);
        $pdf->Cell(15,5,$Totalpoint,1,0,'C',0);
        $pdf->Cell(10,5,' Moy: ',1,0,'C',1);
        $pdf->Cell(12,5,is_numeric($moyAn) ? number_format($moyAn, 2) : $moyAn,1,0,'C',0);
        $pdf->Cell(10,5,' Apprt:',1,0,'C',1);
        $pdf->Cell(14,5,''.$aprT.'',1,0,'C',0);
        $pdf->Ln(1);

        
        /* Fin Statistique */
        $moy_General_raw=$opt->ShowMoy_by_Cls($refcls,$refbul);
        $moy_General = is_numeric($moy_General_raw) ? round($moy_General_raw, 2) : 0;
        $moy_General_display=number_format($moy_General,2);

        $marge=10;
        $NbStd_Taux=$opt->ShowNbStd_for_TauxR_by_Cls($refcls,$refbul,$marge);
        $nbstdclasser = isset($nbstdclasser) ? (float)$nbstdclasser : 0;
        if ($nbstdclasser>0) { $taux_R=$NbStd_Taux*100/$nbstdclasser; $taux_R=round($taux_R,2); }
        else{ $taux_R=0; }
        

        $pdf->SetFillColor(0,167,223);
        $pdf->Ln();
        $pdf->SetFont('Times','B',8);
        $pdf->Cell(40,4,utf8_to_cp1252('Discipline'),1,0,'C',1);
        $pdf->Cell(2,4,'',0,0,'L',0);
        $pdf->Cell(50,4, utf8_to_cp1252("Travail de l'élève"),1,0,'C',1);
        $pdf->Cell(2,4,'',0,0,'L',0);
        $pdf->Cell(40,4,utf8_to_cp1252('Profil de la classe'),1,0,'C',1);
        $pdf->Cell(0,4,utf8_to_cp1252('Fait à '.$_SESSION['ville_etb'].', le ___________'),0,0,'R',0);
        $pdf->Ln();
        $HeureAbs = isset($HeureAbs) ? $HeureAbs : '--'; 
        $pdf->Cell(30,4,utf8_to_cp1252('Abs. Non. J.(h)'),1,0,'L',0);
        $pdf->Cell(10,4,''.$HeureAbs.'',1,0,'C',0); 
        $pdf->Cell(2,4,'',0,0,'L',0);
        $pdf->Cell(10,8,'Moy:',1,0,'L',0);
        $pdf->SetFont('Times','B',12);
        $pdf->SetFillColor(236,235,2);
        $pdf->Cell(15,8,is_numeric($moyAn) ? number_format($moyAn, 2) : $moyAn,1,0,'C',1); 
        $pdf->SetFont('Times','B',8);
        $pdf->Cell(10,8,'Rang: ',1,0,'L',0);
        $pdf->SetFont('Times','B',12);
        $rangstd = isset($rangstd) ? $rangstd : '--'; $strrangstd = isset($strrangstd) ? $strrangstd : '';
        if ($rangstd=='NC') { $pdf->Cell(15,8,''.$rangstd.''.$strrangstd,1,0,'C',1); }
        else{ $pdf->Cell(15,8,''.$rangstd.''.$strrangstd.'/'.$nbstdclasser.'',1,0,'C',1); }
        $pdf->Cell(2,4,'',0,0,'L',0);
        $pdf->SetFont('Times','B',8);
        $pdf->Cell(25,4,utf8_to_cp1252('Moy Gen.'),1,0,'L',0);
        $pdf->Cell(15,4,$moy_General_display,1,0,'C',0); 
        $pdf->Ln();
        $pdf->Cell(30,4,utf8_to_cp1252('Consignes (h)'),1,0,'L',0);
        $pdf->Cell(10,4,'',1,0,'C',0);
        $pdf->Cell(2,8,'',0,0,'L',0);
        $pdf->Cell(52,4,'',0,0,'L',0);
        $moy_1er = isset($moy_1er) ? $moy_1er : 0;
        $moy_1er_display = is_numeric($moy_1er) ? number_format($moy_1er, 2) : '--';
        $pdf->Cell(25,4,'Moy 1er.',1,0,'L',0);
        $pdf->Cell(15,4,$moy_1er_display,1,0,'C',0);
        $pdf->Cell(2,8,'',0,0,'L',0);
        $pdf->Cell(0,4,utf8_to_cp1252('Le Directeur'),0,0,'L',0);
        $pdf->Ln();
        // CORRECTION : impression conditionnelle du cachet de l'établissement (paramètre p_ch)
        if ($etb->ChksigRE() && !empty($_SESSION['sign_respo_etb'])) {
            $pdf->Image('../plugins/images/'.$_SESSION['sign_respo_etb'], 175, $pdf->GetY(), 20);
        }
        $pdf->Cell(30,4,utf8_to_cp1252("Tableau d'Honneur"),1,0,'L',0);
        $pdf->Cell(10,4,''.$th.'',1,0,'C',0); 
        $pdf->Cell(2,4,'',0,0,'L',0);
        $pdf->Cell(10,4,'Cote',1,0,'L',0);
        $pdf->Cell(15,4,$coteT,1,0,'C',0); 
        $pdf->Cell(10,4,'Apprt',1,0,'L',0);
        $pdf->Cell(15,4,$aprT,1,0,'C',0); 
        $pdf->Cell(2,4,'',0,0,'L',0);
        $moy_dern = isset($moy_dern) ? $moy_dern : 0;
        $moy_dern_display = is_numeric($moy_dern) ? number_format($moy_dern, 2) : '--';
        $pdf->Cell(25,4,'Moy der.',1,0,'L',0);
        $pdf->Cell(15,4,$moy_dern_display,1,0,'C',0);
        $pdf->Ln(); 
        $pdf->Cell(30,4,utf8_to_cp1252('Exclusion (jrs)'),1,0,'L',0);
        $pdf->Cell(10,4,'',1,0,'C',0);
        $pdf->Cell(2,4,'',0,0,'L',0);
        $pdf->Cell(50,4,utf8_to_cp1252('Visa du professeur pcpl:'),1,0,'C',1);
        $pdf->Cell(2,4,'',0,0,'L',0);
        $pdf->Cell(25,4,utf8_to_cp1252('Taux de R. (%)'),1,0,'L',0);
        $pdf->Cell(15,4,utf8_to_cp1252($taux_R),1,0,'C',0); 
        $pdf->Cell(2,4,'',0,0,'L',0);
        $pdf->Ln();
        $pdf->Cell(30,4,utf8_to_cp1252('Blâme Travail'),1,0,'L',0);
        $pdf->Cell(10,4,$sblmwk,1,0,'C',0); 
        $pdf->Cell(2,4,'',0,0,'L',0);
        $pdf->Cell(50,4,'',0,0,'L',0);
        $pdf->Ln();
        $pdf->Cell(30,4,utf8_to_cp1252('Avert,'),1,0,'L',0);
        $pdf->Cell(10,4,$avertmwk,1,0,'C',0); 
        $pdf->Cell(2,4,'',0,0,'L',0);
        $pdf->Cell(50,4,'',0,0,'L',0);
        $pdf->Cell(60,2,'',0,0,'C',0);
        $pdf->Ln(3);
        $pdf->SetFont('Times','B',8);
        $pdf->Cell(105,5,utf8_to_cp1252("Un effort s'impose en:"),0,0,'LC',0);
        $pdf->Cell(10,4,'',0,0,'C',0);
        $pdf->Ln();
        $pdf->SetFont('Times','I',6);
        $pdf->Cell(118,4,utf8_to_cp1252(''.$faibles_mat.''),0,0,'L',0);
        $pdf->SetFont('Times','B',10);
        /*FIN TOTAUX*/
                $faibles_mat="";
}

$pdf->Output('I', utf8_to_cp1252('Bulletin_Annuel_'.$refcls.'_'.$_SESSION['nom_std'].'.pdf'));
