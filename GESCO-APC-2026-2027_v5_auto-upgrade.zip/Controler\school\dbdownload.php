<?php
session_start();

// Sécurité : la sauvegarde de la base est réservée aux rôles autorisés sur la page operations.php
if (!isset($_SESSION['user']) || !in_array($_SESSION['user_role'] ?? '', array('admin', 'pcpl', 'sg', 'cs'))) {
    header('location: ../../index.php');
    exit;
}

// CORRECTION : validation stricte du nom de base (anti-injection dans le nom de base / en-tête)
$con_year = preg_replace('/[^a-zA-Z0-9_-]/', '', (string)($_SESSION['con_year'] ?? ''));

$mysqlUserName      = 'root';
$mysqlPassword      = '';
$mysqlHostName      = 'localhost';
$DbName             = 'gescoapc_' . $con_year;

Export_Database($mysqlHostName, $mysqlUserName, $mysqlPassword, $DbName, $tables = false, $backup_name = false);

function Export_Database($host, $user, $pass, $name, $tables = false, $backup_name = false)
{
    $mysqli = new mysqli($host, $user, $pass, $name);
    $mysqli->select_db($name);
    $mysqli->query("SET NAMES 'utf8'");

    $queryTables = $mysqli->query('SHOW TABLES');
    $target_tables = array();
    while ($row = $queryTables->fetch_row()) {
        $target_tables[] = $row[0];
    }

    if ($tables !== false) {
        $target_tables = array_intersect($target_tables, $tables);
    }

    $content = '';
    foreach ($target_tables as $table) {
        $result        = $mysqli->query('SELECT * FROM `' . $table . '`');
        $fields_amount = $result->field_count;
        $fields_col    = $result->fetch_fields();
        $rows_num      = $mysqli->affected_rows;
        $res           = $mysqli->query('SHOW CREATE TABLE `' . $table . '`');
        $TableMLine    = $res->fetch_row();

        $content .= "\n\n" . $TableMLine[1] . ";\n\n";

        for ($i = 0, $st_counter = 0; $i < $fields_amount; $i++, $st_counter = 0) {
            while ($row = $result->fetch_row()) {
                if ($st_counter % 500 == 0 || $st_counter == 0) {
                    $content .= "\nINSERT INTO `$table` (";
                    $i = 0;
                    foreach ($fields_col as $field) {
                        $i++;
                        if ($i < $fields_amount) {
                            $content .= "`" . $field->name . "`, ";
                        } else {
                            $content .= "`" . $field->name . "`";
                        }
                    }
                    $content .= ")  VALUES";
                }

                $content .= "\n(";
                $tab_tp_col = array();
                $ii = 0;
                foreach ($fields_col as $fieldi) {
                    $tab_tp_col[$ii] = $fieldi->type;
                    $ii++;
                }

                for ($j = 0; $j < $fields_amount; $j++) {
                    if (isset($row[$j])) {
                        $val = $row[$j];
                        if ($j == 0 || $tab_tp_col[$j] == "double" || $tab_tp_col[$j] == "float" || $tab_tp_col[$j] == "int") {
                            $content .= $row[$j];
                        } else {
                            // CORRECTION : échappement des guillemets et retours chariot pour un fichier SQL réimportable
                            $content .= '"' . $mysqli->real_escape_string($row[$j]) . '"';
                        }
                    } else {
                        $content .= 'NULL';
                    }
                    if ($j < ($fields_amount - 1)) {
                        $content .= ',';
                    }
                }
                $content .= ")";
                if ((($st_counter + 1) % 500 == 0 && $st_counter != 0) || $st_counter + 1 == $rows_num) {
                    $content .= ";";
                } else {
                    $content .= ",";
                }
                $st_counter = $st_counter + 1;
            }
        }
        $content .= "\n\n\n";
    }

    $now = date('HisdmY');
    // CORRECTION : nom de fichier construit sans caractère dangereux (anti header-injection)
    $backup_name = preg_replace('/[^a-zA-Z0-9_\-]/', '', $name) . (string)$now . '.sql';
    header('Content-Type: application/octet-stream');
    header("Content-Transfer-Encoding: Binary");
    header('Content-disposition: attachment; filename="' . $backup_name . '"');
    echo $content;
    exit;
}
?>