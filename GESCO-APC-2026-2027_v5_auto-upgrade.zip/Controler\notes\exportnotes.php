<?php  
session_start();
  require_once '../../Model/connexion.php';
  require_once '../../core/require.php';  
  $cls= htmlspecialchars($_GET['cls']);
  //$connect = mysqli_connect("localhost", "akrymo", "MJ.48FGMjXl0CQUj", "daler24");
  $etb->ShowEtb();
$output = '';
$prename= date("dmY");
/*if(isset($_POST["export"]))
{*/
 $query = 'SELECT * FROM eleves where ref_class="'.$cls.'" order by nom_prenom_std asc';

 $result = mysqli_query($connect, $query);
 if(mysqli_num_rows($result) > 0)
 {
  $output .= '
   <table class="table" border="1">
   <tr>  
        <td>Matricule</td>  
        <td>NomComplet_FullName</td>  
        <td>Notes_Marks</td> 
    </tr>
   
  ';
  while($row = mysqli_fetch_array($result))
  {
    $nom_cls=$class->ShowCls_namebyID($row['ref_class']);
  $nom=mb_strtoupper($row["nom_prenom_std"]);
  // Conversion ISO-8859-1 (équivalent non déprécié de utf8_decode)
  $nom=mb_convert_encoding($nom, 'ISO-8859-1', 'UTF-8');

   $output .= '
    <tr>  
        <td>'.$_SESSION['pre_matr'].''.$row["mat_std"].'</td>  
        <td>'.$nom.'</td>  
        <td></td> 
    </tr>
   ';
  }
  $output .= '</table>';
 header('Content-Type: application/XLSX');
  $file='Fiche_Note'.$nom_cls.''.$prename.'.xls';
  header('Content-Disposition: attachment; filename='.$file);
  //header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
  header('Content-Transfer-Encoding: binary');
  header('Cache-Control: max-age=0');
  
  echo $output;
 }
/*}*/
?>