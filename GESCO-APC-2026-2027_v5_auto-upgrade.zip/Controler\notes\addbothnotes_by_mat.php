<?php
	session_start();
	require_once '../../Model/connexion.php';
	require_once '../../core/require.php'; 	
	$ref_cls= htmlspecialchars($_POST['ref_cls']);
	$ref_mat= htmlspecialchars($_POST['ref_mat']);
	if (isset($_POST['ref_seq1']) and isset($_POST['ref_seq2'])) {
		$ev1="1";
		$ev2="2";
		# code...
	}
	elseif (isset($_POST['ref_seq3']) and isset($_POST['ref_seq4'])) {
		$ev1="3";
		$ev2="4";
		# code...
	}
	elseif (isset($_POST['ref_seq5']) and isset($_POST['ref_seq6'])) {
		$ev1="5";
		$ev2="6";
		# code...
	}
			
			$note1= array();
			$note2= array();

			$bdd = $GLOBALS['bdd'];	
			$reponse = $bdd->query('SELECT * FROM eleves where ref_class="'.$ref_cls.'"');
			while (($row = $reponse->fetch(PDO::FETCH_ASSOC))) 
			{
				$note1[''.$row['mat_std'].'']= htmlspecialchars($_POST['e'.$ev1.''.$row['mat_std'].'']);
			}

			$bdd = $GLOBALS['bdd'];	
			$reponse = $bdd->query('SELECT * FROM eleves where ref_class="'.$ref_cls.'"');
			while (($row = $reponse->fetch(PDO::FETCH_ASSOC))) 
			{
				$note2[''.$row['mat_std'].'']= htmlspecialchars($_POST['e'.$ev2.''.$row['mat_std'].'']);
			}


		
			foreach ($note1 as $key => $value) 
			{

				if ($value!="")
				{
					if ($class->CheckNoteStd_by_MatCls($ref_cls,$ref_mat,$ev1,$key)) {
						$coef=$opt->SelectCoef_by_MatCls($ref_cls,$ref_mat);
						$notei=(float)$value;
						if ($notei<0) {
						$notei=NULL;
						$ucoef=NULL;
						$note_x_coeff=NULL;
						$bdd = $GLOBALS['bdd'];	
						$req ='UPDATE table_note_par_mat_eval'.$ev1.' SET note= ?, coef= ?, note_x_coeff= ? where(ref_cls="'.$ref_cls.'" and ref_mat="'.$ref_mat.'" and ref_eval="'.$ev1.'" and ref_std="'.$key.'")';

						$rep = $bdd->prepare($req);
						$rep->execute(array($notei,$ucoef,$note_x_coeff));
							
						}
						else{
		
							$notei=(float)$value;
							$note_x_coeff=$notei*$coef;
							$note_x_coeff=(string)$note_x_coeff;
							$bdd = $GLOBALS['bdd'];	
							$req ='UPDATE  table_note_par_mat_eval'.$ev1.' SET note= ?, coef= ?, note_x_coeff= ? where(ref_cls="'.$ref_cls.'" and ref_mat="'.$ref_mat.'" and ref_eval="'.$ev1.'" and ref_std="'.$key.'")';

							$rep = $bdd->prepare($req);
							$rep->execute(array($value,$coef,$note_x_coeff));
						}
						}
					else
					{
						
						$coef=$opt->SelectCoef_by_MatCls($ref_cls,$ref_mat);
						$notei=(float)$value;
						$note_x_coeff=$notei*$coef;
						$note_x_coeff=(string)$note_x_coeff;
						$req = "INSERT INTO table_note_par_mat_eval".$ev1." (ref_mat, ref_cls, ref_std, ref_eval, note, coef, note_x_coeff) VALUES(?, ?, ?, ?, ?, ?, ?)" ;

						$rep = $bdd->prepare($req);
						if ($rep->execute(array($ref_mat, $ref_cls, $key, $ev1, $value,$coef,$note_x_coeff ))) {
						}
						else{
							echo "Erreur2";
						}
					}
				}
			}

			foreach ($note2 as $key => $value) 
			{

				if ($value!="")
				{
					if ($class->CheckNoteStd_by_MatCls($ref_cls,$ref_mat,$ev2,$key)) {
						$coef=$opt->SelectCoef_by_MatCls($ref_cls,$ref_mat);
						$notei=(float)$value;
						if ($notei<0) {
						$notei=NULL;
						$ucoef=NULL;
						$note_x_coeff=NULL;
						$bdd = $GLOBALS['bdd'];	
						$req ='UPDATE  table_note_par_mat_eval'.$ev2.' SET note= ?, coef= ?, note_x_coeff= ? where(ref_cls="'.$ref_cls.'" and ref_mat="'.$ref_mat.'" and ref_eval="'.$ev2.'" and ref_std="'.$key.'")';

						$rep = $bdd->prepare($req);
						$rep->execute(array($notei,$ucoef,$note_x_coeff));
							
						}
						else{
		
							$notei=(float)$value;
							$note_x_coeff=$notei*$coef;
							$note_x_coeff=(string)$note_x_coeff;
							$bdd = $GLOBALS['bdd'];	
							$req ='UPDATE  table_note_par_mat_eval'.$ev2.' SET note= ?, coef= ?, note_x_coeff= ? where(ref_cls="'.$ref_cls.'" and ref_mat="'.$ref_mat.'" and ref_eval="'.$ev2.'" and ref_std="'.$key.'")';

							$rep = $bdd->prepare($req);
							$rep->execute(array($value,$coef,$note_x_coeff));
						}
						}
					else
					{
						
						$coef=$opt->SelectCoef_by_MatCls($ref_cls,$ref_mat);
						$notei=(float)$value;
						$note_x_coeff=$notei*$coef;
						$note_x_coeff=(string)$note_x_coeff;
						$req = "INSERT INTO table_note_par_mat_eval".$ev2." (ref_mat, ref_cls, ref_std, ref_eval, note, coef, note_x_coeff) VALUES(?, ?, ?, ?, ?, ?, ?)" ;

						$rep = $bdd->prepare($req);
						if ($rep->execute(array($ref_mat, $ref_cls, $key, $ev2, $value,$coef,$note_x_coeff ))) {
						}
						else{
							echo "Erreur2";
						}
					}
				}
			}
			if (($_SESSION['user_role']!="admin") and ($_SESSION['user_role']!="cs") and ($_SESSION['user_role']!="pcpl")) 
		{
			header('location: ../../espace_notes.php'); 
		}else{
			header('location: ../../gestion_notes_by_mat.php');
		}
			
	
		
?>