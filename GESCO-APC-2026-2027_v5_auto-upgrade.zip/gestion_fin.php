<?php
    session_start();   
	require_once 'core/require.php'; 
	require_once 'Model/connexion.php';
     if (!isset($_SESSION['user'])) {
    session_unset();
    session_destroy();
    header('location: index.php');    
    }
    if (($_SESSION['user_role']!="admin") and ($_SESSION['user_role']!="pcpl") and ($_SESSION['user_role']!="caisse") ) 
    {

          header('location: poste_de_saisie.php?trim=t1');   
        }
      


    $dy=date('Y');
    $dm=date('m');
    $dd=date('d');
    $strmaxdate=''.$dy.'-'.$dm.'-'.$dd.'';
    $flashMessage = null;
    if (isset($_GET['ext'])) {
        $flashMessage = 'Une pension est déjà créée pour ce niveau.';
    } elseif (isset($_GET['ep'])) {
        $flashMessage = 'Pension soldée ou montant en excès.';
    } elseif (isset($_GET['f'])) {
        $flashMessage = 'Erreur : vérifiez les paramètres de configuration de scolarité du niveau.';
    }
    $etb->ShowEtb();
    $etb->CkLE();
    $etb->ckexneE();
    $nbps=$fin->NombrePensions();

    // Filtre périodique de l'historique des versements
    $prdOptions = array(
        '30'     => '30 derniers',
        'today'  => "Aujourd'hui",
        'week'   => 'Cette semaine',
        'month'  => 'Ce mois',
        'custom' => 'Personnalisée',
        'all'    => 'Toute'
    );
    $curPrd = (isset($_GET['prd']) && array_key_exists($_GET['prd'], $prdOptions)) ? $_GET['prd'] : '30';
    $prd0 = isset($_GET['prd0']) ? $_GET['prd0'] : '';
    $prd1 = isset($_GET['prd1']) ? $_GET['prd1'] : '';

    // Statistiques globales de la finance
    $fstats = $fin->GetFinanceStats();
    if (!function_exists('finStatCard')) {
        function finStatCard($icon, $label, $value, $color = 'primary') {
            return '<div class="col-6 col-md-4 col-xl-3 mb-3">'
                .'<div class="card h-100 fin-stat border-0">'
                .'<div class="card-body d-flex align-items-center gap-3 p-3">'
                .'<span class="fin-stat-icon bg-'.$color.'-subtle text-'.$color.'"><i class="fa '.$icon.'"></i></span>'
                .'<span class="min-w-0">'
                .'<span class="fin-stat-value d-block">'.$value.'</span>'
                .'<span class="fin-stat-label text-muted">'.$label.'</span>'
                .'</span>'
                .'</div></div></div>';
        }
    }
    $fcfa = function ($n) { return number_format((float)$n, 0, ',', ' '); };
?>
<!DOCTYPE html>
<html>
  <head>
   <?php Config::head(); ?>
    <title>GESCOAPC| FINANCE</title>
    <style>
        .dropdown-menu.w-100,
        .dropmenu.w-100 {
            width: 100% !important;
            max-height: 360px;
            overflow-y: auto;
        }
        /* Assure que l'input et le séparateur restent visibles */
        .dropdown-header-area {
             display: block !important;
             position: sticky;
             top: 0;
             z-index: 5;
             background-color: var(--bg-card);
        }
        .white-box {
            background-color: var(--bg-card);
            border: 1px solid var(--border-color);
            border-radius: 8px;
            padding: 16px;
        }
        .white-box .box-title {
            font-weight: 700;
            color: var(--primary-color);
            font-size: 1.05rem;
        }
        .accordion-button h3 { font-size: 1.05rem; }
        .fin-stat { transition: transform .18s ease, box-shadow .18s ease; }
        .fin-stat:hover { transform: translateY(-3px); box-shadow: 0 10px 24px rgba(15,23,42,.12); }
        .fin-stat-icon {
            width: 46px; height: 46px; min-width: 46px;
            display: inline-flex; align-items: center; justify-content: center;
            border-radius: 12px; font-size: 1.15rem;
        }
        .fin-stat-value { font-size: 1.15rem; font-weight: 700; line-height: 1.1; }
        .fin-stat-label { font-size: .76rem; text-transform: uppercase; letter-spacing: .03em; }
        .fin-mini {
            display: flex; align-items: center; gap: .6rem;
            padding: .65rem .9rem; border-radius: 10px; height: 100%;
            border: 1px solid var(--border-color); background: var(--bg-card);
        }
        .fin-mini i { font-size: 1.1rem; }
        .fin-mini .v { font-weight: 700; line-height: 1; }
        .fin-mini .t { font-size: .72rem; color: var(--text-muted, #6c757d); }
        .min-w-0 { min-width: 0; }
        .vsm-modal-header {
            background: linear-gradient(135deg, #1e3a8a 0%, #2563eb 100%);
            border-bottom: 0;
        }
        .vsm-avatar {
            width: 42px; height: 42px; min-width: 42px;
            display: inline-flex; align-items: center; justify-content: center;
            border-radius: 50%; font-size: 1.1rem;
            background: rgba(255,255,255,.18);
        }
        .vsm-section-title {
            font-size: .8rem; font-weight: 700; text-transform: uppercase;
            letter-spacing: .04em; color: #1e3a8a;
            padding-bottom: .4rem; border-bottom: 1px solid var(--border-color);
            margin-bottom: .8rem;
        }
        .vsm-info-card {
            border: 1px solid var(--border-color); border-radius: 12px;
            padding: 1rem; background: var(--bg-card);
        }
        .vsm-list { list-style: none; margin: 0; padding: 0; }
        .vsm-list li {
            display: flex; justify-content: space-between; gap: 1rem;
            padding: .35rem 0; border-bottom: 1px dashed var(--border-color);
        }
        .vsm-list li:last-child { border-bottom: 0; }
        .vsm-list li span { color: var(--text-muted, #6c757d); font-size: .85rem; }
        .vsm-list li b { text-align: right; }
        .vsm-tile {
            border-radius: 10px; padding: .6rem .7rem; height: 100%;
            display: flex; flex-direction: column; gap: .15rem;
            color: #fff;
        }
        .vsm-tile span { font-size: .72rem; opacity: .85; text-transform: uppercase; letter-spacing: .03em; }
        .vsm-tile b { font-size: 1rem; line-height: 1.1; }
        .tile-primary { background: linear-gradient(135deg, #1e40af, #3b82f6); }
        .tile-success { background: linear-gradient(135deg, #15803d, #22c55e); }
        .tile-warning { background: linear-gradient(135deg, #b45309, #f59e0b); }
        .tile-danger  { background: linear-gradient(135deg, #b91c1c, #ef4444); }
        .vsm-print-check {
            border: 1px dashed var(--border-color); border-radius: 10px;
            padding: .65rem .9rem .65rem 2.4rem;
        }
    </style>
  </head>

<body>
    <?php if (!empty($flashMessage)) Config::toast($flashMessage, 'warning'); ?>
    <div class="wrapper">
      <!-- Sidebar -->

      <!-- Inclusion du menu de navigation externe réutilisable -->
      <?php include 'core/sidebar.php'; ?>  

<div class="main-content-wrapper">
        <!-- Barre supérieure de navigation adaptative -->
        <div class="mobile-navbar-fixed p-3 mb-4 rounded shadow-sm border">
            <div class="row align-items-center g-2">
                <div class="col-auto d-md-none">
                    <button class="btn btn-outline-dark btn-sm" id="toggleMobileMenu"><i class="fa fa-bars fa-lg"></i></button>
                </div>
                <div class="col-12 col-md-4">
                    <h4 class="m-0 fw-bold text-primary text-uppercase">Gestion des finances</h4>
                </div>
                <div class="col-12 col-md-4">
                    <label class="small fw-bold text-secondary mb-1">VERSEMENT ELEVE EXISTANT(E)</label>
                    <div class="dropdown w-100">
                        <button class="btn btn-outline-secondary dropdown-toggle w-100 text-start btn-sm" type="button" id="dropdownMenuButton" data-bs-toggle="dropdown" aria-expanded="false">
                            Recherche nom ou matricule
                        </button>
                        <ul class="dropdown-menu w-100" aria-labelledby="dropdownMenuButton">
                            <li class="px-2 pb-2 dropdown-header-area">
                                <input type="text" id="searchInput" class="form-control" placeholder="Rechercher...">
                            </li>
                            <li class="dropdown-header-area"><hr class="dropdown-divider"></li>
                            <?php $fin->ShowSearchLisStd_Ps(); ?>
                        </ul>
                    </div>
                </div>
                <div class="col-12 col-md-4 d-flex justify-content-md-end">
                    <button type="button" class="btn btn-primary btn-sm" data-bs-toggle="modal" data-bs-target="#addstd" data-whatever="@mdo">Versement par ajout <i class="fa fa-add"></i></button>
                </div>
            </div>
        </div>
      <!-- End Sidebar -->
          
    <div class="container-fluid pt-3 mt-2">
                 
                <!-- ===== STATISTIQUES GLOBALES ===== -->
                <div class="row mt-5 pt-5 mb-2">
                    <?= finStatCard('fa-users', 'Élèves inscrits', $fcfa($fstats['eleves']), 'primary') ?>
                    <?= finStatCard('fa-school', 'Classes', $fcfa($fstats['classes']), 'info') ?>
                    <?= finStatCard('fa-money-bill-wave', 'Total versé (FCFA)', $fcfa($fstats['verse']), 'success') ?>
                    <?= finStatCard('fa-percent', 'Remises (FCFA)', $fcfa($fstats['remise']), 'warning') ?>
                    <?= finStatCard('fa-file-invoice-dollar', 'Pension attendue (FCFA)', $fcfa($fstats['attendu']), 'secondary') ?>
                    <?= finStatCard('fa-hand-holding-dollar', 'Reste à recouvrer (FCFA)', $fcfa($fstats['reste']), 'danger') ?>
                    <?= finStatCard('fa-coins', "Versements aujourd'hui", $fcfa($fstats['nb_today']).' / '.$fcfa($fstats['mt_today']).' F', 'primary') ?>
                    <?= finStatCard('fa-chart-line', 'Ce mois (nb / montant)', $fcfa($fstats['nb_month']).' / '.$fcfa($fstats['mt_month']).' F', 'success') ?>
                </div>

                <div class="row mt-4">

                    <div class="accordion mt-4" id="accordionExample">
                          
                          <div class="accordion-item mt-5 ">
                            <h2 class="accordion-header">
                              <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
                               <h3 class="fw-bolder" > <i class="fa fa-arrow-right"></i> IMPRIMER LES ETATS DE PAIEMENTS PAR CLASSE </h3>
                              </button>
                            </h2>
                            <div id="collapseTwo" class="accordion-collapse collapse " data-bs-parent="#accordionExample">
                              <div class="accordion-body">
                                <!-- ===== SYNTHÈSE PÉRIODIQUE (avant impression) ===== -->
                                <div class="row g-2 mb-3">
                                    <div class="col-12 col-md-4">
                                        <div class="fin-mini">
                                            <i class="fa fa-calendar-day text-primary"></i>
                                            <div>
                                                <div class="v"><?= $fcfa($fstats['nb_today']) ?> versement(s)</div>
                                                <div class="t">Aujourd'hui • <?= $fcfa($fstats['mt_today']) ?> FCFA</div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-12 col-md-4">
                                        <div class="fin-mini">
                                            <i class="fa fa-calendar-week text-info"></i>
                                            <div>
                                                <div class="v"><?= $fcfa($fstats['nb_week']) ?> versement(s)</div>
                                                <div class="t">Cette semaine • <?= $fcfa($fstats['mt_week']) ?> FCFA</div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-12 col-md-4">
                                        <div class="fin-mini">
                                            <i class="fa fa-calendar-days text-success"></i>
                                            <div>
                                                <div class="v"><?= $fcfa($fstats['nb_month']) ?> versement(s)</div>
                                                <div class="t">Ce mois • <?= $fcfa($fstats['mt_month']) ?> FCFA</div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <form action="fpdf185/etatpaybycls.php" method="GET" enctype=multipart/form-data>
                                    <div class="row">
                                        <div class=" col-10 col-sm-8">
                                            <label for="exampleInputEmail1" class="form-label">Classe:</label>
                                            <select id="inputState" class="form-control" name="refcls" required>
                                              <option value="" >Choisir...</option>
                                           <?php  $std-> SelectClassesNames(); ?>
                                           </select>
                                        </div>
                          
                                        <div class="col-10 col-sm-4">
                                            <label for="exampleInputEmail1" class="form-label">Opération</label>
                                            <button class="btn btn-primary" type="submit">Imprimer</button>
                                        </div>
                                    </div>
                                </form>
                            </div>
                          </div>
                         <?php if ($_SESSION['user_role']=="admin" or $_SESSION['user_role']=="dir") {
                              echo ' <div class="accordion-item">
                            <h2 class="accordion-header">
                              <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
                               <h3 class="fw-bolder" ><i class="fa fa-arrow-right"></i>- PARAMETRE DE SCOLARITE PAR NIVEAU</h3>
                              </button>
                            </h2>
                            <div id="collapseThree" class="accordion-collapse collapse" data-bs-parent="#accordionExample">
                              <div class="accordion-body">
                                <strong>Configuration de la scolarité</strong>
                                <div class="row">
                                  <div class="col-md-12 col-lg-12 col-sm-12">
                                      <div class="white-box">
                                          <h3 class="box-title">Total Niveaux > ( ' . $nbps . ' ) <button type="button" class="btn btn-primary ms-2" data-bs-toggle="modal" data-bs-target="#addclasse" data-whatever="@mdo">Ajouter une Pension</button></h3>
                                          <div class="table-responsive table-sm">
                                              <table class="table">
                                                  <thead>
                                                      <tr>
                                                          <th>#</th>
                                                          <th>NIVEAU</th>
                                                          <th>SECTION</th>
                                                          <th>MONTANT</th>
                                                          <th>P. BULLETIN</th>
                                                          <th>MODIFIER</th>
                                                          <th>SUPPRIMER</th>
                                                      </tr>
                                                  </thead>
                                                  <tbody class="table-hover">';?>
                                                      <?php  $fin-> ShowAllPensions(); 
                                                      echo '
                                                      

                                                  
                                                  </tbody>
                                              </table>
                                          </div>
                                      </div>
                                  </div>
                                </div>                                    
                              </div>
                            </div>
                         
                          </div>
                              ';
                         } ?> 
                         

                          <div class="accordion-item">
                            <h2 class="accordion-header">
                              <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseFour" aria-expanded="false" aria-controls="collapseFour">
                               <h3 class="fw-bolder" ><i class="fa fa-arrow-right"></i> HISTORIQUE DES VERSEMENTS</h3>
                              </button>
                            </h2>
                            <div id="collapseFour" class="accordion-collapse collapse" data-bs-parent="#accordionExample">
                              <div class="accordion-body">
                                <strong>Historique des derniers versements</strong>
                                <form method="GET" action="gestion_fin.php" class="row g-2 align-items-end mt-3 mb-3">
                                    <div class="col-12 col-sm-6 col-md-3">
                                        <label for="prdFilter" class="form-label mb-1">Période</label>
                                        <select class="form-select" id="prdFilter" name="prd">
                                            <?php foreach ($prdOptions as $val => $lbl): ?>
                                                <option value="<?= htmlspecialchars($val) ?>" <?= $curPrd === $val ? 'selected' : '' ?>><?= htmlspecialchars($lbl) ?></option>
                                            <?php endforeach; ?>
                                        </select>
                                    </div>
                                    <div class="col-6 col-sm-3 col-md-2 prd-custom" style="display:none">
                                        <label for="prd0" class="form-label mb-1">Du</label>
                                        <input type="date" class="form-control" id="prd0" name="prd0" value="<?= htmlspecialchars($prd0) ?>">
                                    </div>
                                    <div class="col-6 col-sm-3 col-md-2 prd-custom" style="display:none">
                                        <label for="prd1" class="form-label mb-1">Au</label>
                                        <input type="date" class="form-control" id="prd1" name="prd1" value="<?= htmlspecialchars($prd1) ?>" max="<?= htmlspecialchars($strmaxdate) ?>">
                                    </div>
                                    <div class="col-12 col-sm-6 col-md-3 d-flex gap-2">
                                        <button type="submit" class="btn btn-primary flex-grow-1"><i class="fa fa-filter me-1"></i>Filtrer</button>
                                        <a href="gestion_fin.php" class="btn btn-outline-secondary" title="Réinitialiser"><i class="fa fa-rotate-left"></i></a>
                                    </div>
                                    <div class="col-12 col-sm-6 col-md-3">
                                        <button type="submit" class="btn btn-danger w-100" formaction="fpdf185/allvsm.php" formmethod="post" formtarget="_blank"><i class="fa fa-file-pdf me-1"></i>Imprimer PDF</button>
                                    </div>
                                </form>
                                
                                <div class="row">
                                  <div class="col-md-12 col-lg-12 col-sm-12">
                                      <div class="white-box">
                                            <div class="container mt-2" style="max-width: 100%;">
                                  <div class="dropdown w-100">
                                      <button class="btn btn-outline-secondary dropdown-toggle w-100 text-start" type="button" id="dropdownMenuButton2" data-bs-toggle="dropdown" aria-expanded="false">
                                          Recherche nom ou matricule
                                      </button>

                                      <ul class="dropdown-menu dropmenu w-100" aria-labelledby="dropdownMenuButton2">
                                          <!-- Section toujours visible (header) -->
                                          <li class="px-2 pb-2 dropdown-header-area">
                                              <input type="text" id="searchInput2" class="form-control" placeholder="Rechercher...">
                                          </li>
                                          <li class="dropdown-header-area"><hr class="dropdown-divider"></li>

                                          <!-- Liste des élèves - AJOUT DE LA CLASSE D-NONE INITIALE -->

                                          <?php  $fin-> ShowSearchLisStd_Vs($curPrd, $prd0, $prd1); ?>
                                          <!-- <li><a class="dropdown-item d-none" href="#">Jean Dupont</a></li> -->
                                          
                                      </ul>
                                  </div>
    </div>
                                          
                                          <div class="table-responsive table-sm mt-5">
                                              <table class="table">
                                                  <thead>
                                                      <tr>
                                                          <th>#</th>
                                                          <th>Matricule</th>
                                                          <th>Noms</th>
                                                          <th>Versements</th>
                                                          <th>Remises</th>
                                                          <th>Date</th>
                                                          <th>Reçus</th>
                                                          <th>Annuler</th>
                                                      </tr>
                                                  </thead>
                                                  <tbody class="table-hover">
                                            
                                                      <?php  $fin-> ShowAllVsmt($curPrd, $prd0, $prd1); ?>
                                                                                              
                                                  </tbody>
                                              </table>
                                          </div>
                                      </div>
                                  </div>
                                </div>                                    
                                </div>
                              </div>
                         
                          </div>



                          <div class="accordion-item">
                            <h2 class="accordion-header">
                              <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseFive" aria-expanded="false" aria-controls="collapseFive">
                               <h3 class="fw-bolder" ><i class="fa fa-arrow-right"></i> ETAT GENERAL DE PAIEMENTS </h3>
                              </button>
                            </h2>
                            <div id="collapseFive" class="accordion-collapse collapse" data-bs-parent="#accordionExample">
                              <div class="accordion-body">
                                <strong>Consulter les etats pour toutes les classes.</strong>
                                <form action="fpdf185/etatpay.php" method="GET" enctype=multipart/form-data>
                                    <div class="row">
                          
                                        <div class="col-10 col-sm-4">
                                            <label for="exampleInputEmail1" class="form-label">Opération</label>
                                            <button class="btn btn-primary" type="submit">Imprimer</button>
                                        </div>
                                    </div>
                                </form>                                    
                              </div>
                            </div>
                         
                          </div>
                      </div>
                <!-- ============================================================== -->
                <div class="row">

                   <div class="modal fade" id="hisvers" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                      <div class="modal-dialog modal-lg" role="document">
                        <div class="modal-content " >
                          <div class="modal-header">
                            <h4 class="modal-title" id="exampleModalLabel"> HISTORIQUE DES VERSEMENTS </h4>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Fermer"></button>
                          </div>
                          <div class="modal-body" style=""> 
                           <div class="container-fluid">
                            <div class="row">
                                  <div class="col-md-12 mx-2">
                                    <form action="fpdf185/allvsm.php" method="post" >                       
                                      <label for="inputState">PERIODE:</label>
                                      <select id="prd" class="form-control" name="prd"  required="true">
                                      <option selected value="">Choisir...</option>
                                      <option value="0">Aujourd'hui</option>
                                      <option value="pr">Personnalisée</option>
                                      <option value="all">Toute</option>
                                      </select>
                                    </div> 

                                     <div id="p0" class="col-md-6 my-2 " style="display: none">
                                      <label for="inputState">Du :</label>
                                      <input type="date" name="prd0" style="font-size: 1.2em"  >
                                      </div>
                                      <div id="p1" class="col-md-6 my-2 " style="display: none">
                                      <label for="inputState">Au :</label>
                                      <input type="date" name="prd1" max='<?php echo $strmaxdate; ?>' style="font-size: 1.2em"   >
                                      </div> 
                                     </div>
                              </div>
                              </div>
                              <div class="modal-footer" >  
                                <div class="row text-start mx-2"> 
                                    <button type="submit" class="btn btn-primary">Enrégistrer</button>
                                  </div>
                                   <div class="row text-end mx-2">
                                    <button type="button" class="btn btn-danger" data-bs-dismiss="modal">Annuler</button>
                                  </div>
                                  </form>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                  </div>
       

                    <div class="modal fade" id="addclasse" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                      <div class="modal-dialog modal-lg" role="document">
                        <div class="modal-content">
                          <div class="modal-header">
                            <h5 class="modal-title" id="exampleModalLabel">Ajouter une Pension</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Fermer"></button>
                          </div>
                          <div class="modal-body">
                             <div class="container-fluid">
                              <form action="Controler/finances/pensions/addps.php" method="post" >                        
                                    <div class="row">
                                        
                                        <div class="col-md-6 ">
                                            <label for="inputState">Niveau: </label>
                                             <select id="inputState" class="form-control" name="ref_n" required>
                                                <option >Choisir...</option>
                                                <?php  $class-> SelectNiveauCls(); ?>
                                                
                                            
                                            </select>
                                        </div>
                                        <div class="col-md-6">
                                            <label for="inputState">Section: </label>
                                            <select id="inputState" class="form-control" name="ref_s"  required="true" required>
                                                <option >Choisir...</option>
                                                 <?php  $class-> SelectSessCls(); ?>
                                        
                                                
                                            </select>
                                        </div>
                                        <div class="col-md-6 ">                                            
                                            <label for="inputEmail4">Montant: </label>
                                            <input type="number" class="form-control" id="prix" name="prix" placeholder="en FCFA"   required>
                                        </div>
                                        <div class="col-md-6 ">                                            
                                            <label for="inputEmail4">Pension Bulletin: </label>
                                            <input type="number" class="form-control" id="ps_bull" name="ps_bull" placeholder="marge minimun pour avoir le Bulletin"   required>
                                        </div>
                                    </div>
                                   <button type="submit" class="btn btn-primary mt-3">Enrégistrer</button>
                                    </form>
                                    </div>
                                </div>
                                <div class="modal-footer">
                                        
                                     
                                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Annuler</button>
                              </div>
                        </div>
                      </div>
                  </div>


                  <div class="modal fade" id="addstd" tabindex="-1" aria-labelledby="addstdLabel" aria-hidden="true">
                    <div class="modal-dialog modal-lg modal-dialog-centered modal-dialog-scrollable">
                      <div class="modal-content border-0 shadow">
                        <div class="modal-header vsm-modal-header text-white">
                          <div class="d-flex align-items-center gap-2">
                            <span class="vsm-avatar"><i class="fa fa-user-plus"></i></span>
                            <div>
                              <h5 class="modal-title mb-0" id="addstdLabel">Versement par ajout</h5>
                              <small class="opacity-75">Inscrire un nouvel élève et enregistrer son versement</small>
                            </div>
                          </div>
                          <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Fermer"></button>
                        </div>
                        <div class="modal-body">
                          <form action="Controler/finances/vsmts/addvsm_std.php" method="post">
                            <h6 class="vsm-section-title"><i class="fa fa-id-card me-1"></i>Identification</h6>
                            <div class="row g-3">
                              <div class="col-md-12">
                                <label class="form-label" for="classe_std">Classe (Pension)</label>
                                <select id="classe_std" class="form-select" name="classe_std" required>
                                  <option value="">Choisir...</option>
                                  <?php  $fin-> SelectClassesNames_Ps(); ?>
                                </select>
                              </div>
                              <div class="col-md-8">
                                <label class="form-label" for="nom_std">Nom</label>
                                <input type="text" class="form-control text-uppercase" id="nom_std" name="nom_std" maxlength="50" required>
                              </div>
                              <div class="col-md-4">
                                <label class="form-label" for="prenom_std">Prénom</label>
                                <input type="text" class="form-control text-uppercase" id="prenom_std" name="prenom_std" maxlength="50">
                              </div>
                              <div class="col-md-4">
                                <label class="form-label" for="sexe_std">Sexe</label>
                                <select id="sexe_std" class="form-select" name="sexe" required>
                                  <option value="M">Masculin</option>
                                  <option value="F">Féminin</option>
                                </select>
                              </div>
                              <div class="col-md-4">
                                <label class="form-label" for="date_naiss_std">Date de naissance</label>
                                <input type="date" class="form-control" id="date_naiss_std" name="date_naiss_std" required>
                              </div>
                              <div class="col-md-4">
                                <label class="form-label" for="lieu_naiss_std">Lieu de naissance</label>
                                <input type="text" class="form-control text-uppercase" id="lieu_naiss_std" name="lieu_naiss_std" maxlength="50" required>
                              </div>
                            </div>

                            <h6 class="vsm-section-title mt-4"><i class="fa fa-money-bill-transfer me-1"></i>Paiement</h6>
                            <div class="row g-3 align-items-end">
                              <div class="col-md-4">
                                <label class="form-label" for="val_remise_add">Remise (FCFA)</label>
                                <input type="number" min="0" class="form-control" id="val_remise_add" name="val_remise" placeholder="0 si aucune">
                                <div class="form-text">Laisser vide si pas de remise.</div>
                              </div>
                              <div class="col-md-4">
                                <label class="form-label" for="vsm_std_add">Montant à verser (FCFA)</label>
                                <input type="number" min="0" class="form-control" id="vsm_std_add" name="vsm_std" required>
                              </div>
                              <div class="col-md-4">
                                <div class="form-check vsm-print-check">
                                  <input type="checkbox" class="form-check-input" id="print_add" name="print" value="oui">
                                  <label class="form-check-label" for="print_add">Imprimer le reçu</label>
                                </div>
                              </div>
                            </div>

                            <div class="d-flex justify-content-end gap-2 mt-4">
                              <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Annuler</button>
                              <button type="submit" class="btn btn-primary"><i class="fa fa-save me-1"></i>Enrégistrer</button>
                            </div>
                          </form>
                        </div>
                      </div>
                    </div>
                  </div>

                       <?php  $fin-> Show_modal_vsm(); ?>
                       <?php  $fin-> Show_modal_vsm_del(); ?>
                
            </div>
     
        </div>
       
    </div>


		<?php 
		 	Config::scriptJs();
		?>
    <script type="text/javascript">
            /* When the user clicks on the button,
toggle between hiding and showing the dropdown content */
function myFunction() {
  document.getElementById("myDropdown").classList.toggle("show");
}

function filterFunction() {
  var input, filter, ul, li, a, i;
  input = document.getElementById("myInput");
  filter = input.value.toUpperCase();
  div = document.getElementById("myDropdown");
  a = div.getElementsByTagName("a");
  for (i = 0; i < a.length; i++) {
    txtValue = a[i].textContent || a[i].innerText;
    if (txtValue.toUpperCase().indexOf(filter) > -1) {
      a[i].style.display = "";
    } else {
      a[i].style.display = "none";
    }
  }
}
        </script>

<script>
        $(document).ready(function() {
            var items = $('.dropdown-item');

            $('#searchInput').on('keyup', function() {
                var searchText = $(this).val().toLowerCase();

                if (searchText.length > 0) {
                    // Si l'utilisateur a saisi du texte, on filtre
                    items.each(function() {
                        var itemText = $(this).text().toLowerCase();
                        if (itemText.includes(searchText)) {
                            $(this).removeClass('d-none');
                        } else {
                            $(this).addClass('d-none');
                        }
                    });
                } else {
                    // Si la barre de recherche est vide, on cache tout à nouveau
                    items.addClass('d-none');
                }
            });

            // Empêche la fermeture du dropdown lorsqu'on clique dans le champ de recherche
            $('.dropdown-menu').on('click', function(e) {
                if ($(e.target).is('#searchInput') || $(e.target).closest('li').hasClass('dropdown-header-area')) {
                    e.stopPropagation();
                }
            });

            // Mettre à jour le texte du bouton lorsque l'on sélectionne un élément
            $('.dropdown-item').on('click', function(e) {
                e.preventDefault();
                var selectedText = $(this).text();
                $('#dropdownMenuButton').text(selectedText);
                // Optionnel: Cacher de nouveau la liste après sélection si vous le souhaitez
                // items.addClass('d-none'); 
            });
        });
    </script>

    <script>
        $(document).ready(function() {
            var items = $('.dropitem2');

            $('#searchInput2').on('keyup', function() {
                var searchText = $(this).val().toLowerCase();

                if (searchText.length > 0) {
                    // Si l'utilisateur a saisi du texte, on filtre
                    items.each(function() {
                        var itemText = $(this).text().toLowerCase();
                        if (itemText.includes(searchText)) {
                            $(this).removeClass('d-none');
                        } else {
                            $(this).addClass('d-none');
                        }
                    });
                } else {
                    // Si la barre de recherche est vide, on cache tout à nouveau
                    items.addClass('d-none');
                }
            });

            // Empêche la fermeture du dropdown lorsqu'on clique dans le champ de recherche
            $('.dropmenu').on('click', function(e) {
                if ($(e.target).is('#searchInput2') || $(e.target).closest('li').hasClass('dropdown-header-area')) {
                    e.stopPropagation();
                }
            });

            // Mettre à jour le texte du bouton lorsque l'on sélectionne un élément
            $('.dropitem2').on('click', function(e) {
                if ($(e.target).closest('a, button').length) { return; }
                var selectedText = $(this).find('.fw-bold').text();
                $('#dropdownMenuButton2').text(selectedText);
            });
        });
    </script>
        <script type="text/javascript">

            
            $(document).ready(function(){
                $('#toast').toast('show');
    
            });
            //$('#element').toast('show');
            $("#reduc").on('click', function(){
           var taux = $("#reduc").val();

           if (taux=="oui") {
            $('#taux').css('display', 'block');
           }
           else{
            $('#taux').css('display', 'none');
           }
          });

             $(".reduc1").on('click', function(){
           var taux = $("#reduc1").val();
           $('#taux1').css('display', 'none');

           if (taux=="oui") {
            $('.taux1').css('display', 'block');
           }
           else{
            $('.taux1').css('display', 'none');
           }
          });

             $("#prd").on('click', function(){
                var prd = $("#prd").val();

           if (prd=='0' || prd=='' || prd=='all') {
            $('#p0').css('display', 'none');
            $('#p1').css('display', 'none');
           }
           else{
           $('#p0').css('display', 'block');
            $('#p1').css('display', 'block');
           }
          });

            
        </script>
        <script>
            (function () {
                var sel = document.getElementById('prdFilter');
                if (!sel) { return; }
                function toggleCustom() {
                    var show = sel.value === 'custom';
                    document.querySelectorAll('.prd-custom').forEach(function (el) {
                        el.style.display = show ? '' : 'none';
                    });
                }
                sel.addEventListener('change', toggleCustom);
                toggleCustom();
            })();
        </script>
	</body>
</html>
