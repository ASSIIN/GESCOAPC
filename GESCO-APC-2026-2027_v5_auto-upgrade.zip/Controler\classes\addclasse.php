<?php
session_start();
// Désactivation des affichages d'erreurs brutes pour éviter de casser les redirections
ini_set('display_errors', 0);
error_reporting(0);

require_once '../../Model/connexion.php';
require_once '../../core/require.php'; 	

$bdd = $GLOBALS['bdd'];

if (isset($_POST['nom_class']) && !empty($_POST['nom_class'])) {
    
    $nom_classe = htmlspecialchars($_POST['nom_class']);
    $niveau = htmlspecialchars($_POST['niveau']);
    $session = htmlspecialchars($_POST['session']);
    $model_class = htmlspecialchars($_POST['model_class'] ?? '');
    
    $codeswift = "";
 
    // RESTAURATION : Génération du code de classe aléatoire unique de 5 caractères
    $password1 = str_shuffle('0123456789');
    $pass1 = substr($password1, 0, 10);
    $chaine1 = str_shuffle($nom_classe);
    $pass1 .= $chaine1;
    $pass2 = substr($pass1, 0, 5);
    $codeswift .= $pass2;
    $codeswift = strtoupper($codeswift); 

    // Sécurité anti-doublon : on boucle tant que le code existe déjà
    while ($class->CkExistingCode($codeswift)) {
        $password1 = str_shuffle('0123456789');
        $pass1 = substr($password1, 0, 10);
        $chaine1 = str_shuffle($nom_classe);
        $pass1 .= $chaine1;
        $pass2 = substr($pass1, 0, 5);
        $codeswift = strtoupper($pass2);
    }
         
    if (isset($codeswift) && !empty($codeswift)) {
        
        $nom_classe = mb_strtoupper($nom_classe, 'UTF-8');

        // Hydratation de la classe MyClasses
        $class->setNom_class($nom_classe);
        $class->setRef_class_niveau($niveau);
        $class->setClass_session($session);
        $class->setCode_class($codeswift);

        // Création de la classe + copie optionnelle de la configuration modèle dans une transaction unique
        $bdd->beginTransaction();

        try {
            if (!$class->AddClasses()) {
                throw new Exception("echec_insert");
            }

            // Mise à jour du compteur de classes de la session
            $nbCls = $class->ReturnNvCls_by_Sess($session);
            $req = $bdd->prepare('UPDATE sess SET nb_class_par_sess = ? WHERE abr_sess = ?');
            $req->execute(array($nbCls, $session));

            // Copie de la configuration d'une classe modèle (matières + compétences)
            if (!empty($model_class) && $model_class != $codeswift) {
                $stmt_src = $bdd->prepare('SELECT ref_mat, nom_mat, coeff_mat, group_mat, ref_ens, ref_niveau_class FROM config_bull WHERE ref_class = ?');
                $stmt_src->execute(array($model_class));
                $ins = $bdd->prepare('INSERT INTO config_bull (ref_class, ref_mat, nom_mat, coeff_mat, group_mat, ref_ens, ref_niveau_class) VALUES (?, ?, ?, ?, ?, ?, ?)');
                while ($cfg = $stmt_src->fetch(PDO::FETCH_ASSOC)) {
                    $ins->execute(array($codeswift, $cfg['ref_mat'], $cfg['nom_mat'], $cfg['coeff_mat'], $cfg['group_mat'], $cfg['ref_ens'], $cfg['ref_niveau_class']));
                }

                $stmt_comp = $bdd->prepare('SELECT ref_mat, num_compt, nom_compt FROM competences_matieres WHERE ref_class = ?');
                $stmt_comp->execute(array($model_class));
                $insc = $bdd->prepare('INSERT INTO competences_matieres (ref_class, ref_mat, num_compt, nom_compt) VALUES (?, ?, ?, ?)');
                while ($cmp = $stmt_comp->fetch(PDO::FETCH_ASSOC)) {
                    $insc->execute(array($codeswift, $cmp['ref_mat'], $cmp['num_compt'], $cmp['nom_compt']));
                }
            }

            $bdd->commit();
            header('location: ../../menu_classes.php?success=1');
            exit();
        } catch (Exception $e) {
            $bdd->rollBack();
            echo "Erreur lors de l'insertion de la nouvelle classe.";
        }
    } else {
        echo "Erreur lors de la génération du code de sécurité de la classe.";
    }
} else {
    header('location: ../../menu_classes.php');
    exit();
}
?>
