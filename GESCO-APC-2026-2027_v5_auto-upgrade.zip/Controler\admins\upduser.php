<?php
	session_start();
	require_once '../../Model/connexion.php';
	require_once '../../core/require.php'; 

	// Sécurité : seuls les rôles admin, pcpl et cs sont autorisés à modifier un compte
	if (!isset($_SESSION['user']) || !in_array($_SESSION['user_role'], array('admin', 'pcpl', 'cs'))) {
		header('location: ../../index.php');
		exit;
	}

	$id=htmlspecialchars($_POST['iduser']);
	$user_civ= htmlspecialchars($_POST['user_civ']);
	$user_role= htmlspecialchars($_POST['user_role']);
	$user_name= htmlspecialchars($_POST['user_name']);
	$pass= htmlspecialchars($_POST['pass']);
	$tel= htmlspecialchars($_POST['user_tel']);
	$master_cls= htmlspecialchars($_POST['master_cls']);
	
	if (isset($id)) 
	{
		/* conversion*/
		$user_name=mb_strtoupper($user_name);
		
		$id=(int)$id;
		// CORRECTION : suppression de la colonne 'ref_class' qui n'existe pas dans admins (erreur SQL)
		$elt= array('civilite' =>$user_civ , 'username' =>$user_name, 'password' =>$pass, 'user_tel' =>$tel, 'role' =>$user_role, 'master_cls' =>$master_cls);
		
		foreach ($elt as $key => $value) {
			if ($value!="") {

			$bdd = $GLOBALS['bdd'];	
			// SÉCURISÉ : nom de colonne issu d'une liste interne + WHERE lié par paramètre (anti-injection SQL)
			$req ='UPDATE admins SET '.$key.'=? where id = ?';
			$rep = $bdd->prepare($req);
			$rep->execute(array($value, $id));
				
			}
			
		}
		
		header('location: ../../users.php?');
	}
	else
	{
		echo "Error 1";
	
	}
  		
	
		
?>