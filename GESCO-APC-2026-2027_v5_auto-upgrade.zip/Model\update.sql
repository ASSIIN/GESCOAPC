-- ============================================================================
--  GESCO-APC — Model/update.sql
--  Corrections SQL à appliquer sur les installations EXISTANTES (base réelle).
--  Les installations NEUVES utilisent directement Model/gescoapc_25_26.sql
--  (schéma déjà corrigé) : dans ce cas, NE PAS réexécuter ce fichier.
--
--  Usage :
--      mysql -u <user> -p gescoapc_25_26 < update.sql
--  (ou via phpMyAdmin : importer le fichier dans la base de l'année courante)
-- ============================================================================

-- ----------------------------------------------------------------------------
-- 1. Cachet/signature sur les bulletins
--    Ajoute le paramètre « p_ch » à la table `etablissement` :
--       'O'  -> le cachet (sign_respo_etb) est imprimé sur le bulletin
--       'N'  -> masqué (valeur par défaut)
--    Tableau de bord : general_setting.php → CACHET SUR LES BULLETINS
--    Utilisation : fpdf185/bul_*.php (via $etb->ChksigRE()).
-- ----------------------------------------------------------------------------
ALTER TABLE `etablissement`
    ADD COLUMN `p_ch` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT 'N'
    AFTER `sign_respo_etb`;