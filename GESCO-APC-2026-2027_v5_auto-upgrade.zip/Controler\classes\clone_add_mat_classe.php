<?php
// Controler/classes/clone_add_mat_classe.php
session_start();
// Désactivation des affichages d'erreurs pour éviter de bloquer les redirections de Laragon
ini_set('display_errors', 0);
error_reporting(0);

require_once '../../Model/connexion.php';
require_once '../../core/require.php';

$bdd = $GLOBALS['bdd'];

if (isset($_POST['ref_class']) && isset($_POST['type'])) {
    
    $refclass = htmlspecialchars($_POST['ref_class']);	
    $type = htmlspecialchars($_POST['type'] ?? 'nv');

    $cls_nv = $class->ReturnClasseNvByCode($refclass);
    $cls_ss = $class->ReturnClasseSessionByCode($refclass);

    // 1. Détermination de la liste des classes cibles selon le filtre choisi
    if ($type == 'nv') {
        // Uniquement les classes de même niveau et de même section
        $stmt_targets = $bdd->prepare('SELECT code_class FROM classes WHERE ref_class_niveau = ? AND class_session = ? AND code_class != ?');
        $stmt_targets->execute(array($cls_nv, $cls_ss, $refclass));
    } else {
        // Absolument toutes les classes de l'établissement
        $stmt_targets = $bdd->prepare('SELECT code_class FROM classes WHERE code_class != ?');
        $stmt_targets->execute(array($refclass));
    }

    // Ouverture d'une transaction globale pour accélérer les écritures en masse
    $bdd->beginTransaction();

    try {
        // Préparation des requêtes de copie et d'initialisation
        $sql_clone_bull = "INSERT INTO config_bull (ref_class, ref_mat, nom_mat, coeff_mat, group_mat, ref_ens, ref_niveau_class)
                           SELECT :classe_cible, ref_mat, nom_mat, coeff_mat, group_mat, ref_ens, ref_niveau_class
                           FROM config_bull
                           WHERE ref_class = :classe_source
                           AND ref_mat NOT IN (SELECT ref_mat FROM config_bull WHERE ref_class = :classe_cible)";
        $stmt_clone_bull = $bdd->prepare($sql_clone_bull);

        // Requête pour greffer les compétences réelles de la matière source vers chaque matière
        // (re)copiée dans la classe cible, sans écraser celles déjà existantes côté cible.
        $sql_ins_comp = "INSERT INTO competences_matieres (ref_class, ref_mat, num_compt, nom_compt)
                         SELECT :classe_cible, src.ref_mat, src.num_compt, src.nom_compt
                         FROM competences_matieres src
                         WHERE src.ref_class = :classe_source
                           AND src.ref_mat IN (SELECT ref_mat FROM config_bull WHERE ref_class = :classe_cible)
                           AND src.ref_mat NOT IN (SELECT ref_mat FROM competences_matieres WHERE ref_class = :classe_cible)";
        $stmt_ins_comp = $bdd->prepare($sql_ins_comp);

        // Parcours de chaque classe cible
        while ($row = $stmt_targets->fetch(PDO::FETCH_ASSOC)) {
            $classe_source = $refclass;
            $classe_cible = $row['code_class'];

            // Étape A : Clonage des matières du bulletin (avec protection anti-doublon intégrée)
            $stmt_clone_bull->bindParam(':classe_cible', $classe_cible);
            $stmt_clone_bull->bindParam(':classe_source', $classe_source);
            $stmt_clone_bull->execute();

            // Étape B : Copie des compétences réelles depuis la classe source pour chaque nouvelle matière clonée
            $stmt_ins_comp->bindParam(':classe_cible', $classe_cible);
            $stmt_ins_comp->bindParam(':classe_source', $classe_source);
            $stmt_ins_comp->execute();
        }

        // Validation définitive de la transaction
        $bdd->commit();
        header('location: ../../config_bull.php?id=' . urlencode($refclass) . '&clone_success=1');
        exit();

    } catch (PDOException $e) {
        // En cas d'erreur sur une table, on annule tout pour éviter des configurations bancales
        $bdd->rollBack();
        echo "Erreur système lors de la duplication en masse : " . $e->getMessage();
    }

} else {
    header('location: ../../menu_classes.php');
    exit();
}
?>
