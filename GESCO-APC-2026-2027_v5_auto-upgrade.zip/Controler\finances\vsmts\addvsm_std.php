<?php
	session_start();
	require_once '../../../Model/connexion.php';
	require_once '../../../core/require.php'; 	
	$classe_std= htmlspecialchars($_POST['classe_std']);
	$nom_std= htmlspecialchars($_POST['nom_std']);
	$prenom_std= htmlspecialchars($_POST['prenom_std']);
	$date_naiss= htmlspecialchars($_POST['date_naiss_std']);
	$sexe_std= htmlspecialchars($_POST['sexe']);
	$lieu_naiss_std= htmlspecialchars($_POST['lieu_naiss_std']);
	$prix_vsm= htmlspecialchars($_POST['vsm_std']);

	if (!isset($_POST['val_remise'])) {
		$remise=NULL;
	}
	else{
		$remise= htmlspecialchars($_POST['val_remise']);
	}
	if (!isset($_POST['print'])) {
		$print="non";
	}else{
		$print= htmlspecialchars($_POST['print']);
	}
	$nom_prenom_std="";
	if($prenom_std=="")
	{
		$nom_prenom_std=$nom_std;

	}else
	{
		$nom_prenom_std=$nom_std.' '.$prenom_std;

	}
	$date_naiss=strval($date_naiss);

	
		/* conversion*/
		$nom_std=mb_strtoupper($nom_std);
		$prenom_std=mb_strtoupper($prenom_std);
		$nom_prenom_std=mb_strtoupper($nom_prenom_std);
		$lieu_naiss_std=mb_strtoupper($lieu_naiss_std);
  		
  		 
       /* Generation du code*/
       $lastMat=$std->IncrimValMatr();
       if ($lastMat!="")
       {
       	 	$NumMat=(int)$lastMat;  
       	   $NumMat++;
       	   $codeswift="0000";
       	   $codeN=$codeswift.$NumMat;
       	   $code=substr($codeN,-4);
       }

        /* Generation du Id vsm*/
       $lastvsm=$fin->IncrimIDvsmt();
       if ($lastvsm!="")
       {
       	  $Numvsm=(int)$lastvsm;  
       	   $Numvsm++;
       	   $codeswift2="0000";
       	   $codeN2=$codeswift2.$Numvsm;
       	   $id_vsm=substr($codeN2,-4);
       }
       else{
       		$lastvsm="1";
       	 	$Numvsm=(int)$lastvsm;  
       	   $Numvsm++;
       	   $codeswift2="0000";
       	   $codeN2=$codeswift2.$Numvsm;
       	   $id_vsm=substr($codeN2,-4);
       }
        
    	$nv=$fin->ReturnClasseNiveauByCode($classe_std);
		$sess=$fin->ReturnClasseSessionByCode($classe_std);
		$ps=$fin->Return_Ps_Nv($nv,$sess);

		if ($ps!=0) {
			

				if (isset($code) and isset($nom_std)) 
				{

					$bdd = $GLOBALS['bdd'];

					$req = 'INSERT INTO eleves (nom_std, date_nais, lieu_nais, sexe_std, mat_std, ref_class) VALUES( ?, ?, ?, ?, ?, ?)' ;

						$rep = $bdd->prepare($req);
						if ($rep->execute(array($nom_prenom_std, $date_naiss, $lieu_naiss_std, $sexe_std, $code, $classe_std)))
						{

							$bdd = $GLOBALS['bdd'];

							$req2 = 'INSERT INTO versements (ref_std, prix_vsm, id_vsm) VALUES(?, ?, ?)' ;

							$rep2 = $bdd->prepare($req2);
							if ($rep2->execute(array($code, $prix_vsm, $id_vsm))) 
							{

								if ($remise!=NULL) 
								{
									$bdd = $GLOBALS['bdd'];

									$req3 = 'INSERT INTO remises (ref_std, prix_rms, ref_vsm) VALUES(?, ?, ?)' ;

									$rep3 = $bdd->prepare($req3);
									$rep3->execute(array($code, $remise, $id_vsm));
									
								}
								if ($print=="oui") 
								{
									header('location: ../../../fpdf185/print_recu.php?id='.$id_vsm.'&std='.$code.'');
								}

								else{
								header('location: ../../../gestion_fin.php');
							}
							}
							
								
						}
						else{
							header('location: ../../../gestion_fin.php?f=0');
						}		

		
			}
	}
	else{
		header('location: ../../../gestion_fin.php?f=0');
			}

		
?>