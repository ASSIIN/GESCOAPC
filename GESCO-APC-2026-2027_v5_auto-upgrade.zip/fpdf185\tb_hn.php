<?php
session_start();
require_once '../Model/connexion.php';
require_once '../core/require.php';
 if (!isset($_SESSION['user'])) {
    session_unset();
    session_destroy();
    header('location: ../index.php');    
    }
 $etb->ShowEtb();
 if (!isset($_GET['tcls']) and !isset($_GET['bul'])) {
	header('location: ../impression.php');
 }

$refcls= htmlspecialchars($_GET['tcls']);
$ua= htmlspecialchars($_GET['bul']);
$fond= htmlspecialchars($_GET['f']);

if ($ua=="1") {
	$nomtrim="1er TRIMESTRE (Fst TERM)";
	$fileN="TRIM_1";
}elseif ($ua=="2") {
	$nomtrim="2e TRIMESTRE (2ND TERM)";
	$fileN="TRIM_2";
}elseif ($ua=="3") {
	$nomtrim="3e TRIMESTRE (3RD TERM)";
	$fileN="TRIM_3";
}

if ($fond=="1") {
	$bg="fond1.jpg";
}
elseif ($fond=="2") {
	$bg="fond2.jpg";
}
elseif ($fond=="3") {
	$bg="fond3.jpg";
}
elseif ($fond=="4") {
	$bg="fond4.jpg";
}
elseif ($fond=="5") {
	$bg="fond5.jpg";
}
else{
	$bg="fond0.jpg";
}

$class->CkClasseByCode($refcls);
						
$nomcls=$_SESSION['nom_class'];
require('fpdf.php');
$pdf = new FPDF();

class PDF extends FPDF
{
// En-tête
function Header()
{
	 $this->SetY(15);
    // Logo
    $this->Image('../plugins/images/'.$_SESSION['logo_etb'].'',12,12,30);
    // Police Arial gras 15
    $this->SetFont('Arial','B',15);
    // Décalage à droite
    $this->Cell(80);
    // Titre
    $this->Cell(30,10,'Titre',1,0,'C');
    // Saut de ligne
    $this->Ln(20);
}

// Pied de page
function Footer()
{
    // Positionnement à 1,5 cm du bas
    $this->SetY(-15);
    // Police Arial italique 8
    $this->SetFont('Arial','I',8);
    // Numéro de page
    $this->Cell(0,10,'Page '.$this->PageNo().'/{nb}',0,0,'C');
}
}

//code for print data

		 $bdd = $GLOBALS['bdd'];
			$reponse = $bdd->query('SELECT * FROM eleves where ref_class="'.$refcls.'" order by nom_std asc');
			while($row = $reponse->fetch(PDO::FETCH_ASSOC)) 
			{

				$bdd = $GLOBALS['bdd'];
				$reponse1 = $bdd->query('SELECT * FROM table_note_par_trim'.$ua.' where (ref_cls="'.$refcls.'" and ref_trim="'.$ua.'" and ref_std="'.$row['mat_std'].'" )');
				while($row1 = $reponse1->fetch(PDO::FETCH_ASSOC)) 
				{
					if ($row1['moy']>=12) 
					{
						$nbstdclasser=$opt->NbrStudentClasserByClass($refcls,$ua);
						$nbstdclasser=(float)$nbstdclasser;
						$sexestd=$row['sexe_std'];

						$rangstd=(string)$row1['rang'];
						$strrangstd='';
						$classer_std='';
						if (($rangstd=='1') or ($rangstd=='21') or ($rangstd=='31') or ($rangstd=='41') or ($rangstd=='51') or ($rangstd=='61') or ($rangstd=='71') or ($rangstd=='81') or ($rangstd=='91') or ($rangstd=='101') or ($rangstd=='121') or ($rangstd=='131') or ($rangstd=='141') or ($rangstd=='151') or ($rangstd=='161') or ($rangstd=='171') or ($rangstd=='181') or ($rangstd=='191') or $rangstd=='201' or $rangstd=='221' or $rangstd=='231' or $rangstd=='241' or $rangstd=='251' or $rangstd=='261' or $rangstd=='271' or $rangstd=='281' or $rangstd=='291') {
							if ($sexestd=='M') {
								$strrangstd='er(st)';
							}else{
								$strrangstd='ere(st)';
							}
							
						}
						elseif ($rangstd=='2' or $rangstd=='22' or $rangstd=='32' or $rangstd=='42' or $rangstd=='52' or $rangstd=='62' or $rangstd=='72' or $rangstd=='82' or $rangstd=='92' or $rangstd=='102' or $rangstd=='122' or $rangstd=='132' or $rangstd=='142' or $rangstd=='152' or $rangstd=='162' or $rangstd=='172' or $rangstd=='182' or $rangstd=='192' or $rangstd=='202' or $rangstd=='222' or $rangstd=='232' or $rangstd=='242' or $rangstd=='252' or $rangstd=='262' or $rangstd=='272' or $rangstd=='282' or $rangstd=='292') {
							$strrangstd='e(nd)';
						}
						elseif ($rangstd=='3' or $rangstd=='23' or $rangstd=='33' or $rangstd=='43' or $rangstd=='53' or $rangstd=='63' or $rangstd=='73' or $rangstd=='83' or $rangstd=='93' or $rangstd=='103' or $rangstd=='123' or $rangstd=='133' or $rangstd=='143' or $rangstd=='153' or $rangstd=='163' or $rangstd=='173' or $rangstd=='183' or $rangstd=='193' or  $rangstd=='203' or $rangstd=='223' or $rangstd=='233' or $rangstd=='243' or $rangstd=='253' or $rangstd=='263' or $rangstd=='273' or $rangstd=='283' or $rangstd=='293') {
							$strrangstd='e(rd)';
						}else
						{
							if ($row1['classer']=='Y') {
								$strrangstd='e(th)';
							}else{
								$strrangstd='';
								
							}

				
						}

						$pdf->AddPage('L','a5');
						$pdf->Image('bg/'.$bg.'',9,12,193);
						$pdf->AliasNBPages();
						$pdf->SetDrawColor(0,255,0);
						$pdf->SetLineWidth(4);
						$pdf->Line(200, 10, 10, 10);
						$pdf->Line(10, 140, 10, 10);
						$pdf->Line(200, 10, 200, 140);
						$pdf->Line(10, 140, 200, 140);
						$pdf->SetLineWidth(1);
						$i=1;
						$eff=0;
						/*En-tête*/
							$pdf->SetFont('Times','',6);
							

							$pdf->Image('../plugins/images/'.$_SESSION['logo_etb'].'',92,18,25);
							$pdf->Ln();
							$pdf->Cell(70,3,'REPUBLIQUE DU CAMEROUN',0,0,'C');
							$pdf->Cell(50,3,'',0,0);
							$pdf->Cell(70,3,'REPUBLIC OF CAMEROON',0,1,'C');

							$pdf->Cell(70,3,'Paix-Travail-Patrie',0,0,'C');
							$pdf->Cell(50,3,'',0,0);
							$pdf->Cell(70,3,'Peace-Work-Fatherland',0,1,'C');

							$pdf->Cell(70,3, utf8_to_cp1252("".$_SESSION['minist_etb_fr'].""),0,0,'C');
							$pdf->Cell(50,3,'',0,0);
							$pdf->Cell(70,3,utf8_to_cp1252(''.$_SESSION['minist_etb_en'].''),0,1,'C');

							$pdf->Cell(70,3,utf8_to_cp1252("".$_SESSION['region_etb_fr'].""),0,0,'C');
							$pdf->Cell(50,3,'',0,0);
							$pdf->Cell(70,3,utf8_to_cp1252(''.$_SESSION['region_etb_en'].''),0,1,'C');

							$pdf->Cell(70,3,utf8_to_cp1252(''.$_SESSION['depart_etb_fr'].''),0,0,'C');
							$pdf->Cell(50,3,'',0,0);
							$pdf->Cell(70,3,utf8_to_cp1252(''.$_SESSION['depart_etb_en'].''),0,1,'C');
							$pdf->SetFont('Times','B',8);
							$pdf->Cell(70,5,utf8_to_cp1252(''.$_SESSION['nom_etb_fr'].''),0,0,'C');
							$pdf->Cell(50,5,'',0,0);
							$pdf->Cell(70,5,utf8_to_cp1252(''.$_SESSION['nom_etb_en'].''),0,1,'C');
							$pdf->SetFont('Times','',8);
							$pdf->Cell(70,4,utf8_to_cp1252(''.$_SESSION['code_pste_etb'].' / '.$_SESSION['tel_etb'].''),0,0,'C');
							$pdf->Cell(50,4,'',0,0);
							$pdf->Cell(70,4,utf8_to_cp1252(''.$_SESSION['code_pste_etb'].'/ '.$_SESSION['tel_etb'].''),0,1,'C');
							$pdf->SetFont('Times','',8);
							$pdf->Cell(70,3,utf8_to_cp1252(''.$_SESSION['email_etb'].''),0,0,'C');
							$pdf->Cell(50,3,'',0,0);
							$pdf->Cell(70,3,utf8_to_cp1252(''.$_SESSION['email_etb'].''),0,1,'C');
								$pdf->Ln();
								$pdf->SetFont('Times','I',7);
								$pdf->Cell(65,4,'',0,0);
								$pdf->Cell(60,4,utf8_to_cp1252(''.$_SESSION['code_im_etb'].''),0,0,'C');
								$pdf->Ln();
								$pdf->Ln();
						/*FIN En-tête*/
						//Titre 
								$pdf->SetFont('Times','B',15);
								$pdf->SetFillColor(255,255,0);
								$pdf->SetDrawColor(255,0,0);
								$pdf->Cell(35,10,'',0,0,'C');
								$pdf->Cell(120,10,'TABLEAU D\'HONNEUR / HONOUR ROLL',1,0,'C',1);
								$pdf->Cell(30,10,'',0,1,'C');
								$pdf->Cell(130,2,'',0,0,'C');
								$pdf->Ln();
								$pdf->SetFont('Times','I',12);
								$pdf->Cell(40,4,'',0,0,'C');
								$pdf->Cell(100,4,utf8_to_cp1252('Décerné à / Awarded to'),0,0,'C',0);
								$pdf->Cell(30,4,'',0,0,'C');

						

					
					//$pdf->SetFont('Times','B',10);
						
					 
					
						$Nom=htmlspecialchars($row['nom_std']);
						$Nom=mb_strtoupper($Nom);
						$Nom = str_replace("&#039;", "'", $Nom);

						$lieu_nais=mb_strtoupper($row['lieu_nais']);
						$lieu_nais=substr($lieu_nais, 0,26);
						$lieu_nais = str_replace("&#039;", "'", $lieu_nais);
						
						$Nom=substr($Nom, 0,34);
						$date_nais_fr= date('d/m/Y ',strtotime($row['date_nais']));
						/*$row['mat_std'];
						$row['nom_prenom_std']
						$row['sexe_std']
						$row['date_nais']
						$row['lieu_nais']*/
						$pdf->SetFont('Times','B',12);

						$pdf->SetFont('Times','',12);
						$pdf->Ln();
						$pdf->Ln();
						$pdf->Cell(5,6,'',0,0,'L');
						$pdf->Cell(39,6,utf8_to_cp1252('L\'élève (The student) :'),0,0,'L');
						$pdf->SetFont('Times','BI',19);
						$pdf->Cell(130,6,utf8_to_cp1252($Nom.','),0,1,'L');
						$pdf->SetFont('Times','',12);
						$pdf->Cell(5,6,'',0,0,'L');
						$pdf->Cell(31,6,utf8_to_cp1252('né(e) le (born on)'),0,0,'L');
						$pdf->SetFont('Times','BI',12);			
						$pdf->Cell(20,6,utf8_to_cp1252(''.$date_nais_fr.' '),0,0,'L');
						$pdf->SetFont('Times','',12);
						$pdf->Cell(10,6,utf8_to_cp1252('à (at)'),0,0,'L');
						$pdf->SetFont('Times','BI',9);
						$pdf->Cell(45,6,utf8_to_cp1252($lieu_nais.','),0,0,'L');
						$pdf->SetFont('Times','',10);
						$pdf->Cell(5,6,'',0,0,'L');
						$pdf->Cell(30,6,utf8_to_cp1252('Matr: '.$row['cni_std'].','),0,0,'L');
						$pdf->Cell(15,6,utf8_to_cp1252('Class(e):'),0,0,'L');
						$pdf->SetFont('Times','BI',12);
						$pdf->Cell(40,6,utf8_to_cp1252(''.$nomcls.''),0,1,'L');
						$pdf->SetFont('Times','',12);
						$pdf->Cell(5,6,'',0,0,'L');
						$pdf->Cell(96,6,utf8_to_cp1252('a obtenu une moyenne de (has obtained an average of) :'),0,0,'L');
						$pdf->SetFont('Times','B',18);
						$pdf->SetTextColor(255,0,0);
						$pdf->Cell(27,6,utf8_to_cp1252($row1['moy'].' / 20'),0,0,'L');
						$pdf->SetFont('Times','',12);
						$pdf->SetTextColor(0,0,0);
						$pdf->Cell(30,6,'Rang (position) :',0,0,'L');
						$pdf->SetFont('Times','B',14);
						$pdf->SetTextColor(0,0,0);
						$pdf->Cell(25,6,utf8_to_cp1252(''.$row1['rang'].''.$strrangstd.' / '.$nbstdclasser.''),0,1,'L');
						$pdf->SetFont('Times','',12);
						$pdf->Cell(5,6,'',0,0,'L');
						$pdf->Cell(5,6,utf8_to_cp1252('au'),0,0,'L');
						$pdf->SetFont('Times','B',12);
						$pdf->Cell(58,6,utf8_to_cp1252(''.$nomtrim.''),0,0,'L');
						$pdf->SetFont('Times','',12);
						$pdf->Cell(60,6,utf8_to_cp1252(' de l\'année scolaire (school year) :'),0,0,'L');
						$pdf->SetFont('Times','B',14);
						$pdf->Cell(35,6,utf8_to_cp1252($_SESSION['school_year'].'.'),0,0,'L');

							$pdf->Ln();				
							$pdf->Ln();
							$pdf->SetFont('Times','',12);
							$pdf->Cell(15,5,'',0,0,'C',0);
							$pdf->Cell(5,5,'',1,0,'C',0);
							$pdf->Cell(40,5,'Avec Encouragement',0,0,'C');
							$pdf->Cell(32,5,'',0,0,'C',0);
							$pdf->Cell(60,5,utf8_to_cp1252($_SESSION['ville_etb'].', le/On __________________'),0,0);
							$pdf->Ln();
							$pdf->Cell(20,5,'',0,0,'C');
							$pdf->Cell(40,5,'With Encouragement',0,0,'C');
							$pdf->Cell(32,5,'',0,0,'C',0);
							$pdf->Cell(60,5,utf8_to_cp1252('Le Proviseur / The Principal,'),0,0);

							
							$pdf->Ln();
			


						}
					}
				}
				
$pdf->Output('T_D_HONNEUR_'.$fileN.'_ '.$nomcls.'.pdf','I');
$pdf->Close();
?>
