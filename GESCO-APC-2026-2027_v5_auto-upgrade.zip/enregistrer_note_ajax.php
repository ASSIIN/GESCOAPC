<?php
session_start();    
require_once 'core/require.php';
require_once 'Model/connexion.php';

header('Content-Type: application/json');

// CORRECTION : garde d'accès (utilisateur connecté)
if (!isset($_SESSION['user']) || empty($_SESSION['user'])) {
    echo json_encode(['status' => 'error', 'message' => 'Non authentifié.']);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['status' => 'error', 'message' => 'Méthode non valide.']);
    exit;
}

$bdd = $GLOBALS['bdd'];

// CORRECTION : validation/nettoyage des entrées
$ref_class  = trim($_POST['ref_class'] ?? '');
$ref_mat    = trim($_POST['ref_mat'] ?? '');
$ref_std    = trim($_POST['id_eleve'] ?? '');
$label_eval = $_POST['label_eval'] ?? '';
$notes      = (isset($_POST['notes']) && is_array($_POST['notes'])) ? $_POST['notes'] : array();

if ($ref_class === '' || $ref_mat === '' || $ref_std === '' || count($notes) === 0) {
    echo json_encode(['status' => 'error', 'message' => 'Paramètres manquants.']);
    exit;
}

// CORRECTION (autorisation) : l'enseignant ne saisit que les matières qui lui sont attribuées (config_bull.ref_ens = login)
if (($_SESSION['user_role'] ?? '') === 'ens') {
    $auth = $bdd->prepare('SELECT id FROM config_bull WHERE ref_class = ? AND ref_mat = ? AND ref_ens = ? LIMIT 1');
    $auth->execute(array($ref_class, $ref_mat, $_SESSION['login'] ?? ''));
    if (!$auth->fetch()) {
        echo json_encode(['status' => 'error', 'message' => 'Action non autorisée pour cette classe/matière.']);
        exit;
    }
}

try {
    $bdd->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $bdd->beginTransaction();

    foreach ($notes as $note_data) {
        // CORRECTION : $ref_eval borné 1..6 (évite l'énumération de tables)
        $ref_eval = (int)($note_data['ref_eval'] ?? 0);
        if ($ref_eval < 1 || $ref_eval > 6) {
            throw new Exception('Période d\'évaluation invalide.');
        }
        $raw_note = isset($note_data['note']) ? $note_data['note'] : '';
        $coef     = (float)($note_data['coef'] ?? 0);

        $note = null;
        $note_x_coeff = null;

        if ($raw_note !== "" && $raw_note !== null) {
            $val = (float)$raw_note;
            if ($val != -1) {
                // CORRECTION : une note est comprise entre 0 et 20
                if ($val < 0 || $val > 20) {
                    throw new Exception('Note hors limite (0 à 20).');
                }
                $note = $val;
                $note_x_coeff = $note * $coef;
            }
        }

        $table_name = "table_note_par_mat_eval" . $ref_eval;

        $check = $bdd->prepare("SELECT id FROM $table_name WHERE ref_cls = ? AND ref_mat = ? AND ref_std = ? AND ref_eval = ?");
        $check->execute([$ref_class, $ref_mat, $ref_std, $ref_eval]);
        
        if ($check->fetch()) {
            $sql = "UPDATE $table_name SET note = ?, coef = ?, note_x_coeff = ? WHERE ref_cls = ? AND ref_mat = ? AND ref_std = ? AND ref_eval = ?";
            $bdd->prepare($sql)->execute([$note, $coef, $note_x_coeff, $ref_class, $ref_mat, $ref_std, $ref_eval]);
        } elseif ($raw_note !== "") {
            $sql = "INSERT INTO $table_name (ref_cls, ref_mat, ref_std, ref_eval, note, coef, note_x_coeff) VALUES (?, ?, ?, ?, ?, ?, ?)";
            $bdd->prepare($sql)->execute([$ref_class, $ref_mat, $ref_std, $ref_eval, $note, $coef, $note_x_coeff]);
        }
    }

    $bdd->commit();
    // On renvoie le label dans la réponse
    echo json_encode(['status' => 'success', 'label' => $label_eval]);

} catch (Exception $e) {
    if ($bdd->inTransaction()) $bdd->rollBack();
    echo json_encode(['status' => 'error', 'message' => $e->getMessage()]);
}