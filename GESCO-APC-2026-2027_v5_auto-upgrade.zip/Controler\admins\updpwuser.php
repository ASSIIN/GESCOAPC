<?php
	session_start();
	require_once '../../Model/connexion.php';
	require_once '../../core/require.php'; 

	// Sécurité : sans session, redirection vers l'écran de connexion
	if (!isset($_SESSION['user'])) {
		header('location: ../../index.php');
		exit;
	}

	$id=htmlspecialchars($_POST['login'] ?? '');
	$l_pw= htmlspecialchars($_POST['l_pw'] ?? '');
	$new_pw1= htmlspecialchars($_POST['new_pw1'] ?? '');
	$new_pw2= htmlspecialchars($_POST['new_pw2'] ?? '');

	if ($id != "") 
	{
		// Sécurité : un utilisateur non-admin ne peut changer QUE son propre mot de passe
		if (($_SESSION['user_role'] ?? '') !== 'admin' && $id !== $_SESSION['login']) {
			header('location: ../../account_setting.php?i');
			exit;
		}

		if ($new_pw1 == $new_pw2 && $new_pw1 != "") 
		{
			$bdd = $GLOBALS['bdd'];

			// SÉCURISÉ : l'ancien mot de passe saisi est vérifié contre la BASE (et non contre le champ caché du HTML)
			$stmt = $bdd->prepare('SELECT password FROM admins WHERE login=? LIMIT 1');
			$stmt->execute(array($id));
			$row = $stmt->fetch(PDO::FETCH_ASSOC);

			if ($row && (password_verify($l_pw, $row['password']) || $l_pw === $row['password'])) {
				// SÉCURISÉ : requête préparée anti-injection SQL
				$req ='UPDATE admins SET password=? where login=?';
				$rep = $bdd->prepare($req);
				$rep->execute(array($new_pw2, $id));
				header('location: ../../account_setting.php');
				exit;
			} else {
				header('location: ../../account_setting.php?i');
				exit;
			}
		}
		else{
			header('location: ../../account_setting.php?i');
			exit;
		}
			
	}
	else
	{
		header('location: ../../account_setting.php?e');
	
	}
  		
	
		
?>