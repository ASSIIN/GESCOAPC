<?php 
	/**
	 * 
	 */
	class MyFinance
	{
		private $ref_s, $ref_n, $prix, $ps_bull;
		
		function __construct()
		{
			# code...
		}

		public function setRef_s($value)
		{
			$this->ref_s = $value;
		}
		public function getRef_s()
		{
			return $this->ref_s;
		}

		public function setRef_n($value)
		{
			$this->ref_n = $value;
		}
		public function getRef_n()
		{
			return $this->ref_n;
		}

		public function setPrix($value)
		{
			$this->prix = $value;
		}
		public function getPrix()
		{
			return $this->prix;
		}

		public function setPs_bull($value)
		{
			$this->ps_bull=$value;
		}
		public function getPs_bull()
		{
			return $this->ps_bull;
		}


		public function AddPension()
		{
			$bdd = $GLOBALS['bdd'];
	

			$req = "INSERT INTO pensions (ref_s, ref_n, prix, ps_bull) VALUES(?, ?, ?, ?)" ;

				$rep = $bdd->prepare($req);
				if ($rep->execute( array($this->ref_s, $this->ref_n, $this->prix, $this->ps_bull))) {
					return true;
				}
				else{
					return false;
				}
		}

		public function ShowAllPensions()
		{
			$bdd = $GLOBALS['bdd'];
			$i=0;
			$nt=0;
			$nv="";
			$reponse = $bdd->query('SELECT * FROM pensions where id>=0 order by ref_n asc');
			while($row = $reponse->fetch(PDO::FETCH_ASSOC)) 
			{
				$reponse0 = $bdd->query('SELECT * FROM niveaux where ref_niveau="'.$row['ref_n'].'" ');
				while($row0 = $reponse0->fetch(PDO::FETCH_ASSOC)) 
				{
					$nv= $row0['nom_niveau'];
						# code...
				}
				$i++;

				$prix= number_format($row['prix'],0,",",".");
				$ps_bull= number_format($row['ps_bull'],0,",",".");

				echo '
				<tr>
				<td id="id">'.$i.'</td>             
                <td>'.$nv.'</td>
                <td class="txt-oflo">'.$row['ref_s'].'</td>
                <td>'.$prix.' FCFA</td>
                <td>'.$ps_bull.' FCFA</td>
                <td>
                 <button type="button" class="btn btn-primary btn-sm ml-2" data-bs-toggle="modal" data-bs-target="#mod_edit'.$row['id'].'" data-whatever="@mdo"><i class="fa fa-edit fa-1x" aria-hidden="true"></i></button>
                  
					<div class="modal fade" id="mod_edit'.$row['id'].'" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                      <div class="modal-dialog" role="document">
                        <div class="modal-content">
                          <div class="modal-header">
                            <h5 class="modal-title" id="exampleModalLabel">Modifier</h5>
														<button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Fermer"></button>
                          </div>
                          <div class="modal-body">
                           <div class="container-fluid">
                                <div class="row">            
	                          	 	<div class="col-md-6">
	                          	 		<form action="Controler/finances/pensions/updps.php" method="post">
	                          	 		<input type="text" class="form-control" id="id" name="id"  hidden="true" value="'.$row['id'].'">
	                    
                                     
                                        <label for="inputEmail4"> Montant: </label>
                                        <input type="number" class="form-control" id="prix" name="prix"  >
                                    </div>
                                    <div class="col-md-6 ">                                            
                                            <label for="inputEmail4">Pension Bulletin: </label>
                                            <input type="number" class="form-control" id="ps_bull" name="ps_bull" placeholder="marge minimun pour avoir le Bulletin"  >
                                        </div> 
 									</div>
                                  <div class="row text-end mt-3 mx-3"> 
                                    <input type="submit" name="submit" class="btn btn-primary" value="Enrégistrer">
                                    <button type="button" class="btn btn-danger" data-bs-dismiss="modal">Annuler</button>
                                  </form>
                                  </div>
                                <div class="modal-footer">
                                 
                               
                                	
                          		</div>
                        </div>
					</div>
				</td>
				<td>
                 <button type="button" class="btn btn-danger btn-sm ml-2" data-bs-toggle="modal" data-bs-target="#mod_del'.$row['id'].'" data-whatever="@mdo"><i class="fa fa-remove fa-1x" aria-hidden="true"></i></button>
                  
					<div class="modal fade" id="mod_del'.$row['id'].'" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                      <div class="modal-dialog" role="document">
                        <div class="modal-content">
                          <div class="modal-header">
                            <h5 class="modal-title" id="exampleModalLabel">SUPPRIMER </h5>
														<button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Fermer"></button>
                          </div>
                          <div class="modal-body">
                          		<h5 class="modal-title" id="exampleModalLabel">Voulez-vous supprimmer ? Cette action est irréversible.</h5>
                          		<a href="Controler/finances/pensions/delps.php?id='.$row['id'].'" ><button  class="btn btn-primary">Oui</button></a>                  
                                       
                                </div>
                                <div class="modal-footer">
                                 
                               
                                	<button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Annuler</button>
                          		</div>
                        </div>
					</div>
				</td>
                </tr>
                </tr>
				';
					
			}
			$nt=$i;
			$i=0;
				
		}

		public function SelectFullNombyMat($mat)
		{

			$bdd = $GLOBALS['bdd'];	

			$reponse = $bdd->query('SELECT * FROM eleves where mat_std="'.$mat.'"');
			while (($row = $reponse->fetch(PDO::FETCH_ASSOC))) 
			{
				return $row['nom_std'];
			}
		}

		

		public function ReturnRemisebyVsmID_and_Std($id,$std)
		{

			$bdd = $GLOBALS['bdd'];	

			$reponse = $bdd->query('SELECT * FROM remises where (ref_vsm="'.$id.'" and ref_std="'.$std.'")');
			while (($row = $reponse->fetch(PDO::FETCH_ASSOC))) 
			{
				return $row['prix_rms'];
			}
		}

		public function ShowAllVsmt($prd = '30', $p0 = null, $p1 = null)
		{
			$bdd = $GLOBALS['bdd'];
			$i=0;
			$params = array();
			$clause = $this->vsmPeriodClause($prd, $p0, $p1, $params);
			if ($prd === '30') { $limit = ' LIMIT 30'; }
			elseif ($prd === 'all') { $limit = ' LIMIT 1000'; }
			else { $limit = ''; }
			$sql = 'SELECT id, ref_std, prix_vsm, id_vsm, DATE_FORMAT(post_on, \'%d/%m/%Y %H:%i:%s\') AS date_fr FROM versements where id>=0'.$clause.' order by post_on desc'.$limit;
			if ($params) {
				$reponse = $bdd->prepare($sql);
				$reponse->execute($params);
			}
			else {
				$reponse = $bdd->query($sql);
			}
			while($row = $reponse->fetch(PDO::FETCH_ASSOC)) 
			{
				$i++;
				$nomstd=$this->SelectFullNombyMat($row['ref_std']);
				$rms=$this->ReturnRemisebyVsmID_and_Std($row['id_vsm'],$row['ref_std']);
				$frms = ($rms!=0) ? number_format($rms,0,",",".") : 0;
				$vsm= number_format($row['prix_vsm'],0,",",".");
				echo '
				<tr>
				<td id="id">'.$i.'</td>
                <td>'.$_SESSION['pre_matr'].''.$row['ref_std'].'</td>
                <td class="txt-oflo">'.$nomstd.'</td>
                <td>'.$vsm.' FCFA</td>
                <td>'.$frms.' FCFA</td>
             	<td>'.$row['date_fr'].'</td>
              	<td>
                 	<a href="fpdf185/print_recu.php?std='.$row['ref_std'].'&id='.$row['id_vsm'].'"><button type="button" class="btn btn-primary btn-sm ms-2" ><i class="fa fa-print fa-1x" aria-hidden="true"></i></button></a>
              	</td>
				<td>
                  <button type="button" class="btn btn-danger btn-sm ms-2" data-bs-toggle="modal" data-bs-target="#mod_delv'.$row['id'].'" data-whatever="@mdo"><i class="fa fa-remove fa-1x" aria-hidden="true"></i></button>

					<div class="modal fade" id="mod_delv'.$row['id'].'" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                      <div class="modal-dialog" role="document">
                        <div class="modal-content">
                          <div class="modal-header">
                            <h5 class="modal-title" id="exampleModalLabel">SUPPRIMER </h5>
														<button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Fermer"></button>
                          </div>
                          <div class="modal-body">
                          		<h5 class="modal-title" id="exampleModalLabel">Voulez-vous supprimmer ce versement y compris sa remise ? Cette action est irréversible.</h5>
                          		<a href="Controler/finances/vsmts/delvsm.php?id='.$row['id'].'" ><button  class="btn btn-primary">Oui</button></a>                  
                                
                                </div>
                                <div class="modal-footer">
                                 
                               
                                	<button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Annuler</button>
                          		</div>
                        </div>
					</div>
				</td>
                </tr>
				';
			}
			$nt=$i;
			$i=0;
		}

		private function vsmPeriodClause($prd, $p0, $p1, &$params)
		{
			$params = array();
			switch ($prd) {
				case 'today':
					return ' AND DATE(post_on) = CURDATE()';
				case 'week':
					return ' AND YEARWEEK(post_on, 1) = YEARWEEK(CURDATE(), 1)';
				case 'month':
					return ' AND YEAR(post_on) = YEAR(CURDATE()) AND MONTH(post_on) = MONTH(CURDATE())';
				case 'custom':
					if ($p0 !== null and $p0 !== '' and $p1 !== null and $p1 !== '') {
						$params = array(':p0' => $p0, ':p1' => $p1);
						return ' AND DATE(post_on) >= :p0 AND DATE(post_on) <= :p1';
					}
					return '';
				default:
					return '';
			}
		}

		public function ShowSearchLisStd_Ps()
		{
			$bdd = $GLOBALS['bdd'];
			$i=0;
			$nt=0;
			$reponse = $bdd->query('SELECT * FROM eleves where id>=1 order by nom_std asc');
			while($row = $reponse->fetch(PDO::FETCH_ASSOC)) 
			{
				
				$cls=$this->ReturnClasseNameByCode($row['ref_class']); 

				echo '
				 <li>
				 <a class="dropdown-item d-none" data-bs-toggle="modal" data-bs-target="#vsmstd_'.$row['id'].'" data-whatever="@mdo">'.$_SESSION['pre_matr'].''.$row['mat_std'].' -  '.$row['cni_std'].'-  '.$row['nom_std'].'</a>
				 </li>';

				  }
			}

		public function ShowSearchLisStd_Vs($prd = '30', $p0 = null, $p1 = null)
		{
			$bdd = $GLOBALS['bdd'];
			$params = array();
			$clause = $this->vsmPeriodClause($prd, $p0, $p1, $params);
			if ($prd === '30') { $limit = ' LIMIT 30'; }
			elseif ($prd === 'all') { $limit = ' LIMIT 1000'; }
			else { $limit = ''; }
			$sql = 'SELECT id, ref_std, prix_vsm, id_vsm, DATE_FORMAT(post_on, \'%d/%m/%Y %H:%i:%s\') AS date_fr FROM versements where id>=0'.$clause.' order by post_on desc'.$limit;
			if ($params) {
				$reponse = $bdd->prepare($sql);
				$reponse->execute($params);
			}
			else {
				$reponse = $bdd->query($sql);
			}
			while($row = $reponse->fetch(PDO::FETCH_ASSOC)) 
			{
				$nomstd=$this->SelectFullNombyMat($row['ref_std']);
				$vsm= number_format($row['prix_vsm'],0,",",".");
				echo '

				 <li class="dropitem2 d-none">
				  <div class="d-flex align-items-center justify-content-between px-2 py-1">
				   <span class="text-truncate me-2" style="max-width:70%">
				    <span class="fw-bold">'.$_SESSION['pre_matr'].''.$row['ref_std'].'</span> - '.$nomstd.'
				    <span class="badge bg-success ms-1">'.$vsm.' F</span>
				    <span class="text-muted small d-block">'.$row['date_fr'].'</span>
				   </span>
				   <span class="btn-group btn-group-sm flex-shrink-0">
				    <a class="btn btn-outline-primary" title="Imprimer le reçu" href="fpdf185/print_recu.php?std='.$row['ref_std'].'&id='.$row['id_vsm'].'"><i class="fa fa-print fa-1x" aria-hidden="true"></i></a>
				    <button type="button" class="btn btn-outline-danger" title="Supprimer" data-bs-toggle="modal" data-bs-target="#mod_delv2'.$row['id'].'"><i class="fa fa-remove fa-1x" aria-hidden="true"></i></button>
				   </span>
				  </div>
				 </li>';
			}
		}

		public function Show_modal_vsm_del()
		{
			$bdd = $GLOBALS['bdd'];
			$reponse = $bdd->query('SELECT id FROM versements where id>=0 order by post_on desc');
			while($row = $reponse->fetch(PDO::FETCH_ASSOC)) 
			{
				echo '
				 <div class="modal fade" id="mod_delv2'.$row['id'].'" tabindex="-1" aria-hidden="true">
				  <div class="modal-dialog">
				   <div class="modal-content">
				    <div class="modal-header">
				     <h5 class="modal-title">SUPPRIMER</h5>
				     <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Fermer"></button>
				    </div>
				    <div class="modal-body">
				     <p>Voulez-vous supprimer ce versement y compris sa remise ? Cette action est irréversible.</p>
				    </div>
				    <div class="modal-footer">
				     <a href="Controler/finances/vsmts/delvsm.php?id='.$row['id'].'" class="btn btn-danger">Oui</a>
				     <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Annuler</button>
				    </div>
				   </div>
				  </div>
				 </div>';
			}
		}

			public function Show_modal_vsm()
		{

			$bdd = $GLOBALS['bdd'];
			$i=0;
			$nt=0;
			$reponse = $bdd->query('SELECT * FROM eleves where id>=1 order by nom_std asc');
			while (($row = $reponse->fetch(PDO::FETCH_ASSOC))) 
			{
				$cls=$this->ReturnClasseNameByCode($row['ref_class']);
				$nv=$this->ReturnClasseNiveauByCode($row['ref_class']);
				$sess=$this->ReturnClasseSessionByCode($row['ref_class']);
				$ps=$this->Return_Ps_Nv($nv,$sess);
				$rdt=$this->Return_All_rdt_std($row['mat_std']);
				$vsm=$this->Return_All_vsm_std($row['mat_std']);
				$date_nais_fr= date('d/m/Y ',strtotime($row['date_nais']));
				$reste=$ps-$vsm-$rdt;
				if ($ps!=0) {
					$reste=$ps-$vsm-$rdt;
					$ps= number_format($ps,0,",",".");
					$rdt= number_format($rdt,0,",",".");
					$vsm= number_format($vsm,0,",",".");
					$reste= number_format($reste,0,",",".");				
				}
				
					


			  echo '
				<div class="modal fade" id="vsmstd_'.$row['id'].'" tabindex="-1" aria-labelledby="vsmstd_lbl_'.$row['id'].'" aria-hidden="true">
				  <div class="modal-dialog modal-lg modal-dialog-centered modal-dialog-scrollable">
					<div class="modal-content border-0 shadow">
					  <div class="modal-header vsm-modal-header text-white">
						<div class="d-flex align-items-center gap-2">
						  <span class="vsm-avatar"><i class="fa fa-user-graduate"></i></span>
						  <div>
							<h5 class="modal-title mb-0" id="vsmstd_lbl_'.$row['id'].'">Nouveau versement</h5>
							<small class="opacity-75">'.$_SESSION['pre_matr'].''.$row['mat_std'].' &bull; '.$row['nom_std'].'</small>
						  </div>
						</div>
						<button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Fermer"></button>
					  </div>
					  <div class="modal-body">
						<div class="row g-3">
						  <div class="col-md-6">
							<div class="vsm-info-card h-100">
							  <h6 class="vsm-section-title"><i class="fa fa-id-card me-1"></i>Informations élève</h6>
							  <ul class="vsm-list">
								<li><span>Inscription</span><b>'.$_SESSION['pre_matr'].''.$row['mat_std'].'</b></li>
								<li><span>Matricule</span><b>'.$row['cni_std'].'</b></li>
								<li><span>Classe</span><b>'.$cls.'</b></li>
								<li><span>Sexe</span><b>'.$row['sexe_std'].'</b></li>
								<li><span>Né(e) le</span><b>'.$date_nais_fr.'</b></li>
								<li><span>Lieu de naissance</span><b>'.$row['lieu_nais'].'</b></li>
							  </ul>
							</div>
						  </div>
						  <div class="col-md-6">
							<div class="vsm-info-card h-100">
							  <h6 class="vsm-section-title"><i class="fa fa-coins me-1"></i>Situation financière</h6>
							  <div class="row g-2">
								<div class="col-6"><div class="vsm-tile tile-primary"><span>Pension</span><b>'.$ps.' F</b></div></div>
								<div class="col-6"><div class="vsm-tile tile-success"><span>Déjà versé</span><b>'.$vsm.' F</b></div></div>
								<div class="col-6"><div class="vsm-tile tile-warning"><span>Réduction</span><b>'.$rdt.' F</b></div></div>
								<div class="col-6"><div class="vsm-tile tile-danger"><span>Reste</span><b>'.$reste.' F</b></div></div>
							  </div>
							</div>
						  </div>
						</div>
						<form action="Controler/finances/vsmts/addvsm.php" method="post" class="mt-3">
						  <input type="hidden" name="ref_std" value="'.$row['mat_std'].'">
						  <input type="hidden" name="ref_cls" value="'.$row['ref_class'].'">
						  <h6 class="vsm-section-title"><i class="fa fa-money-bill-transfer me-1"></i>Enregistrer un versement</h6>
						  <div class="row g-3 align-items-end">
							<div class="col-md-4">
							  <label class="form-label" for="remise_'.$row['id'].'">Remise (FCFA)</label>
							  <input type="number" min="0" class="form-control" id="remise_'.$row['id'].'" name="val_remise" placeholder="0 si aucune">
							  <div class="form-text">Laisser vide si pas de remise.</div>
							</div>
							<div class="col-md-4">
							  <label class="form-label" for="vsm_'.$row['id'].'">Montant à verser (FCFA)</label>
							  <input type="number" min="0" class="form-control" id="vsm_'.$row['id'].'" name="vsm_std" required placeholder="Max. '.$reste.'">
							</div>
							<div class="col-md-4">
							  <div class="form-check vsm-print-check">
								<input type="checkbox" class="form-check-input" id="print_'.$row['id'].'" name="print" value="oui">
								<label class="form-check-label" for="print_'.$row['id'].'">Imprimer le reçu</label>
							  </div>
							</div>
						  </div>
						  <div class="d-flex justify-content-end gap-2 mt-4">
							<button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Annuler</button>
							<button type="submit" class="btn btn-primary"><i class="fa fa-save me-1"></i>Enrégistrer</button>
						  </div>
						</form>
					  </div>
					</div>
				  </div>
				</div>';
			}
				
		}

		public function SelectClassesNames_Ps()
		{
			$bdd = $GLOBALS['bdd'];
			$i=0;
			$nt=0;
			$reponse = $bdd->query('SELECT * FROM classes where id>=1 order by ref_class_niveau asc');
			while($row = $reponse->fetch(PDO::FETCH_ASSOC)) 
			{
				$prix=$this->Return_Ps_Nv($row['ref_class_niveau'], $row['class_session']);
				
				$prix= number_format($prix,0,",",".");
				$i++;

				echo '<option value="'.$row['code_class'].'" id="'.$row['code_class'].'">'.$i.' - '.$row['nom_class'].'  --  ( <i style="color:#f33155"> '.$prix.' ) FCFA</i></option>';
				}
		}

			public function ReturnClasseNameByCode($code)
		{
			$bdd = $GLOBALS['bdd'];
			$i=0;
			$nt=0;
			// SÉCURISÉ : requête préparée anti-injection SQL
			$rep = $bdd->prepare('SELECT * FROM classes where code_class=?');
			$rep->execute(array($code));
			$reponse = $rep;
			while($row = $reponse->fetch(PDO::FETCH_ASSOC)) 
			{
				return $row['nom_class'];
			}
		}
		public function ReturnClasseNiveauByCode($code)
		{
			$bdd = $GLOBALS['bdd'];
			$i=0;
			$nt=0;
			// SÉCURISÉ : requête préparée anti-injection SQL
			$rep = $bdd->prepare('SELECT * FROM classes where code_class=?');
			$rep->execute(array($code));
			$reponse = $rep;
			while($row = $reponse->fetch(PDO::FETCH_ASSOC)) 
			{
				return $row['ref_class_niveau'];
			}
		}

		public function ReturnClasseSessionByCode($code)
		{
			$bdd = $GLOBALS['bdd'];
			$i=0;
			$nt=0;
			// SÉCURISÉ : requête préparée anti-injection SQL
			$rep = $bdd->prepare('SELECT * FROM classes where code_class=?');
			$rep->execute(array($code));
			$reponse = $rep;
			while($row = $reponse->fetch(PDO::FETCH_ASSOC)) 
			{
				return $row['class_session'];
			}
		}

		public function CkExt_Ps_Nv($n,$s)
		{

			$bdd = $GLOBALS['bdd'];	
			// SÉCURISÉ : requête préparée anti-injection SQL
			$rep = $bdd->prepare('SELECT * FROM pensions where ref_n=? and ref_s=?');
			$rep->execute(array($n,$s));
			$reponse = $rep;
			while (($row = $reponse->fetch(PDO::FETCH_ASSOC))) 
			{
				return true;
			}
		}

		public function IncrimIDvsmt()
		{

			$bdd = $GLOBALS['bdd'];	

			// CORRECTION : renvoie 0 si la table est vide (évite le doublon du 1er id_vsm)
			$rep = $bdd->prepare('SELECT COALESCE(MAX(id),0) AS last_id FROM versements');
			$rep->execute();
			$row = $rep->fetch(PDO::FETCH_ASSOC);
			return (int)$row['last_id'];
		}

		

		public function Return_Ps_Nv($n,$s)
		{

			$bdd = $GLOBALS['bdd'];
			$val=0;
			// SÉCURISÉ : requête préparée anti-injection SQL
			$rep = $bdd->prepare('SELECT * FROM pensions where ref_n=? and ref_s=?');
			$rep->execute(array($n,$s));
			$reponse = $rep;
			while (($row = $reponse->fetch(PDO::FETCH_ASSOC))) 
			{				
				$val= (float)$row['prix'];
			}
			if ($val!=0) {
				return $val;
			}else{
				return 0;
			}
		}

		public function Return_PB_Nv($n,$s)
		{

			$bdd = $GLOBALS['bdd'];
			$val=0;
			// SÉCURISÉ : requête préparée anti-injection SQL
			$rep = $bdd->prepare('SELECT * FROM pensions where ref_n=? and ref_s=?');
			$rep->execute(array($n,$s));
			$reponse = $rep;
			while (($row = $reponse->fetch(PDO::FETCH_ASSOC))) 
			{				
				$val= (float)$row['ps_bull'];
			}
			if ($val!=0) {
				return $val;
			}else{
				return 0;
			}
		}

		public function Return_All_vsm_std($mat)
		{

			$bdd = $GLOBALS['bdd'];
			$val=0;
			// SÉCURISÉ : requête préparée anti-injection SQL
			$rep = $bdd->prepare('SELECT SUM(prix_vsm) as prix_verse FROM versements where ref_std=?');
			$rep->execute(array($mat));
			$reponse = $rep;
			while(($row = $reponse->fetch(PDO::FETCH_ASSOC))) 
			{
				$val= (float)$row['prix_verse'];
			}
			if ($val!=0) {
				return $val;
			}else{
				return 0;
			}
		}

		public function Return_All_rdt_std($mat)
		{

			$bdd = $GLOBALS['bdd'];	
			$val=0;
			// SÉCURISÉ : requête préparée anti-injection SQL
			$rep = $bdd->prepare('SELECT SUM(prix_rms) as total_rms FROM remises where ref_std=?');
			$rep->execute(array($mat));
			$reponse = $rep;
			while(($row = $reponse->fetch(PDO::FETCH_ASSOC))) 
			{
				$val=(float)$row['total_rms'];
			}
			if ($val!=0) {
				return $val;
			}else{
				return 0;
			}
		}

		


		public function NombrePensions()
		{
			$n=0;
			$ntotal=0;
			$bdd = $GLOBALS['bdd'];
			$reponse = $bdd->query("SELECT * FROM pensions where id>=1 ");

			while($row = $reponse->fetch(PDO::FETCH_ASSOC)) 
			{ 
					$n++;
			}
				$ntotal= $n;
				return $ntotal;
		}



		public function delPs($code)
		{
			$bdd = $GLOBALS['bdd'];

			$req = 'DELETE FROM pensions WHERE id=?';
			$rep = $bdd->prepare($req);
			if($rep->execute(array($code)))
			{
				return true;
			}else{
				return false;
			}
		}


		public function delVsm($code)
		{
			$bdd = $GLOBALS['bdd'];

			$req = 'DELETE FROM versements WHERE id=?';
			$rep = $bdd->prepare($req);
			if($rep->execute(array($code)))
			{
				return true;
			}
			else{
				return false;
			}
		}

		public function Full_delVsm($code)
		{
			$bdd = $GLOBALS['bdd'];
			
			$idv=$this->ReturnIdVsmByID($code);
			$req = 'DELETE FROM versements WHERE id=?';
			$rep = $bdd->prepare($req);
			if($rep->execute(array($code)))
			{
				$req1 = 'DELETE FROM remises WHERE ref_vsm=?';
			    $rep1 = $bdd->prepare($req1);
			    $rep1->execute(array($idv));
				return true;
			}
			else{
				return false;
			}
		}

		public function ReturnIdVsmByID($id)
		{

			$bdd = $GLOBALS['bdd'];	
			// SÉCURISÉ : requête préparée anti-injection SQL
			$rep = $bdd->prepare('SELECT * FROM versements where id=?');
			$rep->execute(array($id));
			$reponse = $rep;
			while (($row = $reponse->fetch(PDO::FETCH_ASSOC))) 
			{
				return $row['id_vsm'];
			}
		}


		public function GetFinanceStats()
		{
			$bdd = $GLOBALS['bdd'];
			$stats = array(
				'eleves' => 0, 'classes' => 0, 'pensions' => 0,
				'attendu' => 0, 'verse' => 0, 'remise' => 0, 'reste' => 0,
				'nb_today' => 0, 'nb_week' => 0, 'nb_month' => 0,
				'mt_today' => 0, 'mt_week' => 0, 'mt_month' => 0
			);
			$simple = array(
				'eleves'   => 'SELECT COUNT(*) FROM eleves',
				'classes'  => 'SELECT COUNT(*) FROM classes',
				'pensions' => 'SELECT COUNT(*) FROM pensions',
				'verse'    => 'SELECT COALESCE(SUM(prix_vsm),0) FROM versements',
				'remise'   => 'SELECT COALESCE(SUM(prix_rms),0) FROM remises'
			);
			foreach ($simple as $key => $sql) {
				try {
					$stats[$key] = (float)$bdd->query($sql)->fetchColumn();
				} catch (Exception $e) {
					$stats[$key] = 0;
				}
			}
			try {
				$sql = 'SELECT COALESCE(SUM(p.prix),0) FROM eleves e JOIN classes c ON c.code_class = e.ref_class JOIN pensions p ON p.ref_n = c.ref_class_niveau AND p.ref_s = c.class_session';
				$stats['attendu'] = (float)$bdd->query($sql)->fetchColumn();
			} catch (Exception $e) {
				$stats['attendu'] = 0;
			}
			$stats['reste'] = $stats['attendu'] - $stats['verse'] - $stats['remise'];
			$periods = array(
				'today' => 'DATE(post_on) = CURDATE()',
				'week'  => 'YEARWEEK(post_on, 1) = YEARWEEK(CURDATE(), 1)',
				'month' => 'YEAR(post_on) = YEAR(CURDATE()) AND MONTH(post_on) = MONTH(CURDATE())'
			);
			foreach ($periods as $key => $clause) {
				try {
					$row = $bdd->query('SELECT COUNT(*) AS nb, COALESCE(SUM(prix_vsm),0) AS mt FROM versements WHERE '.$clause)->fetch(PDO::FETCH_ASSOC);
					$stats['nb_'.$key] = (int)$row['nb'];
					$stats['mt_'.$key] = (float)$row['mt'];
				} catch (Exception $e) {
					$stats['nb_'.$key] = 0;
					$stats['mt_'.$key] = 0;
				}
			}
			return $stats;
		}


}


	$fin = new MyFinance();

?>