<?php
// Controler/classes/upd_mat_classe.php
session_start();
// Désactivation des affichages d'erreurs pour éviter de bloquer les redirections de Laragon
ini_set('display_errors', 0);
error_reporting(0);

require_once '../../Model/connexion.php';
require_once '../../core/require.php';

$bdd = $GLOBALS['bdd'];

if (isset($_POST['ref_class']) && isset($_POST['ref_mat'])) {
    
    $refcls = htmlspecialchars($_POST['ref_class']);	
    $refmat = htmlspecialchars($_POST['ref_mat']);
    
    $coeff = htmlspecialchars($_POST['coeff']);
    $groupe = htmlspecialchars($_POST['groupe']);
    $ens = htmlspecialchars($_POST['ens']);

    // Tableaux pour construire la requête SQL dynamique
    $updates = array();
    $params = array();

    // SÉCURITÉ 1 : On vérifie chaque champ pour construire une seule requête SQL propre
    if ($coeff !== "") {
        $updates[] = "coeff_mat = ?";
        $params[] = $coeff;
    }
    
    if ($groupe !== "") {
        $updates[] = "group_mat = ?";
        $params[] = $groupe;
    }
    
    if ($ens !== "") {
        $updates[] = "ref_ens = ?";
        $params[] = $ens;
    }

    // Si au moins un champ a été modifié, on exécute la mise à jour
    if (count($updates) > 0) {
        // Ajout des conditions WHERE à la fin des paramètres
        $params[] = $refcls;
        $params[] = $refmat;
        
        // Construction de la requête SQL dynamique sécurisée
        $sql = "UPDATE config_bull SET " . implode(", ", $updates) . " WHERE ref_class = ? AND ref_mat = ?";
        
        $stmt = $bdd->prepare($sql);
        $success = $stmt->execute($params);
        
        if ($success) {
            header('location: ../../config_bull.php?id=' . urlencode($refcls) . '&upd_success=1');
            exit();
        } else {
            echo "Erreur lors de la mise à jour des paramètres de la matière.";
        }
    } else {
        // Si aucun champ n'a été saisi, on redirige simplement
        header('location: ../../config_bull.php?id=' . urlencode($refcls));
        exit();
    }

} else {
    header('location: ../../config_bull.php');
    exit();
}
?>
