-- GESCOAPC / datas : script idempotent, rejouable sans doublon. N'efface ni ne modifie l'existant.
-- Referentiel SFT : departements puis matieres (ajoutes seulement s'ils n'existent pas). Ajoutez ici vos propres matieres/departements.

INSERT INTO departements (nom_dep, ref_session, abr_dep)
SELECT 'ALLEMAND', 'SFG', 'ALLEMAND' FROM DUAL
WHERE NOT EXISTS (SELECT 1 FROM departements WHERE nom_dep = 'ALLEMAND' AND ref_session = 'SFG');
INSERT INTO departements (nom_dep, ref_session, abr_dep)
SELECT 'ANGLAIS', 'SFG', 'ANGLAIS' FROM DUAL
WHERE NOT EXISTS (SELECT 1 FROM departements WHERE nom_dep = 'ANGLAIS' AND ref_session = 'SFG');
INSERT INTO departements (nom_dep, ref_session, abr_dep)
SELECT 'ARABE', 'SFG', 'ARABE' FROM DUAL
WHERE NOT EXISTS (SELECT 1 FROM departements WHERE nom_dep = 'ARABE' AND ref_session = 'SFG');
INSERT INTO departements (nom_dep, ref_session, abr_dep)
SELECT 'CHINOIS', 'SFG', 'CHINOIS' FROM DUAL
WHERE NOT EXISTS (SELECT 1 FROM departements WHERE nom_dep = 'CHINOIS' AND ref_session = 'SFG');
INSERT INTO departements (nom_dep, ref_session, abr_dep)
SELECT 'DISCIPLINE', 'SFG', 'DISCIPLINE' FROM DUAL
WHERE NOT EXISTS (SELECT 1 FROM departements WHERE nom_dep = 'DISCIPLINE' AND ref_session = 'SFG');
INSERT INTO departements (nom_dep, ref_session, abr_dep)
SELECT 'ECONOMIE SOCIALE ET FAMILIALE', 'SFG', 'ECONOMIE SOCIALE ET ' FROM DUAL
WHERE NOT EXISTS (SELECT 1 FROM departements WHERE nom_dep = 'ECONOMIE SOCIALE ET FAMILIALE' AND ref_session = 'SFG');
INSERT INTO departements (nom_dep, ref_session, abr_dep)
SELECT 'EDUCATION ARTISTIQUE ET CULTURELLE', 'SFG', 'EDUCATION ARTISTIQUE' FROM DUAL
WHERE NOT EXISTS (SELECT 1 FROM departements WHERE nom_dep = 'EDUCATION ARTISTIQUE ET CULTURELLE' AND ref_session = 'SFG');
INSERT INTO departements (nom_dep, ref_session, abr_dep)
SELECT 'EPS', 'SFG', 'EPS' FROM DUAL
WHERE NOT EXISTS (SELECT 1 FROM departements WHERE nom_dep = 'EPS' AND ref_session = 'SFG');
INSERT INTO departements (nom_dep, ref_session, abr_dep)
SELECT 'ESPAGNOL', 'SFG', 'ESPAGNOL' FROM DUAL
WHERE NOT EXISTS (SELECT 1 FROM departements WHERE nom_dep = 'ESPAGNOL' AND ref_session = 'SFG');
INSERT INTO departements (nom_dep, ref_session, abr_dep)
SELECT 'FRANCAIS', 'SFG', 'FRANCAIS' FROM DUAL
WHERE NOT EXISTS (SELECT 1 FROM departements WHERE nom_dep = 'FRANCAIS' AND ref_session = 'SFG');
INSERT INTO departements (nom_dep, ref_session, abr_dep)
SELECT 'HIST-GEO-ECM', 'SFG', 'HIST-GEO-ECM' FROM DUAL
WHERE NOT EXISTS (SELECT 1 FROM departements WHERE nom_dep = 'HIST-GEO-ECM' AND ref_session = 'SFG');
INSERT INTO departements (nom_dep, ref_session, abr_dep)
SELECT 'INFORMATIQUE', 'SFG', 'INFORMATIQUE' FROM DUAL
WHERE NOT EXISTS (SELECT 1 FROM departements WHERE nom_dep = 'INFORMATIQUE' AND ref_session = 'SFG');
INSERT INTO departements (nom_dep, ref_session, abr_dep)
SELECT 'ITALIEN', 'SFG', 'ITALIEN' FROM DUAL
WHERE NOT EXISTS (SELECT 1 FROM departements WHERE nom_dep = 'ITALIEN' AND ref_session = 'SFG');
INSERT INTO departements (nom_dep, ref_session, abr_dep)
SELECT 'LANG-CULT_NAT', 'SFG', 'LANG-CULT_NAT' FROM DUAL
WHERE NOT EXISTS (SELECT 1 FROM departements WHERE nom_dep = 'LANG-CULT_NAT' AND ref_session = 'SFG');
INSERT INTO departements (nom_dep, ref_session, abr_dep)
SELECT 'LETTRES CLASSIQUES', 'SFG', 'LETTRES CLASSIQUES' FROM DUAL
WHERE NOT EXISTS (SELECT 1 FROM departements WHERE nom_dep = 'LETTRES CLASSIQUES' AND ref_session = 'SFG');
INSERT INTO departements (nom_dep, ref_session, abr_dep)
SELECT 'MATHEMATIQUE', 'SFG', 'MATHEMATIQUE' FROM DUAL
WHERE NOT EXISTS (SELECT 1 FROM departements WHERE nom_dep = 'MATHEMATIQUE' AND ref_session = 'SFG');
INSERT INTO departements (nom_dep, ref_session, abr_dep)
SELECT 'PHYSIQUE-CHIMIE-TECHNO', 'SFG', 'PHYSIQUE-CHIMIE-TECH' FROM DUAL
WHERE NOT EXISTS (SELECT 1 FROM departements WHERE nom_dep = 'PHYSIQUE-CHIMIE-TECHNO' AND ref_session = 'SFG');
INSERT INTO departements (nom_dep, ref_session, abr_dep)
SELECT 'SVTEEHB', 'SFG', 'SVTEEHB' FROM DUAL
WHERE NOT EXISTS (SELECT 1 FROM departements WHERE nom_dep = 'SVTEEHB' AND ref_session = 'SFG');
INSERT INTO departements (nom_dep, ref_session, abr_dep)
SELECT 'GESTION ET COMMERCE', 'SFT', 'GESTION ET COMMERCE' FROM DUAL
WHERE NOT EXISTS (SELECT 1 FROM departements WHERE nom_dep = 'GESTION ET COMMERCE' AND ref_session = 'SFT');
INSERT INTO departements (nom_dep, ref_session, abr_dep)
SELECT 'TECHNOLOGIE INDUSTRIELLE', 'SFT', 'TECHNOLOGIE INDUSTRI' FROM DUAL
WHERE NOT EXISTS (SELECT 1 FROM departements WHERE nom_dep = 'TECHNOLOGIE INDUSTRIELLE' AND ref_session = 'SFT');

INSERT INTO matieres (abr_mat, nom_mat, ref_depart)
SELECT 'ALL', 'ALLEMAND', (SELECT id FROM departements WHERE nom_dep = 'ALLEMAND' AND ref_session = 'SFG' ORDER BY id LIMIT 1) FROM DUAL
WHERE NOT EXISTS (SELECT 1 FROM matieres WHERE abr_mat = 'ALL' AND nom_mat = 'ALLEMAND');
INSERT INTO matieres (abr_mat, nom_mat, ref_depart)
SELECT 'ENG', 'ANGLAIS', (SELECT id FROM departements WHERE nom_dep = 'ANGLAIS' AND ref_session = 'SFG' ORDER BY id LIMIT 1) FROM DUAL
WHERE NOT EXISTS (SELECT 1 FROM matieres WHERE abr_mat = 'ENG' AND nom_mat = 'ANGLAIS');
INSERT INTO matieres (abr_mat, nom_mat, ref_depart)
SELECT 'ARA', 'ARABE', (SELECT id FROM departements WHERE nom_dep = 'ARABE' AND ref_session = 'SFG' ORDER BY id LIMIT 1) FROM DUAL
WHERE NOT EXISTS (SELECT 1 FROM matieres WHERE abr_mat = 'ARA' AND nom_mat = 'ARABE');
INSERT INTO matieres (abr_mat, nom_mat, ref_depart)
SELECT 'CHIN', 'CHINOIS', (SELECT id FROM departements WHERE nom_dep = 'CHINOIS' AND ref_session = 'SFG' ORDER BY id LIMIT 1) FROM DUAL
WHERE NOT EXISTS (SELECT 1 FROM matieres WHERE abr_mat = 'CHIN' AND nom_mat = 'CHINOIS');
INSERT INTO matieres (abr_mat, nom_mat, ref_depart)
SELECT 'TM', 'TRAVAIL MANUEL', (SELECT id FROM departements WHERE nom_dep = 'DISCIPLINE' AND ref_session = 'SFG' ORDER BY id LIMIT 1) FROM DUAL
WHERE NOT EXISTS (SELECT 1 FROM matieres WHERE abr_mat = 'TM' AND nom_mat = 'TRAVAIL MANUEL');
INSERT INTO matieres (abr_mat, nom_mat, ref_depart)
SELECT 'ESF', 'ECO. SOC. FAMILIALE', (SELECT id FROM departements WHERE nom_dep = 'ECONOMIE SOCIALE ET FAMILIALE' AND ref_session = 'SFG' ORDER BY id LIMIT 1) FROM DUAL
WHERE NOT EXISTS (SELECT 1 FROM matieres WHERE abr_mat = 'ESF' AND nom_mat = 'ECO. SOC. FAMILIALE');
INSERT INTO matieres (abr_mat, nom_mat, ref_depart)
SELECT 'EAC', 'EDUC. ARTIST. CULT.', (SELECT id FROM departements WHERE nom_dep = 'EDUCATION ARTISTIQUE ET CULTURELLE' AND ref_session = 'SFG' ORDER BY id LIMIT 1) FROM DUAL
WHERE NOT EXISTS (SELECT 1 FROM matieres WHERE abr_mat = 'EAC' AND nom_mat = 'EDUC. ARTIST. CULT.');
INSERT INTO matieres (abr_mat, nom_mat, ref_depart)
SELECT 'EPS', 'EPS', (SELECT id FROM departements WHERE nom_dep = 'EPS' AND ref_session = 'SFG' ORDER BY id LIMIT 1) FROM DUAL
WHERE NOT EXISTS (SELECT 1 FROM matieres WHERE abr_mat = 'EPS' AND nom_mat = 'EPS');
INSERT INTO matieres (abr_mat, nom_mat, ref_depart)
SELECT 'ESP', 'ESPAGNOL', (SELECT id FROM departements WHERE nom_dep = 'ESPAGNOL' AND ref_session = 'SFG' ORDER BY id LIMIT 1) FROM DUAL
WHERE NOT EXISTS (SELECT 1 FROM matieres WHERE abr_mat = 'ESP' AND nom_mat = 'ESPAGNOL');
INSERT INTO matieres (abr_mat, nom_mat, ref_depart)
SELECT 'FR', 'FRANCAIS', (SELECT id FROM departements WHERE nom_dep = 'FRANCAIS' AND ref_session = 'SFG' ORDER BY id LIMIT 1) FROM DUAL
WHERE NOT EXISTS (SELECT 1 FROM matieres WHERE abr_mat = 'FR' AND nom_mat = 'FRANCAIS');
INSERT INTO matieres (abr_mat, nom_mat, ref_depart)
SELECT 'ECM', 'ECM', (SELECT id FROM departements WHERE nom_dep = 'HIST-GEO-ECM' AND ref_session = 'SFG' ORDER BY id LIMIT 1) FROM DUAL
WHERE NOT EXISTS (SELECT 1 FROM matieres WHERE abr_mat = 'ECM' AND nom_mat = 'ECM');
INSERT INTO matieres (abr_mat, nom_mat, ref_depart)
SELECT 'GEO', 'GEOGRAPHIE', (SELECT id FROM departements WHERE nom_dep = 'HIST-GEO-ECM' AND ref_session = 'SFG' ORDER BY id LIMIT 1) FROM DUAL
WHERE NOT EXISTS (SELECT 1 FROM matieres WHERE abr_mat = 'GEO' AND nom_mat = 'GEOGRAPHIE');
INSERT INTO matieres (abr_mat, nom_mat, ref_depart)
SELECT 'HIST', 'HISTOIRE', (SELECT id FROM departements WHERE nom_dep = 'HIST-GEO-ECM' AND ref_session = 'SFG' ORDER BY id LIMIT 1) FROM DUAL
WHERE NOT EXISTS (SELECT 1 FROM matieres WHERE abr_mat = 'HIST' AND nom_mat = 'HISTOIRE');
INSERT INTO matieres (abr_mat, nom_mat, ref_depart)
SELECT 'INFO', 'INFORMATIQUE', (SELECT id FROM departements WHERE nom_dep = 'INFORMATIQUE' AND ref_session = 'SFG' ORDER BY id LIMIT 1) FROM DUAL
WHERE NOT EXISTS (SELECT 1 FROM matieres WHERE abr_mat = 'INFO' AND nom_mat = 'INFORMATIQUE');
INSERT INTO matieres (abr_mat, nom_mat, ref_depart)
SELECT 'ITA', 'ITALIEN', (SELECT id FROM departements WHERE nom_dep = 'ITALIEN' AND ref_session = 'SFG' ORDER BY id LIMIT 1) FROM DUAL
WHERE NOT EXISTS (SELECT 1 FROM matieres WHERE abr_mat = 'ITA' AND nom_mat = 'ITALIEN');
INSERT INTO matieres (abr_mat, nom_mat, ref_depart)
SELECT 'CT', 'CULT. NAT', (SELECT id FROM departements WHERE nom_dep = 'LANG-CULT_NAT' AND ref_session = 'SFG' ORDER BY id LIMIT 1) FROM DUAL
WHERE NOT EXISTS (SELECT 1 FROM matieres WHERE abr_mat = 'CT' AND nom_mat = 'CULT. NAT');
INSERT INTO matieres (abr_mat, nom_mat, ref_depart)
SELECT 'LN', 'LANG. NAT', (SELECT id FROM departements WHERE nom_dep = 'LANG-CULT_NAT' AND ref_session = 'SFG' ORDER BY id LIMIT 1) FROM DUAL
WHERE NOT EXISTS (SELECT 1 FROM matieres WHERE abr_mat = 'LN' AND nom_mat = 'LANG. NAT');
INSERT INTO matieres (abr_mat, nom_mat, ref_depart)
SELECT 'GREC', 'GREC', (SELECT id FROM departements WHERE nom_dep = 'LETTRES CLASSIQUES' AND ref_session = 'SFG' ORDER BY id LIMIT 1) FROM DUAL
WHERE NOT EXISTS (SELECT 1 FROM matieres WHERE abr_mat = 'GREC' AND nom_mat = 'GREC');
INSERT INTO matieres (abr_mat, nom_mat, ref_depart)
SELECT 'LAT', 'LATIN', (SELECT id FROM departements WHERE nom_dep = 'LETTRES CLASSIQUES' AND ref_session = 'SFG' ORDER BY id LIMIT 1) FROM DUAL
WHERE NOT EXISTS (SELECT 1 FROM matieres WHERE abr_mat = 'LAT' AND nom_mat = 'LATIN');
INSERT INTO matieres (abr_mat, nom_mat, ref_depart)
SELECT 'MATHS', 'MATHEMATIQUES', (SELECT id FROM departements WHERE nom_dep = 'MATHEMATIQUE' AND ref_session = 'SFG' ORDER BY id LIMIT 1) FROM DUAL
WHERE NOT EXISTS (SELECT 1 FROM matieres WHERE abr_mat = 'MATHS' AND nom_mat = 'MATHEMATIQUES');
INSERT INTO matieres (abr_mat, nom_mat, ref_depart)
SELECT 'PCT', 'PCT', (SELECT id FROM departements WHERE nom_dep = 'PHYSIQUE-CHIMIE-TECHNO' AND ref_session = 'SFG' ORDER BY id LIMIT 1) FROM DUAL
WHERE NOT EXISTS (SELECT 1 FROM matieres WHERE abr_mat = 'PCT' AND nom_mat = 'PCT');
INSERT INTO matieres (abr_mat, nom_mat, ref_depart)
SELECT 'SVT', 'SVTEEHB', (SELECT id FROM departements WHERE nom_dep = 'SVTEEHB' AND ref_session = 'SFG' ORDER BY id LIMIT 1) FROM DUAL
WHERE NOT EXISTS (SELECT 1 FROM matieres WHERE abr_mat = 'SVT' AND nom_mat = 'SVTEEHB');
INSERT INTO matieres (abr_mat, nom_mat, ref_depart)
SELECT 'COMPTA', 'COMPTABILITE', (SELECT id FROM departements WHERE nom_dep = 'GESTION ET COMMERCE' AND ref_session = 'SFT' ORDER BY id LIMIT 1) FROM DUAL
WHERE NOT EXISTS (SELECT 1 FROM matieres WHERE abr_mat = 'COMPTA' AND nom_mat = 'COMPTABILITE');
INSERT INTO matieres (abr_mat, nom_mat, ref_depart)
SELECT 'DROIT', 'DROIT', (SELECT id FROM departements WHERE nom_dep = 'GESTION ET COMMERCE' AND ref_session = 'SFT' ORDER BY id LIMIT 1) FROM DUAL
WHERE NOT EXISTS (SELECT 1 FROM matieres WHERE abr_mat = 'DROIT' AND nom_mat = 'DROIT');
INSERT INTO matieres (abr_mat, nom_mat, ref_depart)
SELECT 'ECO', 'ECONOMIE', (SELECT id FROM departements WHERE nom_dep = 'GESTION ET COMMERCE' AND ref_session = 'SFT' ORDER BY id LIMIT 1) FROM DUAL
WHERE NOT EXISTS (SELECT 1 FROM matieres WHERE abr_mat = 'ECO' AND nom_mat = 'ECONOMIE');
INSERT INTO matieres (abr_mat, nom_mat, ref_depart)
SELECT 'MATH. FIN', 'MATHEMATIQUES FINANCIERES', (SELECT id FROM departements WHERE nom_dep = 'GESTION ET COMMERCE' AND ref_session = 'SFT' ORDER BY id LIMIT 1) FROM DUAL
WHERE NOT EXISTS (SELECT 1 FROM matieres WHERE abr_mat = 'MATH. FIN' AND nom_mat = 'MATHEMATIQUES FINANCIERES');
INSERT INTO matieres (abr_mat, nom_mat, ref_depart)
SELECT 'TECH. ADM', 'TECHNIQUES ADMINISTRATIVES', (SELECT id FROM departements WHERE nom_dep = 'GESTION ET COMMERCE' AND ref_session = 'SFT' ORDER BY id LIMIT 1) FROM DUAL
WHERE NOT EXISTS (SELECT 1 FROM matieres WHERE abr_mat = 'TECH. ADM' AND nom_mat = 'TECHNIQUES ADMINISTRATIVES');
INSERT INTO matieres (abr_mat, nom_mat, ref_depart)
SELECT 'TECH. COM', 'TECHNIQUES COMMERCIALES', (SELECT id FROM departements WHERE nom_dep = 'GESTION ET COMMERCE' AND ref_session = 'SFT' ORDER BY id LIMIT 1) FROM DUAL
WHERE NOT EXISTS (SELECT 1 FROM matieres WHERE abr_mat = 'TECH. COM' AND nom_mat = 'TECHNIQUES COMMERCIALES');
INSERT INTO matieres (abr_mat, nom_mat, ref_depart)
SELECT 'ATELIER', 'ATELIER', (SELECT id FROM departements WHERE nom_dep = 'TECHNOLOGIE INDUSTRIELLE' AND ref_session = 'SFT' ORDER BY id LIMIT 1) FROM DUAL
WHERE NOT EXISTS (SELECT 1 FROM matieres WHERE abr_mat = 'ATELIER' AND nom_mat = 'ATELIER');
INSERT INTO matieres (abr_mat, nom_mat, ref_depart)
SELECT 'DESS. TECH', 'DESSIN TECHNIQUE', (SELECT id FROM departements WHERE nom_dep = 'TECHNOLOGIE INDUSTRIELLE' AND ref_session = 'SFT' ORDER BY id LIMIT 1) FROM DUAL
WHERE NOT EXISTS (SELECT 1 FROM matieres WHERE abr_mat = 'DESS. TECH' AND nom_mat = 'DESSIN TECHNIQUE');
INSERT INTO matieres (abr_mat, nom_mat, ref_depart)
SELECT 'TECH. SPE', 'TECHNOLOGIE DE SPECIALITE', (SELECT id FROM departements WHERE nom_dep = 'TECHNOLOGIE INDUSTRIELLE' AND ref_session = 'SFT' ORDER BY id LIMIT 1) FROM DUAL
WHERE NOT EXISTS (SELECT 1 FROM matieres WHERE abr_mat = 'TECH. SPE' AND nom_mat = 'TECHNOLOGIE DE SPECIALITE');
INSERT INTO matieres (abr_mat, nom_mat, ref_depart)
SELECT 'TECHNO', 'TECHNOLOGIE', (SELECT id FROM departements WHERE nom_dep = 'TECHNOLOGIE INDUSTRIELLE' AND ref_session = 'SFT' ORDER BY id LIMIT 1) FROM DUAL
WHERE NOT EXISTS (SELECT 1 FROM matieres WHERE abr_mat = 'TECHNO' AND nom_mat = 'TECHNOLOGIE');
