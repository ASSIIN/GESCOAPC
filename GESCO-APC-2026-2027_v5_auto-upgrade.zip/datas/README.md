# datas/ — scripts SQL de configuration automatique

Exécutés par PHP (`core/autoconfig_core.php`) depuis le bouton **Configuration automatique** de `menu_classes.php`.
Tous les scripts sont **idempotents** : ils ajoutent seulement ce qui manque, sans rien supprimer ni modifier.

```
datas/
├─ _enseignant_modele.sql      création d'un enseignant générique (PROF ANGLAIS 1 = 1er cycle, PROF ANGLAIS 2 = 2nd cycle)
└─ SFG/ SAG/ SFT/ SAT/         une section = un dossier de 3 lettres
    ├─ 01_niveaux.sql          niveaux 1-7, cycle (1 = niveaux 1-4, 2 = niveaux 5-7), préfixe des noms de classes
    ├─ 02_referentiel.sql      départements + matières (INSERT … WHERE NOT EXISTS) — ajoutez ici vos matières/départements
    ├─ 03_modele_bulletin.sql  matières / coefficient / groupe par niveau et par « tag » (STD, ALL, ESP, C, D, A4ALL, PEBS…)
    ├─ 04_competences.sql      compétences par matière et niveau (éval. 1-2 = trimestre 1, 3-4 = trim. 2, 5-6 = trim. 3)
    ├─ 05_series.sql           séries/options par niveau (4E ALL, 4E ESP, 2NDE C, 2NDE A4 ESP, TLE D…) et tags appliqués
    └─ 06_equivalences.sql     matières équivalentes (FR = C. ORTH + E. TEXTE + EXP. E…) pour ne pas créer de doublon
```

Sources des valeurs :
- niveaux 1 à 4 (SFG) et Forms 1 à 5 (SAG) : bulletins APC Minesec (coefficients + compétences) ;
- 3e : pas de bulletin 3e ordinaire fourni → structure de la 4e ; la série « PEBS » reprend le bulletin 3e PEBS ;
- 2nd cycle SFG, L6/U6 SAG, SFT, SAT : valeurs **indicatives** (analogie) à vérifier ;
- ajouter une série ou une matière = ajouter une ligne dans les fichiers 05 / 03 (+ 02 si la matière est nouvelle).

Reprise de l'année dernière : base `gescoapc_*` de l'année précédente (liste automatique) ou fichier `.sql`
(racine, `datas/`, `datas/dumps/`, `Model/`). Copie fidèle, puis modèle standard pour les niveaux absents si coché.
