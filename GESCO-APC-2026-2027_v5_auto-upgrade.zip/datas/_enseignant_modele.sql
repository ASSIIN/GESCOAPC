-- GESCOAPC / datas : modele execute par PHP pour creer un enseignant generique (ex. PROF ANGLAIS 1 = 1er cycle, PROF ANGLAIS 2 = 2nd cycle).
-- Jetons remplaces par PHP : @@USERNAME@@, @@LOGIN@@ (code unique ; mot de passe = login, comme dans la creation habituelle), @@DEP_ID@@ (departement de la matiere).
-- N'est execute que si aucun enseignant de ce nom n'existe deja.
INSERT INTO admins (civilite, username, login, password, role, ref_dep)
SELECT 'Mr', @@USERNAME@@, @@LOGIN@@, @@LOGIN@@, 'ens', @@DEP_ID@@ FROM DUAL
WHERE NOT EXISTS (SELECT 1 FROM admins WHERE role = 'ens' AND username = @@USERNAME@@);
