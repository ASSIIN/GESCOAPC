-- GESCOAPC / datas : script idempotent, rejouable sans doublon. N'efface ni ne modifie l'existant.
-- Series / options par niveau : code (utilise dans le nom de classe), libelle, tags du modele appliques, nombre de classes propose.
DROP TEMPORARY TABLE IF EXISTS tmp_series;
CREATE TEMPORARY TABLE tmp_series (niveau int NOT NULL, serie varchar(30) NOT NULL, libelle varchar(60) NOT NULL, tags varchar(60) NOT NULL, defaut int NOT NULL) DEFAULT CHARSET=utf8mb4;
INSERT INTO tmp_series (niveau, serie, libelle, tags, defaut) VALUES
  (1, '', 'Classe', 'STD', 1),
  (1, 'LAT', 'LATIN', 'STD,LAT', 0),
  (2, '', 'Classe', 'STD', 1),
  (2, 'LAT', 'LATIN', 'STD,LAT', 0),
  (3, 'ALL', 'ALLEMAND', 'STD,ALL', 1),
  (3, 'ESP', 'ESPAGNOL', 'STD,ESP', 1),
  (3, 'ARA', 'ARABE', 'STD,ARA', 0),
  (3, 'CHIN', 'CHINOIS', 'STD,CHIN', 0),
  (3, 'ITA', 'ITALIEN', 'STD,ITA', 0),
  (3, 'LAT', 'LATIN', 'STD,LAT', 0),
  (4, 'ALL', 'ALLEMAND', 'STD,ALL', 1),
  (4, 'ESP', 'ESPAGNOL', 'STD,ESP', 1),
  (4, 'ARA', 'ARABE', 'STD,ARA', 0),
  (4, 'CHIN', 'CHINOIS', 'STD,CHIN', 0),
  (4, 'ITA', 'ITALIEN', 'STD,ITA', 0),
  (4, 'PEBS ALL', 'PEBS ALLEMAND', 'PEBS,ALL', 0),
  (4, 'PEBS ESP', 'PEBS ESPAGNOL', 'PEBS,ESP', 0),
  (5, 'C', 'Série C', 'C', 1),
  (5, 'A4 ALL', 'Série A4 ALL', 'A4ALL', 1),
  (5, 'A4 ESP', 'Série A4 ESP', 'A4ESP', 1),
  (6, 'C', 'Série C', 'C', 1),
  (6, 'D', 'Série D', 'D', 0),
  (6, 'A4 ALL', 'Série A4 ALL', 'A4ALL', 1),
  (6, 'A4 ESP', 'Série A4 ESP', 'A4ESP', 1),
  (7, 'C', 'Série C', 'C', 1),
  (7, 'D', 'Série D', 'D', 0),
  (7, 'A4 ALL', 'Série A4 ALL', 'A4ALL', 1),
  (7, 'A4 ESP', 'Série A4 ESP', 'A4ESP', 1);
