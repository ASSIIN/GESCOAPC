-- GESCOAPC / datas : script idempotent, rejouable sans doublon. N'efface ni ne modifie l'existant.
-- niveaux 1-4 = 1er cycle ; niveaux 5-7 = 2nd cycle
DROP TEMPORARY TABLE IF EXISTS tmp_niveaux;
CREATE TEMPORARY TABLE tmp_niveaux (niveau int NOT NULL, cycle int NOT NULL, prefixe varchar(20) NOT NULL, libelle varchar(60) NOT NULL) DEFAULT CHARSET=utf8mb4;
INSERT INTO tmp_niveaux (niveau, cycle, prefixe, libelle) VALUES
  (1, 1, '6EME', '6EME / 1ERE ANNEE'),
  (2, 1, '5EME', '5EME / 2EME ANNEE'),
  (3, 1, '4EME', '4EME / 3EME ANNEE'),
  (4, 1, '3EME', '3EME / 4EME ANNEE'),
  (5, 2, '2NDE', '2NDE'),
  (6, 2, '1ERE', '1ERE'),
  (7, 2, 'TLE', 'TERMINALE');
