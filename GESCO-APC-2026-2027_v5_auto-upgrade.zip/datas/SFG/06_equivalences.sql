-- GESCOAPC / datas : script idempotent, rejouable sans doublon. N'efface ni ne modifie l'existant.
-- Equivalences : si la classe possede deja la matiere de droite, la matiere de gauche n'est PAS ajoutee (evite les doublons FR / C. ORTH / E. TEXTE...).
DROP TEMPORARY TABLE IF EXISTS tmp_equiv;
CREATE TEMPORARY TABLE tmp_equiv (abr_mat varchar(50) NOT NULL, abr_equiv varchar(50) NOT NULL) DEFAULT CHARSET=utf8mb4;
INSERT INTO tmp_equiv (abr_mat, abr_equiv) VALUES
  ('FR', 'C. ORTH'),
  ('FR', 'E. TEXTE'),
  ('FR', 'EXP. E'),
  ('FR', 'LITTERATURE'),
  ('FR', 'LANGUE'),
  ('GEO', 'HG'),
  ('HIST', 'HG'),
  ('CT', 'LCN'),
  ('LN', 'LCN'),
  ('SVT', 'SC'),
  ('PCT', 'PHYS'),
  ('PCT', 'CHIM'),
  ('PCT', 'SC'),
  ('ECM', 'CIT.');
