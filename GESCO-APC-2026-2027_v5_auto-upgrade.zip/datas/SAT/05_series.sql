-- GESCOAPC / datas : script idempotent, rejouable sans doublon. N'efface ni ne modifie l'existant.
-- Series / options par niveau : code (utilise dans le nom de classe), libelle, tags du modele appliques, nombre de classes propose.
DROP TEMPORARY TABLE IF EXISTS tmp_series;
CREATE TEMPORARY TABLE tmp_series (niveau int NOT NULL, serie varchar(30) NOT NULL, libelle varchar(60) NOT NULL, tags varchar(60) NOT NULL, defaut int NOT NULL) DEFAULT CHARSET=utf8mb4;
INSERT INTO tmp_series (niveau, serie, libelle, tags, defaut) VALUES
  (1, '', 'Class', 'STD', 1),
  (2, '', 'Class', 'STD', 1),
  (3, '', 'Class', 'STD', 1),
  (4, 'INDUSTRIAL', 'Industrial', 'STD,IND', 1),
  (4, 'COMMERCIAL', 'Commercial', 'STD,COMM', 1),
  (5, 'INDUSTRIAL', 'Industrial', 'STD,IND', 1),
  (5, 'COMMERCIAL', 'Commercial', 'STD,COMM', 1),
  (6, 'INDUSTRIAL', 'Industrial', 'STD,IND', 1),
  (6, 'COMMERCIAL', 'Commercial', 'STD,COMM', 1),
  (7, 'INDUSTRIAL', 'Industrial', 'STD,IND', 1),
  (7, 'COMMERCIAL', 'Commercial', 'STD,COMM', 1);
