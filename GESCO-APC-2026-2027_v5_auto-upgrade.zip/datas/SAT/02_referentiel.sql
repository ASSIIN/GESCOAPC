-- GESCOAPC / datas : script idempotent, rejouable sans doublon. N'efface ni ne modifie l'existant.
-- Referentiel SAT : departements puis matieres (ajoutes seulement s'ils n'existent pas). Ajoutez ici vos propres matieres/departements.

INSERT INTO departements (nom_dep, ref_session, abr_dep)
SELECT 'ARTS', 'SAG', 'ARTS' FROM DUAL
WHERE NOT EXISTS (SELECT 1 FROM departements WHERE nom_dep = 'ARTS' AND ref_session = 'SAG');
INSERT INTO departements (nom_dep, ref_session, abr_dep)
SELECT 'SCIENCES', 'SAG', 'SCIENCES' FROM DUAL
WHERE NOT EXISTS (SELECT 1 FROM departements WHERE nom_dep = 'SCIENCES' AND ref_session = 'SAG');
INSERT INTO departements (nom_dep, ref_session, abr_dep)
SELECT 'TECHNICAL', 'SAG', 'TECHNICAL' FROM DUAL
WHERE NOT EXISTS (SELECT 1 FROM departements WHERE nom_dep = 'TECHNICAL' AND ref_session = 'SAG');
INSERT INTO departements (nom_dep, ref_session, abr_dep)
SELECT 'COMMERCIAL STUDIES', 'SAT', 'COMMERCIAL STUDIES' FROM DUAL
WHERE NOT EXISTS (SELECT 1 FROM departements WHERE nom_dep = 'COMMERCIAL STUDIES' AND ref_session = 'SAT');
INSERT INTO departements (nom_dep, ref_session, abr_dep)
SELECT 'TECHNICAL ENGINEERING', 'SAT', 'TECHNICAL ENGINEERIN' FROM DUAL
WHERE NOT EXISTS (SELECT 1 FROM departements WHERE nom_dep = 'TECHNICAL ENGINEERING' AND ref_session = 'SAT');

INSERT INTO matieres (abr_mat, nom_mat, ref_depart)
SELECT 'ACC', 'ACCOUNTING', (SELECT id FROM departements WHERE nom_dep = 'ARTS' AND ref_session = 'SAG' ORDER BY id LIMIT 1) FROM DUAL
WHERE NOT EXISTS (SELECT 1 FROM matieres WHERE abr_mat = 'ACC' AND nom_mat = 'ACCOUNTING');
INSERT INTO matieres (abr_mat, nom_mat, ref_depart)
SELECT 'ACN', 'ART AND CULTURE', (SELECT id FROM departements WHERE nom_dep = 'ARTS' AND ref_session = 'SAG' ORDER BY id LIMIT 1) FROM DUAL
WHERE NOT EXISTS (SELECT 1 FROM matieres WHERE abr_mat = 'ACN' AND nom_mat = 'ART AND CULTURE');
INSERT INTO matieres (abr_mat, nom_mat, ref_depart)
SELECT 'CIT.', 'CITIZENSHIP', (SELECT id FROM departements WHERE nom_dep = 'ARTS' AND ref_session = 'SAG' ORDER BY id LIMIT 1) FROM DUAL
WHERE NOT EXISTS (SELECT 1 FROM matieres WHERE abr_mat = 'CIT.' AND nom_mat = 'CITIZENSHIP');
INSERT INTO matieres (abr_mat, nom_mat, ref_depart)
SELECT 'ECON.', 'ECONOMICS', (SELECT id FROM departements WHERE nom_dep = 'ARTS' AND ref_session = 'SAG' ORDER BY id LIMIT 1) FROM DUAL
WHERE NOT EXISTS (SELECT 1 FROM matieres WHERE abr_mat = 'ECON.' AND nom_mat = 'ECONOMICS');
INSERT INTO matieres (abr_mat, nom_mat, ref_depart)
SELECT 'ENG. LANG', 'ENGLISH LANG.', (SELECT id FROM departements WHERE nom_dep = 'ARTS' AND ref_session = 'SAG' ORDER BY id LIMIT 1) FROM DUAL
WHERE NOT EXISTS (SELECT 1 FROM matieres WHERE abr_mat = 'ENG. LANG' AND nom_mat = 'ENGLISH LANG.');
INSERT INTO matieres (abr_mat, nom_mat, ref_depart)
SELECT 'FR', 'FRENCH', (SELECT id FROM departements WHERE nom_dep = 'ARTS' AND ref_session = 'SAG' ORDER BY id LIMIT 1) FROM DUAL
WHERE NOT EXISTS (SELECT 1 FROM matieres WHERE abr_mat = 'FR' AND nom_mat = 'FRENCH');
INSERT INTO matieres (abr_mat, nom_mat, ref_depart)
SELECT 'GEO', 'GEOGRAPHY', (SELECT id FROM departements WHERE nom_dep = 'ARTS' AND ref_session = 'SAG' ORDER BY id LIMIT 1) FROM DUAL
WHERE NOT EXISTS (SELECT 1 FROM matieres WHERE abr_mat = 'GEO' AND nom_mat = 'GEOGRAPHY');
INSERT INTO matieres (abr_mat, nom_mat, ref_depart)
SELECT 'HIST.', 'HISTORY', (SELECT id FROM departements WHERE nom_dep = 'ARTS' AND ref_session = 'SAG' ORDER BY id LIMIT 1) FROM DUAL
WHERE NOT EXISTS (SELECT 1 FROM matieres WHERE abr_mat = 'HIST.' AND nom_mat = 'HISTORY');
INSERT INTO matieres (abr_mat, nom_mat, ref_depart)
SELECT 'LIT IN ENG', 'LIT. IN ENGLISH', (SELECT id FROM departements WHERE nom_dep = 'ARTS' AND ref_session = 'SAG' ORDER BY id LIMIT 1) FROM DUAL
WHERE NOT EXISTS (SELECT 1 FROM matieres WHERE abr_mat = 'LIT IN ENG' AND nom_mat = 'LIT. IN ENGLISH');
INSERT INTO matieres (abr_mat, nom_mat, ref_depart)
SELECT 'LOGIC', 'LOGIC', (SELECT id FROM departements WHERE nom_dep = 'ARTS' AND ref_session = 'SAG' ORDER BY id LIMIT 1) FROM DUAL
WHERE NOT EXISTS (SELECT 1 FROM matieres WHERE abr_mat = 'LOGIC' AND nom_mat = 'LOGIC');
INSERT INTO matieres (abr_mat, nom_mat, ref_depart)
SELECT 'NCUL', 'NATIONAL CULTURE', (SELECT id FROM departements WHERE nom_dep = 'ARTS' AND ref_session = 'SAG' ORDER BY id LIMIT 1) FROM DUAL
WHERE NOT EXISTS (SELECT 1 FROM matieres WHERE abr_mat = 'NCUL' AND nom_mat = 'NATIONAL CULTURE');
INSERT INTO matieres (abr_mat, nom_mat, ref_depart)
SELECT 'NLAN', 'NATIONAL LANGUAGES', (SELECT id FROM departements WHERE nom_dep = 'ARTS' AND ref_session = 'SAG' ORDER BY id LIMIT 1) FROM DUAL
WHERE NOT EXISTS (SELECT 1 FROM matieres WHERE abr_mat = 'NLAN' AND nom_mat = 'NATIONAL LANGUAGES');
INSERT INTO matieres (abr_mat, nom_mat, ref_depart)
SELECT 'BIO', 'BIOLOGY', (SELECT id FROM departements WHERE nom_dep = 'SCIENCES' AND ref_session = 'SAG' ORDER BY id LIMIT 1) FROM DUAL
WHERE NOT EXISTS (SELECT 1 FROM matieres WHERE abr_mat = 'BIO' AND nom_mat = 'BIOLOGY');
INSERT INTO matieres (abr_mat, nom_mat, ref_depart)
SELECT 'CHE', 'CHEMISTRY', (SELECT id FROM departements WHERE nom_dep = 'SCIENCES' AND ref_session = 'SAG' ORDER BY id LIMIT 1) FROM DUAL
WHERE NOT EXISTS (SELECT 1 FROM matieres WHERE abr_mat = 'CHE' AND nom_mat = 'CHEMISTRY');
INSERT INTO matieres (abr_mat, nom_mat, ref_depart)
SELECT 'COM', 'COMMERCE', (SELECT id FROM departements WHERE nom_dep = 'SCIENCES' AND ref_session = 'SAG' ORDER BY id LIMIT 1) FROM DUAL
WHERE NOT EXISTS (SELECT 1 FROM matieres WHERE abr_mat = 'COM' AND nom_mat = 'COMMERCE');
INSERT INTO matieres (abr_mat, nom_mat, ref_depart)
SELECT 'CS', 'COMPUTER SC', (SELECT id FROM departements WHERE nom_dep = 'SCIENCES' AND ref_session = 'SAG' ORDER BY id LIMIT 1) FROM DUAL
WHERE NOT EXISTS (SELECT 1 FROM matieres WHERE abr_mat = 'CS' AND nom_mat = 'COMPUTER SC');
INSERT INTO matieres (abr_mat, nom_mat, ref_depart)
SELECT 'MATHS.', 'MATHEMATICS', (SELECT id FROM departements WHERE nom_dep = 'SCIENCES' AND ref_session = 'SAG' ORDER BY id LIMIT 1) FROM DUAL
WHERE NOT EXISTS (SELECT 1 FROM matieres WHERE abr_mat = 'MATHS.' AND nom_mat = 'MATHEMATICS');
INSERT INTO matieres (abr_mat, nom_mat, ref_depart)
SELECT 'PHYS', 'PHYSICS', (SELECT id FROM departements WHERE nom_dep = 'SCIENCES' AND ref_session = 'SAG' ORDER BY id LIMIT 1) FROM DUAL
WHERE NOT EXISTS (SELECT 1 FROM matieres WHERE abr_mat = 'PHYS' AND nom_mat = 'PHYSICS');
INSERT INTO matieres (abr_mat, nom_mat, ref_depart)
SELECT 'FAN', 'FOOD AND NUTR.', (SELECT id FROM departements WHERE nom_dep = 'TECHNICAL' AND ref_session = 'SAG' ORDER BY id LIMIT 1) FROM DUAL
WHERE NOT EXISTS (SELECT 1 FROM matieres WHERE abr_mat = 'FAN' AND nom_mat = 'FOOD AND NUTR.');
INSERT INTO matieres (abr_mat, nom_mat, ref_depart)
SELECT 'HE', 'HOME ECONOMICS', (SELECT id FROM departements WHERE nom_dep = 'TECHNICAL' AND ref_session = 'SAG' ORDER BY id LIMIT 1) FROM DUAL
WHERE NOT EXISTS (SELECT 1 FROM matieres WHERE abr_mat = 'HE' AND nom_mat = 'HOME ECONOMICS');
INSERT INTO matieres (abr_mat, nom_mat, ref_depart)
SELECT 'ML', 'MANUAL LABOUR', (SELECT id FROM departements WHERE nom_dep = 'TECHNICAL' AND ref_session = 'SAG' ORDER BY id LIMIT 1) FROM DUAL
WHERE NOT EXISTS (SELECT 1 FROM matieres WHERE abr_mat = 'ML' AND nom_mat = 'MANUAL LABOUR');
INSERT INTO matieres (abr_mat, nom_mat, ref_depart)
SELECT 'SPORTS', 'SPORTS &AMP; PHYS. EDU.', (SELECT id FROM departements WHERE nom_dep = 'TECHNICAL' AND ref_session = 'SAG' ORDER BY id LIMIT 1) FROM DUAL
WHERE NOT EXISTS (SELECT 1 FROM matieres WHERE abr_mat = 'SPORTS' AND nom_mat = 'SPORTS &AMP; PHYS. EDU.');
INSERT INTO matieres (abr_mat, nom_mat, ref_depart)
SELECT 'BUS. MATHS', 'BUSINESS MATHEMATICS', (SELECT id FROM departements WHERE nom_dep = 'COMMERCIAL STUDIES' AND ref_session = 'SAT' ORDER BY id LIMIT 1) FROM DUAL
WHERE NOT EXISTS (SELECT 1 FROM matieres WHERE abr_mat = 'BUS. MATHS' AND nom_mat = 'BUSINESS MATHEMATICS');
INSERT INTO matieres (abr_mat, nom_mat, ref_depart)
SELECT 'OFFICE PR', 'OFFICE PRACTICE', (SELECT id FROM departements WHERE nom_dep = 'COMMERCIAL STUDIES' AND ref_session = 'SAT' ORDER BY id LIMIT 1) FROM DUAL
WHERE NOT EXISTS (SELECT 1 FROM matieres WHERE abr_mat = 'OFFICE PR' AND nom_mat = 'OFFICE PRACTICE');
INSERT INTO matieres (abr_mat, nom_mat, ref_depart)
SELECT 'TECH. DRAW', 'TECHNICAL DRAWING', (SELECT id FROM departements WHERE nom_dep = 'TECHNICAL ENGINEERING' AND ref_session = 'SAT' ORDER BY id LIMIT 1) FROM DUAL
WHERE NOT EXISTS (SELECT 1 FROM matieres WHERE abr_mat = 'TECH. DRAW' AND nom_mat = 'TECHNICAL DRAWING');
INSERT INTO matieres (abr_mat, nom_mat, ref_depart)
SELECT 'TECHNOLOGY', 'TECHNOLOGY', (SELECT id FROM departements WHERE nom_dep = 'TECHNICAL ENGINEERING' AND ref_session = 'SAT' ORDER BY id LIMIT 1) FROM DUAL
WHERE NOT EXISTS (SELECT 1 FROM matieres WHERE abr_mat = 'TECHNOLOGY' AND nom_mat = 'TECHNOLOGY');
INSERT INTO matieres (abr_mat, nom_mat, ref_depart)
SELECT 'WORKSHOP', 'WORKSHOP PRACTICE', (SELECT id FROM departements WHERE nom_dep = 'TECHNICAL ENGINEERING' AND ref_session = 'SAT' ORDER BY id LIMIT 1) FROM DUAL
WHERE NOT EXISTS (SELECT 1 FROM matieres WHERE abr_mat = 'WORKSHOP' AND nom_mat = 'WORKSHOP PRACTICE');
