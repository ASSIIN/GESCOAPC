-- GESCOAPC / datas : script idempotent, rejouable sans doublon. N'efface ni ne modifie l'existant.
-- niveaux 1-4 = 1er cycle ; niveaux 5-7 = 2nd cycle
DROP TEMPORARY TABLE IF EXISTS tmp_niveaux;
CREATE TEMPORARY TABLE tmp_niveaux (niveau int NOT NULL, cycle int NOT NULL, prefixe varchar(20) NOT NULL, libelle varchar(60) NOT NULL) DEFAULT CHARSET=utf8mb4;
INSERT INTO tmp_niveaux (niveau, cycle, prefixe, libelle) VALUES
  (1, 1, 'FORM 1', 'FORM 1'),
  (2, 1, 'FORM 2', 'FORM 2'),
  (3, 1, 'FORM 3', 'FORM 3'),
  (4, 1, 'FORM 4', 'FORM 4'),
  (5, 2, 'FORM 5', 'FORM 5'),
  (6, 2, 'L6', 'LOWER SIXTH'),
  (7, 2, 'U6', 'UPPER SIXTH');
