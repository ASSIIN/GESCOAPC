<?php
if (!isset($_SESSION['user_role'])) { return; }
$role = (string) $_SESSION['user_role'];
$current = basename($_SERVER['PHP_SELF'] ?? '');
$canAdmin = in_array($role, ['admin', 'cs', 'pcpl', 'caisse'], true);
$canSchool = in_array($role, ['admin', 'cs', 'pcpl'], true);
$canFinance = in_array($role, ['admin', 'caisse'], true);
$canSg = in_array($role, ['admin', 'sg'], true);
$active = static function (array $pages) use ($current): string { return in_array($current, $pages, true) ? ' active' : ''; };
?>
<div class="sidebar-backdrop"></div>
<aside class="sidebar-wrapper" id="sidebarMenu" aria-label="Navigation principale">
  <div class="sidebar-brand">
    <a href="home.php" class="d-block"><img src="images/logo.png" alt="GESCOAPC" class="img-fluid sidebar-logo"></a>
    <div class="small sidebar-user"><i class="fa-solid fa-user me-1"></i><?= htmlspecialchars($_SESSION['login'] ?? '', ENT_QUOTES, 'UTF-8') ?></div>
    <button type="button" class="theme-toggle-btn w-100 mt-3" id="toggleTheme" data-theme-toggle>
      <i class="fa-solid fa-moon me-1" id="themeIcon" data-theme-icon></i><span id="themeText" data-theme-text> Mode sombre</span>
    </button>
  </div>
  <nav class="sidebar-scroll">
    <div class="sidebar-section-label">Espace de travail</div>
    <ul class="sidebar-menu">
      <?php if ($canAdmin): ?><li class="<?= $active(['home.php']) ?>"><a href="home.php"><i class="fa-solid fa-users"></i><span>Élèves</span></a></li><?php endif; ?>
      <?php if ($canSchool): ?>
        <li class="<?= $active(['menu_classes.php','edit_classe.php','config_competences.php']) ?>"><a href="menu_classes.php"><i class="fa-solid fa-school"></i><span>Classes</span></a></li>
        <li class="<?= $active(['menu_departements.php']) ?>"><a href="menu_departements.php"><i class="fa-solid fa-sitemap"></i><span>Départements</span></a></li>
        <li class="<?= $active(['menu_matieres.php']) ?>"><a href="menu_matieres.php"><i class="fa-solid fa-book-open"></i><span>Matières</span></a></li>
        <li class="<?= $active(['users.php']) ?>"><a href="users.php"><i class="fa-solid fa-user-group"></i><span>Personnels</span></a></li>
      <?php endif; ?>
      <li class="<?= $active(['poste_de_saisie.php','poste_de_saisie_std.php','espace_notes.php','gestion_notes.php','gestion_notes_by_mat.php','gestion_notes_by_mat_std.php']) ?>"><a href="poste_de_saisie.php?trim=t1"><i class="fa-solid fa-pen-to-square"></i><span>Édition des notes</span></a></li>
      <?php if ($canSg): ?><li class="<?= $active(['discipline.php','absences.php']) ?>"><a href="discipline.php"><i class="fa-solid fa-gavel"></i><span>Discipline & absences</span></a></li><?php endif; ?>
      <li class="<?= $active(['calculs_notes.php','config_bull.php']) ?>"><a href="calculs_notes.php"><i class="fa-solid fa-calculator"></i><span>Calculs des moyennes</span></a></li>
      <?php if ($canSchool): ?><li class="<?= $active(['config_competences.php']) ?>"><a href="config_competences.php" title="Configurer les compétences"><i class="fa-solid fa-list-check"></i><span>Gestion des compétences</span></a></li><?php endif; ?>
      <li class="<?= $active(['impression.php','bull_ind.php']) ?>"><a href="impression.php"><i class="fa-solid fa-print"></i><span>Impressions</span></a></li>
      <?php if ($canFinance): ?><li class="<?= $active(['gestion_fin.php','interface_ajout_points.php']) ?>"><a href="gestion_fin.php"><i class="fa-solid fa-wallet"></i><span>Finances</span></a></li><?php endif; ?>
      <li class="<?= $active(['operations.php','operationsa.php','reconduire_notes.php']) ?>"><a href="operations.php"><i class="fa-solid fa-clock-rotate-left"></i><span>Opérations & historique</span></a></li>
    </ul>
    <div class="sidebar-section-label">Compte</div>
    <ul class="sidebar-menu">
      <li class="<?= $active(['general_setting.php']) ?>"><a href="general_setting.php"><i class="fa-solid fa-sliders"></i><span>Gestion générale des paramètres de l'établissement</span></a></li>
      <li class="<?= $active(['account_setting.php']) ?>"><a href="account_setting.php"><i class="fa-solid fa-gear"></i><span>Paramètres du compte</span></a></li>
    </ul>
  </nav>
  <div class="sidebar-footer"><a href="exit.php" class="btn btn-danger w-100 fw-bold"><i class="fa-solid fa-power-off me-2"></i>Déconnexion</a></div>
</aside>
