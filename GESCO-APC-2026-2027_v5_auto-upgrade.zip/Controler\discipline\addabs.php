<?php
	session_start();
	require_once '../../Model/connexion.php';
	require_once '../../core/require.php'; 

	// Sécurité : connexion obligatoire
	if (!isset($_SESSION['user'])) {
		header('location: ../../index.php');
		exit;
	}

	$ref_cls= trim((string)($_POST['cls'] ?? ''));
	$ref_trim= trim((string)($_POST['trim'] ?? ''));
	$bdd = $GLOBALS['bdd'];	
	$note= array();

	// SÉCURISÉ : requête préparée anti-injection SQL
	$stmt = $bdd->prepare('SELECT mat_std FROM eleves WHERE ref_class = ?');
	$stmt->execute(array($ref_cls));
	while (($row = $stmt->fetch(PDO::FETCH_ASSOC))) 
	{
		$note[''.$row['mat_std'].'']= htmlspecialchars((string)($_POST[''.$row['mat_std'].''] ?? ''));
	}
	
	foreach ($note as $key => $value) 
	{
		if ($value!="")
		{
			if ($opt->CheckAbsStd_by_Cls($ref_cls,$key,$ref_trim)) {
				
				$bdd = $GLOBALS['bdd'];	
				// SÉCURISÉ : requête préparée anti-injection SQL (WHERE sur valeurs liées)
				$req ='UPDATE absences SET heure= ? WHERE ref_cls=? AND ref_trim=? AND ref_std=?';
				$rep = $bdd->prepare($req);
				$rep->execute(array($value, $ref_cls, $ref_trim, $key));
				
			}
			else
			{
				
				$req = "INSERT INTO absences (ref_cls, ref_std, ref_trim, heure) VALUES(?, ?, ?, ?)" ;

				$rep = $bdd->prepare($req);
				if ($rep->execute(array($ref_cls, $key, $ref_trim, $value))) {
				}
				else{
					echo "Erreur2";
				}
			}
		}
	}
	header('location: ../../discipline.php');
	exit;
?>