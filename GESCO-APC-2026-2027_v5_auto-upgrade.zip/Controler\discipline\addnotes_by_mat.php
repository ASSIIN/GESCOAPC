<?php
	session_start();
	require_once '../../Model/connexion.php';
	require_once '../../core/require.php'; 

	// Sécurité : connexion obligatoire
	if (!isset($_SESSION['user'])) {
		header('location: ../../index.php');
		exit;
	}

	$ref_cls= trim((string)($_POST['ref_cls'] ?? ''));
	$ref_mat= trim((string)($_POST['ref_mat'] ?? ''));
	$ref_seq= trim((string)($_POST['ref_seq'] ?? ''));
	$coef=$opt->SelectCoef_by_MatCls($ref_cls,$ref_mat);

	$bdd = $GLOBALS['bdd'];	
	$note= array();

	// SÉCURISÉ : requête préparée anti-injection SQL
	$stmt = $bdd->prepare('SELECT mat_std FROM eleves WHERE ref_class = ?');
	$stmt->execute(array($ref_cls));
	while (($row = $stmt->fetch(PDO::FETCH_ASSOC))) 
	{
		$note[''.$row['mat_std'].'']= htmlspecialchars((string)($_POST[''.$row['mat_std'].''] ?? ''));
	}

	foreach ($note as $key => $value) 
	{
		if ($value!="")
		{
			if ($class->CheckNoteStd_by_MatCls($ref_cls,$ref_mat,$ref_seq,$key)) {
	
				$notei=(float)$value;
				$note_x_coeff=$notei*$coef;
				$note_x_coeff=(string)$note_x_coeff;
				$bdd = $GLOBALS['bdd'];	
				// SÉCURISÉ : requête préparée anti-injection SQL (WHERE sur valeurs liées)
				$req ='UPDATE table_note_par_mat SET note= ?, note_x_coeff= ? WHERE ref_cls=? AND ref_mat=? AND ref_eval=? AND ref_std=?';

				$rep = $bdd->prepare($req);
				$rep->execute(array($value, $note_x_coeff, $ref_cls, $ref_mat, $ref_seq, $key));
				
			}
			else
			{
				
				$notei=(float)$value;
				$note_x_coeff=$notei*$coef;
				$note_x_coeff=(string)$note_x_coeff;
				$req = "INSERT INTO table_note_par_mat (ref_mat, ref_cls, ref_std, ref_eval, note, note_x_coeff) VALUES(?, ?, ?, ?, ?, ?)" ;

				$rep = $bdd->prepare($req);
				if ($rep->execute(array($ref_mat, $ref_cls, $key, $ref_seq, $value, $note_x_coeff ))) {
				}
				else{
					echo "Erreur2";
				}
			}
		}
	}
	header('location: ../../gestion_notes_by_mat.php');
	exit;
?>