<?php
session_start();
// Désactivation des affichages d'erreurs pour éviter de bloquer les redirections de Laragon
ini_set('display_errors', 0);
error_reporting(0);

require_once '../../Model/connexion.php';
require_once '../../core/require.php';

$bdd = $GLOBALS['bdd'];
    
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['competences'])) {
    
    // Sécurisation et nettoyage des paramètres initiaux
    $ref_class = htmlspecialchars($_POST['ref_class']);
    $ref_mat = htmlspecialchars($_POST['ref_mat']);
    $competences = $_POST['competences'];

    // Activation d'une transaction PDO pour décupler la vitesse d'exécution de la boucle
    $bdd->beginTransaction();

    try {
        // Préparation unique des requêtes pour optimiser la mémoire vive de Laragon
        $stmt_check = $bdd->prepare("SELECT id FROM competences_matieres WHERE ref_class = :ref_class AND ref_mat = :ref_mat AND num_compt = :num_compt LIMIT 1");
        $stmt_update = $bdd->prepare("UPDATE competences_matieres SET nom_compt = :nom_compt WHERE ref_class = :ref_class AND ref_mat = :ref_mat AND num_compt = :num_compt");
        $stmt_insert = $bdd->prepare("INSERT INTO competences_matieres (ref_class, ref_mat, num_compt, nom_compt) VALUES (:ref_class, :ref_mat, :num_compt, :nom_compt)");

        // Traitement itératif des 6 compétences du formulaire
        foreach ($competences as $num_compt => $nom_compt) {
            
            $num_compt = (int)$num_compt;
            // Nettoyage et conversion en majuscules propres
            $nom_compt = mb_strtoupper(trim(preg_replace('/\s+/', ' ', htmlspecialchars($nom_compt))), 'UTF-8');

            // Sécurité : évite un libellé vide si l'utilisateur efface le texte
            if (empty($nom_compt)) {
                $nom_compt = 'COMPETENCE ' . $num_compt;
            }

            // 1. Vérification de l'existence de la ligne
            $stmt_check->bindParam(':ref_class', $ref_class);
            $stmt_check->bindParam(':ref_mat', $ref_mat);
            $stmt_check->bindParam(':num_compt', $num_compt);
            $stmt_check->execute();
            $existing = $stmt_check->fetch();

            if ($existing) {
                // 2. Mise à jour de la compétence existante
                $stmt_update->bindParam(':nom_compt', $nom_compt);
                $stmt_update->bindParam(':ref_class', $ref_class);
                $stmt_update->bindParam(':ref_mat', $ref_mat);
                $stmt_update->bindParam(':num_compt', $num_compt);
                $stmt_update->execute();
            } else {
                // 3. Insertion de secours si la ligne avait été accidentellement supprimée
                $stmt_insert->bindParam(':ref_class', $ref_class);
                $stmt_insert->bindParam(':ref_mat', $ref_mat);
                $stmt_insert->bindParam(':num_compt', $num_compt);
                $stmt_insert->bindParam(':nom_compt', $nom_compt);
                $stmt_insert->execute();
            }
        }

        // Validation définitive de toutes les écritures de la transaction
        $bdd->commit();
        
        // Redirection vers l'interface de configuration avec message de succès personnalisé
        header('Location: ../../config_competences.php?id=' . urlencode($ref_class) . '&ref_mat=' . urlencode($ref_mat) . '&message=' . urlencode('Compétences mises à jour avec succès'));
        exit;

    } catch (PDOException $e) {
        // En cas de panne de courant ou d'erreur SQL, annulation complète pour protéger la base
        $bdd->rollBack();
        echo "Erreur lors de l'enregistrement des compétences : " . $e->getMessage();
    }
} else {
    header('Location: ../../menu_classes.php');
    exit;
}
?>
