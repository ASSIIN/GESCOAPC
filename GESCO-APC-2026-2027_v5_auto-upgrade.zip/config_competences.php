<?php
    session_start();   
	require_once 'core/require.php'; 
	require_once 'Model/connexion.php';
     if (!isset($_SESSION['user'])) {
    session_unset();
    session_destroy();
    header('location: index.php');    
     exit;
    }

     if (!in_array($_SESSION['user_role'] ?? '', ['admin', 'cs', 'pcpl'], true)) {
       header('location: poste_de_saisie.php?trim=t1');    
       exit;
    }
    //Virifions si la classes Existe
      if (isset($_GET['id']) ) 
    {
    
$ckcls=$class->CkExistingCode($_GET['id']);

        if (($_GET['id']=="") || ($ckcls == false)) {
      
             header('location: menu_classes.php');    
          }
        
      else{
         $ref_classe=htmlspecialchars($_GET['id']);
         if (isset($_GET['ref_mat']) and $_GET['ref_mat'] !="" ) {
           $ref_mat=htmlspecialchars($_GET['ref_mat']);
         }

         else
         {
           $ref_mat=$class->getStartConfigMatBull_by_cls($ref_classe);
         }
         // Filtre de sécurité : la matière doit appartenir à la configuration de la classe
         if (!empty($ref_mat) && !$class->CkMatbyCls($ref_classe, $ref_mat)) {
            $ref_mat=$class->getStartConfigMatBull_by_cls($ref_classe);
         }
        
      }
    }
    else{
        $startcls=$class->getStartClasseCode();
        $startmat=$class->getStartConfigMatBull();
          if ($startcls==null) 
          {
             header('location: menu_classes.php');
          }
          else{
            $ref_classe=$startcls;
            $ref_mat= $startmat;
          }
    }
    $etb->ShowEtb();
    $etb->CkLE();
    $etb->ckexneE(); 
    $class->ShowClassInfos($ref_classe);
    $nbmat=$class->NombreMatbyCls($ref_classe);
    $nnPP=$class->ShowNom_Cls_Master($ref_classe);
    $nbcoeff=$class->NombreCoeffbyCls($ref_classe);
    $nbclasses=$class->NombreClasses();

    $nextcls=$class->getNextClasseCode($ref_classe);
    $precls=$class->getPreClasseCode($ref_classe);

    $nextmat=$class->getNextMatCode($ref_classe,$ref_mat);
    $premat=$class->getPreMatCode($ref_classe,$ref_mat);

    $bdd = $GLOBALS['bdd'];

    $ref_class = $ref_classe;
     $ref_mat = $ref_mat;
// Récupérer les compétences existantes pour la classe et la matière
$stmt = $bdd->prepare("SELECT num_compt, nom_compt FROM competences_matieres WHERE ref_class = :ref_class AND ref_mat = :ref_mat");
$stmt->bindParam(':ref_class', $ref_class);
$stmt->bindParam(':ref_mat', $ref_mat);
$stmt->execute();
$competences = [];
while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
    $competences[$row['num_compt']] = $row['nom_compt'];
}

// Préparer les données pour le formulaire
$nom_mat = $class->ReturnNomMatbyRef($ref_mat); // Vous pouvez récupérer le nom de la matière depuis une requête si nécessaire
?>

<!DOCTYPE html>
<html>
  <head>
   <?php Config::head(); ?>
    <title>GESCOAPC| CONFIG_BULLETIN</title>
  </head>

<body>
    <div class="wrapper">
      <!-- Sidebar -->

      <!-- Inclusion du menu de navigation externe réutilisable -->
      <?php include 'core/sidebar.php'; ?>  
       
      <div class="main-content-wrapper">
        <!-- Barre supérieure de navigation adaptative -->
        <div class="mobile-navbar-fixed p-3 mb-4 rounded shadow-sm border">
            <div class="row align-items-center g-2">
                <div class="col-auto d-md-none">
                    <button class="btn btn-outline-dark btn-sm" id="toggleMobileMenu"><i class="fa fa-bars fa-lg"></i></button>
                </div>
                <div class="col-12 col-md">
                    <h4 class="m-0 fw-bold text-primary text-uppercase">Paramétrage des compétences</h4>
                </div>
                <div class="col-12 col-md-auto d-flex justify-content-md-end flex-wrap gap-1">
                    <span class="badge bg-success align-self-center"><i class="fa fa-tag"></i> <?php echo $_SESSION['class_session']; ?></span>
                    <button type="button" class="btn btn-primary btn-sm" data-bs-toggle="modal" data-bs-target="#clone" data-whatever="@mdo">Cloner <i class="fa fa-copy"></i></button>
                </div>
            </div>
            <div class="row g-2 mt-2 pt-2 border-top">
                <div class="col-md-6 d-flex align-items-center justify-content-start gap-1 flex-wrap">
                    <?php if ($precls!=null) { echo '<a href="config_competences.php?id='.$precls.'" class="btn btn-outline-success btn-sm">Précédent <i class="fa fa-arrow-left"></i></a>'; } else { echo '<a href="#" class="btn btn-outline-success btn-sm disabled">Précédent <i class="fa fa-arrow-left"></i></a>'; } ?>
                    <strong class="text-success mx-1"><?php echo $_SESSION['nom_class']; ?></strong>
                    <?php if ($nextcls!=null) { echo '<a href="config_competences.php?id='.$nextcls.'" class="btn btn-outline-success btn-sm">Suivant <i class="fa fa-arrow-right"></i></a>'; } else { echo '<a href="#" class="btn btn-outline-success btn-sm disabled">Suivant <i class="fa fa-arrow-right"></i></a>'; } ?>
                </div>
                <div class="col-md-6 d-flex align-items-center justify-content-md-end gap-1 flex-wrap mt-1">
                    <?php if ($premat!=null) { echo '<a href="config_competences.php?id='.$ref_class.'&ref_mat='.$premat.'" class="btn btn-outline-success btn-sm">Précédent <i class="fa fa-arrow-left"></i></a>'; } else { echo '<a href="#" class="btn btn-outline-success btn-sm disabled">Précédent <i class="fa fa-arrow-left"></i></a>'; } ?>
                    <strong class="text-muted mx-1"><?php echo $nom_mat; ?></strong>
                    <?php if ($nextmat!=null) { echo '<a href="config_competences.php?id='.$ref_class.'&ref_mat='.$nextmat.'" class="btn btn-outline-success btn-sm">Suivant <i class="fa fa-arrow-right"></i></a>'; } else { echo '<a href="#" class="btn btn-outline-success btn-sm disabled">Suivant <i class="fa fa-arrow-right"></i></a>'; } ?>
                </div>
            </div>
        </div>

      <div class="container-fluid">
          <div class="row mt-3">
              <div class="text-center w-100">
                  <h4 class="mt-3">Paramétrage du bulletin</h4>
              </div>
          </div>
      </div>
     <div class="container-fluid mt-3 mb-2">
    <h4 class="text-center">Compétences pour la classe <?= htmlspecialchars($ref_class); ?> - Matière: <?= htmlspecialchars($nom_mat); ?> <i class="fa fa-book"></i></h4>
    <form method="POST" action="Controler/classes/upd_compt_by_mat_by_classe.php">
        <input type="hidden" name="ref_class" value="<?= htmlspecialchars($ref_class); ?>">
        <input type="hidden" name="ref_mat" value="<?= htmlspecialchars($ref_mat); ?>">
        <table class="table table-striped table-hover">
            <thead class="table-dark">
                <tr>
                    <th width="10%">Compétence</th>
                    <th width="90%">Description</th>
                </tr>
            </thead>
            <tbody>
                <?php for ($i = 1; $i <= 6; $i++) { 
                    $competence = isset($competences[$i]) ? $competences[$i] : '';
                ?>
                    <tr>
                        <td>
                            <label for="competence<?= $i; ?>">Compétence <?= $i; ?></label>
                        </td>
                        <td>
                            <textarea class="form-control" id="competence<?= $i; ?>" name="competences[<?= $i; ?>]" rows="2"><?= htmlspecialchars($competence); ?></textarea>
                        </td>
                    </tr>
                <?php } ?>
            </tbody>
        </table>
        <button type="submit" class="btn btn-primary"><i class="fa fa-save"></i> Mettre à jour les compétences</button>

    </form>
</div>

    <div class="modal fade" id="clone" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                      <div class="modal-dialog" role="document">
                        <div class="modal-content">
                          <div class="modal-header">
                            <h5 class="modal-title" id="exampleModalLabel">CLONER LA CONFIGURATION</h5>
<button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                          </div>
                          <div class="modal-body">
                              <h5 class="modal-title" id="exampleModalLabel">Cloner les parametrages des competences de cette matière avec d'autres classes<br></h5>
                                                
                    <form action="Controler/classes/clone_upd_compt_by_mat_by_classe.php" method="post" >
                      <input type="text" class="form-control" id="ref_class" name="ref_class"  hidden="true" value="<?php echo $ref_classe; ?>">
                      <input type="text" class="form-control" id="ref_mat" name="ref_mat"  hidden="true" value="<?php echo $ref_mat; ?>">
                    
                          <div class="mb-3">
                              <label for="groupe" class="form-label">Type</label>
                              <select id="groupe" name="type" class="form-select" required> 
                                  <option value="nv">Par Niveau</option>
                                  <option value="all">Toutes les classes de la section</option>
                              </select>
                          </div>     
                                </div>
                                <div class="modal-footer">
                                 <button  class="btn btn-primary">Remplacer et copier</button>
                                  <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Annuler</button>
                              </div>
                            </form>
                        </div>
                  </div>
          </div>
            </div>
                
            </div>
           
      
      </div>
        <!-- ============================================================== -->
        <!-- End Page Content -->
        <!-- ============================================================== -->


		<?php 
		 	Config::scriptJs();
		?>

     <script type="text/javascript">
        
        </script>
        <script type="text/javascript">
            $('#exampleModal').on('show.bs.modal', function (event) {
  var button = $(event.relatedTarget) // Button that triggered the modal
  var recipient = button.data('whatever') // Extract info from data-* attributes
  // If necessary, you could initiate an AJAX request here (and then do the updating in a callback).
  // Update the modal's content. We'll use jQuery here, but you could use a data binding library or other methods instead.
  var modal = $(this)
  modal.find('.modal-title').text('New message to ' + recipient)
  modal.find('.modal-body input').val(recipient)
})
        </script>
	</body>
</html>