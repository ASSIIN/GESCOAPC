<?php
session_start();
require_once '../Model/connexion.php';
require_once '../core/require.php';
 if (!isset($_SESSION['user'])) {
    session_unset();
    session_destroy();
    header('location: ../index.php');    
    }
if ((!isset($_GET['cag']) or !isset($_GET['cfg']) or !isset($_GET['cft']) or !isset($_GET['cat'])) and (!isset($_GET['vall_trim']))) {
	header('location: ../impression.php?e');
}

$elt= array('cfg' =>htmlspecialchars($_GET['cfg']), 'cag' =>htmlspecialchars($_GET['cag']), 'cft' =>htmlspecialchars($_GET['cft']), 'cat' =>htmlspecialchars($_GET['cat']));
		
		foreach ($elt as $key => $value) {
			if ($value!="") {
		$refcls=$value;
	  }
}
	$refbul=htmlspecialchars($_GET['vall_trim']);
 	 $ckcls=$class->CkExistingCode($refcls);
    if (($refcls=="") or ($ckcls==false)) 
    {
    header('location: ../impression.php?ec=0');
	}

	elseif (!$exist_moy=$opt->Ck_ExistMoy_by_Cls($refcls,$refbul)) {
		header('location: ../calculs_notes.php');
	}

 $etb->ShowEtb();
$today=date('d-m-Y');

$faibles_mat='';
$nomcls='';
		if ($refbul=='1') {
			$eval1='1';
			$eval2='2';
			$titreB='BULLETIN DU TRIM 1 / TERM 1  REPORT CARD';
			$titreE='trim 1';
		}elseif($refbul=='2') {
			$eval1='3';
			$eval2='4';
			$titreB='BULLETIN DU TRIM 2 / TERM 2 REPORT CARD';
			$titreE='trim 2';
		}elseif($refbul=='3') {
			$eval1='5';
			$eval2='6';
			$titreB='BULLETIN DU TRIM 3 / TERM 3 REPORT CARD';
			$titreE='trim 3';
		}else{
			$titreB='BULLETIN ANNUEL / ANNUAL REPORT CARD';
			$titreE='Bull Ann';
			$eval1='5';
			$eval2='6';

		}

require('fpdf.php');
$pdf = new FPDF();

class PDF extends FPDF
{
// En-tête
function Header()
{
	 $this->SetY(15);
    // Logo
    $this->Image('../plugins/images/'.$_SESSION['logo_etb'].'',10,6,30);
    // Police Arial gras 15
    $this->SetFont('Arial','B',15);
    // Décalage à droite
    $this->Cell(80);
    // Titre
    $this->Cell(30,10,'Titre',1,0,'C');
    // Saut de ligne
    $this->Ln(20);
}

// Pied de page
function Footer()
{
    // Positionnement à 1,5 cm du bas
    $this->SetY(-15);
    // Police Arial italique 8
    $this->SetFont('Arial','I',8);
    // Numéro de page
    $this->Cell(0,10,'Page '.$this->PageNo().'/{nb}',0,0,'C');
}
}
	$bdd = $GLOBALS['bdd'];
		$reponse0 = $bdd->query('SELECT * FROM eleves where ref_class="'.$refcls.'" order by nom_std asc');
		while($row0 = $reponse0->fetch(PDO::FETCH_ASSOC)) 
		{
			$refstd=$row0['mat_std'];
			$stdclasser=$class->RetrunStd_ClasserbyTrim($refbul,$refstd);

			$pdf->AddPage();
			//code for print data

	$bdd = $GLOBALS['bdd'];
	$reponse = $bdd->query('SELECT * FROM config_bull where ref_class="'.$refcls.'" order by group_mat asc');

	/*En-tête*/
		$pdf->SetFont('Times','',8);
		$pdf->Image('../plugins/images/'.$_SESSION['logo_etb'].'',92,15,30);
		$pdf->Cell(70,4,'REPUBLIQUE DU CAMEROUN',0,0,'C');
		$pdf->Cell(50,4,'',0,0);
		$pdf->Cell(70,4,'REPUBLIC OF CAMEROON',0,1,'C');

		$pdf->Cell(70,4,'Paix-Travail-Patrie',0,0,'C');
		$pdf->Cell(50,4,'',0,0);
		$pdf->Cell(70,4,'Peace-Work-Fatherland',0,1,'C');

		$pdf->Cell(70,4, utf8_to_cp1252("".$_SESSION['minist_etb_fr'].""),0,0,'C');
		$pdf->Cell(50,4,'',0,0);
		$pdf->Cell(70,4,utf8_to_cp1252(''.$_SESSION['minist_etb_en'].''),0,1,'C');

		$pdf->Cell(70,4,utf8_to_cp1252("".$_SESSION['region_etb_fr'].""),0,0,'C');
		$pdf->Cell(50,4,'',0,0);
		$pdf->Cell(70,4,utf8_to_cp1252(''.$_SESSION['region_etb_en'].''),0,1,'C');

		$pdf->Cell(70,4,utf8_to_cp1252(''.$_SESSION['depart_etb_fr'].''),0,0,'C');
		$pdf->Cell(50,4,'',0,0);
		$pdf->Cell(70,4,utf8_to_cp1252(''.$_SESSION['depart_etb_en'].''),0,1,'C');
		$pdf->SetFont('Times','B',10);
		$pdf->Cell(70,6,utf8_to_cp1252(''.$_SESSION['nom_etb_fr'].''),0,0,'C');
		$pdf->Cell(50,6,'',0,0);
		$pdf->Cell(70,6,utf8_to_cp1252(''.$_SESSION['nom_etb_en'].''),0,1,'C');
		$pdf->SetFont('Times','',8);
		$pdf->Cell(70,5,utf8_to_cp1252(''.$_SESSION['code_pste_etb'].' / '.$_SESSION['tel_etb'].''),0,0,'C');
		$pdf->Cell(50,5,'',0,0);
		$pdf->Cell(70,5,utf8_to_cp1252(''.$_SESSION['code_pste_etb'].'/ '.$_SESSION['tel_etb'].''),0,1,'C');
		$pdf->SetFont('Times','',8);
		$pdf->Cell(70,4,utf8_to_cp1252(''.$_SESSION['email_etb'].''),0,0,'C');
		$pdf->Cell(50,4,'',0,0);
		$pdf->Cell(70,4,utf8_to_cp1252(''.$_SESSION['email_etb'].''),0,1,'C');
			$pdf->Ln();
			$pdf->SetFont('Times','I',12);
			$pdf->Cell(65,5,'',0,0);
			$pdf->Cell(60,5,utf8_to_cp1252(''.$_SESSION['code_im_etb'].''),0,0,'C');
			$pdf->Ln();
			$pdf->Ln();
	/*FIN En-tête*/
	//Titre 
				$pdf->SetFont('Times','I',10);
				$pdf->Cell(50,5,'',0,0,'C');
				$pdf->Cell(60,5,'ANNEE SCOLAIRE/SCHOOL ',0,0,'R');
				$pdf->SetFont('Times','B',12);
				$pdf->Cell(40,5,''.$_SESSION['school_year'].'',0,0,'L');
				$pdf->Cell(40,5,'',0,1,'C');
	
	$pdf->SetFont('Times','B',13);

	$pdf->SetFillColor(171,177,186);
	$pdf->SetFillColor(0,167,223);
	$pdf->Cell(40,8,'',0,0,'C');
	$pdf->Cell(110,8,$titreB,1,0,'C',1);
	$pdf->Cell(20,8,'',0,1,'C');
	$pdf->Ln();
	//les information sur la classe

	$class->CkClasseByCode($refcls);
	$nbstd=$class->NbrStudentByClass($refcls);
	$nbstdclasser=$opt->NbrStudentClasserByClass($refcls,$refbul);
	$nbstdclasser=(float)$nbstdclasser;
	$nbM=$class->NbrBySexeByClass($refcls,'M');
	$nbF=$class->NbrBySexeByClass($refcls,'F');
	$nomcls=$_SESSION['nom_class'];
	$niveaucls=$_SESSION['ref_class_niveau'];
	$pdf->SetFont('Times','',10);

	$pdf->Cell(50,4,"Classe/Class: $nomcls",0,0,'L');
	$pdf->Cell(30,4,"Code: ($refcls)",0,0,'C');
	$pdf->Cell(20,4,"Niv/Level: $niveaucls",0,0,'C');
	$pdf->Cell(20,4,"Eff: $nbstd",0,0,'C');
	$pdf->Cell(10,4,"M: $nbM",0,0,'C');
	$pdf->Cell(10,4,"F: $nbF",0,0,'C');
	$pdf->Ln();
	$pdf->Cell(190,4,'',2,0,'C',0);
	$pdf->Ln();
		//les information de l'eleve
	$std->CkStdByCode_for_Bul($refstd);
	$num=$class->NumStudentByClass($refcls,$refstd);
	$rangstd=$opt->ShowRang_Std($refcls,$refstd,$refbul);
	$classer_std=$opt->ShowClasser_Std($refcls,$refstd,$refbul);
	$HeureAbs=$opt->ShowAbsStd_by_Cls($refcls,$refstd,$refbul);
	$nomstd=$_SESSION['nom_std'];
	$matstd=$_SESSION['mat_std'];
	$sexestd=$_SESSION['sexe_std'];
	$naissstd=$_SESSION['date_fr'];
	$lieu_nais=$_SESSION['lieu_nais'];
	$statut=$_SESSION['statut'];
	$rangstd=(string)$rangstd;
	$strrangstd='';
	if (($rangstd=='1') or ($rangstd=='21') or ($rangstd=='31') or ($rangstd=='41') or ($rangstd=='51') or ($rangstd=='61') or ($rangstd=='71') or ($rangstd=='81') or ($rangstd=='91') or ($rangstd=='101') or ($rangstd=='121') or ($rangstd=='131') or ($rangstd=='141') or ($rangstd=='151') or ($rangstd=='161') or ($rangstd=='171') or ($rangstd=='181') or ($rangstd=='191') or $rangstd=='201' or $rangstd=='221' or $rangstd=='231' or $rangstd=='241' or $rangstd=='251' or $rangstd=='261' or $rangstd=='271' or $rangstd=='281' or $rangstd=='291') {
		if ($sexestd=='M') {
			$strrangstd='er(st)';
		}else{
			$strrangstd='ere(st)';
		}
		
	}
	elseif ($rangstd=='2' or $rangstd=='22' or $rangstd=='32' or $rangstd=='42' or $rangstd=='52' or $rangstd=='62' or $rangstd=='72' or $rangstd=='82' or $rangstd=='92' or $rangstd=='102' or $rangstd=='122' or $rangstd=='132' or $rangstd=='142' or $rangstd=='152' or $rangstd=='162' or $rangstd=='172' or $rangstd=='182' or $rangstd=='192' or $rangstd=='202' or $rangstd=='222' or $rangstd=='232' or $rangstd=='242' or $rangstd=='252' or $rangstd=='262' or $rangstd=='272' or $rangstd=='282' or $rangstd=='292') {
		$strrangstd='e(nd)';
	}
	elseif ($rangstd=='3' or $rangstd=='23' or $rangstd=='33' or $rangstd=='43' or $rangstd=='53' or $rangstd=='63' or $rangstd=='73' or $rangstd=='83' or $rangstd=='93' or $rangstd=='103' or $rangstd=='123' or $rangstd=='133' or $rangstd=='143' or $rangstd=='153' or $rangstd=='163' or $rangstd=='173' or $rangstd=='183' or $rangstd=='193' or  $rangstd=='203' or $rangstd=='223' or $rangstd=='233' or $rangstd=='243' or $rangstd=='253' or $rangstd=='263' or $rangstd=='273' or $rangstd=='283' or $rangstd=='293') {
		$strrangstd='e(rd)';
	}else
	{
		if ($classer_std=='Y') {
			$strrangstd='e(th)';
		}else{
			$strrangstd='';
			
		}

		
	}
				
	$pdf->Image('../plugins/images/imgstd/'.$_SESSION['contenu_std'].'',165,50,25);
	$pdf->SetFont('Times','',10);
	$pdf->Cell(20,5,"Noms/Name:",1,0,'L');
	$pdf->SetFont('Times','B',10);
	$pdf->Cell(110,5,utf8_to_cp1252("$nomstd"),1,0,'L');
	$pdf->SetFont('Times','',10);
	$pdf->Cell(25,5,"Redouble: $statut",1,0,'L');
	$pdf->Cell(25,5,"Sexe/Sex: $sexestd",1,0,'C');

	$pdf->Ln();
	$pdf->Cell(50,5,utf8_to_cp1252("Né(e) le/Born on: $naissstd"),1,0,'L');
	$pdf->Cell(80,5,utf8_to_cp1252("A/At: $lieu_nais"),1,0,'L');
	$pdf->Cell(35,5,utf8_to_cp1252('Matr: '.$_SESSION['pre_matr'].''.$matstd.''),1,0,'L');
	$pdf->Cell(15,5,utf8_to_cp1252("N°: $num"),1,0,'L');
	

	$pdf->SetFont('Times','B',10);
	$pdf->Ln();
	
	$pdf->Cell(190,3,'',2,0,'C',0);
	$pdf->Ln();
	$pdf->SetFillColor(0,167,223);
	/*matiere*/$pdf->Cell(50,5,utf8_to_cp1252('MATIERES / SUBJECTS'),1,0,'C',1);
	/*EVAL1*/$pdf->Cell(15,5,'EVAL1',1,0,'C',1);
	/*EVAL2*/$pdf->Cell(15,5,'EVAL2',1,0,'C',1);
	/*MOY*/$pdf->Cell(15,5,'MOY',1,0,'C',1);
	/*COEFF*/$pdf->Cell(10,5,'CF',1,0,'C',1);
	/*M*C*/$pdf->Cell(15,5,'M*CF',1,0,'C',1);
	/*TOTAL*/$pdf->Cell(15,5,'APPRT',1,0,'C',1);
	/*COMPETENCE*/$pdf->Cell(55,5,'ENSEIGNANT/TEACHER',1,0,'C',1);

	

	/*matieres G1*/

		/*initiation des paramètres*/
		$Totalcoeff=0;
		$Totalpoint=0;

		$bdd = $GLOBALS['bdd'];
		$reponse = $bdd->query('SELECT * FROM config_bull where (ref_class="'.$refcls.'" and group_mat="1")  order by nom_mat asc');
 
		while($row = $reponse->fetch(PDO::FETCH_ASSOC)) 
		{
			$cknote1=$class->SelectNoteStd_by_MatCls($refcls,$row['ref_mat'],$eval1,$refstd);
			$cknote2=$class->SelectNoteStd_by_MatCls($refcls,$row['ref_mat'],$eval2,$refstd);
			$nmat=$mat->ReturnNom_matByIdname($row['ref_mat']);
			$teacher=$user->SelectTeacherName_by_mat_by_cls($row['ref_ens']);
			/*contraintes */
				if (($cknote1<0) and ($cknote2>=0)) 
				{
					$note1='--';
					$note2=(float)$cknote2;
					$coeff=(float)$row['coeff_mat'];
					$note2=round($note2,2);
					$moy=$note2;
					$moy=round($moy,2);
					$total=$moy*$coeff;
					$total=round($total,2);
				}
				elseif (($cknote1>=0) and ($cknote2<0)) {
					$note2='--';
					$note1=(float)$cknote1;
					$coeff=(float)$row['coeff_mat'];
					$note1=round($note1,2);
					$moy=$note1;
					$moy=round($moy,2);
					$total=$moy*$coeff;
					$total=round($total,2);
				}
				elseif (($cknote1<0) and ($cknote2<0)) 
				{
					$note1='--';
					$note2='--';
					$coeff='--';
					$moy='--';
					
					$total='--';
				}
				else 
				{
					
					/*conversions pour les calculs*/
					$note1=(float)$cknote1;
					$note2=(float)$cknote2;
					$note1=round($note1,2);
					$note2=round($note2,2);
					$coeff=(float)$row['coeff_mat'];
					$moy=($note1+$note2)/2;
					$moy=round($moy,2);
					$total=$moy*$coeff;
					$total=round($total,2);
				}
				$Totalcoeff+=(float)$coeff;
				$Totalpoint+=(float)$total;

				/*APPRECIATION*/
				if (($moy>=0) and ($moy<10)) {
					$apr="N A";
				}elseif (($moy>=10) and ($moy<13)) {
					$apr="E C A";
				}
				elseif (($moy>=13) and ($moy<20)) {
					$apr="A";
				}else{
					$apr="--";
				}

			

				$pdf->SetFont('Arial','',9);
				$pdf->Ln();

				/*matiere*/$pdf->Cell(50,4,utf8_to_cp1252($row['nom_mat']),1,0);
				/*EVAL1*/$pdf->Cell(15,4,$note1,1,0,'C');
				/*EVAL2*/$pdf->Cell(15,4,$note2,1,0,'C');
				/*MOY*/$pdf->Cell(15,4,$moy,1,0,'C');
				/*COEFF*/$pdf->Cell(10,4,utf8_to_cp1252($row['coeff_mat']),1,0,'C');
				/*M*C*/$pdf->Cell(15,4,$total,1,0,'C');
				/*TOTAL*/$pdf->Cell(15,4,$apr,1,0,'C');
				/*COMPETENCE*/$pdf->Cell(55,4,$teacher,1,0,'L');
		

				/*Matiere faibles*/
				if (($moy<10) and ($moy!="--")) {
					$faibles_mat.=$nmat.', ';		
				}
				/*Fin Matiere faibles*/

			}

			$pdf->Ln();
			if ($Totalcoeff==0) {
				$moyG1='--';
			}
			else{
				$moyG1=$Totalpoint/$Totalcoeff;
				$moyG1=round($moyG1,2);
			}
			

			/*APPRECIATION*/
			if (($moyG1>=0) and ($moyG1<10)) {
				$aprG1="N A";
			}elseif (($moyG1>=10) and ($moyG1<13)) {
				$aprG1="E C A";
			}
			elseif (($moyG1>=13) and ($moyG1<20)) {
				$aprG1="A";
			}else{
				$aprG1="--";
			}
			$pdf->SetFont('Arial','B',9);
			$pdf->SetFillColor(236,235,2);
			$pdf->Cell(95,5,'TOTAL GROUPE/GROUP 1',1,0,'C',1);
			$pdf->Cell(10,5,$Totalcoeff,1,0,'C',1);
			$pdf->Cell(15,5,$Totalpoint,1,0,'C',1);
			$pdf->Cell(45,5,' Moy/Avg G1 = '.$moyG1.'',1,0,'C',1);
			$pdf->Cell(25,5,' Apprt:'.$aprG1.'',1,0,'C',1);

	/*FIN G1*/

	/*matieres G2*/

		/*initiation des paramètres*/
		$TotalcoeffG2=0;
		$TotalpointG2=0;

		$bdd = $GLOBALS['bdd'];
		$reponse = $bdd->query('SELECT * FROM config_bull where (ref_class="'.$refcls.'" and group_mat="2")  order by nom_mat asc');
	 
		while($row = $reponse->fetch(PDO::FETCH_ASSOC)) 
		{
			$cknote1=$class->SelectNoteStd_by_MatCls($refcls,$row['ref_mat'],$eval1,$refstd);
			$cknote2=$class->SelectNoteStd_by_MatCls($refcls,$row['ref_mat'],$eval2,$refstd);
			$nmat=$mat->ReturnNom_matByIdname($row['ref_mat']);
			$teacher=$user->SelectTeacherName_by_mat_by_cls($row['ref_ens']);
			/*contraintes */
			if (($cknote1<0) and ($cknote2>=0)) 
			{
				$note1='--';
				$note2=(float)$cknote2;
				$coeff=(float)$row['coeff_mat'];
				$note2=round($note2,2);
				$moy=$note2;
				$moy=round($moy,2);
				$total=$moy*$coeff;
				$total=round($total,2);
			}
			elseif (($cknote1>=0) and ($cknote2<0)) 
			{
				$note2='--';
				$note1=(float)$cknote1;
				$coeff=(float)$row['coeff_mat'];
				$note1=round($note1,2);
				$moy=$note1;
				$moy=round($moy,2);
				$total=$moy*$coeff;
				$total=round($total,2);
			}
			elseif (($cknote1<0) and ($cknote2<0)) 
			{

				$note1='--';
				$note2='--';
				$coeff='--';
				$moy='--';
				$total='--';
				
	
			}
			else 
			{
				
				/*conversions pour les calculs*/
				$note1=(float)$cknote1;
				$note2=(float)$cknote2;
				$note1=round($note1,2);
				$note2=round($note2,2);
				$coeff=(float)$row['coeff_mat'];
				$moy=($note1+$note2)/2;
				$moy=round($moy,2);
				$total=$moy*$coeff;
				$total=round($total,2);
			}
			$TotalcoeffG2+=(float)$coeff;
			$TotalpointG2+=(float)$total;

			/*APPRECIATION*/
			if (($moy>=0) and ($moy<10)) {
				$apr="N A";
			}elseif (($moy>=10) and ($moy<13)) {
				$apr="E C A";
			}
			elseif (($moy>=13) and ($moy<20)) {
				$apr="A";
			}else{
				$apr="--";
			}

			$pdf->SetFont('Arial','',9);
			$pdf->Ln();

			/*matiere*/$pdf->Cell(50,4,utf8_to_cp1252($row['nom_mat']),1,0);
			/*EVAL1*/$pdf->Cell(15,4,$note1,1,0,'C');
			/*EVAL2*/$pdf->Cell(15,4,$note2,1,0,'C');
			/*MOY*/$pdf->Cell(15,4,$moy,1,0,'C');
			/*COEFF*/$pdf->Cell(10,4,utf8_to_cp1252($row['coeff_mat']),1,0,'C');
			/*M*C*/$pdf->Cell(15,4,$total,1,0,'C');
			/*TOTAL*/$pdf->Cell(15,4,$apr,1,0,'C');
			/*COMPETENCE*/$pdf->Cell(55,4,$teacher,1,0,'L');
			/*Matiere faibles*/

			/*Matiere faibles*/
			if (($moy<10) and ($moy!="--")) {
				$faibles_mat.=$nmat.', ';		
			}
			/*Fin Matiere faibles*/

		}

		$pdf->Ln();
		if ($TotalcoeffG2==0) {
			$moyG2='--';
		}
		else{
			$moyG2=$TotalpointG2/$TotalcoeffG2;
			$moyG2=round($moyG2,2);
		}
		

		/*APPRECIATION*/
		if (($moyG2>=0) and ($moyG2<10)) {
			$aprG2="N A";
		}elseif (($moyG2>=10) and ($moyG2<13)) {
			$aprG2="E C A";
		}
		elseif (($moyG2>=13) and ($moyG2<20)) {
			$aprG2="A";
		}else{
			$aprG2="--";
		}
		$pdf->SetFont('Arial','B',9);
		$pdf->SetFillColor(236,235,2);
		$pdf->Cell(95,5,'TOTAL GROUPE/GROUP 2',1,0,'C',1);
		$pdf->Cell(10,5,$TotalcoeffG2,1,0,'C',1);
		$pdf->Cell(15,5,$TotalpointG2,1,0,'C',1);
		$pdf->Cell(45,5,' Moy/Avg G2 = '.$moyG2.'',1,0,'C',1);
		$pdf->Cell(25,5,' Apprt:'.$aprG2.'',1,0,'C',1);

	/*FIN G2*/

	/*matieres G3*/

		/*initiation des paramètres*/
		$TotalcoeffG3=0;
		$TotalpointG3=0;

		$bdd = $GLOBALS['bdd'];
		$reponse = $bdd->query('SELECT * FROM config_bull where (ref_class="'.$refcls.'" and group_mat="3")  order by nom_mat asc');
	 
		while($row = $reponse->fetch(PDO::FETCH_ASSOC)) 
		{
			$cknote1=$class->SelectNoteStd_by_MatCls($refcls,$row['ref_mat'],$eval1,$refstd);
			$cknote2=$class->SelectNoteStd_by_MatCls($refcls,$row['ref_mat'],$eval2,$refstd);
			$nmat=$mat->ReturnNom_matByIdname($row['ref_mat']);
			$teacher=$user->SelectTeacherName_by_mat_by_cls($row['ref_ens']);
			/*contraintes */
			if (($cknote1<0) and ($cknote2>=0)) 
			{
				$note1='--';
				$note2=(float)$cknote2;
				$coeff=(float)$row['coeff_mat'];
				$note2=round($note2,2);
				$moy=$note2;
				$moy=round($moy,2);
				$total=$moy*$coeff;
				$total=round($total,2);
			}
			elseif (($cknote1>=0) and ($cknote2<0)) 
			{
				$note2='--';
				$note1=(float)$cknote1;
				$coeff=(float)$row['coeff_mat'];
				$note1=round($note1,2);
				$moy=$note1;
				$moy=round($moy,2);
				$total=$moy*$coeff;
				$total=round($total,2);
			}
			elseif (($cknote1<0) and ($cknote2<0)) 
			{
				$note1='--';
				$note2='--';
				$coeff='--';
				$moy='--';
				$total='--';
				
				/*$coeff=0;
				$moy=0;
				$moy=round($moy,2);
				$total=$moy*$coeff;
				$total=round($total,2);
				$moy=0;*/
			}
			else 
			{
				
				/*conversions pour les calculs*/
				$note1=(float)$cknote1;
				$note2=(float)$cknote2;
				$note1=round($note1,2);
				$note2=round($note2,2);
				$coeff=(float)$row['coeff_mat'];
				$moy=($note1+$note2)/2;
				$moy=round($moy,2);
				$total=$moy*$coeff;
				$total=round($total,2);
			}
			
			
			$TotalcoeffG3+=(float)$coeff;
			$TotalpointG3+=(float)$total;

			/*APPRECIATION*/
			if (($moy>=0) and ($moy<10)) {
				$apr="N A";
			}elseif (($moy>=10) and ($moy<13)) {
				$apr="E C A";
			}
			elseif (($moy>=13) and ($moy<20)) {
				$apr="A";
			}else{
				$apr="--";
			}

			$pdf->SetFont('Arial','',9);
			$pdf->Ln();

			/*matiere*/$pdf->Cell(50,4,utf8_to_cp1252($row['nom_mat']),1,0);
			/*EVAL1*/$pdf->Cell(15,4,$note1,1,0,'C');
			/*EVAL2*/$pdf->Cell(15,4,$note2,1,0,'C');
			/*MOY*/$pdf->Cell(15,4,$moy,1,0,'C');
			/*COEFF*/$pdf->Cell(10,4,utf8_to_cp1252($row['coeff_mat']),1,0,'C');
			/*M*C*/$pdf->Cell(15,4,$total,1,0,'C');
			/*TOTAL*/$pdf->Cell(15,4,$apr,1,0,'C');
			/*COMPETENCE*/$pdf->Cell(55,4,$teacher,1,0,'L');
			
			/*Matiere faibles*/
			
			if (($moy<10) and ($moy!="--")) {
				$faibles_mat.=$nmat.', ';		
			}
			/*Fin Matiere faibles*/

		}

			/*Fin Matiere faibles*/

			$pdf->Ln();

			if ($TotalcoeffG3==0) {
				$moyG3='--';
			}
			else{
				$moyG3=$TotalpointG3/$TotalcoeffG3;
			$moyG3=round($moyG3,2);
			}
			

			/*APPRECIATION*/
			if (($moyG3>=0) and ($moyG3<10)) {
				$aprG3="N A";
			}elseif (($moyG3>=10) and ($moyG3<13)) {
				$aprG3="E C A";
			}
			elseif (($moyG3>=13) and ($moyG3<20)) {
				$aprG3="A";
			}else{
				$aprG3="--";
			}
			$pdf->SetFont('Arial','B',9);
			$pdf->SetFillColor(236,235,2);
			$pdf->Cell(95,5,'TOTAL GROUPE/GROUP 3',1,0,'C',1);
			$pdf->Cell(10,5,$TotalcoeffG3,1,0,'C',1);
			$pdf->Cell(15,5,$TotalpointG3,1,0,'C',1);
			$pdf->Cell(45,5,' Moy/Avg G3 ='.$moyG3.'',1,0,'C',1);
			$pdf->Cell(25,5,' Apprt:'.$aprG3.'',1,0,'C',1);

	/*FIN G3*/

	/*TOTAUX*/
	$TotauxMoy=$Totalpoint+$TotalpointG2+$TotalpointG3;
	$TotauxCoef=$Totalcoeff+$TotalcoeffG2+$TotalcoeffG3;
	if ($TotauxCoef==0) {
		$moyT="--";
	}else{
		$moyT=$TotauxMoy/$TotauxCoef;
			$moyT=round($moyT,2);
	}
	
	$pdf->Ln();
	$pdf->Ln();
	if (($moyT>=0) and ($moyT<10)) {
		$aprT="N A";
	}elseif (($moyT>=10) and ($moyT<13)) {
		$aprT="E C A";
	}
	elseif (($moyT>=13) and ($moyT<20)) {
		$aprT="A";
	}else{
		$aprT="--";
	}
	$pdf->SetFont('Arial','B',9);
	$pdf->SetFillColor(0,167,223);
	$pdf->Cell(95,5,'TOTAUX ',1,0,'C',1);
	$pdf->Cell(10,5,$TotauxCoef,1,0,'C',1);
	$pdf->Cell(15,5,$TotauxMoy,1,0,'C',1);
	$pdf->Cell(45,5,' Moy/Avg = '.$moyT.'',1,0,'C',1);
	$pdf->Cell(25,5,' Apprt:'.$aprT.'',1,0,'C',1);

	
	/*FIN TOTAUX
		*/

	/* Autres Appreciations

		*/
		$avertmwk="--";
		$sblmwk="--";
		$th="--";
	if (($moyT>0) and ($moyT<7)) {
		$avertmwk="--";
		$sblmwk="X";
		$th="--";
	}
	 elseif(($moyT>7) and ($moyT<10)) {
	 	$sblmwk="--";
	 	$avertmwk="X";
		$th="--";
	}elseif (($moyT>=12)){
		$avertmwk="--";
		$sblmwk="--";
		$th="X";
	}
	
	/* Fin Autres Appreciations
		*/

	/*Fin Statistique
						*/
	$moy_General=$opt->ShowMoy_by_Cls($refcls,$refbul);
	$moy_General=round($moy_General,2);


	$marge=10;

	$NbStd_Taux=$opt->ShowNbStd_for_TauxR_by_Cls($refcls,$refbul,$marge);
	//$nbstdclasser=(float)$nbstdclasser;
	if ($nbstdclasser>0) 
	{
	$taux_R=$NbStd_Taux*100/$nbstdclasser;
	$taux_R=round($taux_R,2);
	}
	else{
		$taux_R=0;
	}
	


	/*FIN Stat
		*/

		
	$pdf->Ln();
	$pdf->SetFont('Times','B',10);
	$pdf->SetFillColor(236,235,2);
	$pdf->SetFillColor(0,167,223);
	$pdf->Cell(30,10,'Moy/STD Avg :',1,0,'L',0);
	$pdf->SetFont('Times','B',15);
	$pdf->SetFillColor(236,235,2);
	$pdf->Cell(20,10,$moyT,1,0,'C',1);
	$pdf->SetFont('Times','B',10);
	$pdf->Cell(30,10,'Rang/Position: ',1,0,'L',0);
	$pdf->SetFont('Times','B',15);
	$pdf->Cell(25,10,''.$rangstd.''.$strrangstd.'/'.$nbstdclasser.'',1,0,'C',1);
	$pdf->SetFont('Times','B',10);
	$pdf->SetFillColor(0,167,223);
	$pdf->Cell(85,5,'Discipline / Discipline',1,0,'C',1);
	$pdf->Ln();
	$pdf->Cell(105,5,' ',0,0,'C',0);
	$pdf->Cell(60,5,utf8_to_cp1252('Abs non Justitiées/Unjustified Abs'),1,0,'C',0);
	$pdf->Cell(25,5,''.$HeureAbs.' Hr(s)',1,0,'C',0);

	$pdf->Ln();
	$pdf->Cell(70,5,'Travail/Work ',1,0,'C',1);
	$pdf->Cell(35,5,'Moy Classe/Class:',1,0,'C',1);
	$pdf->Cell(60,5,utf8_to_cp1252('Consignes/Punishment'),1,0,'C',0);
	$pdf->Cell(25,5,'0 Hr(s)',1,0,'C',0);
	$pdf->Ln();
	$pdf->Cell(60,5,'Tableau d\'Honneur/Honours Rol',1,0,'C',0);
	
	$pdf->Cell(10,5,''.$th.'',1,0,'C',0);

	$pdf->Cell(35,5,''.$moy_General.'',1,0,'C',0);
	$pdf->Cell(60,5,utf8_to_cp1252('Exclusion/Exclusion'),1,0,'C',0);
	$pdf->Cell(25,5,'0 Jr(s)/Day(s)',1,0,'C',0);

	$pdf->Ln();
	$pdf->Cell(60,5,'Avert.Travail/Warning!',1,0,'C',0);
	$pdf->Cell(10,5,$avertmwk,1,0,'C',0);
	$pdf->Cell(35,5,utf8_to_cp1252('Taux de Réussite:'),1,0,'C',1);
	$pdf->Cell(60,5,utf8_to_cp1252('Avert. Conduite/Conduct Warnig'),1,0,'C',0);
	$pdf->Cell(25,5,'--',1,0,'C',0);

	$pdf->Ln();
	$pdf->Cell(60,5,utf8_to_cp1252('Blâme Travail/Serious War.'),1,0,'C',0);
	$pdf->Cell(10,5,$sblmwk,1,0,'C',0);
	$pdf->Cell(35,5,''.$taux_R.'%',1,0,'C',0);
	$pdf->Cell(60,5,utf8_to_cp1252('Blâme Conduite/Serious Conduct War'),1,0,'C',0);
	$pdf->Cell(25,5,'--',1,0,'C',0);

	$pdf->Ln();
	$pdf->Cell(190,2,'',0,0,'C',0);
	$pdf->Ln();
	
	$pdf->Cell(105,6,utf8_to_cp1252('Appréciation Générale/General Appreciation'),1,0,'L',1);
		$pdf->Cell(30,4,'',0,0,'C',0);
		$pdf->Ln();
	
	$pdf->Cell(105,7,'Un effort s\'imporse en/an effort is needed in:',0,0,'LC',0);
	$pdf->Cell(10,5,'',0,0,'C',0);
	$pdf->Cell(70,5,utf8_to_cp1252('Fait à/Done at '.$_SESSION['ville_etb'].', le/on ______________'),0,0,'R',0);
	$pdf->Ln();
	$pdf->SetFont('Times','I',7);
	$pdf->Cell(105,6,utf8_to_cp1252(''.$faibles_mat.''),0,0,'L',0);
	$pdf->SetFont('Times','B',10);
	$pdf->Cell(18,4,'',0,0,'C',0);
	$pdf->Cell(50,4,'Le Proviseur/Directeur(trice)/The Princial',0,0,'L',0);
	$pdf->Ln();
	$pdf->Cell(190,2,'',0,0,'C',0);
	$pdf->Ln();
	$pdf->Cell(60,4,'Signature PP/Class Master',0,0,'T',0);
	$pdf->Cell(60,4,utf8_to_cp1252('Décision du Conseil / Council Decision'),0,0,'C',0);
	$pdf->Cell(70,4,'',0,0,'C',0);
	$pdf->Ln();
	$pdf->Cell(60,25,'',1,0,'T',0);
	$pdf->Cell(60,25,'',1,0,'C',0);
	$pdf->Cell(70,25,'',1,0,'T',0);
	
		

			/*FIN TOTAUX*/
			$faibles_mat="";
					

		}
		$pdf->Output('Bulletin_Trim_'.$refbul.'_'.$nomcls.'.pdf','I');	
?>
