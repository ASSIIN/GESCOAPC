<?php
session_start();
require_once '../Model/connexion.php';
require_once '../core/require.php';
 if (!isset($_SESSION['user'])) {
    session_unset();
    session_destroy();
    header('location: ../index.php');    
    }
$etb->ShowEtb();
 if (!isset($_GET['ss']) and !isset($_GET['trim'])) {
	header('location: ../calculs_notes.php');
 }
$ss= htmlspecialchars($_GET['ss']);
$nss=$class->ReturnNomSess_by_Code($ss);
$trim= htmlspecialchars($_GET['trim']);
/*$exist_moy=$opt->Ck_ExistMoy_by_Cls($row0['code_class'],$refbul);
if ($exist_moy==false) {
	header('location: ../calculs_notes.php');
}*/
if ($trim=='1') {
			$ev1='1';
			$ev2='2';
			$titrep='STATISTIQUES DE REMPLISSAGE TRIM N°1 ';
		}elseif($trim=='2') {
			$ev1='3';
			$ev2='4';
			$titrep='STATISTIQUES DE REMPLISSAGE TRIM N°2 ';
		}elseif($trim=='3') {
			$ev1='5';
			$ev2='6';
			$titrep='STATISTIQUES DE REMPLISSAGE TRIM N°3 ';
		}else{
			
		    }
require('fpdf.php');
$pdf = new FPDF();

class PDF extends FPDF
{
// En-tête
function Header()
{
	 $this->SetY(15);
    // Logo
    $this->Image('../plugins/images/'.$_SESSION['logo_etb'].'',10,6,30);
    // Police Arial gras 15
    $this->SetFont('Arial','B',15);
    // Décalage à droite
    $this->Cell(80);
    // Titre
    $this->Cell(30,10,'Titre',1,0,'C');
    // Saut de ligne
    $this->Ln(20);
 }

// Pied de page
function Footer()
{
    // Positionnement à 1,5 cm du bas
    $this->SetY(-15);
    // Police Arial italique 8
    $this->SetFont('Arial','I',8);
    // Numéro de page
    $this->Cell(0,10,'Page '.$this->PageNo().'/{nb}',0,0,'C');
}

}

$pdf->AddPage('P','A4');

$pdf->SetFont('Times','I',8);	
$pdf->Text(10,300,utf8_to_cp1252('By Akrymo Technology *** 656 864 099 / 678 042 612 / 658 626 661'),0,1,'C');
$pdf->Text(210,200,'Page '.$pdf->PageNo().'/{nb}',0,1,'C');
$pdf->AliasNBPages();

	/*En-tête*/
				$pdf->SetFont('Times','',8);
				$pdf->Image('../plugins/images/'.$_SESSION['logo_etb'].'',90,16,30);
				$pdf->Cell(70,4,'REPUBLIQUE DU CAMEROUN',0,0,'C');
				$pdf->Cell(50,4,'',0,0);
				$pdf->Cell(70,4,'REPUBLIC OF CAMEROON',0,1,'C');

				$pdf->Cell(70,4,'Paix-Travail-Patrie',0,0,'C');
				$pdf->Cell(50,4,'',0,0);
				$pdf->Cell(70,4,'Peace-Work-Fatherland',0,1,'C');

				$pdf->Cell(70,4, utf8_to_cp1252("".$_SESSION['minist_etb_fr'].""),0,0,'C');
				$pdf->Cell(50,4,'',0,0);
				$pdf->Cell(70,4,utf8_to_cp1252(''.$_SESSION['minist_etb_en'].''),0,1,'C');

				$pdf->Cell(70,4,utf8_to_cp1252("".$_SESSION['region_etb_fr'].""),0,0,'C');
				$pdf->Cell(50,4,'',0,0);
				$pdf->Cell(70,4,utf8_to_cp1252(''.$_SESSION['region_etb_en'].''),0,1,'C');

				$pdf->Cell(70,4,utf8_to_cp1252(''.$_SESSION['depart_etb_fr'].''),0,0,'C');
				$pdf->Cell(50,4,'',0,0);
				$pdf->Cell(70,4,utf8_to_cp1252(''.$_SESSION['depart_etb_en'].''),0,1,'C');
				$pdf->SetFont('Times','B',10);
				$pdf->Cell(70,6,utf8_to_cp1252(''.$_SESSION['nom_etb_fr'].''),0,0,'C');
				$pdf->Cell(50,6,'',0,0);
				$pdf->Cell(70,6,utf8_to_cp1252(''.$_SESSION['nom_etb_en'].''),0,1,'C');
				$pdf->SetFont('Times','',8);
				$pdf->Cell(70,5,utf8_to_cp1252(''.$_SESSION['code_pste_etb'].' / '.$_SESSION['tel_etb'].''),0,0,'C');
				$pdf->Cell(50,5,'',0,0);
				$pdf->Cell(70,5,utf8_to_cp1252(''.$_SESSION['code_pste_etb'].'/ '.$_SESSION['tel_etb'].''),0,1,'C');
				$pdf->SetFont('Times','',8);
				$pdf->Cell(70,4,utf8_to_cp1252(''.$_SESSION['email_etb'].''),0,0,'C');
				$pdf->Cell(50,4,'',0,0);
				$pdf->Cell(70,4,utf8_to_cp1252(''.$_SESSION['email_etb'].''),0,1,'C');
					$pdf->Ln();
					$pdf->SetFont('Times','I',12);
					$pdf->Cell(65,5,'',0,0);
					$pdf->Cell(60,5,utf8_to_cp1252(''.$_SESSION['code_im_etb'].''),0,0,'C');
					$pdf->Ln();

					$pdf->SetFont('Times','I',9);
				$pdf->Cell(50,5,'',0,0,'C');
				$pdf->Cell(60,5,'ANNEE SCOLAIRE/SCHOOL YEAR ',0,0,'R');
				$pdf->SetFont('Times','B',12);
				$pdf->Cell(40,5,''.$_SESSION['school_year'].'',0,0,'L');
				$pdf->Cell(40,5,'',0,1,'C');
				$pdf->Ln();
			/*FIN En-tête*/
	//Titre 
		$pdf->SetFont('Times','B',13);
		$pdf->SetFillColor(217,245,254);
		$pdf->Cell(35,6,'',0,0,'C');
		$pdf->Cell(120,6,utf8_to_cp1252($titrep),1,0,'C',1);
		$pdf->Cell(35,6,'',0,1,'C');
		$pdf->SetFont('Times','B',10);
		$pdf->Cell(35,6,'',0,0,'C');
		$pdf->Cell(120,5,utf8_to_cp1252('SECTION: '.$nss.'   // TRIM: '.$trim),0,0,'C',0);
	/*FIN TITRE*/		
	/* ENTETE TABLEAU*/		
		$pdf->SetFont('Times','B',9);
		$pdf->Ln();
		$pdf->Ln();
		$pdf->Cell(7,10,utf8_to_cp1252('N°'),1,0,'C',1);
		$pdf->Cell(22,10,'classes',1,0,'C',1);
		$pdf->Cell(25,10,utf8_to_cp1252('Matière/Subject'),1,0,'C',1);
		$pdf->Cell(55,10,utf8_to_cp1252('Enseignant/Teacher'),1,0,'C',1);
		$pdf->Cell(42,5,utf8_to_cp1252('EVAL '.$ev1.''),1,0,'C',1);
		$pdf->Cell(42,5,utf8_to_cp1252('EVAL '.$ev2.''),1,0,'C',1);
		$pdf->Ln();
		$pdf->Cell(109,5,'',0,0,'C',0);
		$pdf->Cell(12,5,utf8_to_cp1252('Insc'),1,0,'C',1);
		$pdf->Cell(12,5,utf8_to_cp1252('rempli'),1,0,'C',1);
		$pdf->Cell(18,5,utf8_to_cp1252('%'),1,0,'C',1);
		$pdf->Cell(12,5,utf8_to_cp1252('Insc'),1,0,'C',1);
		$pdf->Cell(12,5,utf8_to_cp1252('rempli'),1,0,'C',1);
		$pdf->Cell(18,5,utf8_to_cp1252('%'),1,0,'C',1);
		$pdf->Ln();
	/* FIN ENTETE TABLEAU*/	
	/*DATA*/
		/*INITIATION DES PARAMETRES*/

		$i0=0;
		$i1=0;
		$eff=0;
		$NbTH=0;

		$bdd = $GLOBALS['bdd'];
		$reponse0 = $bdd->query('SELECT * FROM  classes where class_session="'.$ss.'" order by ref_class_niveau asc');
			while($row0 = $reponse0->fetch(PDO::FETCH_ASSOC)) 
			{
				$i0++;


				$bdd = $GLOBALS['bdd'];
				$reponse1 = $bdd->query('SELECT * FROM config_bull where ref_class="'.$row0['code_class'].'" order by group_mat asc');
				while($row1 = $reponse1->fetch(PDO::FETCH_ASSOC)) 
				{
					$i1++;
					$cls_shtn=substr($row0['nom_class'], 0,15);
					$mat_shtn=substr($row1['nom_mat'], 0,15);
					$nom_ens=$class->ShowUsernamebyID($row1['ref_ens']);
					$ens_shtn=substr($nom_ens, 0,26);
					$nbstd=$class->NbrStudentByClass($row0['code_class']);
					$nbNotes1=$opt->NbrSdt_Notes_ON_by_Cls($row0['code_class'],$ev1,$row1['ref_mat']);
					$nbNotes2=$opt->NbrSdt_Notes_ON_by_Cls($row0['code_class'],$ev2,$row1['ref_mat']);
					$nbNotes1=(float)$nbNotes1;
					$nbNotes2=(float)$nbNotes2;

					if ($nbstd>0) 
					{
						$freq1=100*$nbNotes1/$nbstd;
						$freq1=round($freq1,2);
						$freq2=100*$nbNotes2/$nbstd;
						$freq2=round($freq2,2);
						$pdf->SetFont('Times','',8);

						$pdf->Cell(7,5,utf8_to_cp1252($i1),1,0,'C',0);
						$pdf->Cell(22,5,utf8_to_cp1252($cls_shtn),1,0,'C',0);
						$pdf->Cell(25,5,utf8_to_cp1252($mat_shtn),1,0,'L',0);
						$pdf->SetFont('Times','',9);
						$pdf->Cell(55,5,utf8_to_cp1252($ens_shtn),1,0,'L',0);
						$pdf->Cell(12,5,utf8_to_cp1252($nbstd),1,0,'C',0);
						$pdf->Cell(12,5,utf8_to_cp1252($nbNotes1),1,0,'C',0);
						if ($freq1<25) {
							$pdf->SetFillColor(255,0,0);
							$pdf->Cell(18,5,utf8_to_cp1252($freq1),1,0,'C',1);
							$pdf->SetFillColor(217,245,254);
						}
						elseif ($freq1<50) {
							$pdf->SetFillColor(255,255,0);
							$pdf->Cell(18,5,utf8_to_cp1252($freq1),1,0,'C',1);
							$pdf->SetFillColor(217,245,254);
						}
						elseif ($freq1<100) {
							$pdf->SetFillColor(0,255,255);
							$pdf->Cell(18,5,utf8_to_cp1252($freq1),1,0,'C',1);
							$pdf->SetFillColor(217,245,254);
							
						}
						else
						{
							$pdf->SetFillColor(0,255,0);
							$pdf->Cell(18,5,utf8_to_cp1252($freq1),1,0,'C',1);
							$pdf->SetFillColor(217,245,254);
						}
						$pdf->Cell(12,5,utf8_to_cp1252($nbstd),1,0,'C',0);
						$pdf->Cell(12,5,utf8_to_cp1252($nbNotes2),1,0,'C',0);
						if ($freq2<25) {
							$pdf->SetFillColor(255,0,0);
							$pdf->Cell(18,5,utf8_to_cp1252($freq2),1,0,'C',1);
							$pdf->SetFillColor(217,245,254);
						}
						elseif ($freq2<50) {
							$pdf->SetFillColor(255,255,0);
							$pdf->Cell(18,5,utf8_to_cp1252($freq2),1,0,'C',1);
							$pdf->SetFillColor(217,245,254);
						}
						elseif ($freq2<100) {
							$pdf->SetFillColor(0,255,255);
							$pdf->Cell(18,5,utf8_to_cp1252($freq2),1,0,'C',1);
							$pdf->SetFillColor(217,245,254);	
						}
						else
						{
							$pdf->SetFillColor(0,255,0);
							$pdf->Cell(18,5,utf8_to_cp1252($freq2),1,0,'C',1);
							$pdf->SetFillColor(217,245,254);
						}
						$pdf->Ln();

					}

					else{
						continue;
					}

				}
				$pdf->Cell(193,0.5,'',0,0,'C',1);
				$pdf->Ln();
				
			}


							
					
$pdf->Output('PV_'.$nss.'_TRIM'.$trim.'.pdf','I');
$pdf->Close();
?>
