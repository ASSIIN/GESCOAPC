<?php
	session_start();
	require_once '../../Model/connexion.php';
	require_once '../../core/require.php';

	// Sécurité : connexion obligatoire + rôles autorisés
	if (!isset($_SESSION['user'])) {
		header('location: ../../index.php');
		exit;
	}
	if (!in_array($_SESSION['user_role'] ?? '', array('admin', 'cs', 'pcpl'), true)) {
		header('location: ../../poste_de_saisie.php?trim=t1');
		exit;
	}
	if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
		header('location: ../../discipline.php');
		exit;
	}

	$ref_cls  = trim((string)($_POST['cls'] ?? ''));
	$ref_trim = trim((string)($_POST['trim'] ?? ''));
	if ($ref_cls === '' || $ref_trim === '') {
		header('location: ../../discipline.php');
		exit;
	}
	$bdd = $GLOBALS['bdd'];

	// Valeurs envoyées : abs[matricule] (nouveau formulaire) ; repli sur l'ancien format name=matricule
	$abs = (isset($_POST['abs']) && is_array($_POST['abs'])) ? $_POST['abs'] : array();

	$saved = 0; $invalid = 0;
	$stmt = $bdd->prepare('SELECT mat_std FROM eleves WHERE ref_class = ?');
	$stmt->execute(array($ref_cls));
	$mats = $stmt->fetchAll(PDO::FETCH_COLUMN);

	$chk = $bdd->prepare('SELECT id FROM absences WHERE ref_cls = ? AND ref_std = ? AND ref_trim = ? LIMIT 1');
	$upd = $bdd->prepare('UPDATE absences SET heure = ? WHERE ref_cls = ? AND ref_trim = ? AND ref_std = ?');
	$ins = $bdd->prepare('INSERT INTO absences (ref_cls, ref_std, ref_trim, heure) VALUES (?, ?, ?, ?)');

	foreach ($mats as $mat) {
		$mat = (string)$mat;
		$raw = isset($abs[$mat]) ? $abs[$mat] : ($_POST[$mat] ?? '');
		$raw = trim((string)$raw);
		if ($raw === '') { continue; }                 // vide = ne rien changer
		if (!ctype_digit($raw)) { $invalid++; continue; }
		$value = (string)min(999, (int)$raw);

		$chk->execute(array($ref_cls, $mat, $ref_trim));
		if ($chk->fetch()) {
			$upd->execute(array($value, $ref_cls, $ref_trim, $mat));
		} else {
			$ins->execute(array($ref_cls, $mat, $ref_trim, $value));
		}
		$saved++;
	}

	// Retour sur la page de saisie avec un message de confirmation
	header('location: ../../absences.php?cls=' . urlencode($ref_cls) . '&trim=' . urlencode($ref_trim) . '&saved=' . $saved . '&err=' . $invalid);
	exit;
?>
