<?php
session_start();
ini_set('display_errors', 0);
error_reporting(0);

require_once '../../Model/connexion.php';
require_once '../../core/require.php'; 

$bdd = $GLOBALS['bdd'];

if (isset($_POST['id_cls']) && !empty($_POST['id_cls'])) {
    
    $code_class = htmlspecialchars($_POST['id_cls']);
    $nom_cls = mb_strtoupper(trim(htmlspecialchars($_POST['nom_cls'])));
    $niveau = htmlspecialchars($_POST['niveau']);
    $class_session = htmlspecialchars($_POST['session']);
    $cls_master = isset($_POST['cls_master']) ? htmlspecialchars($_POST['cls_master']) : '';

    $elt = array(
        'nom_class' => $nom_cls, 
        'ref_class_niveau' => $niveau, 
        'class_session' => $class_session
    );
    
    if (!empty($cls_master)) {
        $elt['cls_master'] = $cls_master;
    }
    
    foreach ($elt as $key => $value) {
        if ($value !== "") {
            // SÉCURITÉ : Injection dynamique du nom de la colonne nettoyée et sécurisation du paramètre
            $sql = "UPDATE classes SET " . $key. " = ? WHERE code_class = ?";
            $rep = $bdd->prepare($sql);
            $rep->execute(array($value, $code_class));
        }
    }
    
    header('location: ../../menu_classes.php?upd_success=1');
    exit();
    //echo $code_class. "<br> Nom: ".$nom_cls."<br> master: ".$cls_master;
} else {
    header('location: ../../menu_classes.php');
    exit();
}
?>
