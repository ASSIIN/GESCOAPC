<?php
// Controler/classes/auto_config.php
// Point d'entrée AJAX (JSON) du module « Configuration automatique » (menu_classes.php).
// Actions : init | source_preview | apply_std | apply_source
session_start();
ini_set('display_errors', 0);
error_reporting(0);
ob_start();

function ac_json($data, $code = 200)
{
    if (ob_get_length()) { ob_clean(); }
    http_response_code($code);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE);
    exit();
}

// Sécurité : mêmes rôles que la création de classes / config bulletin
if (!isset($_SESSION['user']) || !in_array($_SESSION['user_role'] ?? '', array('admin', 'pcpl', 'cs'), true)) {
    ac_json(array('ok' => false, 'message' => 'Accès refusé.'), 403);
}
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    ac_json(array('ok' => false, 'message' => 'Requête invalide.'), 405);
}

try {
    require_once __DIR__ . '/../../Model/connexion.php';
    require_once __DIR__ . '/../../core/autoconfig_core.php';

    $bdd = $GLOBALS['bdd'];
    $ac = new AutoConfig($bdd, dirname(__DIR__, 2));
    $action = isset($_POST['action']) ? (string)$_POST['action'] : '';
    $payload = array();
    if (isset($_POST['payload'])) {
        $payload = json_decode((string)$_POST['payload'], true);
        if (!is_array($payload)) { $payload = array(); }
    }

    // plan[SEC][niveau][serie] = nombre ; serie vide -> "_"
    $cleanPlan = function ($raw) {
        $plan = array();
        if (!is_array($raw)) { return $plan; }
        foreach ($raw as $sec => $niv) {
            if (!preg_match('/^[A-Z]{3}$/', (string)$sec) || !is_array($niv)) { continue; }
            foreach ($niv as $n => $series) {
                if (!is_array($series)) { continue; }
                foreach ($series as $serie => $nb) { $plan[$sec][(int)$n][substr((string)$serie, 0, 30)] = (int)$nb; }
            }
        }
        return $plan;
    };
    $cleanCycles = function ($raw) {
        $c = array();
        foreach ((is_array($raw) ? $raw : array()) as $x) { if ((int)$x === 1 || (int)$x === 2) { $c[] = (int)$x; } }
        return $c;
    };
    $opts = (isset($payload['opts']) && is_array($payload['opts'])) ? $payload['opts'] : array();
    if (isset($opts['mode_ens']) && !in_array($opts['mode_ens'], array('auto', 'generic', 'none'), true)) { $opts['mode_ens'] = 'auto'; }

    switch ($action) {
        case 'init':
            ac_json(array('ok' => true, 'data' => $ac->initInfo()));

        case 'source_preview':
            ac_json(array('ok' => true, 'data' => $ac->previewSource(isset($payload['source']) ? $payload['source'] : '')));

        case 'apply_std':
            $plan = $cleanPlan(isset($payload['plan']) ? $payload['plan'] : array());
            $cycles = $cleanCycles(isset($payload['cycles']) ? $payload['cycles'] : array());
            if (empty($plan) || empty($cycles)) { ac_json(array('ok' => false, 'message' => 'Cochez au moins une section et un cycle.')); }
            ac_json(array('ok' => true, 'report' => $ac->applyStandard($plan, $cycles, $opts)));

        case 'apply_source':
            $codes = array();
            foreach ((isset($payload['classes']) && is_array($payload['classes'])) ? $payload['classes'] : array() as $c) { $codes[] = (string)$c; }
            if (empty($codes)) { ac_json(array('ok' => false, 'message' => 'Sélectionnez au moins une classe à reprendre.')); }
            $plan = !empty($payload['niveaux_suivants']) ? $cleanPlan(isset($payload['plan']) ? $payload['plan'] : array()) : array();
            $cycles = $cleanCycles(isset($payload['cycles']) ? $payload['cycles'] : array());
            ac_json(array('ok' => true, 'report' => $ac->applySource(isset($payload['source']) ? $payload['source'] : '', $codes, $opts, $plan, $cycles)));

        default:
            ac_json(array('ok' => false, 'message' => 'Action inconnue.'), 400);
    }
} catch (Throwable $e) {
    ac_json(array('ok' => false, 'message' => 'Erreur : ' . $e->getMessage()), 500);
}
