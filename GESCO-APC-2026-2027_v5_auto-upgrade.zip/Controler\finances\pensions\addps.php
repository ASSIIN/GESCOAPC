<?php
	session_start();
	require_once '../../../Model/connexion.php';
	require_once '../../../core/require.php'; 	
	$ref_s= htmlspecialchars($_POST['ref_s']);
	$ref_n= htmlspecialchars($_POST['ref_n']);
	$prix= htmlspecialchars($_POST['prix']);
	$ps_bull= htmlspecialchars($_POST['ps_bull']);
	
  		if (isset($ref_s) and $ps_bull<=$prix) 
  		{
  			if ($fin->CkExt_Ps_Nv($ref_n,$ref_s)) {
  				header('location: ../../../gestion_fin.php?ext=1');
  			}
  			else{
  				$prix= (float)$prix;
				$fin->setRef_s($ref_s);
				$fin->setRef_n($ref_n);
				$fin->setPrix($prix);
				$fin->setPs_bull($ps_bull);
				if ($fin->AddPension()) 
					{
					header('location: ../../../gestion_fin.php');
					}

					else  
					{
						echo "Erreur2";
					}
				}
  			}			
			else  {
			header('location: ../../../gestion_fin.php?e=1');
			}

		
		
?>