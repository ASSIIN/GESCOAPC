<?php
	session_start();
	require_once '../../Model/connexion.php';
	require_once '../../core/require.php';
	$class= htmlspecialchars($_POST['refcls']);	
	$pp= htmlspecialchars($_POST['pp']);
	if (isset($class) and isset($pp)) {
 
		$bdd = $GLOBALS['bdd'];	
			$req ='UPDATE classes SET cls_master=? where code_class="'.$class.'"';
			$rep = $bdd->prepare($req);
			if($rep->execute(array($pp))){
				header('location: ../../edit_classe.php?id='.$class.'');
			}
			else{
				echo "Erreur2";
			}
 		
		}	
		
?>