<?php 
  session_start();   
  require_once 'core/require.php'; 
  require_once 'Model/connexion.php';

  if (!isset($_SESSION['user'])) {
      session_unset();
      session_destroy();
      header('location: index.php');    
      exit();
  }

  // Filtrage strict des rôles administratifs autorisés
  if (($_SESSION['user_role'] != "admin") && ($_SESSION['user_role'] != "cs") && ($_SESSION['user_role'] != "pcpl") && ($_SESSION['user_role'] != "caisse")) {
      header('location: poste_de_saisie.php?trim=t1');    
      exit();
  }

  $etb->ShowEtb();
  $etb->ckexneE(); // Vérification de l'intégrité de la structure scolaire   
  $nbclasses = $class->NombreClasses();
?>
<!DOCTYPE html>
<html lang="fr">
  <head>
     <script>
         // Script d'interception immédiate pour empêcher le flash blanc au chargement
         document.documentElement.setAttribute("data-theme", localStorage.getItem("theme") || "light");
     </script>
     <?php Config::head(); ?>
     <title>GESCOAPC | Classes</title>
     <style>
         /* Ajustements de positionnement responsive spécifiques au module classe */
         @media (max-width: 768px) {
             .fixed-top-mobile {
                 position: relative !important;
                 top: 0 !important;
                 margin-left: 0 !important;
                 width: 100% !important;
                 padding: 10px !important;
             }
             .main-content-wrapper {
                 margin-left: 0 !important;
                 padding: 15px !important;
                 padding-top: 80px !important;
             }
             .btn-mobile-full {
                 width: 100% !important;
                 margin-top: 5px;
             }
         }
     </style>
  </head>
  <body>

    <!-- Inclusion du menu de navigation externe réutilisable -->
    <?php include 'core/sidebar.php'; ?>  

    <!-- Conteneur principal de l'application -->
    <div class="main-content-wrapper">
        
        <!-- Barre supérieure d'actions et filtres (Sticky Mobile) -->
        <div class="mobile-navbar-fixed p-3 mb-4 rounded shadow-sm border">
            <div class="row align-items-center g-2">
                
                <!-- Bouton burger mobile tactile -->
                <div class="col-auto d-md-none">
                    <button class="btn btn-outline-dark btn-sm" id="toggleMobileMenu"><i class="fa fa-bars fa-lg"></i></button>
                </div>
                
                <div class="col col-md-6 d-flex align-items-center gap-2">
                    <h4 class="m-0 fw-bold text-primary" style="font-size: 1.1rem;">
                        <i class="fa fa-university me-2"></i>Structures Pédagogiques 
                        <span class="badge bg-danger ms-2 font-monospace"><?php echo $nbclasses; ?></span>
                    </h4>
                </div>

                <div class="col-12 col-md-6 d-flex justify-content-md-end justify-content-start gap-1 flex-wrap">
                    <button type="button" class="btn btn-sm btn-success text-white px-3 fw-bold btn-mobile-full" data-bs-toggle="modal" data-bs-target="#addclasse">
                        <i class="fa fa-plus-circle me-1"></i>Créer une classe
                    </button>
                    <a href="fpdf185/allclass.php" class="btn btn-sm btn-outline-primary fw-bold btn-mobile-full" style="color: var(--text-main); border-color: #0764a8;">
                        <i class="fa fa-print me-1"></i>Imprimer le répertoire (PDF)
                    </a>
                </div>

            </div>
        </div>

        <!-- Section Tableau des Structures Épuré et Filtrable -->
        <div class="card border-0 shadow-sm">
            <div class="table-responsive w-100">
                <table class="table table-striped table-hover align-middle text-center mb-0">
                    <thead class="text-white table-dark-custom">
                        <tr style="font-size: 0.9em;">
                            <th style="width: 60px;">#</th>
                            <th class="text-start" style="padding-left: 20px;">NOM INTÉGRAL DE LA CLASSE</th>
                            <th style="width: 80px;">MODIFIER</th>
                            <th style="width: 160px;">CONFIG BULLETIN</th>
                            <th style="width: 70px;">PDF</th>
                            <th style="width: 70px;">EXCEL</th>
                            <th style="width: 80px;">SUPPRIMER</th>
                        </tr>
                    </thead>
                    <tbody id="tab-classes" style="font-size: 0.88em; font-weight: 500;">
                        <?php $class->ShowAllClasses(); ?>
                    </tbody>
                </table>
            </div>
        </div>

    </div>

    <!-- ============================================================== -->
    <!-- MODAL D'AJOUT D'UNE STRUCTURE CLASSE                           -->
    <!-- ============================================================== -->
    <div class="modal fade" id="addclasse" tabindex="-1" aria-labelledby="addClasseModalLabel" aria-hidden="true">
      <div class="modal-dialog modal-dialog-centered modal-lg">
        <div class="modal-content border-0">
          
          <div class="modal-header text-white border-0 py-2" style="background-color: #0764a8; border-top-left-radius: 12px; border-top-right-radius: 12px;">
            <h5 class="modal-title fw-bold" id="addClasseModalLabel"><i class="fa fa-plus-circle me-2"></i>Ouvrir une nouvelle classe</h5>
            <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
          </div>
          
          <form action="Controler/classes/addclasse.php" method="post">
            <div class="modal-body p-4" style="background-color: var(--bg-main);">
              <div class="container-fluid p-0">                              
                    <div class="row g-3">
                        
                        <div class="col-12 col-md-4">
                            <label for="nom_class" class="form-label fw-bold text-secondary small">Libellé court / Nom de classe</label>
                            <input type="text" class="form-control text-uppercase fw-bold" id="nom_class" name="nom_class" maxlength="12" placeholder="Ex: 6EME A" required style="letter-spacing: 0.5px;">
                        </div>
                        
                        <div class="col-12 col-sm-6 col-md-4">
                            <label for="niveau" class="form-label fw-bold text-secondary small">Palier / Niveau d'étude</label>
                            <select id="niveau" class="form-select" name="niveau" required>
                                <option value="">Choisir le palier...</option>
                                <option value="1">6EME / F1 / 1ERE ANNEE</option>
                                <option value="2">5EME / F2 / 2EME ANNEE</option>
                                <option value="3">4EME / F3 / 3EME ANNEE</option>
                                <option value="4">3EME / F4 / 4EME ANNEE</option>
                                <option value="5">2NDE / F5 / PROBATOIRE IND</option>
                                <option value="6">1ERE / L6 / PREMIÈRE IND</option>
                                <option value="7">TLE / U6 / TERMINALE IND</option>
                            </select>
                        </div>
                        
                        <div class="col-12 col-sm-6 col-md-4">
                            <label for="session" class="form-label fw-bold text-secondary small">Type d'Enseignement / Section</label>
                            <select id="session" class="form-select" name="session" required>
                                <option value="">Choisir la section...</option>
                                <option value="SFG">Sous-Section Francophone Générale (SFG)</option>
                                <option value="SAG">Sous-Section Anglophone Générale (SAG)</option>
                                <option value="SFT">Sous-Section Francophone Technique (SFT)</option>
                                <option value="SAT">Sous-Section Anglophone Technique (SAT)</option>
                            </select>
                        </div>

                        <div class="col-12">
                            <label for="model_class" class="form-label fw-bold text-secondary small"><i class="fa fa-copy me-1"></i>Copier la configuration depuis une classe modèle</label>
                            <select id="model_class" class="form-select" name="model_class">
                                <option value="">Aucune (bulletin à configurer)</option>
                                <?php $class->SelectModelCls(); ?>
                            </select>
                            <div class="form-text">La nouvelle classe récupérera matières, coefficients, enseignants et compétences de la classe choisie.</div>
                        </div>

                    </div>
                </div>
            </div>
            
            <div class="modal-footer border-top-0 pt-0">
                <button type="button" class="btn btn-secondary px-4 fw-bold" data-bs-dismiss="modal">Annuler</button>
                <button type="submit" class="btn text-white fw-bold px-4" style="background-color: #19784f; border: none; box-shadow: 0 4px 10px rgba(25, 120, 79, 0.2);">
                    <i class="fa fa-save me-2"></i>Enregistrer la classe
                </button>
            </div>
          </form>

        </div>
      </div>
    </div>
           
    <?php Footers::TDfoot(); ?>

    <?php Config::scriptJs(); ?>

  </body>
</html>
