<?php
	session_start();
	require_once '../../Model/connexion.php';
	require_once '../../core/require.php'; 	
	$ref_cls= htmlspecialchars($_GET['cls']);
	$de= htmlspecialchars($_GET['de']);
	$vers= htmlspecialchars($_GET['vers']);
	$bdd=$GLOBALS['bdd'];
	$reponse0 = $bdd->query('SELECT * FROM config_bull where ref_class="'.$ref_cls.'" order by group_mat asc');
	while (($row0 = $reponse0->fetch(PDO::FETCH_ASSOC))) 
	{	
	
		$bdd = $GLOBALS['bdd'];
		$reponse = $bdd->query('SELECT * FROM eleves where ref_class="'.$ref_cls.'"');
		while (($row = $reponse->fetch(PDO::FETCH_ASSOC))) 
		{
			$ni=0;
			$nf=0;

			$ref_mat=$row0['ref_mat'];


			if (!$class->CheckNoteStd_by_MatCls($ref_cls,$ref_mat,$de,$row['mat_std'])) 
			{

				if (!$class->CheckNoteStd_by_MatCls($ref_cls,$ref_mat,$vers,$row['mat_std'])) 
				{
					continue;
			 	}

			 	else
			 	{
					$coef=$opt->SelectCoef_by_MatCls($ref_cls,$ref_mat);				
					$nfi=NULL;
					$ucoef=NULL;
					$note_x_coeff=NULL;
					$bdd = $GLOBALS['bdd'];	
					$req ='UPDATE table_note_par_mat SET note= ?, coef= ?, note_x_coeff= ? where ((ref_cls="'.$ref_cls.'" and ref_mat="'.$ref_mat.'") and (ref_eval="'.$vers.'" and ref_std="'.$row['mat_std'].'"))';

					$rep = $bdd->prepare($req);
					$rep->execute(array($nfi,$ucoef,$note_x_coeff));
					
			 	}
			}
			else
			{
				$ni=$class->ShowNoteStd_by_MatCls($ref_cls,$ref_mat, $de,$row['mat_std']);
			
				$nf=(float)$ni;
			
				if ($class->CheckNoteStd_by_MatCls($ref_cls,$ref_mat,$vers,$row['mat_std'])) 
				{
					$coef=$opt->SelectCoef_by_MatCls($ref_cls,$ref_mat);
					
					if ($nf<0) 
					{
						$nf=NULL;
						$ucoef=NULL;
						$note_x_coeff=NULL;
						$bdd = $GLOBALS['bdd'];	
						$req ='UPDATE table_note_par_mat SET note= ?, coef= ?, note_x_coeff= ? where(ref_cls="'.$ref_cls.'" and ref_mat="'.$ref_mat.'" and ref_eval="'.$vers.'" and ref_std="'.$row['mat_std'].'")';

						$rep = $bdd->prepare($req);
						$rep->execute(array($nf,$ucoef,$note_x_coeff));
						
					}
					else
					{
						$note_x_coeff=$nf*$coef;
						$note_x_coeff=(string)$note_x_coeff;
						$bdd = $GLOBALS['bdd'];	
						$req ='UPDATE  table_note_par_mat SET note= ?, coef= ?, note_x_coeff= ? where(ref_cls="'.$ref_cls.'" and ref_mat="'.$ref_mat.'" and ref_eval="'.$vers.'" and ref_std="'.$row['mat_std'].'")';

							$rep = $bdd->prepare($req);
							$rep->execute(array($nf,$coef,$note_x_coeff));
					}
				}
				else
				{
						
					$coef=$opt->SelectCoef_by_MatCls($ref_cls,$ref_mat);
					
					$note_x_coeff=$nf*$coef;
					$note_x_coeff=(string)$note_x_coeff;
					$req = "INSERT INTO table_note_par_mat (ref_mat, ref_cls, ref_std, ref_eval, note, coef, note_x_coeff) VALUES(?, ?, ?, ?, ?, ?, ?)" ;

					$rep = $bdd->prepare($req);
					if ($rep->execute(array($ref_mat, $ref_cls, $row['mat_std'], $vers, $nf,$coef,$note_x_coeff ))) {
					}
					else{
						echo "Erreur2";
					}
				}

			}

			
		}

	}

	$class->CkClasseByCode($ref_cls);
    $sess_bul=$_SESSION['class_session'];
    switch ($sess_bul) {
    	case 'SFG':
    		$cfg=$ref_cls;
    		$cag='';
    		$cft='';
    		$cat='';
    		break;
    	case 'SAG':
    		$cfg='';
    		$cag=$ref_cls;
    		$cft='';
    		$cat='';
    		break;
    	case 'SFT':
    		$cfg='';
    		$cag='';
    		$cft=$ref_cls;
    		$cat='';
    		break;
    	case 'SAT':
    		$cfg='';
    		$cag='';
    		$cft='';
    		$cat=$ref_cls;
    		break;
    	
    	default:
    		$cfg='';
    		$cag='';
    		$cft='';
    		$cat='';
    		break;
    }

	if (($cfg=='' and $cag=='') and ($cft=='' and $cat=='')) 
	{
		header('location: ../../reconduire_notes.php'); 
	}else{
		header('location: ../../reconduire_notes.php?sess_bul='.$sess_bul.'&cfg='.$cfg.'&cag='.$cag.'&cft='.$cft.'&cat='.$cat.'');
	}
			
	
		
?>