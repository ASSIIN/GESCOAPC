<?php
/**
 * Module de migration annuelle des élèves — SECONDAIRE (lycée)
 * Projet: GESCO-APC
 *
 * Règles métier :
 *  - Chaque élève passe au niveau supérieur (niveau+1), même session.
 *  - Les séries sont conservées et/ou réorientées selon les notes :
 *      * 5E  -> 4E   : série ALL ou ESP (comparaison ALL vs ESP).
 *      * 3E  -> 2NDE : 2NDE C (Maths + PCT + SVT/SC >= seuil),
 *                      sinon 2NDE A4 ALL ou 2NDE A4 ESP (ALL vs ESP).
 *      * 2NDE -> 1ERE : 1ERE C (Maths + PCT/Phys-Chim >= seuil),
 *                       sinon 1ERE D (SVTeeb/Science + Chimie >= seuil).
 *      * 1ERE -> TLE  : même logique C / D.
 *  - Terminale (niveau 7) -> classe PROMOTION_{année_courante}.
 *  - Les classes cibles sont créées automatiquement si absentes.
 */
class MigrationManager
{
    private $current_year;
    private $next_year;
    private $current_bdd;
    private $next_bdd;
    private $subjects = [];
    private $matieres_loaded = false;
    private $current_run_id = null;
    private $pending_created_classes = [];

    /** Libellés courts des niveaux (ref_class_niveau -> nom) */
    const LEVEL_SHORT = [1 => '6E', 2 => '5E', 3 => '4E', 4 => '3E', 5 => '2NDE', 6 => '1ERE', 7 => 'TLE'];

    public function __construct(string $current_year, string $next_year)
    {
        $this->current_year = $current_year;
        $this->next_year = $next_year;
        $this->initConnections();
    }

    private function initConnections(): void
    {
        try {
            $this->current_bdd = new PDO(
                "mysql:host=localhost;dbname=gescoapc_{$this->current_year};charset=utf8mb4",
                'root', '', [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
            );
            $this->next_bdd = new PDO(
                "mysql:host=localhost;dbname=gescoapc_{$this->next_year};charset=utf8mb4",
                'root', '', [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
            );
        } catch (Exception $e) {
            throw new RuntimeException("Erreur de connexion DB: " . $e->getMessage());
        }
    }

    /* ================================================================
     * SUJETS (matieres)
     * ================================================================ */

    private function loadMatieres(): void
    {
        if ($this->matieres_loaded) return;
        $this->subjects = [];
        try {
            $stmt = $this->current_bdd->query('SELECT id, abr_mat, nom_mat FROM matieres');
            while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
                $this->subjects[strtoupper(trim($row['abr_mat']))] = (string)$row['id'];
            }
        } catch (PDOException $e) {
            // base non encore migrée : on continue sans
        }
        $this->matieres_loaded = true;
    }

    private function matId(string $abr): ?string
    {
        $this->loadMatieres();
        $key = strtoupper(trim($abr));
        return $this->subjects[$key] ?? null;
    }

    /* ================================================================
     * ANNEES (listage des bases réelles)
     * ================================================================ */

    public static function getAvailableYears(): array
    {
        $years = [];
        try {
            $pdo = new PDO('mysql:host=localhost;charset=utf8mb4', 'root', '', [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]);
            $stmt = $pdo->query("SHOW DATABASES LIKE 'gescoapc\\_%'");
            while ($row = $stmt->fetch(PDO::FETCH_NUM)) {
                $suffix = substr($row[0], strlen('gescoapc_'));
                if (isset($years[$suffix])) continue;
                $years[$suffix] = $suffix;
            }
        } catch (PDOException $e) {
            // rien
        }
        $res = array_values($years);
        sort($res);
        return $res;
    }

    /* ================================================================
     * VERIFICATIONS
     * ================================================================ */

    public function checkNextYearReady(): array
    {
        $result = ['exists' => false, 'classes' => [], 'errors' => []];
        try {
            $stmt = $this->next_bdd->query("SHOW TABLES LIKE 'classes'");
            if ($stmt->rowCount() > 0) {
                $result['exists'] = true;
                $stmt = $this->next_bdd->query("SELECT code_class, nom_class, ref_class_niveau, class_session FROM classes ORDER BY ref_class_niveau ASC, nom_class ASC");
                while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
                    $result['classes'][] = $row;
                }
            }
        } catch (PDOException $e) {
            $result['errors'][] = "Base suivante inaccessible: " . $e->getMessage();
        }
        return $result;
    }

    /* ================================================================
     * LECTURES SOURCE
     * ================================================================ */

    public function getCurrentClasses(): array
    {
        $classes = [];
        try {
            $stmt = $this->current_bdd->query("SELECT code_class, nom_class, ref_class_niveau, class_session FROM classes ORDER BY ref_class_niveau ASC, nom_class ASC");
            while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
                $classes[] = $row;
            }
        } catch (PDOException $e) {
            throw new RuntimeException("Erreur lecture classes: " . $e->getMessage());
        }
        return $classes;
    }

    /**
     * Élèves d'une classe (schéma secondaire réel : eleves)
     */
    public function getStudentsByClass(string $code_class): array
    {
        $students = [];
        try {
            $stmt = $this->current_bdd->prepare(
                "SELECT mat_std, nom_std, date_nais, lieu_nais, sexe_std, ref_class, cni_std, pere_std, mere_std, adresse_std, localite_std, contenu_std, statut, handicap FROM eleves WHERE ref_class = ? ORDER BY mat_std ASC"
            );
            $stmt->execute([$code_class]);
            while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
                $students[] = $row;
            }
        } catch (PDOException $e) {
            throw new RuntimeException("Erreur lecture élèves: " . $e->getMessage());
        }
        return $students;
    }

    /**
     * Moyenne annuelle d'un élève issue de `table_note_par_triman` (ref_trim = 'an').
     */
    public function getAnnualMoy(string $std, string $cls): ?float
    {
        try {
            $stmt = $this->current_bdd->prepare(
                "SELECT moy FROM table_note_par_triman WHERE ref_trim = 'an' AND ref_cls = ? AND ref_std = ? LIMIT 1"
            );
            $stmt->execute([$cls, $std]);
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            if ($row && is_numeric($row['moy'])) {
                return (float)$row['moy'];
            }
        } catch (PDOException $e) {
            try {
                $stmt = $this->current_bdd->prepare("SELECT moy_an AS moy FROM moy_trim WHERE ref_cls = ? AND ref_std = ? LIMIT 1");
                $stmt->execute([$cls, $std]);
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                if ($row && is_numeric($row['moy'])) {
                    return (float)$row['moy'];
                }
            } catch (PDOException $e2) {
                // rien
            }
        }
        return null;
    }

    /* ================================================================
     * CLASSES CIBLES
     * ================================================================ */

    public function classExistsInNext(string $code_class): bool
    {
        try {
            $stmt = $this->next_bdd->prepare("SELECT COUNT(*) FROM classes WHERE code_class = ?");
            $stmt->execute([$code_class]);
            return $stmt->fetchColumn() > 0;
        } catch (PDOException $e) {
            return false;
        }
    }

    public function createClassInNext(string $code_class, string $nom_class, string $ref_niveau, string $class_session): bool
    {
        try {
            $stmt = $this->next_bdd->prepare("INSERT IGNORE INTO classes (code_class, nom_class, ref_class_niveau, class_session) VALUES (?, ?, ?, ?)");
            $ok = $stmt->execute([$code_class, $nom_class, $ref_niveau, $class_session]);
            if ($ok) {
                // Mémorise la classe créée pour pouvoir l'annuler lors d'une restauration.
                if ($this->current_run_id !== null) {
                    $this->pending_created_classes[$code_class] = $class_session;
                }
                $upd = $this->next_bdd->prepare("UPDATE sess SET nb_class_par_sess = (SELECT COUNT(*) FROM classes WHERE class_session = ?) WHERE abr_sess = ?");
                $upd->execute([$class_session, $class_session]);
            }
            return $ok;
        } catch (PDOException $e) {
            return false;
        }
    }

    /**
     * Trouve une classe cible existante (niveau + session) :
     *  - si $serie est vide : la classe « simple » du niveau (ex: 5E).
     *  - sinon : la classe de ce niveau dont le nom contient le jeton de série.
     */
    public function findTargetClass(string $ref_niveau, string $class_session, string $serie): ?array
    {
        try {
            $stmt = $this->next_bdd->prepare(
                "SELECT code_class, nom_class, ref_class_niveau, class_session FROM classes WHERE ref_class_niveau = ? AND class_session = ? ORDER BY nom_class ASC"
            );
            $stmt->execute([$ref_niveau, $class_session]);
            while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
                if ($this->nameMatchesSerie($row['nom_class'], $serie)) {
                    return $row;
                }
            }
        } catch (PDOException $e) {
            // rien
        }
        return null;
    }

    private function nameMatchesSerie(string $nom_class, string $serie): bool
    {
        $nom = strtoupper($nom_class);
        $serie = strtoupper($serie);
        if ($serie === '') {
            // Mode « une seule classe » : n'importe quelle classe simple du niveau
            return $this->detectSerie($nom) === '';
        }
        if ($serie === 'A4ALL')   return strpos($nom, 'A4') !== false && strpos($nom, 'ALL') !== false;
        if ($serie === 'A4ESP')   return strpos($nom, 'A4') !== false && strpos($nom, 'ESP') !== false;
        if ($serie === 'C' || $serie === 'D') {
            return preg_match('/\b' . $serie . '\b/', $nom) === 1;
        }
        if ($serie === 'ALL' || $serie === 'ESP') {
            if ($serie === 'ALL' && strpos($nom, 'A4') !== false) return false;
            if ($serie === 'ESP' && strpos($nom, 'A4') !== false) return false;
            return strpos($nom, $serie) !== false;
        }
        return $nom === $serie;
    }

    private function genClassCode(): string
    {
        $chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ0123456789';
        $code = '';
        for ($i = 0; $i < 5; $i++) {
            $code .= $chars[random_int(0, strlen($chars) - 1)];
        }
        return $code;
    }

    /* ================================================================
     * SERIES & ORIENTATION
     * ================================================================ */

    /**
     * Série de la classe source déduite du nom (ALL / ESP / A4 ALL / A4 ESP / C / D).
     */
    private function detectSerie(string $nom_class): string
    {
        $nom = strtoupper($nom_class);
        if (strpos($nom, 'A4') !== false && strpos($nom, 'ALL') !== false) return 'A4ALL';
        if (strpos($nom, 'A4') !== false && strpos($nom, 'ESP') !== false) return 'A4ESP';
        if (strpos($nom, 'ALL') !== false) return 'ALL';
        if (strpos($nom, 'ESP') !== false) return 'ESP';
        if (preg_match('/\bC\b/', $nom)) return 'C';
        if (preg_match('/\bD\b/', $nom)) return 'D';
        return '';
    }

    /**
     * Moyenne annuelle par matière (sur les 6 séquences) pour un élève d'une classe.
     */
    private function annualAvgBySubject(string $std, string $cls, string $abr): ?float
    {
        $matId = $this->matId($abr);
        if ($matId === null) return null;
        $notes = [];
        for ($seq = 1; $seq <= 6; $seq++) {
            try {
                $table = 'table_note_par_mat_eval' . $seq;
                $stmt = $this->current_bdd->prepare("SELECT note FROM $table WHERE ref_cls = ? AND ref_mat = ? AND ref_std = ? LIMIT 1");
                $stmt->execute([$cls, $matId, $std]);
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                if ($row && is_numeric($row['note']) && (float)$row['note'] >= 0) {
                    $notes[] = (float)$row['note'];
                }
            } catch (PDOException $e) {
                continue;
            }
        }
        if (empty($notes)) return null;
        return round(array_sum($notes) / count($notes), 2);
    }

    private function avg(?float ...$values): ?float
    {
        $vals = array_filter($values, fn($v) => $v !== null);
        if (empty($vals)) return null;
        return round(array_sum($vals) / count($vals), 2);
    }

    /**
     * Calcule la série d'affectation d'un élève selon son niveau de départ.
     */
    private function orientStudent(string $std, array $sourceClass, float $threshold): string
    {
        $srcNv = (int)$sourceClass['ref_class_niveau'];
        $srcSerie = $this->detectSerie($sourceClass['nom_class']);
        $cls = $sourceClass['code_class'];

        $avg = function (array $abrs) use ($std, $cls) {
            $vals = [];
            foreach ($abrs as $abr) {
                $v = $this->annualAvgBySubject($std, $cls, $abr);
                if ($v !== null) $vals[] = $v;
            }
            return empty($vals) ? null : round(array_sum($vals) / count($vals), 2);
        };

        switch ($srcNv) {
            case 1: // 6E -> 5E : conserve la série source (sinon ALL par défaut)
                return ($srcSerie === 'ESP') ? 'ESP' : 'ALL';

            case 2: // 5E -> 4E : série ALL vs ESP
                $all = $this->annualAvgBySubject($std, $cls, 'ALL');
                $esp = $this->annualAvgBySubject($std, $cls, 'ESP');
                if ($all !== null && $esp !== null) return $all >= $esp ? 'ALL' : 'ESP';
                if ($all !== null) return 'ALL';
                if ($esp !== null) return 'ESP';
                return ($srcSerie === 'ESP') ? 'ESP' : 'ALL';

            case 3: // 4E -> 3E : conserve la série source
                if ($srcSerie === 'ALL' || $srcSerie === 'ESP') return $srcSerie;
                return ($srcSerie === 'ESP') ? 'ESP' : 'ALL';

            case 4: // 3E -> 2NDE : C si science, sinon A4 (ALL/ESP)
                $sci = $avg(['MATHS', 'PCT', 'SVT', 'SC']);
                if ($sci !== null && $sci >= $threshold) return 'C';
                $all = $this->annualAvgBySubject($std, $cls, 'ALL');
                $esp = $this->annualAvgBySubject($std, $cls, 'ESP');
                if ($all !== null && $esp !== null) return $all >= $esp ? 'A4ALL' : 'A4ESP';
                if ($all !== null) return 'A4ALL';
                if ($esp !== null) return 'A4ESP';
                return ($srcSerie === 'ESP') ? 'A4ESP' : 'A4ALL';

            case 5: // 2NDE -> 1ERE : C si Maths+PC, sinon D si SVT/SC+Chimie
                $sci = $avg(['MATHS', 'PCT', 'PHYS', 'CHIM']);
                if ($sci !== null && $sci >= $threshold) return 'C';
                $bio = $avg(['SVT', 'SC', 'CHIM']);
                if ($bio !== null && $bio >= $threshold) return 'D';
                if ($sci !== null && $bio !== null) return $sci >= $bio ? 'C' : 'D';
                if ($sci !== null) return 'C';
                if ($bio !== null) return 'D';
                return ($srcSerie === 'D') ? 'D' : 'C';

            case 6: // 1ERE -> TLE : même logique C / D
                $sci = $avg(['MATHS', 'PCT', 'PHYS', 'CHIM']);
                if ($sci !== null && $sci >= $threshold) return 'C';
                $bio = $avg(['SVT', 'SC', 'CHIM']);
                if ($bio !== null && $bio >= $threshold) return 'D';
                if ($sci !== null && $bio !== null) return $sci >= $bio ? 'C' : 'D';
                if ($sci !== null) return 'C';
                if ($bio !== null) return 'D';
                return ($srcSerie === 'D') ? 'D' : 'C';

            default: // Terminale ou inconnu : conservé tel quel
                return $srcSerie;
        }
    }

    /**
     * Nom de la classe cible à créer selon le niveau et la série.
     * Si $serie est vide : libellé simple (ex: « 5E ») — mode une seule classe / redoublants.
     */
    private function buildTargetClassName(int $targetNv, string $serie): string
    {
        $label = self::LEVEL_SHORT[$targetNv] ?? 'CLASSE';
        switch ($serie) {
            case 'A4ALL': return $label . ' A4 ALL';
            case 'A4ESP': return $label . ' A4 ESP';
            case 'ALL':   return $label . ' ALL';
            case 'ESP':   return $label . ' ESP';
            case 'C':     return $label . ' C';
            case 'D':     return $label . ' D';
            default:      return $label;
        }
    }

    /* ================================================================
     * ELEVES CIBLES
     * ================================================================ */

    public function studentExistsInNext(string $matricule): bool
    {
        try {
            $stmt = $this->next_bdd->prepare("SELECT COUNT(*) FROM eleves WHERE mat_std = ?");
            $stmt->execute([$matricule]);
            return $stmt->fetchColumn() > 0;
        } catch (PDOException $e) {
            return false;
        }
    }

    public function insertStudent(array $student, string $code_class): bool
    {
        try {
            $stmt = $this->next_bdd->prepare(
                "INSERT IGNORE INTO eleves (mat_std, nom_std, date_nais, lieu_nais, sexe_std, ref_class, cni_std, pere_std, mere_std, adresse_std, localite_std, contenu_std, statut, handicap, register_std_on) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())"
            );
            return $stmt->execute([
                $student['mat_std'] ?? '',
                $student['nom_std'] ?? '',
                $student['date_nais'] ?? null,
                $student['lieu_nais'] ?? '',
                $student['sexe_std'] ?? '',
                $code_class,
                $student['cni_std'] ?? '',
                $student['pere_std'] ?? null,
                $student['mere_std'] ?? null,
                $student['adresse_std'] ?? null,
                $student['localite_std'] ?? null,
                $student['contenu_std'] ?? 'icon.png',
                $student['statut'] ?? 'N',
                $student['handicap'] ?? 'RAS'
            ]);
        } catch (PDOException $e) {
            throw new RuntimeException("Erreur insertion élève ({$student['mat_std']}): " . $e->getMessage());
        }
    }

    /* ================================================================
     * CONFIG BULLETIN / COMPETENCES (clonage vers classe cible)
     * ================================================================ */

    public function migrateConfigMatieres(string $srcClass, string $dstClass): bool
    {
        try {
            $this->next_bdd->exec("DELETE FROM config_bull WHERE ref_class = " . $this->next_bdd->quote($dstClass));
            $stmt = $this->current_bdd->prepare(
                "SELECT ref_mat, nom_mat, coeff_mat, group_mat, ref_ens, ref_niveau_class FROM config_bull WHERE ref_class = ?"
            );
            $stmt->execute([$srcClass]);
            $ins = $this->next_bdd->prepare(
                "INSERT INTO config_bull (ref_mat, nom_mat, coeff_mat, group_mat, ref_ens, ref_niveau_class, ref_class) VALUES (?, ?, ?, ?, ?, ?, ?)"
            );
            while ($cfg = $stmt->fetch(PDO::FETCH_ASSOC)) {
                $ins->execute([
                    $cfg['ref_mat'], $cfg['nom_mat'], $cfg['coeff_mat'], $cfg['group_mat'],
                    $cfg['ref_ens'], $cfg['ref_niveau_class'], $dstClass
                ]);
            }
            try {
                $this->next_bdd->exec("DELETE FROM competences_matieres WHERE ref_class = " . $this->next_bdd->quote($dstClass));
                $stmt2 = $this->current_bdd->prepare("SELECT ref_mat, num_compt, nom_compt FROM competences_matieres WHERE ref_class = ?");
                $stmt2->execute([$srcClass]);
                $ins2 = $this->next_bdd->prepare("INSERT INTO competences_matieres (ref_mat, num_compt, nom_compt, ref_class) VALUES (?, ?, ?, ?)");
                while ($comp = $stmt2->fetch(PDO::FETCH_ASSOC)) {
                    $ins2->execute([$comp['ref_mat'], $comp['num_compt'], $comp['nom_compt'], $dstClass]);
                }
            } catch (PDOException $e) {
                // table compétences absente : ignoré
            }
            return true;
        } catch (PDOException $e) {
            return false;
        }
    }

    /**
     * Classes (du niveau/session sélectionnés) qui possèdent des élèves mais
     * AUCUNE moyenne annuelle (table_note_par_triman, ref_trim='an').
     */
    public function getClassesWithoutAnnualMoy(string $niveau, string $session): array
    {
        $missing = [];
        try {
            $check = $this->current_bdd->prepare(
                "SELECT COUNT(DISTINCT ref_std) FROM table_note_par_triman WHERE ref_trim = 'an' AND ref_cls = ? AND moy IS NOT NULL"
            );
        } catch (PDOException $e) {
            return $missing;
        }
        foreach ($this->getCurrentClasses() as $class) {
            $code = $class['code_class'];
            if (!empty($niveau) && $class['ref_class_niveau'] != $niveau) continue;
            if (!empty($session) && $session !== 'ALL' && $class['class_session'] !== $session) continue;
            $students = $this->getStudentsByClass($code);
            if (empty($students)) continue;
            try {
                $check->execute([$code]);
                if ((int)$check->fetchColumn() === 0) {
                    $missing[] = ['code' => $code, 'nom' => $class['nom_class']];
                }
            } catch (PDOException $e) {
                $missing[] = ['code' => $code, 'nom' => $class['nom_class']];
            }
        }
        return $missing;
    }

    /**
     * Indique si les moyennes annuelles existent pour l'année source
     * (table_note_par_triman, ref_trim = 'an'). La migration n'est possible
     * que si au moins une moyenne annuelle a été enregistrée (année clôturée).
     */
    public function annualMoyExists(): bool
    {
        try {
            $stmt = $this->current_bdd->query(
                "SELECT COUNT(*) FROM table_note_par_triman WHERE ref_trim = 'an' AND moy IS NOT NULL"
            );
            return (int)$stmt->fetchColumn() > 0;
        } catch (PDOException $e) {
            return false;
        }
    }

    /* ================================================================
     * MIGRATION PRINCIPALE
     * ================================================================ */

    /**
     * Migre les élèves.
     *
     * @param float  $threshold Seuil de réussite (8.00 à 12.00) : un élève dont
     *                          la moyenne annuelle (table_note_par_triman) est >= seuil
     *                          monte au niveau supérieur, sinon il redouble dans une
     *                          classe du MÊME niveau créée si aucune n'existe déjà.
     * @param string $niveau     Filtre niveau (ex: '3'), vide = tous.
     * @param string $session    Filtre session (SFG/SAG/SFT/SAT), 'ALL' = toutes.
     * @param bool   $multi      true = créer une classe par série pour le niveau suivant,
     *                           false = une seule classe accueillant tous les admis.
     */
    public function migrate(float $threshold, string $niveau, string $session, bool $multi = true, ?string $user_login = null): array
    {
        $result = ['success' => true, 'migrated_classes' => [], 'skipped_classes' => [], 'errors' => [], 'stats' => [], 'run_id' => null];

        // Verrou : une migration déjà effectuée doit être restaurée avant toute nouvelle migration.
        $locked = $this->getLockedRun();
        if ($locked !== null) {
            $result['success'] = false;
            $result['errors'][] = "Migration déjà effectuée (du {$this->current_year} vers {$this->next_year}). Restaurez d'abord cette migration pour déverrouiller.";
            return $result;
        }

        // Irréversibilité : la migration n'est possible que si la note annuelle existe.
        if (!$this->annualMoyExists()) {
            $result['success'] = false;
            $result['errors'][] = "Migration impossible : aucune moyenne annuelle n'existe dans table_note_par_triman (ref_trim='an') pour l'année {$this->current_year}. Clôturez les moyennes annuelles avant de migrer.";
            return $result;
        }

        $current_classes = $this->getCurrentClasses();

        // ABANDON TOTAL : si UNE SEULE classe du niveau/session choisi n'a aucune note
        // annuelle, toute la migration est annulée (opération irréversible).
        $no_moy = $this->getClassesWithoutAnnualMoy($niveau, $session);
        if (!empty($no_moy)) {
            $result['success'] = false;
            foreach ($no_moy as $nm) {
                $result['errors'][] = "Classe {$nm['nom']} ({$nm['code']}) : aucun élève n'a de note annuelle (table_note_par_triman, ref_trim='an'). Migration annulée.";
            }
            return $result;
        }
        $promotion_class = null;

        // Ouvre un enregistrement de migration (verrou + journal de restauration).
        $this->current_run_id = $this->startRun($user_login, $threshold);
        $result['run_id'] = $this->current_run_id;

        foreach ($current_classes as $class) {
            $code_class = $class['code_class'];
            $srcNiveau = (int)$class['ref_class_niveau'];

            if (!empty($niveau) && $class['ref_class_niveau'] != $niveau) {
                $result['skipped_classes'][] = ['code' => $code_class, 'reason' => 'Niveau non sélectionné'];
                continue;
            }
            if (!empty($session) && $session !== 'ALL' && $class['class_session'] !== $session) {
                $result['skipped_classes'][] = ['code' => $code_class, 'reason' => 'Session non sélectionnée'];
                continue;
            }

            try {
                $students = $this->getStudentsByClass($code_class);
                if (empty($students)) {
                    $result['migrated_classes'][] = [
                        'code' => $code_class,
                        'nom' => $class['nom_class'],
                        'target' => '',
                        'serie' => $this->detectSerie($class['nom_class']),
                        'students_migrated' => 0,
                        'students_skipped' => 0,
                        'students_redoubles' => 0,
                        'students_admis' => 0,
                        'students_total' => 0
                    ];
                    continue;
                }

                // ----- Terminale -> classe PROMOTION_{année_courante} -----
                if ($srcNiveau === 7) {
                    if ($promotion_class === null) {
                        $promotion_class = $this->resolvePromotionClass($class['class_session']);
                        if ($promotion_class === null) {
                            $result['skipped_classes'][] = ['code' => $code_class, 'reason' => 'Création de la classe PROMOTION impossible'];
                            continue;
                        }
                    }
                    $target = $promotion_class;
                    $serie = 'PROMOTION';

                    $migrated = 0;
                    $skipped = 0;
                    $targets_used = [$target['code_class'] => $target];

                    foreach ($students as $student) {
                        if (!$this->studentExistsInNext($student['mat_std'])) {
                            if ($this->insertStudent($student, $target['code_class'])) {
                                $migrated++;
                                $this->recordUndo($student['mat_std'], $code_class, $target['code_class']);
                            }
                        } else {
                            $skipped++;
                        }
                    }

                    $result['migrated_classes'][] = [
                        'code' => $code_class,
                        'nom' => $class['nom_class'],
                        'target' => $target['nom_class'],
                        'serie' => $serie,
                        'students_migrated' => $migrated,
                        'students_skipped' => $skipped,
                        'students_redoubles' => 0,
                        'students_admis' => 0,
                        'students_total' => count($students)
                    ];
                    $result['stats']['total_students'] = ($result['stats']['total_students'] ?? 0) + $migrated;
                    $result['stats']['total_classes'] = ($result['stats']['total_classes'] ?? 0) + 1;
                    continue;
                }

                // ----- Niveaux 1 à 6 : admis vs redoublants -----
                $srcSerie = $this->detectSerie($class['nom_class']);
                if ($srcSerie === '') $srcSerie = 'ALL';

                $migrated = 0;
                $skipped = 0;
                $redoubles = 0;
                $admis = 0;
                $targets_used = [];
                $mainTargetNom = '';

                foreach ($students as $student) {
                    $moy = $this->getAnnualMoy($student['mat_std'], $code_class);
                    $isAdmis = ($moy !== null && $moy >= $threshold);

                    if ($isAdmis) {
                        $admis++;
                        if ($multi) {
                            // Plusieurs classes par série pour le niveau suivant
                            $stdSerie = $this->orientStudent($student['mat_std'], $class, $threshold);
                            $target = $this->resolveTargetClass($srcNiveau + 1, $class['class_session'], $stdSerie, $class);
                        } else {
                            // Une seule classe pour tous les admis du niveau suivant
                            $target = $this->resolveTargetClass($srcNiveau + 1, $class['class_session'], '', $class);
                        }
                    } else {
                        // Redoublant : classe du MÊME niveau dans la base suivante,
                        // créée si aucune n'existe déjà (classe « simple », ex: 5E).
                        $redoubles++;
                        $target = $this->resolveTargetClass($srcNiveau, $class['class_session'], '', $class);
                    }

                    if ($target === null) {
                        $skipped++;
                        continue;
                    }
                    $targets_used[$target['code_class']] = $target;
                    if ($mainTargetNom === '') $mainTargetNom = $target['nom_class'];

                    if (!$this->studentExistsInNext($student['mat_std'])) {
                        if ($this->insertStudent($student, $target['code_class'])) {
                            $migrated++;
                            $this->recordUndo($student['mat_std'], $code_class, $target['code_class']);
                        }
                    } else {
                        $skipped++;
                    }
                }

                foreach ($targets_used as $tc) {
                    $this->migrateConfigMatieres($code_class, $tc['code_class']);
                }

                $result['migrated_classes'][] = [
                    'code' => $code_class,
                    'nom' => $class['nom_class'],
                    'target' => $mainTargetNom,
                    'serie' => $srcSerie,
                    'students_migrated' => $migrated,
                    'students_skipped' => $skipped,
                    'students_redoubles' => $redoubles,
                    'students_admis' => $admis,
                    'students_total' => count($students)
                ];
                $result['stats']['total_students'] = ($result['stats']['total_students'] ?? 0) + $migrated;
                $result['stats']['total_classes'] = ($result['stats']['total_classes'] ?? 0) + 1;

            } catch (RuntimeException $e) {
                $result['errors'][] = "Classe {$code_class}: " . $e->getMessage();
                $result['success'] = false;
            }
        }

        // Clôture l'enregistrement : persiste les classes créées, met à jour les
        // totaux et VERROUILLE la migration (tant qu'elle n'est pas restaurée).
        $this->finishRun($result['stats'] ?? []);

        return $result;
    }

    /**
     * Résout la classe cible pour une série donnée : la réutilise si elle
     * existe dans la base suivante, sinon la crée (même série, niveau+1).
     */
    private function resolveTargetClass(int $targetNiveau, string $class_session, string $serie, array $sourceClass): ?array
    {
        $existing = $this->findTargetClass((string)$targetNiveau, $class_session, $serie);
        if ($existing !== null) return $existing;

        $targetNom = $this->buildTargetClassName($targetNiveau, $serie);
        $code = $this->genClassCode();
        $tries = 0;
        while ($this->classExistsInNext($code) && $tries < 20) {
            $code = $this->genClassCode();
            $tries++;
        }
        if ($this->createClassInNext($code, $targetNom, (string)$targetNiveau, $class_session)) {
            return ['code_class' => $code, 'nom_class' => $targetNom, 'ref_class_niveau' => (string)$targetNiveau, 'class_session' => $class_session];
        }
        // Re-tentative après création
        $existing = $this->findTargetClass((string)$targetNiveau, $class_session, $serie);
        return $existing;
    }

    /**
     * Classe `PROMOTION_{année_courante}` : accueille tous les élèves sortants (Terminale).
     */
    private function resolvePromotionClass(string $class_session): ?array
    {
        $nom = 'PROMOTION_' . $this->current_year;
        $stmt = $this->next_bdd->prepare("SELECT code_class, nom_class, ref_class_niveau, class_session FROM classes WHERE nom_class = ? LIMIT 1");
        $stmt->execute([$nom]);
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        if ($row) return $row;

        $code = $this->genClassCode();
        $tries = 0;
        while ($this->classExistsInNext($code) && $tries < 20) {
            $code = $this->genClassCode();
            $tries++;
        }
        if ($this->createClassInNext($code, $nom, '7', $class_session)) {
            return ['code_class' => $code, 'nom_class' => $nom, 'ref_class_niveau' => '7', 'class_session' => $class_session];
        }
        return null;
    }

    /* ================================================================
     * VERROU & RESTAURATION
     * ================================================================ */

    private function ensureRunTables(): void
    {
        try {
            $this->next_bdd->exec("CREATE TABLE IF NOT EXISTS migration_state (
                id INT AUTO_INCREMENT PRIMARY KEY,
                current_year VARCHAR(10),
                next_year VARCHAR(10),
                user_login VARCHAR(50),
                seuil DECIMAL(4,2) DEFAULT NULL,
                total_classes INT DEFAULT 0,
                total_students INT DEFAULT 0,
                status VARCHAR(20) DEFAULT 'done',
                created_at DATETIME,
                restored_at DATETIME NULL
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
            $this->next_bdd->exec("CREATE TABLE IF NOT EXISTS migration_undo (
                id INT AUTO_INCREMENT PRIMARY KEY,
                run_id INT,
                mat_std VARCHAR(50),
                old_class VARCHAR(50),
                new_class VARCHAR(50),
                created_at DATETIME
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
            $this->next_bdd->exec("CREATE TABLE IF NOT EXISTS migration_created_classes (
                id INT AUTO_INCREMENT PRIMARY KEY,
                run_id INT,
                code_class VARCHAR(50),
                class_session VARCHAR(10),
                created_at DATETIME
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
        } catch (PDOException $e) {
            // rien
        }
    }

    private function startRun(?string $user_login, float $threshold): int
    {
        $this->ensureRunTables();
        $this->pending_created_classes = [];
        try {
            $stmt = $this->next_bdd->prepare(
                "INSERT INTO migration_state (current_year, next_year, user_login, seuil, status, created_at) VALUES (?, ?, ?, ?, 'running', NOW())"
            );
            $stmt->execute([$this->current_year, $this->next_year, $user_login, $threshold]);
            return (int)$this->next_bdd->lastInsertId();
        } catch (PDOException $e) {
            return 0;
        }
    }

    private function recordUndo(string $mat, string $old_class, string $new_class): void
    {
        if (!$this->current_run_id) return;
        try {
            $stmt = $this->next_bdd->prepare(
                "INSERT INTO migration_undo (run_id, mat_std, old_class, new_class, created_at) VALUES (?, ?, ?, ?, NOW())"
            );
            $stmt->execute([$this->current_run_id, $mat, $old_class, $new_class]);
        } catch (PDOException $e) {
            // rien
        }
    }

    private function finishRun(array $stats): void
    {
        if (!$this->current_run_id) return;
        $students = (int)($stats['total_students'] ?? 0);
        $classes  = (int)($stats['total_classes'] ?? 0);
        $status   = $students > 0 ? 'done' : 'empty';
        try {
            if (!empty($this->pending_created_classes)) {
                $ins = $this->next_bdd->prepare(
                    "INSERT INTO migration_created_classes (run_id, code_class, class_session, created_at) VALUES (?, ?, ?, NOW())"
                );
                foreach ($this->pending_created_classes as $code => $sess) {
                    $ins->execute([$this->current_run_id, $code, $sess]);
                }
            }
            $stmt = $this->next_bdd->prepare(
                "UPDATE migration_state SET status = ?, total_classes = ?, total_students = ? WHERE id = ?"
            );
            $stmt->execute([$status, $classes, $students, $this->current_run_id]);
        } catch (PDOException $e) {
            // rien
        }
        $this->current_run_id = null;
        $this->pending_created_classes = [];
    }

    /**
     * Retourne la migration verrouillante (déjà effectuée, non restaurée) pour
     * la paire d'années courante, ou null si aucune.
     */
    public function getLockedRun(): ?array
    {
        try {
            $this->ensureRunTables();
            $stmt = $this->next_bdd->prepare(
                "SELECT * FROM migration_state WHERE current_year = ? AND next_year = ? AND status = 'done' ORDER BY id DESC LIMIT 1"
            );
            $stmt->execute([$this->current_year, $this->next_year]);
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            return $row ?: null;
        } catch (PDOException $e) {
            return null;
        }
    }

    /**
     * Annule une migration : supprime de la base suivante tous les élèves qui y
     * ont été transférés par cette migration, ainsi que les classes créées et
     * devenues vides. Les élèves déjà présents avant la migration sont conservés.
     */
    public function restoreMigration(int $run_id): array
    {
        $res = ['success' => false, 'students_restored' => 0, 'classes_removed' => 0, 'errors' => []];
        try {
            $s = $this->next_bdd->prepare("SELECT * FROM migration_state WHERE id = ? AND status = 'done' LIMIT 1");
            $s->execute([$run_id]);
            $run = $s->fetch(PDO::FETCH_ASSOC);
            if (!$run) {
                $res['errors'][] = "Migration introuvable ou déjà restaurée.";
                return $res;
            }

            // 1) Supprimer les élèves insérés par cette migration (jamais les pré-existants).
            $u = $this->next_bdd->prepare("SELECT mat_std, new_class FROM migration_undo WHERE run_id = ?");
            $u->execute([$run_id]);
            $del = $this->next_bdd->prepare("DELETE FROM eleves WHERE mat_std = ? AND ref_class = ?");
            while ($row = $u->fetch(PDO::FETCH_ASSOC)) {
                $del->execute([$row['mat_std'], $row['new_class']]);
                $res['students_restored'] += $del->rowCount();
            }

            // 2) Supprimer les classes créées devenues vides.
            $c = $this->next_bdd->prepare("SELECT code_class, class_session FROM migration_created_classes WHERE run_id = ?");
            $c->execute([$run_id]);
            $cnt = $this->next_bdd->prepare("SELECT COUNT(*) FROM eleves WHERE ref_class = ?");
            $delCls = $this->next_bdd->prepare("DELETE FROM classes WHERE code_class = ?");
            $delCfg = $this->next_bdd->prepare("DELETE FROM config_bull WHERE ref_class = ?");
            $delComp = $this->next_bdd->prepare("DELETE FROM competences_matieres WHERE ref_class = ?");
            while ($row = $c->fetch(PDO::FETCH_ASSOC)) {
                $cnt->execute([$row['code_class']]);
                if ((int)$cnt->fetchColumn() === 0) {
                    try { $delCfg->execute([$row['code_class']]); } catch (PDOException $e) {}
                    try { $delComp->execute([$row['code_class']]); } catch (PDOException $e) {}
                    if ($delCls->execute([$row['code_class']])) {
                        $res['classes_removed']++;
                        try {
                            $upd = $this->next_bdd->prepare("UPDATE sess SET nb_class_par_sess = (SELECT COUNT(*) FROM classes WHERE class_session = ?) WHERE abr_sess = ?");
                            $upd->execute([$row['class_session'], $row['class_session']]);
                        } catch (PDOException $e) {}
                    }
                }
            }

            // 3) Déverrouiller (statut restauré) et nettoyer les journaux.
            $this->next_bdd->prepare("UPDATE migration_state SET status = 'restored', restored_at = NOW() WHERE id = ?")->execute([$run_id]);
            $this->next_bdd->prepare("DELETE FROM migration_undo WHERE run_id = ?")->execute([$run_id]);
            $this->next_bdd->prepare("DELETE FROM migration_created_classes WHERE run_id = ?")->execute([$run_id]);

            $res['success'] = true;
        } catch (PDOException $e) {
            $res['errors'][] = "Erreur restauration: " . $e->getMessage();
        }
        return $res;
    }

    /**
     * Historique des migrations (verrou/restauration) pour la paire d'années courante.
     */
    public function getRuns(): array
    {
        try {
            $this->ensureRunTables();
            $stmt = $this->next_bdd->prepare("SELECT * FROM migration_state WHERE current_year = ? AND next_year = ? ORDER BY id DESC LIMIT 20");
            $stmt->execute([$this->current_year, $this->next_year]);
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (PDOException $e) {
            return [];
        }
    }

    /* ================================================================
     * HISTORIQUE
     * ================================================================ */

    public function logMigration(string $user_login, string $current_year, string $next_year, array $stats, string $threshold): bool
    {
        try {
            $this->next_bdd->exec("CREATE TABLE IF NOT EXISTS migration_log (
                id INT AUTO_INCREMENT PRIMARY KEY,
                user_login VARCHAR(50),
                current_year VARCHAR(10),
                next_year VARCHAR(10),
                seuil DECIMAL(4,2),
                total_classes INT DEFAULT 0,
                total_students INT DEFAULT 0,
                date_migration DATETIME
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
            $stmt = $this->next_bdd->prepare(
                "INSERT INTO migration_log (user_login, current_year, next_year, seuil, total_classes, total_students, date_migration) VALUES (?, ?, ?, ?, ?, ?, NOW())"
            );
            return $stmt->execute([
                $user_login, $current_year, $next_year, $threshold,
                $stats['total_classes'] ?? 0, $stats['total_students'] ?? 0
            ]);
        } catch (PDOException $e) {
            return false;
        }
    }

    public function getMigrationHistory(): array
    {
        try {
            $stmt = $this->next_bdd->query("SELECT * FROM migration_log ORDER BY date_migration DESC LIMIT 50");
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (PDOException $e) {
            return [];
        }
    }

    public function __destruct()
    {
        $this->current_bdd = null;
        $this->next_bdd = null;
    }
}