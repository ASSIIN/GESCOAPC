<?php 
 session_start(); 
 
  require_once '../Model/connexion.php';
  require_once '../core/require.php'; 
  require_once '../vendor/autoload.php';
  use PhpOffice\PhpSpreadsheet\IOFactory;
  use PhpOffice\PhpSpreadsheet\Spreadsheet;
  use PhpOffice\PhpSpreadsheet\Writer\Xlsx;
  use PhpOffice\PhpSpreadsheet\Shared\Date;

if (!isset($_SESSION['user'])) {
    header('location: ../index.php');
    exit;
}

$etb->ShowEtb();

// CORRECTION : récupération sécurisée du paramètre GET
$refcls= trim((string)($_GET['refcls'] ?? ''));
// Virifions si la classes Existe
   $ckcls=$class->CkExistingCode($refcls);
    if ($refcls==="" || $ckcls===false) {
    header('location: ../menu_classes.php');    
    exit;
  }
  else 
  {

    $bdd = $GLOBALS['bdd'];
      // CORRECTION : requête préparée anti-injection SQL (la concaténation $refcls
      // dans la clause WHERE était vulnérable)
      $reponse = $bdd->prepare('SELECT * FROM eleves WHERE ref_class = ? ORDER BY nom_std ASC');
      $reponse->execute(array($refcls));
  
        // Créer un objet PHPExcel

      // Créez un tableau Excel
$spreadsheet = new Spreadsheet();
$sheet = $spreadsheet->getActiveSheet();

// Définissez les en-têtes de colonnes
 $sheet->setCellValue('A1', '#');
$sheet->setCellValue('B1', 'N° Inscipt');
$sheet->setCellValue('C1', 'Matricule');
$sheet->setCellValue('D1', 'Noms_et_Prénoms/Full_Name');
$sheet->setCellValue('E1', 'Né(e)le/Born');
$sheet->setCellValue('F1', 'Lieu_de_nais/Place');
$sheet->setCellValue('G1', 'Sexe');
$sheet->setCellValue('H1', 'Red');
$sheet->setCellValue('I1', 'Contact');

// Récupérez les données de la base de données
// CORRECTION : requête préparée anti-injection SQL
$stmt = $bdd->prepare('SELECT * FROM eleves WHERE ref_class = ? ORDER BY nom_std ASC');
$stmt->execute(array($refcls));
$results = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Insérez les données dans la feuille de calcul
$i = 2;
foreach ($results as $result) {

        $ni=(string)$i-1;
        $Nom=htmlspecialchars($result['nom_std']); 
        $sheet->setCellValue('A' . $i, $ni);
        $sheet->setCellValue('B' . $i, $_SESSION['pre_matr'].''.$result['mat_std']);
        $sheet->setCellValue('C' . $i, $result['cni_std']);
        $sheet->setCellValue('D' . $i, $Nom);
        $sheet->setCellValue('E' . $i, date_format(new DateTime($result['date_nais']), 'd/m/Y'));
        $sheet->setCellValue('F' . $i, $result['lieu_nais']);
        $sheet->setCellValue('G' . $i, $result['sexe_std']);
        if ($result['sexe_std'] !== NULL) {
            $sheet->setCellValue('G' . $i, $result['sexe_std']);
        } else {
            $sheet->setCellValue('G' . $i, '');
        }
         if ($result['statut'] !== NULL) {
            $sheet->setCellValue('H' . $i, $result['statut']);
        } else {
            $sheet->setCellValue('H' . $i, '');
        }

        if ($result['adresse_std'] !== NULL) {
            $sheet->setCellValue('I' . $i, $result['adresse_std']);
        } else {
            $sheet->setCellValue('I' . $i, '');
        }
         $i++;
}

// Augmente la taille des colonnes en fonction du contenu
$sheet->getColumnDimension('A')->setAutoSize(true);
$sheet->getColumnDimension('B')->setAutoSize(true);
$sheet->getColumnDimension('C')->setAutoSize(true);
$sheet->getColumnDimension('D')->setAutoSize(true);
$sheet->getColumnDimension('E')->setAutoSize(true);
$sheet->getColumnDimension('F')->setAutoSize(true);
$sheet->getColumnDimension('G')->setAutoSize(true);
$sheet->getColumnDimension('H')->setAutoSize(true);
$sheet->getColumnDimension('I')->setAutoSize(true);

// Définit le format de la date
$sheet->getStyle('E2:E' . $i-1)->getNumberFormat()->setFormatCode('dd/mm/yyyy');


// Définissez les en-têtes HTTP pour le téléchargement du fichier Excel
$writer = new Xlsx($spreadsheet);
// CORRECTION : nom de fichier assaini (anti header-injection)
$safe_cls = preg_replace('/[^A-Za-z0-9 _-]/', '', (string)($_SESSION['nom_class'] ?? ''));
$filename = 'CLASS_LIST_' . $safe_cls . date('mdHis') . '.xlsx';
header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
header("Content-Disposition: attachment; filename=\"$filename\"");
header('Cache-Control: max-age=0');
ob_end_clean();
$writer->save('php://output');
exit;

    }


 
?>