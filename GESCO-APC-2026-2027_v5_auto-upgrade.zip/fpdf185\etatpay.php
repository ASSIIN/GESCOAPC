<?php
session_start();
require_once '../Model/connexion.php';
require_once '../core/require.php';
 if (!isset($_SESSION['user'])) {
    session_unset();
    session_destroy();
    header('location: ../index.php');    
    }
 $etb->ShowEtb();

/*//Virifions si la classes Existe
       $ckcls=$class->CkExistingCode($_GET['refcls']);
        if (($_GET['rs']=="") or ($ckcls==false)) {
        header('location: ../gestion_fin.php');    
      }*/
require('fpdf.php');
$pdf = new FPDF();

class PDF extends FPDF
{
// En-tête
function Header()
{
	 $this->SetY(15);
    // Logo
    $this->Image('../plugins/images/'.$_SESSION['logo_etb'].'',10,6,30);
    // Police Arial gras 15
    $this->SetFont('Arial','B',15);
    // Décalage à droite
    $this->Cell(80);
    // Titre
    $this->Cell(30,10,'Titre',1,0,'C');
    // Saut de ligne
    $this->Ln(20);
}

// Pied de page
function Footer()
{
    // Positionnement à 1,5 cm du bas
    $this->SetY(-15);
    // Police Arial italique 8
    $this->SetFont('Arial','I',8);
    // Numéro de page
    $this->Cell(0,10,'Page '.$this->PageNo().'/{nb}',0,0,'C');
}
}
$pdf->AliasNBPages();
$pdf->AddPage();
//code for print data

			$i=1;
			$eff=0;
			/*En-tête*/
				$pdf->SetFont('Times','',8);
				$pdf->Image('../plugins/images/'.$_SESSION['logo_etb'].'',90,15,30);
				$pdf->Cell(70,4,'REPUBLIQUE DU CAMEROUN',0,0,'C');
				$pdf->Cell(50,4,'',0,0);
				$pdf->Cell(70,4,'REPUBLIC OF CAMEROON',0,1,'C');

				$pdf->Cell(70,4,'Paix-Travail-Patrie',0,0,'C');
				$pdf->Cell(50,4,'',0,0);
				$pdf->Cell(70,4,'Peace-Work-Fatherland',0,1,'C');

				$pdf->Cell(70,4, utf8_to_cp1252("".$_SESSION['minist_etb_fr'].""),0,0,'C');
				$pdf->Cell(50,4,'',0,0);
				$pdf->Cell(70,4,utf8_to_cp1252(''.$_SESSION['minist_etb_en'].''),0,1,'C');

				$pdf->Cell(70,4,utf8_to_cp1252("".$_SESSION['region_etb_fr'].""),0,0,'C');
				$pdf->Cell(50,4,'',0,0);
				$pdf->Cell(70,4,utf8_to_cp1252(''.$_SESSION['region_etb_en'].''),0,1,'C');

				$pdf->Cell(70,4,utf8_to_cp1252(''.$_SESSION['depart_etb_fr'].''),0,0,'C');
				$pdf->Cell(50,4,'',0,0);
				$pdf->Cell(70,4,utf8_to_cp1252(''.$_SESSION['depart_etb_en'].''),0,1,'C');
				$pdf->SetFont('Times','B',10);
				$pdf->Cell(70,6,utf8_to_cp1252(''.$_SESSION['nom_etb_fr'].''),0,0,'C');
				$pdf->Cell(50,6,'',0,0);
				$pdf->Cell(70,6,utf8_to_cp1252(''.$_SESSION['nom_etb_en'].''),0,1,'C');
				$pdf->SetFont('Times','',8);
				$pdf->Cell(70,5,utf8_to_cp1252(''.$_SESSION['code_pste_etb'].' / '.$_SESSION['tel_etb'].''),0,0,'C');
				$pdf->Cell(50,5,'',0,0);
				$pdf->Cell(70,5,utf8_to_cp1252(''.$_SESSION['code_pste_etb'].'/ '.$_SESSION['tel_etb'].''),0,1,'C');
				$pdf->SetFont('Times','',8);
				$pdf->Cell(70,4,utf8_to_cp1252(''.$_SESSION['email_etb'].''),0,0,'C');
				$pdf->Cell(50,4,'',0,0);
				$pdf->Cell(70,4,utf8_to_cp1252(''.$_SESSION['email_etb'].''),0,1,'C');
					$pdf->Ln();
					$pdf->SetFont('Times','I',12);
					$pdf->Cell(65,5,'',0,0);
					$pdf->Cell(60,5,utf8_to_cp1252(''.$_SESSION['code_im_etb'].''),0,0,'C');
					$pdf->Ln();
					$pdf->Ln();
			/*FIN En-tête*/
						$today= date('d/m/Y');
					$pdf->SetFont('Times','B',12);
					$pdf->SetFillColor(171,177,186);
					$pdf->SetFillColor(217,245,254);
					$pdf->Cell(20,6,'',0,0,'C');
					$pdf->Cell(150,6,'TOUS LES ETATS DE PAIEMENTS /FULL PAYMENT STATEMENTS',1,0,'C',1);
					$pdf->Ln();
					$pdf->SetTextColor(255,2,2);
					$pdf->SetFont('Times','B',12);
					$pdf->Cell(60,5,'',0,0,'C');
					$pdf->Cell(70,5,utf8_to_cp1252('Du/From  '.$today.''),0,1,'C');
					$pdf->Cell(60,5,'',0,0,'C');
					$pdf->Ln();
					$pdf->SetTextColor(0,0,0);
					$pdf->SetFont('Times','B',12);
					$pdf->Ln();
					$pdf->SetFont('Times','B',10);
			$pdf->Ln();
				$pdf->Cell(10,6,utf8_to_cp1252('N°'),1,0, 'C');
				$pdf->Cell(30,6,'Class(e)',1,0, 'C');
				$pdf->Cell(10,6,utf8_to_cp1252('Eff'),1,0, 'C');
				$pdf->Cell(20,6,utf8_to_cp1252('Ps/Sc.fees'),1,0, 'C');
				$pdf->Cell(32,6,utf8_to_cp1252('(Ps/Sc.fees)*Eff'),1,0, 'C');
				$pdf->Cell(28,6,utf8_to_cp1252('Payé/Paid'),1,0, 'C');
				$pdf->Cell(28,6,utf8_to_cp1252('Remise/Discount'),1,0, 'C');
				$pdf->Cell(28,6,utf8_to_cp1252('Reste/Unpaid'),1,0, 'C');

			$i=0;
			$Tg_ps=0;
			$Tg_rdt=0;
			$Tg_vsm=0;
			$Tg_reste=0;
			$Tnbstd=0;

			$bdd = $GLOBALS['bdd'];
			$reponse0 = $bdd->query('SELECT * FROM classes where id>=0 order by ref_class_niveau asc');

			while($row0 = $reponse0->fetch(PDO::FETCH_ASSOC)) 
			{	
				$i++;

			/* Initier les paramètres*/
				$nv=$fin->ReturnClasseNiveauByCode($row0['code_class']);
				$sess=$fin->ReturnClasseSessionByCode($row0['code_class']);
				$ps=$fin->Return_Ps_Nv($nv,$sess);
				$class->CkClasseByCode($row0['code_class']);
				$nomcls=$_SESSION['nom_class'];			
				$bdd = $GLOBALS['bdd'];
				$nbstd=$class->NbrStudentByClass($row0['code_class']);
				$g_ps=0;
				$g_rdt=0;
				$g_vsm=0;
				$g_reste=0;
				$nf_g_ps=0;
				$nf_g_rdt=0;
				$nf_g_vsm=0;
				$nf_g_reste=0;
				$nf_ps=0;

				$reponse1 = $bdd->query('SELECT * FROM eleves where ref_class="'.$row0['code_class'].'" order by nom_std asc');
						
				while($row1 = $reponse1->fetch(PDO::FETCH_ASSOC)) 
				{
					$rdt=$fin->Return_All_rdt_std($row1['mat_std']);
					$vsm=$fin->Return_All_vsm_std($row1['mat_std']);
					$reste=$ps-$vsm-$rdt;
					$g_rdt+=$rdt;
					$g_vsm+=$vsm;
					$g_reste+=$reste;
					
				}
				$g_ps=$ps*$nbstd;

				if ($ps!=0) {
					
					$nf_g_ps= number_format($g_ps,0,",",".");
					$nf_g_rdt= number_format($g_rdt,0,",",".");
					$nf_g_vsm= number_format($g_vsm,0,",",".");
					$nf_g_reste= number_format($g_reste,0,",",".");
					$nf_ps= number_format($ps,0,",",".");				
					}			
				 
				 $pdf->SetFont('Arial','',10);
					$pdf->Ln();
							
					$pdf->Cell(10,8,utf8_to_cp1252($i),1,0,'C');
					$pdf->Cell(30,8,utf8_to_cp1252($nomcls),1,0,'L');
					$pdf->Cell(10,8,utf8_to_cp1252($nbstd),1,0,'C');
					$pdf->Cell(20,8,utf8_to_cp1252($nf_ps),1,0,'C');
					$pdf->Cell(32,8,utf8_to_cp1252($nf_g_ps),1,0,'C');
					$pdf->Cell(28,8,utf8_to_cp1252($nf_g_vsm),1,0,'C');
					$pdf->Cell(28,8,utf8_to_cp1252($nf_g_rdt),1,0,'C');
					$pdf->Cell(28,8,utf8_to_cp1252($nf_g_reste),1,0,'C');
					$Tg_ps+=$g_ps;
					$Tnbstd+=$nbstd;
					$Tg_rdt+=$g_rdt;
					$Tg_vsm+=$g_vsm;
					$Tg_reste+=$g_reste;
				}

					
					$Tg_ps= number_format($Tg_ps,0,",",".");
					$Tg_rdt= number_format($Tg_rdt,0,",",".");
					$Tg_vsm= number_format($Tg_vsm,0,",",".");
					$Tg_reste= number_format($Tg_reste,0,",",".");
					

				 $pdf->SetFont('Arial','B',12);
					$pdf->Ln();
							
					
					$pdf->Cell(40,8,utf8_to_cp1252('Pension Total'),1,0,'L');
					$pdf->Cell(10,8,utf8_to_cp1252($Tnbstd),1,0,'C');
					$pdf->Cell(20,8,utf8_to_cp1252('---'),1,0,'C');
					$pdf->Cell(32,8,utf8_to_cp1252($Tg_ps),1,0,'C');
					$pdf->Cell(28,8,utf8_to_cp1252($Tg_vsm),1,0,'C');
					$pdf->Cell(28,8,utf8_to_cp1252($Tg_rdt),1,0,'C');
					$pdf->Cell(28,8,utf8_to_cp1252($Tg_reste),1,0,'C');
					$pdf->SetXY(125,272);
					$pdf->SetFont('Arial','',10);
				$pdf->Cell(0,3,'Page '.$pdf->PageNo().'/{nb}',0,1,'C');
				$pdf->Output('ETATS_PAIEMENTS_GENERAL.pdf','I');
				$pdf->Close();
?>
