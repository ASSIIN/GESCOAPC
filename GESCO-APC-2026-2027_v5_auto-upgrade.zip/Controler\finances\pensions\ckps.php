<?php
	session_start();
	require_once '../../Model/connexion.php';
	require_once '../../core/require.php'; 
	
	$codeswift= htmlspecialchars($_GET['ref']);
  		 /* Conversion*/
  		 $codeswift=strtoupper($codeswift);
  		 
			$client->CkClient($codeswift);
		 	$id=$_SESSION['id_tampC'];
			$ref=$_SESSION['ref'];
			$admin->CkAdmin($ref);

				if ($codeswift== $_SESSION['codeT']) {
				header('location: ../../View/checktranfert.php?id='.$id.'');
				}
			else {
				header('location: ../../View/check.php');
				}	
?>