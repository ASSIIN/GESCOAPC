<?php
session_start();
require_once '../Model/connexion.php';
require_once '../core/require.php';
 if (!isset($_SESSION['user'])) {
    session_unset();
    session_destroy();
    header('location: ../index.php');    
    }
 $etb->ShowEtb();

require('fpdf.php');
$pdf = new FPDF();

class PDF extends FPDF
{
// En-tête
function Header()
{
	 $this->SetY(15);
    // Logo
    $this->Image('../plugins/images/'.$_SESSION['logo_etb'].'',10,6,30);
    // Police Arial gras 15
    $this->SetFont('Arial','B',15);
    // Décalage à droite
    $this->Cell(80);
    // Titre
    $this->Cell(30,10,'Titre',1,0,'C');
    // Saut de ligne
    $this->Ln(20);
}

// Pied de page
function Footer()
{
    // Positionnement à 1,5 cm du bas
    $this->SetY(-15);
    // Police Arial italique 8
    $this->SetFont('Arial','I',8);
    // Numéro de page
    $this->Cell(0,10,'Page '.$this->PageNo().'/{nb}',0,0,'C');
}
}
$pdf->AliasNBPages();
$pdf->AddPage();
//code for print data

			/*En-tête*/
				$pdf->SetFont('Times','',7);
				$pdf->Image('../plugins/images/'.$_SESSION['logo_etb'].'',95,15,18);
				$pdf->Cell(70,4,'REPUBLIQUE DU CAMEROUN',0,0,'C');
				$pdf->Cell(50,4,'',0,0);
				$pdf->Cell(70,4,'REPUBLIC OF CAMEROON',0,1,'C');

				$pdf->Cell(70,4,'Paix-Travail-Patrie',0,0,'C');
				$pdf->Cell(50,4,'',0,0);
				$pdf->Cell(70,4,'Peace-Work-Fatherland',0,1,'C');

				$pdf->Cell(70,4, utf8_to_cp1252("".$_SESSION['minist_etb_fr'].""),0,0,'C');
				$pdf->Cell(50,4,'',0,0);
				$pdf->Cell(70,4,utf8_to_cp1252(''.$_SESSION['minist_etb_en'].''),0,1,'C');

				$pdf->Cell(70,4,utf8_to_cp1252("".$_SESSION['region_etb_fr'].""),0,0,'C');
				$pdf->Cell(50,4,'',0,0);
				$pdf->Cell(70,4,utf8_to_cp1252(''.$_SESSION['region_etb_en'].''),0,1,'C');

				$pdf->Cell(70,4,utf8_to_cp1252(''.$_SESSION['depart_etb_fr'].''),0,0,'C');
				$pdf->Cell(50,4,'',0,0);
				$pdf->Cell(70,4,utf8_to_cp1252(''.$_SESSION['depart_etb_en'].''),0,1,'C');
				$pdf->SetFont('Times','B',10);
				$pdf->Cell(70,6,utf8_to_cp1252(''.$_SESSION['nom_etb_fr'].''),0,0,'C');
				$pdf->Cell(50,6,'',0,0);
				$pdf->Cell(70,6,utf8_to_cp1252(''.$_SESSION['nom_etb_en'].''),0,1,'C');
				$pdf->SetFont('Times','',8);
				$pdf->Cell(70,5,utf8_to_cp1252(''.$_SESSION['code_pste_etb'].' / '.$_SESSION['tel_etb'].''),0,0,'C');
				$pdf->Cell(50,5,'',0,0);
				$pdf->Cell(70,5,utf8_to_cp1252(''.$_SESSION['code_pste_etb'].'/ '.$_SESSION['tel_etb'].''),0,1,'C');
				$pdf->SetFont('Times','',8);
				$pdf->Cell(70,4,utf8_to_cp1252(''.$_SESSION['email_etb'].''),0,0,'C');
				$pdf->Cell(50,4,'',0,0);
				$pdf->Cell(70,4,utf8_to_cp1252(''.$_SESSION['email_etb'].''),0,1,'C');
				$pdf->Ln();
				$pdf->SetFont('Times','I',12);
				$pdf->Cell(65,5,'',0,0);
				$pdf->Cell(60,5,utf8_to_cp1252(''.$_SESSION['code_im_etb'].''),0,0,'C');
				$pdf->Ln();
				$pdf->Ln();
			/*FIN En-tête*/
				$pdf->SetFont('Times','B',12);
				$pdf->SetFillColor(171,177,186);
				$pdf->Cell(20,6,'',0,0,'C');
				$pdf->Cell(150,6,'LISTE DE TOUTES LES CLASSES/ ALL CLASS LIST',1,0,'C',1);
				$pdf->Cell(20,6,'',0,1,'C');
				$pdf->Ln();

				$clsSFG=$class->CkNbClsbySess("SFG");
				$nomSFG=$class->ReturnNomSess_by_Code("SFG");
				$clsSAG=$class->CkNbClsbySess("SAG");
				$nomSAG=$class->ReturnNomSess_by_Code("SAG");
				$MaxnvSFG=$class->Return_MaxNVCls_Sess("SFG");
				$MaxnvSAG=$class->Return_MaxNVCls_Sess("SAG");
				$nbClssSAG=$class->ReturnNvCls_by_Sess('SAG');	
		        $nbClssSFG=$class->ReturnNvCls_by_Sess('SFG');

		        $clsSFT=$class->CkNbClsbySess("SFT");
				$nomSFT=$class->ReturnNomSess_by_Code("SFT");
				$clsSAT=$class->CkNbClsbySess("SAT");
				$nomSAT=$class->ReturnNomSess_by_Code("SAT");
				$MaxnvSFT=$class->Return_MaxNVCls_Sess("SFT");
				$MaxnvSAT=$class->Return_MaxNVCls_Sess("SAT");
				$nbClssSAT=$class->ReturnNvCls_by_Sess('SAT');	
		        $nbClssSFT=$class->ReturnNvCls_by_Sess('SFT');

		        /*if ($lnv==$MaxnvSA) 
				{		
					$pdf->SetFillColor(203,220,247);
					$pdf->Ln();
					$pdf->Cell(20,7,'',0,0,'C',0);
					$pdf->Cell(97,7,'Total Niveau '.$lnv,1,0,'C',1);
					$pdf->Cell(15,7,$TFlnv,1,0,'C',1);
					$pdf->Cell(15,7,$TGlnv,1,0,'C',1);
					$pdf->Cell(22,7,$Tlnv,1,0,'C',1);
				}*/
				if ($clsSFG>0) 
				{
					
					$pdf->SetFont('Times','B',12);
					$pdf->SetFillColor(213,210,1);
					$pdf->Ln();
					$pdf->Cell(20,7,'',0,0,'C',0);
					$pdf->Cell(10,7,utf8_to_cp1252('N°'),1,0,'C',1);
					$pdf->Cell(22,7,'Code',1,0,'C',1);
					$pdf->Cell(15,7,'Niveau',1,0,'C',1);
					$pdf->Cell(50,7,'Nom de la Classe',1,0,'C',1);
					$pdf->Cell(15,7,'F',1,0,'C',1);
					$pdf->Cell(15,7,'G',1,0,'C',1);
					$pdf->Cell(22,7,'Total',1,0,'C',1);
					$pdf->SetFont('Times','B',10);
					$bdd = $GLOBALS['bdd'];
					$i=0;
					$eff=false;
					$lnv=1;
					$nnv=2;
					$TFlnv=0;
					$TGlnv=0;
					$TFnnv=0;
					$TGnnv=0;
					$Tlnv=0;
					$Tnnv=0;
					$Tnv=0;
					$nbstd=0;
					$nbM=0;
					$nbF=0;
					$endnv=0;

					for ($a=1; $a <7 ; $a++) 
					{ 
						$TFlnv=0;
						$TGlnv=0;
						$Tlnv=0;

						$reponse = $bdd->query('SELECT * FROM classes where (class_session="SFG" and ref_class_niveau='.$a.') order by nom_class asc');
						while($row = $reponse->fetch(PDO::FETCH_ASSOC)) 
						{
						
							$i++;
							$eff=true;
							$lnv=(int)$row['ref_class_niveau'];
							$nbstd=$class->NbrStudentByClass($row['code_class']);
							$nbM=$class->NbrBySexeByClass($row['code_class'],'M');
							$nbF=$class->NbrBySexeByClass($row['code_class'],'F');
							$nomcls=$row['nom_class'];
							$TFlnv+=(int)$nbF;
							$TGlnv+=(int)$nbM;
							$Tlnv+=(int)$nbstd;
							$TFnnv+=(int)$nbF;
							$TGnnv+=(int)$nbM;
							$Tnnv+=(int)$nbstd;
							$pdf->Ln();
							$pdf->Cell(20,7,'',0,0,'C',0);
							$pdf->Cell(10,6,$i,1,0,'C');
							$pdf->Cell(22,6,$row['code_class'],1,0,'C');
							$pdf->Cell(15,6,$row['ref_class_niveau'] ,1,0,'C');
							$pdf->Cell(50,6,utf8_to_cp1252($nomcls),1,0,'L');
							$pdf->Cell(15,6,$nbF,1,0,'C');
							$pdf->Cell(15,6,$nbM,1,0,'C');
							$pdf->Cell(22,6,$nbstd,1,0,'C');
							
						}


						if ($eff){
							$pdf->SetFillColor(203,220,247);
						$pdf->Ln();
						$pdf->Cell(20,7,'',0,0,'C',0);
						$pdf->Cell(97,7,'Total Niveau '.$lnv,1,0,'C',1);
						$pdf->Cell(15,7,$TFlnv,1,0,'C',1);
						$pdf->Cell(15,7,$TGlnv,1,0,'C',1);
						$pdf->Cell(22,7,$Tlnv,1,0,'C',1);
						$eff=false;
						}
						
					}
		
					$pdf->SetFillColor(213,210,1);
					$pdf->Ln();
					$pdf->Cell(20,7,'',0,0,'C',0);
					$pdf->Cell(97,7,utf8_to_cp1252('Total '.$nomSFG),1,0,'C',1);
					$pdf->Cell(15,7,$TFnnv,1,0,'C',1);
					$pdf->Cell(15,7,$TGnnv,1,0,'C',1);
					$pdf->Cell(22,7,$Tnnv,1,0,'C',1);

					$pdf->Ln();
					$pdf->Ln();
				}

				if ($clsSAG>0) 
				{
					
					$pdf->SetFont('Times','B',12);
					$pdf->SetFillColor(213,210,1);
					$pdf->Ln();
					$pdf->Cell(20,7,'',0,0,'C',0);
					$pdf->Cell(10,7,utf8_to_cp1252('N°'),1,0,'C',1);
					$pdf->Cell(22,7,'Code',1,0,'C',1);
					$pdf->Cell(15,7,'Niveau',1,0,'C',1);
					$pdf->Cell(50,7,'Nom de la Classe',1,0,'C',1);
					$pdf->Cell(15,7,'F',1,0,'C',1);
					$pdf->Cell(15,7,'G',1,0,'C',1);
					$pdf->Cell(22,7,'Total',1,0,'C',1);
					$pdf->SetFont('Times','B',10);
					$bdd = $GLOBALS['bdd'];
					$i=0;
					$eff=false;
					$lnv=1;
					$nnv=2;
					$TFlnv=0;
					$TGlnv=0;
					$TFnnv=0;
					$TGnnv=0;
					$Tlnv=0;
					$Tnnv=0;
					$Tnv=0;
					$nbstd=0;
					$nbM=0;
					$nbF=0;
					$endnv=0;

					for ($a=1; $a <7 ; $a++) 
					{ 
						$TFlnv=0;
						$TGlnv=0;
						$Tlnv=0;

						$reponse = $bdd->query('SELECT * FROM classes where (class_session="SAG" and ref_class_niveau='.$a.') order by nom_class asc');
						while($row = $reponse->fetch(PDO::FETCH_ASSOC)) 
						{
						
							$i++;
							$eff=true;
							$lnv=(int)$row['ref_class_niveau'];
							$nbstd=$class->NbrStudentByClass($row['code_class']);
							$nbM=$class->NbrBySexeByClass($row['code_class'],'M');
							$nbF=$class->NbrBySexeByClass($row['code_class'],'F');
							$nomcls=$row['nom_class'];
							$TFlnv+=(int)$nbF;
							$TGlnv+=(int)$nbM;
							$Tlnv+=(int)$nbstd;
							$TFnnv+=(int)$nbF;
							$TGnnv+=(int)$nbM;
							$Tnnv+=(int)$nbstd;
							$pdf->Ln();
							$pdf->Cell(20,7,'',0,0,'C',0);
							$pdf->Cell(10,6,$i,1,0,'C');
							$pdf->Cell(22,6,$row['code_class'],1,0,'C');
							$pdf->Cell(15,6,$row['ref_class_niveau'] ,1,0,'C');
							$pdf->Cell(50,6,utf8_to_cp1252($nomcls),1,0,'L');
							$pdf->Cell(15,6,$nbF,1,0,'C');
							$pdf->Cell(15,6,$nbM,1,0,'C');
							$pdf->Cell(22,6,$nbstd,1,0,'C');
							
						}


						if ($eff){
							$pdf->SetFillColor(203,220,247);
						$pdf->Ln();
						$pdf->Cell(20,7,'',0,0,'C',0);
						$pdf->Cell(97,7,'Total Niveau '.$lnv,1,0,'C',1);
						$pdf->Cell(15,7,$TFlnv,1,0,'C',1);
						$pdf->Cell(15,7,$TGlnv,1,0,'C',1);
						$pdf->Cell(22,7,$Tlnv,1,0,'C',1);
						$eff=false;
						}
						
					}
		
					$pdf->SetFillColor(213,210,1);
					$pdf->Ln();
					$pdf->Cell(20,7,'',0,0,'C',0);
					$pdf->Cell(97,7,utf8_to_cp1252('Total '.$nomSAG),1,0,'C',1);
					$pdf->Cell(15,7,$TFnnv,1,0,'C',1);
					$pdf->Cell(15,7,$TGnnv,1,0,'C',1);
					$pdf->Cell(22,7,$Tnnv,1,0,'C',1);

					$pdf->Ln();
					$pdf->Ln();
				}

				if ($clsSFT>0) 
				{
					
					$pdf->SetFont('Times','B',12);
					$pdf->SetFillColor(213,210,1);
					$pdf->Ln();
					$pdf->Cell(20,7,'',0,0,'C',0);
					$pdf->Cell(10,7,utf8_to_cp1252('N°'),1,0,'C',1);
					$pdf->Cell(22,7,'Code',1,0,'C',1);
					$pdf->Cell(15,7,'Niveau',1,0,'C',1);
					$pdf->Cell(50,7,'Nom de la Classe',1,0,'C',1);
					$pdf->Cell(15,7,'F',1,0,'C',1);
					$pdf->Cell(15,7,'G',1,0,'C',1);
					$pdf->Cell(22,7,'Total',1,0,'C',1);
					$pdf->SetFont('Times','B',10);
					$bdd = $GLOBALS['bdd'];
					$i=0;
					$eff=false;
					$lnv=1;
					$nnv=2;
					$TFlnv=0;
					$TGlnv=0;
					$TFnnv=0;
					$TGnnv=0;
					$Tlnv=0;
					$Tnnv=0;
					$Tnv=0;
					$nbstd=0;
					$nbM=0;
					$nbF=0;
					$endnv=0;

					for ($a=1; $a <7 ; $a++) 
					{ 
						$TFlnv=0;
						$TGlnv=0;
						$Tlnv=0;

						$reponse = $bdd->query('SELECT * FROM classes where (class_session="SFT" and ref_class_niveau='.$a.') order by nom_class asc');
						while($row = $reponse->fetch(PDO::FETCH_ASSOC)) 
						{
						
							$i++;
							$eff=true;
							$lnv=(int)$row['ref_class_niveau'];
							$nbstd=$class->NbrStudentByClass($row['code_class']);
							$nbM=$class->NbrBySexeByClass($row['code_class'],'M');
							$nbF=$class->NbrBySexeByClass($row['code_class'],'F');
							$nomcls=$row['nom_class'];
							$TFlnv+=(int)$nbF;
							$TGlnv+=(int)$nbM;
							$Tlnv+=(int)$nbstd;
							$TFnnv+=(int)$nbF;
							$TGnnv+=(int)$nbM;
							$Tnnv+=(int)$nbstd;
							$pdf->Ln();
							$pdf->Cell(20,7,'',0,0,'C',0);
							$pdf->Cell(10,6,$i,1,0,'C');
							$pdf->Cell(22,6,$row['code_class'],1,0,'C');
							$pdf->Cell(15,6,$row['ref_class_niveau'] ,1,0,'C');
							$pdf->Cell(50,6,utf8_to_cp1252($nomcls),1,0,'L');
							$pdf->Cell(15,6,$nbF,1,0,'C');
							$pdf->Cell(15,6,$nbM,1,0,'C');
							$pdf->Cell(22,6,$nbstd,1,0,'C');
							
						}


						if ($eff){
							$pdf->SetFillColor(203,220,247);
						$pdf->Ln();
						$pdf->Cell(20,7,'',0,0,'C',0);
						$pdf->Cell(97,7,'Total Niveau '.$lnv,1,0,'C',1);
						$pdf->Cell(15,7,$TFlnv,1,0,'C',1);
						$pdf->Cell(15,7,$TGlnv,1,0,'C',1);
						$pdf->Cell(22,7,$Tlnv,1,0,'C',1);
						$eff=false;
						}
						
					}
		
					$pdf->SetFillColor(213,210,1);
					$pdf->Ln();
					$pdf->Cell(20,7,'',0,0,'C',0);
					$pdf->Cell(97,7, utf8_to_cp1252('Total '.$nomSFT),1,0,'C',1);
					$pdf->Cell(15,7,$TFnnv,1,0,'C',1);
					$pdf->Cell(15,7,$TGnnv,1,0,'C',1);
					$pdf->Cell(22,7,$Tnnv,1,0,'C',1);

					$pdf->Ln();
					$pdf->Ln();
				}

				if ($clsSAT>0) 
				{
					
					$pdf->SetFont('Times','B',12);
					$pdf->SetFillColor(213,210,1);
					$pdf->Ln();
					$pdf->Cell(20,7,'',0,0,'C',0);
					$pdf->Cell(10,7,utf8_to_cp1252('N°'),1,0,'C',1);
					$pdf->Cell(22,7,'Code',1,0,'C',1);
					$pdf->Cell(15,7,'Niveau',1,0,'C',1);
					$pdf->Cell(50,7,'Nom de la Classe',1,0,'C',1);
					$pdf->Cell(15,7,'F',1,0,'C',1);
					$pdf->Cell(15,7,'G',1,0,'C',1);
					$pdf->Cell(22,7,'Total',1,0,'C',1);
					$pdf->SetFont('Times','B',10);
					$bdd = $GLOBALS['bdd'];
					$i=0;
					$eff=false;
					$lnv=1;
					$nnv=2;
					$TFlnv=0;
					$TGlnv=0;
					$TFnnv=0;
					$TGnnv=0;
					$Tlnv=0;
					$Tnnv=0;
					$Tnv=0;
					$nbstd=0;
					$nbM=0;
					$nbF=0;
					$endnv=0;

					for ($a=1; $a <7 ; $a++) 
					{ 
						$TFlnv=0;
						$TGlnv=0;
						$Tlnv=0;

						$reponse = $bdd->query('SELECT * FROM classes where (class_session="SAT" and ref_class_niveau='.$a.') order by nom_class asc');
						while($row = $reponse->fetch(PDO::FETCH_ASSOC)) 
						{
						
							$i++;
							$eff=true;
							$lnv=(int)$row['ref_class_niveau'];
							$nbstd=$class->NbrStudentByClass($row['code_class']);
							$nbM=$class->NbrBySexeByClass($row['code_class'],'M');
							$nbF=$class->NbrBySexeByClass($row['code_class'],'F');
							$nomcls=$row['nom_class'];
							$TFlnv+=(int)$nbF;
							$TGlnv+=(int)$nbM;
							$Tlnv+=(int)$nbstd;
							$TFnnv+=(int)$nbF;
							$TGnnv+=(int)$nbM;
							$Tnnv+=(int)$nbstd;
							$pdf->Ln();
							$pdf->Cell(20,7,'',0,0,'C',0);
							$pdf->Cell(10,6,$i,1,0,'C');
							$pdf->Cell(22,6,$row['code_class'],1,0,'C');
							$pdf->Cell(15,6,$row['ref_class_niveau'] ,1,0,'C');
							$pdf->Cell(50,6,utf8_to_cp1252($nomcls),1,0,'L');
							$pdf->Cell(15,6,$nbF,1,0,'C');
							$pdf->Cell(15,6,$nbM,1,0,'C');
							$pdf->Cell(22,6,$nbstd,1,0,'C');
							
						}


						if ($eff){
							$pdf->SetFillColor(203,220,247);
						$pdf->Ln();
						$pdf->Cell(20,7,'',0,0,'C',0);
						$pdf->Cell(97,7,'Total Niveau '.$lnv,1,0,'C',1);
						$pdf->Cell(15,7,$TFlnv,1,0,'C',1);
						$pdf->Cell(15,7,$TGlnv,1,0,'C',1);
						$pdf->Cell(22,7,$Tlnv,1,0,'C',1);
						$eff=false;
						}
						
					}
		
					$pdf->SetFillColor(213,210,1);
					$pdf->Ln();
					$pdf->Cell(20,7,'',0,0,'C',0);
					$pdf->Cell(97,7,utf8_to_cp1252('Total '.$nomSAT),1,0,'C',1);
					$pdf->Cell(15,7,$TFnnv,1,0,'C',1);
					$pdf->Cell(15,7,$TGnnv,1,0,'C',1);
					$pdf->Cell(22,7,$Tnnv,1,0,'C',1);

					$pdf->Ln();
					$pdf->Ln();
				}


				
				

				$pdf->SetXY(123,271);
$pdf->Cell(0,3,'Page '.$pdf->PageNo().'/{nb}',0,1,'C');
$pdf->Output('CLASS_LIST_.pdf','I');
$pdf->Close();
?>
