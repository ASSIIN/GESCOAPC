<?php
    session_start();   
	require_once 'core/require.php'; 
	require_once 'Model/connexion.php';
     if (!isset($_SESSION['user'])) {
    session_unset();
    session_destroy();
    header('location: index.php');    
    }
    //Virifions si la classes Existe
       $ckcls=$class->CkExistingCode($_GET['id']);
        if (($_GET['id']=="") or ($ckcls==false)) {
        header('location: menu_classes.php');    
      }
    $etb->ShowEtb();
    $etb->CkLE();
    $etb->ckexneE();
    $ref_classe=htmlspecialchars($_GET['id']);
    $class->ShowClassInfos($ref_classe);
    $nbmat=$class->NombreMatbyCls($ref_classe);
    $nnPP=$class->ShowNom_Cls_Master($ref_classe);
    $nbcoeff=$class->NombreCoeffbyCls($ref_classe);
    $nbclasses=$class->NombreClasses();
?>


<!DOCTYPE html>
<html>
  <head>
   <?php Config::head(); ?>
    <title>GESCOAPC| DEPARTEMENTS</title>
  </head>

<body>
    <div class="wrapper">
      <!-- Sidebar -->

      <!-- Inclusion du menu de navigation externe réutilisable -->
      <?php include 'core/sidebar.php'; ?>  
       
<div class="main-content-wrapper">
        <!-- Barre supérieure de navigation adaptative -->
        <div class="mobile-navbar-fixed p-3 mb-4 rounded shadow-sm border">
            <div class="row align-items-center g-2">
                <div class="col-auto d-md-none">
                    <button class="btn btn-outline-dark btn-sm" id="toggleMobileMenu"><i class="fa fa-bars fa-lg"></i></button>
                </div>
                <div class="col-12 col-md">
                    <h4 class="m-0 fw-bold text-primary text-uppercase">Tous les départements</h4>
                </div>
                <div class="col-12 col-md-auto d-flex justify-content-md-end">
                    <button type="button" class="btn btn-outline-primary btn-sm me-2" data-bs-toggle="modal" data-bs-target="#addclasse" data-whatever="@mdo">Ajouter</button>
                    <input class="form-control form-control-sm" id="search" type="text" placeholder="&#xF002; Recherche ou Tri" style="font-family: Arial, FontAwesome">
                </div>
            </div>
        </div>
                <div class="row">
                    <div class="accordion" id="accordionExample">
                      <div class="accordion-item">
                        <h2 class="accordion-header">
                          <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                            <h2 class="fw-bolder" >1 - Liste des Matières de: <i style="color:#d9d602 "> <?php echo $_SESSION['nom_class']; ?> </i></h2>
                          </button>
                        </h2>
                        <div id="collapseOne" class="accordion-collapse collapse" data-bs-parent="#accordionExample">
                          <div class="accordion-body">
                              <div class="table-responsive table-sm">
                                <table class="table">
                                    <thead>
                                        <tr>
                                            <th>#</th>
                                            <th>Matières</th>
                                            <th>Coeff</th>
                                            <th>Groupe</th>
                                             <th>Enseignant</th>
                                             <th>Modifier</th>
                                            <th>Supprimer</th>
                                        </tr>
                                    </thead>
                                    <tbody class="table-hover">
                                      <tr style="background-color: #47d6a5; font-size: 1.2em; color: white" class="text-bold">
                                            <th>Config</th>
                                            <td colspan="3"> -- Session :  <?php echo $_SESSION['class_session']; ?>  / Niveau :  <?php echo $_SESSION['ref_class_niveau']; ?>/ Classe:  <?php echo $_SESSION['nom_class']; ?> </td>
                                            <td colspan="3" class="txt-oflo">Matieres(<?php echo $nbmat; ?>) / Total Coeff(<?php echo $nbcoeff; ?>)  </td>
                                            
                                        </tr>
                                        <?php  $class->ShowEdit_Bul($_SESSION['code_class']); 
                                          
                                        ?>
                                    </tbody>
                                </table>
                              </div>
                          </div>
                        </div>
                      </div>
                      <div class="accordion-item">
                        <h2 class="accordion-header">
                          <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
                           <h2 class="fw-bolder" >2- Ajouter des Matières: <i style="color:#d9d602 "> (<?php echo $nbmat; ?>) -- Total Coeff(<?php echo $nbcoeff; ?>)</i></h2> 
                          </button>
                        </h2>
                        <div id="collapseTwo" class="accordion-collapse collapse" data-bs-parent="#accordionExample">
                          <div class="accordion-body">
                            <strong>Choisir une matière</strong>
                            <form action="Controler/classes/add_mat_classe.php" method="post" >
                                  <div class="row">
                                      <div class=" col-6 col-sm-4">
                                        <input type="text" class="form-control" id="ref_class" name="ref_class"  hidden="true" value="<?php echo $ref_classe; ?>">
                                          <label for="exampleInputEmail1" class="form-label">Matiere:</label>
                                          <select class="form-select form-select-lg mb-2" aria-label=".form-select-lg example" name="mat" id="mat">
                                            <option value=""> Choisir...</option>
                                                  <?php $mat->SelectMatieres(); ?> 
                                          </select>
                                      </div>

                                      <div class="col-2 col-sm-4">
                                        <label for="exampleInputEmail1" class="form-label">Enseignant:</label>
                                        <select class="form-select form-select-lg mb-2" aria-label=".form-select-lg example" name="ens" id="ens">
                                          <option value=""> Choisir...</option>
                                        <?php $user->SelectTeacher(); ?> 
                                        </select>
                                      </div>
                                      <div class="col-2 col-sm-2">
                                          <label for="exampleInputEmail1" class="form-label">Coeff:</label>
                                          <input type="number" class="form-control" id="coeff" name="coeff"  min="1" max="20"   required>
                                      </div>
                                      <div class="col-2 col-sm-2">
                                          <label for="exampleInputEmail1" class="form-label">Groupe:</label>
                                          <input type="number" class="form-control" id="groupe" name="groupe"  min="1" max="3"   required>
                                      </div>
                                      <div class="col-10 col-sm-2">
                                          <label for="exampleInputEmail1" class="form-label">Opération</label>
                                          <button class="btn btn-primary" type="submit">Enregistrer</button>
                                      </div>
                                  </div>
                            </form>
                          </div>
                      
                        </div>
                      </div>
                      <div class="accordion-item">
                        <h2 class="accordion-header">
                          <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseTree" aria-expanded="false" aria-controls="collapseTree">
                           <h2 class="fw-bolder" >3 - Modifier Le Professeur principal: <i style="color:#d9d602 "> (<?php echo $nnPP; ?>) </i></h2>
                          </button>
                        </h2>
                        <div id="collapseTree" class="accordion-collapse collapse" data-bs-parent="#accordionExample">
                          <div class="accordion-body">
                            <strong> </strong>
                            <form action="Controler/classes/add_pp_classe.php" method="post" >
                                  <div class="row">
                                      <div class="col-6 col-sm-6">
                                        <input type="text" class="form-control" id="refcls" name="refcls"  maxlength="10"  hidden="true" value="<?php echo $ref_classe; ?>">
                                        <label for="exampleInputEmail1" class="form-label">Enseignant</label>
                                        <select class="form-select form-select-lg mb-2" aria-label=".form-select-lg example" name="pp" id="pp">
                                          <option value=""> Choisir...</option>
                                        <?php $user->SelectTeacher(); ?> 
                                        </select>
                                      </div>
                              
                                      <div class="col-6 col-sm-6">
                                          <label for="exampleInputEmail1" class="form-label">Opération</label><br>
                                          <button class="btn btn-primary" type="submit">Enregistrer</button>
                                      </div>
                                  </div>
                            </form>
                          </div>
                      
                        </div>
                      </div>

                      <div class="accordion-item">
                        <h2 class="accordion-header">
                          <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseFoor" aria-expanded="false" aria-controls="collapseFoor">
                           <h2 class="fw-bolder" >4 - Modifier le nom de la classe </i></h2>
                          </button>
                        </h2>
                        <div id="collapseFoor" class="accordion-collapse collapse" data-bs-parent="#accordionExample">
                          <div class="accordion-body">
                            <strong> </strong>
                            <form action="Controler/classes/upd_ncls.php" method="post" >
                                  <div class="row">
                                      <div class="col-6 col-sm-6">
                                        <input type="text" class="form-control" id="refcls" name="ref_cls"  maxlength="10"  hidden="true" value="<?php echo $ref_classe; ?>">
                                        <label for="exampleInputEmail1" class="form-label">Nouvelle Nom:</label>
                                       <input type="text" class="form-control" id="new_ncls" name="new_ncls"  maxlength="25">
                                      </div>
                              
                                      <div class="col-6 col-sm-6">
                                          <label for="exampleInputEmail1" class="form-label">Opération</label><br>
                                          <button class="btn btn-primary" type="submit">Enregistrer</button>
                                      </div>
                                  </div>
                            </form>
                          </div>
                      
                        </div>
                      </div>
                <!-- ============================================================== -->
              
                    </div>
                </div>
                
            </div>
           
        <?php 
            Footers::TDfoot();
        ?>
      </div>
        <!-- ============================================================== -->
        <!-- End Page Content -->
        <!-- ============================================================== -->


		<?php 
		 	Config::scriptJs();
		?>

     <script type="text/javascript">
        
        </script>
        <script type="text/javascript">
            $('#exampleModal').on('show.bs.modal', function (event) {
  var button = $(event.relatedTarget) // Button that triggered the modal
  var recipient = button.data('whatever') // Extract info from data-* attributes
  // If necessary, you could initiate an AJAX request here (and then do the updating in a callback).
  // Update the modal's content. We'll use jQuery here, but you could use a data binding library or other methods instead.
  var modal = $(this)
  modal.find('.modal-title').text('New message to ' + recipient)
  modal.find('.modal-body input').val(recipient)
})
        </script>
	</body>
</html>
