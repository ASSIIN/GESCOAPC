<?php
	session_start();
	require_once '../../../Model/connexion.php';
	require_once '../../../core/require.php'; 
	$prix= htmlspecialchars($_POST['prix']);
	$ps_bull= htmlspecialchars($_POST['ps_bull']);
	$id= htmlspecialchars($_POST['id']);
	if (isset($id)) 
	{
		if (!isset($prix)) {
			$prix=NULL;
		}
		if (!isset($ps_bull)) {
			$ps_bull=NULL;
		}

		$elt= array('prix' =>$prix, 'ps_bull' =>$ps_bull);
		
		foreach ($elt as $key => $value) 
		{
			if ($value!=NULL)
			{
		

			$bdd = $GLOBALS['bdd'];	
			$req ='UPDATE pensions SET '.$key.'= ? where id='.$id.'';
			$rep = $bdd->prepare($req);
			$rep->execute(array($value));
			}		
		
			
		}
		header('location: ../../../gestion_fin.php');
	}
	else
	{
		header('location: ../../../gestion_fin.php?e=1');
	
	}
 	
		
?>