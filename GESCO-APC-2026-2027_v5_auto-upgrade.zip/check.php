<?php
session_start();    
    require_once 'core/require.php';

    $_SESSION['opt']="Connexion";
  $mailA= htmlspecialchars($_POST['login']);
  $passA= htmlspecialchars($_POST['password']);
  $_SESSION['con_year']= htmlspecialchars($_POST['an']);
   $postan="";
  if (isset($_SESSION['con_year'])) 
  {
   $_SESSION['postan']=$etb->CkPost_an($_SESSION['con_year']);
    $postan=$_SESSION['postan'];
      require_once 'Model/connexion.php'; 
      require_once 'less/patch.php';
      
  }
    
    else{
       header('location: index.php?ey');
    }  
 
 //echo $_SESSION['con_year'].'<br>';
//echo $_SESSION['postan'];

   if (($user->ckconM($mailA)) and ($user->ckconP($passA))) 
   {
      $etb->Updl();  
      if ($etb->ckexneE() and ($etb->CkLE_An($postan)) and $user->UpdConUser($_SESSION['user']))
      {
        if ($_SESSION['user_role']=="esn")
        {
           header('location: poste_ens.php');
        }
        else{
           header('location: home.php');
        }
      }
      else{

      header('location: index.php?el');
      }
              
      }

   else{

    header('location: index.php?e');
   }
        
?>