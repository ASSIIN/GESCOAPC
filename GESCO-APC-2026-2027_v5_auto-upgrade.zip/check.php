<?php
ob_start();
session_start(); 

// Affichage des erreurs lors du développement (à masquer lors de la livraison finale)
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

require_once 'core/require.php';
$_SESSION['opt'] = "Connexion";

$mailA = trim(htmlspecialchars($_POST['login']));
$passA = trim(htmlspecialchars($_POST['password']));
$_SESSION['con_year'] = htmlspecialchars($_POST['an']);
$postan = "";

if (isset($_SESSION['con_year']) && !empty($_SESSION['con_year'])) {
    $_SESSION['postan'] = $etb->CkPost_an($_SESSION['con_year']);
    $postan = $_SESSION['postan'];
    require_once 'Model/connexion.php'; 
    require_once 'less/patch.php'; // Le contrôle d'activation INOFIB s'exécute d'abord ici
} else {
    header('location: index.php?ey');
    exit();
}  

// Utilisation de la validation unifiée de la classe MyAdmins
if ($admin->authentifier($mailA, $passA)) {
    $etb->Updl();  
    
    if ($etb->ckexneE() && $etb->CkLE_An($postan) && $user->UpdConUser($_SESSION['user'])) {
        if ($_SESSION['user_role'] == 'ens') {
            header('location: poste_de_saisie.php?trim=t1');
            exit();
        } else {
            header('location: home.php');
            exit();
        }
    } else {
        header('location: index.php?el');
        exit();
    }
} else {
    header('location: index.php?e');
    exit();
}

ob_end_flush();
?>
