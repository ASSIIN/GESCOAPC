<?php
// core/modal_auto_config.php : modal « Configuration automatique » (inclus dans menu_classes.php)
if (!isset($_SESSION['user_role']) || !in_array($_SESSION['user_role'], array('admin', 'pcpl', 'cs'), true)) { return; }
?>
<!-- ============================================================== -->
<!-- MODAL : CONFIGURATION AUTOMATIQUE (classes, séries, matières, enseignants, compétences) -->
<!-- ============================================================== -->
<div class="modal fade" id="autoConfigModal" tabindex="-1" aria-labelledby="autoConfigLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered modal-xl modal-dialog-scrollable">
    <div class="modal-content border-0">

      <div class="modal-header text-white border-0 py-2" style="background-color:#b45f06;">
        <h5 class="modal-title fw-bold" id="autoConfigLabel"><i class="fa fa-magic me-2"></i>Configuration automatique</h5>
        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>

      <div class="modal-body p-3" style="background-color: var(--bg-main);">
        <div class="alert alert-info py-2 small mb-3">
          <i class="fa fa-shield-halved me-1"></i>
          Ce module <b>complète seulement</b> : aucune classe, matière, coefficient ou compétence existants n'est supprimé ou modifié.
          Les doublons de noms (6e = 6EME, 2ndeC = 2nde C) sont détectés. Il peut être relancé sans créer de doublons.
        </div>

        <ul class="nav nav-tabs mb-3" role="tablist">
          <li class="nav-item"><button class="nav-link active fw-bold" id="ac-tab-std" data-bs-toggle="tab" data-bs-target="#ac-pane-std" type="button" role="tab"><i class="fa fa-list-check me-1"></i>Modèle standard (APC Minesec)</button></li>
          <li class="nav-item"><button class="nav-link fw-bold" id="ac-tab-src" data-bs-toggle="tab" data-bs-target="#ac-pane-src" type="button" role="tab"><i class="fa fa-clock-rotate-left me-1"></i>Reprise de l'année dernière</button></li>
        </ul>

        <div class="tab-content">

          <!-- ===== MODÈLE STANDARD ===== -->
          <div class="tab-pane fade show active" id="ac-pane-std" role="tabpanel">
            <div id="ac-std-loading" class="text-center text-secondary py-4"><span class="spinner-border spinner-border-sm me-2"></span>Chargement…</div>
            <div id="ac-std-body" class="d-none">
              <div class="d-flex flex-wrap gap-3 mb-2 align-items-center">
                <span class="fw-bold small text-secondary">Cycles :</span>
                <div class="form-check form-check-inline m-0"><input class="form-check-input ac-cycle" type="checkbox" id="ac-cy1" value="1" checked><label class="form-check-label small fw-bold" for="ac-cy1">1<sup>er</sup> cycle (niveaux 1 à 4)</label></div>
                <div class="form-check form-check-inline m-0"><input class="form-check-input ac-cycle" type="checkbox" id="ac-cy2" value="2" checked><label class="form-check-label small fw-bold" for="ac-cy2">2<sup>nd</sup> cycle (niveaux 5, 6, 7 : séries C, D, A4…)</label></div>
              </div>
              <div class="small text-secondary mb-2">Cochez les sections de votre établissement :</div>
              <div id="ac-std-sections" class="row g-3"></div>
              <div class="form-text mt-2">« Souhaitées » = <b>nombre total</b> de classes voulu pour le niveau/série : seules les classes manquantes sont créées.
                Niveaux 1 à 4 : coefficients et compétences des bulletins APC Minesec. Niveau 4 : structure de la 4<sup>e</sup> (série PEBS à part).
                Niveaux 5 à 7, SFT et SAT : valeurs <b>indicatives</b> à vérifier dans « Config bulletin ».</div>
            </div>
          </div>

          <!-- ===== REPRISE ANNÉE DERNIÈRE ===== -->
          <div class="tab-pane fade" id="ac-pane-src" role="tabpanel">
            <div class="row g-2 align-items-end mb-3">
              <div class="col-12 col-md-8">
                <label class="form-label small fw-bold text-secondary" for="ac-src">Source de l'année précédente</label>
                <select id="ac-src" class="form-select form-select-sm"></select>
              </div>
              <div class="col-12 col-md-4"><button type="button" class="btn btn-sm btn-outline-primary w-100 fw-bold" id="ac-src-analyse"><i class="fa fa-search me-1"></i>Analyser</button></div>
            </div>
            <div id="ac-src-tree"></div>
            <div id="ac-src-opts" class="border rounded p-2 mt-3 small d-none">
              <div class="form-check"><input class="form-check-input" type="checkbox" id="ac-s-comp" checked><label class="form-check-label" for="ac-s-comp">Reprendre les compétences</label></div>
              <div class="form-check"><input class="form-check-input" type="checkbox" id="ac-s-ens" checked><label class="form-check-label" for="ac-s-ens">Reprendre les enseignants (comptes existants réutilisés ; comptes « enseignant » absents créés ; comptes administratifs jamais recréés)</label></div>
              <div class="form-check"><input class="form-check-input" type="checkbox" id="ac-s-next"><label class="form-check-label" for="ac-s-next">Ajouter aussi, depuis le <b>modèle standard</b>, les <b>niveaux absents</b> de l'année dernière (ex. second cycle) — utilise les sections, cycles, séries et nombres choisis dans l'onglet « Modèle standard »</label></div>
            </div>
          </div>

        </div>

        <!-- ===== OPTIONS COMMUNES : ENSEIGNANTS ===== -->
        <div class="border rounded p-2 mt-3 small">
          <div class="fw-bold mb-1"><i class="fa fa-chalkboard-user me-1"></i>Enseignants et options communes</div>
          <div class="row g-2 align-items-center">
            <div class="col-12 col-md-6">
              <label class="form-label small mb-0" for="ac-mode-ens">Affectation des enseignants (modèle standard)</label>
              <select id="ac-mode-ens" class="form-select form-select-sm">
                <option value="auto" selected>Enseignant déjà affecté à la matière, sinon « PROF ANGLAIS 1 / 2 »</option>
                <option value="generic">Toujours « PROF &lt;MATIÈRE&gt; » (comptes génériques)</option>
                <option value="none">Ne pas affecter d'enseignant</option>
              </select>
            </div>
            <div class="col-12 col-md-6">
              <div class="form-check"><input class="form-check-input" type="checkbox" id="ac-par-cycle" checked><label class="form-check-label" for="ac-par-cycle">Un enseignant par cycle : <b>PROF ANGLAIS 1</b> (1<sup>er</sup> cycle) et <b>PROF ANGLAIS 2</b> (2<sup>nd</sup> cycle)</label></div>
              <div class="form-check"><input class="form-check-input" type="checkbox" id="ac-completer" checked><label class="form-check-label" for="ac-completer">Compléter aussi les classes déjà existantes (matières, enseignants, compétences manquants)</label></div>
              <div class="form-check"><input class="form-check-input" type="checkbox" id="ac-comp" checked><label class="form-check-label" for="ac-comp">Pré-remplir les compétences par matière</label></div>
              <div class="form-check"><input class="form-check-input" type="checkbox" id="ac-remplacer"><label class="form-check-label text-danger" for="ac-remplacer"><b>Remplacer</b> les enseignants déjà affectés par ceux du modèle / de l'année dernière</label></div>
            </div>
          </div>
        </div>

        <div id="ac-result" class="mt-3"></div>
      </div>

      <div class="modal-footer border-top-0 pt-0">
        <button type="button" class="btn btn-secondary px-4 fw-bold" data-bs-dismiss="modal">Fermer</button>
        <button type="button" class="btn btn-success px-4 fw-bold" id="ac-run"><i class="fa fa-play me-2"></i>Lancer la configuration</button>
      </div>

    </div>
  </div>
</div>

<script>
(function () {
  'use strict';
  var URL_API = 'Controler/classes/auto_config.php';
  var modal = document.getElementById('autoConfigModal');
  if (!modal) { return; }
  var INIT = null, SRC = null;

  function $(id) { return document.getElementById(id); }
  function esc(s) { return String(s).replace(/[&<>"']/g, function (c) { return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[c]; }); }

  function api(action, payload) {
    var fd = new FormData();
    fd.append('action', action);
    fd.append('payload', JSON.stringify(payload || {}));
    return fetch(URL_API, { method: 'POST', body: fd, credentials: 'same-origin' })
      .then(function (r) { return r.json().catch(function () { throw new Error('Réponse invalide du serveur.'); }); })
      .then(function (j) { if (!j.ok) { throw new Error(j.message || 'Erreur.'); } return j; });
  }
  function activePane() { return $('ac-tab-src').classList.contains('active') ? 'src' : 'std'; }

  function showReport(rep) {
    var s = rep.stats, t = $('ac-result');
    var h = '<div class="alert alert-success mb-2"><b><i class="fa fa-circle-check me-1"></i>Configuration terminée.</b><ul class="mb-0 mt-1 small">';
    h += '<li>Classes créées : <b>' + s.classes_creees + '</b> (existantes conservées : ' + s.classes_existantes + ')</li>';
    h += '<li>Matières ajoutées : <b>' + s.matieres_ajoutees + '</b> · déjà configurées (non modifiées) : ' + s.matieres_deja + ' · équivalentes déjà présentes (ex. FR / C. ORTH) : ' + s.matieres_equivalentes + '</li>';
    h += '<li>Enseignants affectés : <b>' + s.enseignants_affectes + '</b> · remplacés : <b>' + s.enseignants_remplaces + '</b> · comptes créés : <b>' + s.enseignants_crees + '</b></li>';
    h += '<li>Compétences ajoutées : <b>' + s.competences_ajoutees + '</b> · départements/matières créés : <b>' + s.referentiel_crees + '</b></li></ul></div>';
    if (rep.notes && rep.notes.length) {
      h += '<div class="alert alert-warning small mb-2"><b>À vérifier :</b><ul class="mb-0">' + rep.notes.map(function (n) { return '<li>' + esc(n) + '</li>'; }).join('') + '</ul></div>';
    }
    h += '<button type="button" class="btn btn-sm btn-primary" onclick="location.reload()"><i class="fa fa-rotate me-1"></i>Actualiser la liste des classes</button>';
    t.innerHTML = h;
  }
  function showError(msg) { $('ac-result').innerHTML = '<div class="alert alert-danger small mb-0"><i class="fa fa-circle-exclamation me-1"></i>' + esc(msg) + '</div>'; }

  /* ---------- Modèle standard ---------- */
  function renderStd() {
    var host = $('ac-std-sections'); host.innerHTML = '';
    INIT.sections.forEach(function (sec) {
      var col = document.createElement('div'); col.className = 'col-12 col-xl-6';
      var h = '<div class="card h-100 border-0 shadow-sm"><div class="card-body p-2">';
      h += '<div class="form-check mb-2"><input class="form-check-input ac-sec" type="checkbox" id="ac-sec-' + sec.code + '" data-sec="' + sec.code + '"' + (sec.modele ? (sec.code === 'SFG' ? ' checked' : '') : ' disabled') + '>';
      h += '<label class="form-check-label fw-bold" for="ac-sec-' + sec.code + '">' + esc(sec.label) + '</label></div>';
      if (!sec.modele) {
        h += '<div class="small text-secondary">Aucun script dans <code>datas/' + sec.code + '</code>.</div>';
      } else {
        h += '<table class="table table-sm align-middle mb-0 small"><thead><tr><th>Niveau / série</th><th class="text-center">Existantes</th><th style="width:85px">Souhaitées</th></tr></thead><tbody>';
        sec.niveaux.forEach(function (n) {
          n.series.forEach(function (s, i) {
            var lab = (i === 0 ? '<b>' + esc(n.libelle) + '</b> <span class="badge bg-secondary">C' + n.cycle + '</span>' : '') ;
            var sub = (s.serie !== '' ? (i === 0 ? '<div class="ps-3">↳ ' : '<span class="badge bg-secondary invisible">C' + n.cycle + '</span><div class="ps-3">↳ ') + esc(s.libelle) + '</div>' : '');
            h += '<tr data-cycle="' + n.cycle + '"><td>' + lab + sub + '</td><td class="text-center">' + s.existantes + '</td>';
            h += '<td><input type="number" min="0" max="20" class="form-control form-control-sm ac-nb" data-sec="' + sec.code + '" data-niv="' + n.niveau + '" data-serie="' + esc(s.serie === '' ? '_' : s.serie) + '" value="' + s.defaut + '"></td></tr>';
          });
        });
        h += '</tbody></table>';
      }
      h += '</div></div>';
      col.innerHTML = h; host.appendChild(col);
    });
    applyCycleFilter();
  }
  function applyCycleFilter() {
    var on = {}; document.querySelectorAll('.ac-cycle').forEach(function (c) { on[c.value] = c.checked; });
    document.querySelectorAll('#ac-std-sections tr[data-cycle]').forEach(function (tr) {
      var act = !!on[tr.getAttribute('data-cycle')];
      tr.style.opacity = act ? '1' : '.35';
      tr.querySelectorAll('input').forEach(function (i) { i.disabled = !act; });
    });
  }
  function collectStd() {
    var plan = {}, cycles = [];
    document.querySelectorAll('.ac-cycle').forEach(function (c) { if (c.checked) { cycles.push(parseInt(c.value, 10)); } });
    document.querySelectorAll('.ac-sec').forEach(function (cb) {
      if (!cb.checked || cb.disabled) { return; }
      var sec = cb.getAttribute('data-sec'); plan[sec] = {};
      document.querySelectorAll('.ac-nb[data-sec="' + sec + '"]').forEach(function (i) {
        var n = i.getAttribute('data-niv'), s = i.getAttribute('data-serie');
        (plan[sec][n] = plan[sec][n] || {})[s] = parseInt(i.value, 10) || 0;
      });
    });
    return { plan: plan, cycles: cycles };
  }
  function commonOpts() {
    return { mode_ens: $('ac-mode-ens').value, ens_par_cycle: $('ac-par-cycle').checked, completer_existantes: $('ac-completer').checked,
             competences: $('ac-comp').checked, remplacer_enseignants: $('ac-remplacer').checked };
  }

  /* ---------- Reprise ---------- */
  function renderSrc(list) {
    var groups = {};
    list.forEach(function (c) { var k = c.section + '|' + c.cycle; (groups[k] = groups[k] || []).push(c); });
    var h = '';
    Object.keys(groups).sort().forEach(function (k) {
      var p = k.split('|'), id = 'ac-g-' + k.replace('|', '-');
      h += '<div class="card border-0 shadow-sm mb-2"><div class="card-body p-2">';
      h += '<div class="form-check mb-1"><input class="form-check-input ac-grp" type="checkbox" data-grp="' + k + '" id="' + id + '" checked>';
      h += '<label class="form-check-label fw-bold" for="' + id + '">Section ' + esc(p[0]) + ' — ' + (p[1] === '1' ? '1<sup>er</sup> cycle' : '2<sup>nd</sup> cycle') + '</label></div><div class="row g-1 ps-3">';
      groups[k].forEach(function (c) {
        h += '<div class="col-12 col-md-6 col-xl-4"><div class="form-check small"><input class="form-check-input ac-cls" type="checkbox" data-grp="' + k + '" value="' + esc(c.code) + '" id="ac-c-' + esc(c.code) + '" checked>';
        h += '<label class="form-check-label" for="ac-c-' + esc(c.code) + '">' + esc(c.nom) + ' <span class="text-secondary">(niv. ' + c.niveau + ', ' + c.nb_mat + ' mat.)</span> ' + (c.existe ? '<span class="badge bg-info text-dark">existe → complétée</span>' : '<span class="badge bg-success">nouvelle</span>') + '</label></div></div>';
      });
      h += '</div></div></div>';
    });
    $('ac-src-tree').innerHTML = h;
    $('ac-src-opts').classList.remove('d-none');
    document.querySelectorAll('.ac-grp').forEach(function (g) {
      g.addEventListener('change', function () {
        document.querySelectorAll('.ac-cls[data-grp="' + g.getAttribute('data-grp') + '"]').forEach(function (c) { c.checked = g.checked; });
      });
    });
  }

  /* ---------- Événements ---------- */
  modal.addEventListener('show.bs.modal', function () {
    if (INIT) { return; }
    api('init').then(function (j) {
      INIT = j.data;
      $('ac-std-loading').classList.add('d-none'); $('ac-std-body').classList.remove('d-none');
      renderStd();
      var sel = $('ac-src');
      sel.innerHTML = INIT.sources.length ? INIT.sources.map(function (d) { return '<option value="' + esc(d.id) + '">' + esc(d.nom) + '</option>'; }).join('') : '<option value="">Aucune base ni fichier .sql trouvé</option>';
    }).catch(function (e) { $('ac-std-loading').innerHTML = '<span class="text-danger">' + esc(e.message) + '</span>'; });
  });
  document.addEventListener('change', function (e) { if (e.target.classList && e.target.classList.contains('ac-cycle')) { applyCycleFilter(); } });

  $('ac-src-analyse').addEventListener('click', function () {
    var id = $('ac-src').value; if (!id) { return; }
    var btn = this; btn.disabled = true;
    $('ac-src-tree').innerHTML = '<div class="text-secondary small"><span class="spinner-border spinner-border-sm me-2"></span>Analyse…</div>';
    api('source_preview', { source: id }).then(function (j) { SRC = j.data; renderSrc(j.data.classes); })
      .catch(function (e) { $('ac-src-tree').innerHTML = '<div class="alert alert-danger small">' + esc(e.message) + '</div>'; })
      .then(function () { btn.disabled = false; });
  });

  $('ac-run').addEventListener('click', function () {
    var btn = this, pane = activePane(), req, std = collectStd(), o = commonOpts();
    if (o.remplacer_enseignants && !confirm('ATTENTION : les enseignants déjà affectés aux matières concernées seront REMPLACÉS. Continuer ?')) { return; }
    if (pane === 'std') {
      if (!Object.keys(std.plan).length || !std.cycles.length) { showError('Cochez au moins une section et un cycle.'); return; }
      if (!confirm('Lancer la configuration automatique ? Les éléments existants seront conservés.')) { return; }
      req = api('apply_std', { plan: std.plan, cycles: std.cycles, opts: o });
    } else {
      var codes = []; document.querySelectorAll('.ac-cls:checked').forEach(function (c) { codes.push(c.value); });
      if (!SRC || !codes.length) { showError('Analysez la source puis cochez au moins une classe.'); return; }
      var next = $('ac-s-next').checked;
      if (next && (!Object.keys(std.plan).length || !std.cycles.length)) { showError('Pour ajouter les niveaux absents, cochez une section et un cycle dans l\'onglet « Modèle standard ».'); return; }
      if (!confirm('Reprendre ' + codes.length + ' classe(s) de l\'année dernière ? Les éléments existants seront conservés.')) { return; }
      o.competences = $('ac-s-comp').checked; o.enseignants = $('ac-s-ens').checked;
      req = api('apply_source', { source: $('ac-src').value, classes: codes, opts: o, niveaux_suivants: next, plan: std.plan, cycles: std.cycles });
    }
    btn.disabled = true; $('ac-result').innerHTML = '<div class="text-secondary small"><span class="spinner-border spinner-border-sm me-2"></span>Traitement en cours…</div>';
    req.then(function (j) { showReport(j.report); }).catch(function (e) { showError(e.message); }).then(function () { btn.disabled = false; });
  });
})();
</script>
