<?php
/**
 * AutoConfig : configuration automatique des classes / séries / matières / enseignants / compétences.
 * Projet GESCOAPC.
 *
 * Données de référence : scripts SQL du dossier /datas (exécutés par PHP) ou configuration de l'année précédente
 * (fichier .sql de sauvegarde OU base de données de l'année dernière).
 * RÈGLE D'OR : on COMPLÈTE. Aucune suppression. Les coefficients, groupes, compétences existants ne sont jamais modifiés.
 * Seule exception, uniquement si l'option « remplacer les enseignants » est cochée : l'enseignant d'une matière déjà configurée.
 */
class AutoConfig
{
    /** @var PDO */
    private $bdd;
    private $root;
    private $datas;

    private $depCache = array();
    private $matCache = array();
    private $teacherCache = array();
    private $presentCache = array();

    public $stats = array(
        'classes_creees' => 0, 'classes_existantes' => 0,
        'matieres_ajoutees' => 0, 'matieres_deja' => 0, 'matieres_equivalentes' => 0,
        'enseignants_affectes' => 0, 'enseignants_remplaces' => 0, 'enseignants_crees' => 0,
        'competences_ajoutees' => 0, 'referentiel_crees' => 0,
    );
    public $notes = array();

    public function __construct(PDO $bdd, $root = null)
    {
        $this->bdd   = $bdd;
        $this->root  = $root ? rtrim($root, '/\\') : dirname(__DIR__);
        $this->datas = $this->root . '/datas';
    }

    private static function opt($o, $k, $def = false) { return isset($o[$k]) ? $o[$k] : $def; }

    /* ====================================================================
     *  UTILITAIRES : SQL, noms de classes
     * ==================================================================== */

    public static function splitSql($sql)
    {
        $out = array(); $buf = ''; $q = '';
        $len = strlen($sql);
        for ($i = 0; $i < $len; $i++) {
            $c = $sql[$i];
            if ($q !== '') {
                $buf .= $c;
                if ($c === '\\' && $q !== '`' && $i + 1 < $len) { $buf .= $sql[++$i]; continue; }
                if ($c === $q) {
                    if ($i + 1 < $len && $sql[$i + 1] === $q) { $buf .= $sql[++$i]; continue; }
                    $q = '';
                }
                continue;
            }
            if ($c === "'" || $c === '"' || $c === '`') { $q = $c; $buf .= $c; continue; }
            if (($c === '-' && $i + 2 < $len && $sql[$i + 1] === '-' && ctype_space($sql[$i + 2])) || $c === '#') {
                while ($i < $len && $sql[$i] !== "\n") { $i++; }
                $buf .= "\n";
                continue;
            }
            if ($c === ';') {
                $s = trim($buf);
                if ($s !== '') { $out[] = $s; }
                $buf = '';
                continue;
            }
            $buf .= $c;
        }
        $s = trim($buf);
        if ($s !== '') { $out[] = $s; }
        return $out;
    }

    public function runSqlFile($relPath, array $tokens = array())
    {
        $path = $this->datas . '/' . ltrim($relPath, '/\\');
        if (!is_file($path)) { throw new RuntimeException('Script introuvable : datas/' . $relPath); }
        $sql = file_get_contents($path);
        if ($sql === false) { throw new RuntimeException('Lecture impossible : datas/' . $relPath); }
        foreach ($tokens as $k => $v) {
            $sql = str_replace('@@' . $k . '@@', $this->bdd->quote((string)$v), $sql);
        }
        $affected = 0;
        foreach (self::splitSql($sql) as $stmt) {
            $n = $this->bdd->exec($stmt);
            if (is_int($n) && $n > 0) { $affected += $n; }
        }
        return $affected;
    }

    /**
     * Clé canonique d'un nom de classe : « 6e », « 6ème », « 6EME » -> 6E ; « 2ndeC », « 2nd C », « 2NDE C » -> 2NDEC ;
     * « 4E ALL » = « 4EME ALL ». Sert à repérer les doublons.
     */
    public static function canonKey($nom)
    {
        $s = mb_strtoupper(trim((string)$nom), 'UTF-8');
        $s = strtr($s, array('É' => 'E', 'È' => 'E', 'Ê' => 'E', 'Ë' => 'E', 'À' => 'A', 'Â' => 'A', 'Ä' => 'A',
            'Î' => 'I', 'Ï' => 'I', 'Ô' => 'O', 'Ö' => 'O', 'Ù' => 'U', 'Û' => 'U', 'Ü' => 'U', 'Ç' => 'C'));
        $s = preg_replace('/[^A-Z0-9]/', '', $s);
        $rules = array(
            array('/^(SIXIEME|6IEME|6EME|6EM|6E)/', '6E'),
            array('/^(CINQUIEME|5IEME|5EME|5EM|5E)/', '5E'),
            array('/^(QUATRIEME|4IEME|4EME|4EM|4E)/', '4E'),
            array('/^(TROISIEME|3IEME|3EME|3EM|3E)/', '3E'),
            array('/^(SECONDE|2NDE|2ND|2DE)/', '2NDE'),
            array('/^(PREMIERE|1ERE|1RE|1ER)/', '1ERE'),
            array('/^(TERMINALE|TLE|TERM|TL)/', 'TLE'),
            array('/^(LOWERSIXTH|LSIXTH|L6)/', 'L6'),
            array('/^(UPPERSIXTH|USIXTH|U6)/', 'U6'),
        );
        foreach ($rules as $r) {
            if (preg_match($r[0], $s)) { return preg_replace($r[0], $r[1], $s, 1); }
        }
        if (preg_match('/^(FORM|F)(\d)/', $s)) { return preg_replace('/^(FORM|F)(\d)/', 'F$2', $s, 1); }
        return $s;
    }

    public static function cycleOf($niveau) { return ((int)$niveau >= 1 && (int)$niveau <= 4) ? 1 : 2; }

    public static function sectionLabels()
    {
        return array(
            'SFG' => 'Francophone Générale (SFG)',
            'SAG' => 'Anglophone Générale (SAG)',
            'SFT' => 'Francophone Technique (SFT)',
            'SAT' => 'Anglophone Technique (SAT)',
        );
    }

    /* ====================================================================
     *  DONNÉES DU MODÈLE (datas/<SECTION>/)
     * ==================================================================== */

    public function sectionHasModel($sec)
    {
        $d = $this->datas . '/' . $sec;
        if (!preg_match('/^[A-Z]{3}$/', $sec)) { return false; }
        foreach (array('01_niveaux', '02_referentiel', '03_modele_bulletin', '05_series') as $f) {
            if (!is_file($d . '/' . $f . '.sql')) { return false; }
        }
        return true;
    }

    private function loadNiveaux($sec)
    {
        $this->runSqlFile($sec . '/01_niveaux.sql');
        return $this->bdd->query('SELECT niveau, cycle, prefixe, libelle FROM tmp_niveaux ORDER BY niveau')->fetchAll(PDO::FETCH_ASSOC);
    }

    private function loadSeries($sec)
    {
        $this->runSqlFile($sec . '/05_series.sql');
        $res = array();
        foreach ($this->bdd->query('SELECT niveau, serie, libelle, tags, defaut FROM tmp_series ORDER BY niveau')->fetchAll(PDO::FETCH_ASSOC) as $r) {
            $res[(int)$r['niveau']][] = $r;
        }
        return $res;
    }

    /** Répartit les classes existantes d'un niveau entre les séries : serie => [codes], + '?' = non rattachées. */
    private function groupClasses($sec, $niv, $prefixe, array $series)
    {
        $st = $this->bdd->prepare('SELECT code_class, nom_class FROM classes WHERE class_session = ? AND ref_class_niveau = ? ORDER BY id');
        $st->execute(array($sec, (string)$niv));
        $lvl = self::canonKey($prefixe);
        $keys = array();
        foreach ($series as $s) { $keys[$s['serie']] = $lvl . self::canonKey($s['serie']); }
        $groups = array('?' => array());
        foreach ($series as $s) { $groups[$s['serie']] = array(); }
        while ($c = $st->fetch(PDO::FETCH_ASSOC)) {
            $ck = self::canonKey($c['nom_class']);
            $best = null; $bl = -1;
            foreach ($keys as $serie => $K) {
                if ($serie === '') { continue; }
                if (strncmp($ck, $K, strlen($K)) === 0 && strlen($K) > $bl) { $best = $serie; $bl = strlen($K); }
            }
            if ($best === null && isset($keys[''])) { $best = ''; }
            if ($best === null) { $groups['?'][] = $c; } else { $groups[$best][] = $c; }
        }
        return $groups;
    }

    public function initInfo()
    {
        $sections = array();
        foreach (self::sectionLabels() as $code => $label) {
            $item = array('code' => $code, 'label' => $label, 'modele' => $this->sectionHasModel($code), 'niveaux' => array());
            if ($item['modele']) {
                $nv = $this->loadNiveaux($code);
                $series = $this->loadSeries($code);
                foreach ($nv as $n) {
                    $niv = (int)$n['niveau'];
                    $ss = isset($series[$niv]) ? $series[$niv] : array();
                    $groups = $this->groupClasses($code, $niv, $n['prefixe'], $ss);
                    $row = array('niveau' => $niv, 'cycle' => (int)$n['cycle'], 'libelle' => $n['libelle'], 'series' => array(), 'non_rattachees' => count($groups['?']));
                    foreach ($ss as $s) {
                        $e = count($groups[$s['serie']]);
                        $row['series'][] = array('serie' => $s['serie'], 'libelle' => $s['libelle'], 'existantes' => $e,
                            'defaut' => $e > 0 ? $e : (int)$s['defaut']);
                    }
                    $item['niveaux'][] = $row;
                }
            }
            $sections[] = $item;
        }
        $sources = array();
        foreach ($this->findDumpFiles() as $i => $f) {
            $sources[] = array('id' => 'f' . $i, 'nom' => 'Fichier : ' . $f['nom'] . ' (' . round($f['taille'] / 1024) . ' Ko)');
        }
        foreach ($this->listPreviousDatabases() as $db) {
            array_unshift($sources, array('id' => 'd:' . $db, 'nom' => 'Base de données : ' . $db));
        }
        return array('sections' => $sections, 'sources' => $sources);
    }

    /* ====================================================================
     *  BASE DE DONNÉES : recherche / création sans doublon
     * ==================================================================== */

    private function randomCode($len, $table, $col)
    {
        for ($t = 0; $t < 300; $t++) {
            $code = '';
            for ($i = 0; $i < $len; $i++) { $code .= (string)mt_rand(0, 9); }
            $st = $this->bdd->prepare("SELECT 1 FROM `$table` WHERE `$col` = ? LIMIT 1");
            $st->execute(array($code));
            if (!$st->fetch()) { return $code; }
        }
        throw new RuntimeException('Impossible de générer un code unique.');
    }

    /** Toutes les clés canoniques des classes d'une section. */
    private function canonSet($sec)
    {
        $st = $this->bdd->prepare('SELECT code_class, nom_class FROM classes WHERE class_session = ?');
        $st->execute(array($sec));
        $set = array();
        while ($r = $st->fetch(PDO::FETCH_ASSOC)) { $set[self::canonKey($r['nom_class'])] = $r['code_class']; }
        return $set;
    }

    /** Classe de la section dont le nom équivaut (6e = 6EME, 2ndeC = 2nd C...). */
    private function findClassCanon($nom, $sec)
    {
        $set = $this->canonSet($sec);
        $k = self::canonKey($nom);
        return isset($set[$k]) ? $set[$k] : null;
    }

    private function createClass($nom, $niveau, $session)
    {
        $nom = mb_strtoupper(trim($nom), 'UTF-8');
        $code = $this->randomCode(5, 'classes', 'code_class');
        $st = $this->bdd->prepare('INSERT INTO classes (nom_class, ref_class_niveau, class_session, code_class) VALUES (?, ?, ?, ?)');
        $st->execute(array($nom, (string)$niveau, $session, $code));
        $this->stats['classes_creees']++;
        $up = $this->bdd->prepare('UPDATE sess SET nb_class_par_sess = (SELECT COUNT(id) FROM classes WHERE class_session = ?) WHERE abr_sess = ?');
        $up->execute(array($session, $session));
        return $code;
    }

    private function findMatiere($abr, $nom)
    {
        $k = mb_strtoupper($abr . '|' . $nom, 'UTF-8');
        if (isset($this->matCache[$k])) { return $this->matCache[$k]; }
        $st = $this->bdd->prepare('SELECT id, abr_mat, nom_mat, ref_depart FROM matieres WHERE abr_mat = ? AND nom_mat = ? ORDER BY id LIMIT 1');
        $st->execute(array($abr, $nom));
        $r = $st->fetch(PDO::FETCH_ASSOC);
        if ($r) { $this->matCache[$k] = $r; }
        return $r;
    }

    private function ensureDepartement($nom, $session, $abr = '')
    {
        $k = mb_strtoupper($nom . '|' . $session, 'UTF-8');
        if (isset($this->depCache[$k])) { return $this->depCache[$k]; }
        $st = $this->bdd->prepare('SELECT id FROM departements WHERE nom_dep = ? AND ref_session = ? ORDER BY id LIMIT 1');
        $st->execute(array($nom, $session));
        $id = $st->fetchColumn();
        if (!$id) {
            $ins = $this->bdd->prepare('INSERT INTO departements (nom_dep, ref_session, abr_dep) VALUES (?, ?, ?)');
            $ins->execute(array($nom, $session, $abr !== '' ? $abr : mb_substr($nom, 0, 20)));
            $id = $this->bdd->lastInsertId();
            $this->stats['referentiel_crees']++;
        }
        return $this->depCache[$k] = (string)$id;
    }

    private function ensureMatiere($abr, $nom, $depId)
    {
        $r = $this->findMatiere($abr, $nom);
        if ($r) { return $r; }
        $ins = $this->bdd->prepare('INSERT INTO matieres (abr_mat, nom_mat, ref_depart) VALUES (?, ?, ?)');
        $ins->execute(array($abr, $nom, (string)$depId));
        $this->stats['referentiel_crees']++;
        $this->matCache = array();
        return $this->findMatiere($abr, $nom);
    }

    /* ====================================================================
     *  ENSEIGNANTS
     * ==================================================================== */

    private static function teacherLabel($nomMat)
    {
        $s = html_entity_decode((string)$nomMat, ENT_QUOTES, 'UTF-8');
        $s = str_ireplace(array('&amp;', '&'), 'ET', $s);
        return trim(mb_strtoupper($s, 'UTF-8'));
    }

    /**
     * Enseignant (login) pour une matière et un cycle.
     * mode_ens : auto (enseignant réel déjà affecté à la matière, sinon PROF générique) | generic (toujours PROF générique) | none.
     * ens_par_cycle : PROF ANGLAIS 1 (1er cycle) / PROF ANGLAIS 2 (2nd cycle) au lieu d'un seul PROF ANGLAIS.
     */
    private function teacherFor(array $mat, $cycle, array $opts)
    {
        $mode = self::opt($opts, 'mode_ens', 'auto');
        if ($mode === 'none') { return null; }
        $perCycle = (bool)self::opt($opts, 'ens_par_cycle', true);
        $key = $mat['id'] . '|' . ($perCycle ? (int)$cycle : 0) . '|' . $mode;
        if (isset($this->teacherCache[$key])) { return $this->teacherCache[$key]; }

        $login = null;
        if ($mode === 'auto') {
            $st = $this->bdd->prepare("SELECT c.ref_ens FROM config_bull c JOIN admins a ON a.login = c.ref_ens
                WHERE c.ref_mat = ? AND a.role IN ('ens','esn') AND a.username NOT LIKE 'PROF %'
                GROUP BY c.ref_ens ORDER BY COUNT(*) DESC LIMIT 1");
            $st->execute(array((string)$mat['id']));
            $l = $st->fetchColumn();
            if ($l) { $login = (string)$l; }
        }
        if ($login === null) {
            $username = 'PROF ' . self::teacherLabel($mat['nom_mat']) . ($perCycle ? ' ' . (int)$cycle : '');
            $sel = $this->bdd->prepare("SELECT login FROM admins WHERE role = 'ens' AND username = ? ORDER BY id LIMIT 1");
            $sel->execute(array($username));
            $l = $sel->fetchColumn();
            if (!$l) {
                $n = $this->runSqlFile('_enseignant_modele.sql', array(
                    'USERNAME' => $username,
                    'LOGIN'    => $this->randomCode(4, 'admins', 'login'),
                    'DEP_ID'   => (string)$mat['ref_depart'],
                ));
                if ($n > 0) { $this->stats['enseignants_crees']++; }
                $sel->execute(array($username));
                $l = $sel->fetchColumn();
            }
            $login = $l ? (string)$l : null;
        }
        return $this->teacherCache[$key] = $login;
    }

    /* ====================================================================
     *  ÉCRITURE DANS config_bull / competences_matieres (jamais d'écrasement)
     * ==================================================================== */

    private function presentAbrs($code)
    {
        if (!isset($this->presentCache[$code])) {
            $st = $this->bdd->prepare('SELECT m.abr_mat FROM config_bull c JOIN matieres m ON m.id = c.ref_mat WHERE c.ref_class = ?');
            $st->execute(array($code));
            $set = array();
            while ($r = $st->fetch(PDO::FETCH_NUM)) { $set[mb_strtoupper($r[0], 'UTF-8')] = true; }
            $this->presentCache[$code] = $set;
        }
        return $this->presentCache[$code];
    }

    private function completeMatiere($codeClasse, $niveau, $matId, $abrMat, $coeff, $groupe, $ens, array $comp, $withComp, $replaceTeacher)
    {
        $st = $this->bdd->prepare('SELECT id, ref_ens FROM config_bull WHERE ref_class = ? AND ref_mat = ? LIMIT 1');
        $st->execute(array($codeClasse, (string)$matId));
        $ex = $st->fetch(PDO::FETCH_ASSOC);

        if (!$ex) {
            $ins = $this->bdd->prepare('INSERT INTO config_bull (ref_class, ref_mat, nom_mat, coeff_mat, group_mat, ref_ens, ref_niveau_class) VALUES (?, ?, ?, ?, ?, ?, ?)');
            $ins->execute(array($codeClasse, (string)$matId, $abrMat, (string)$coeff, (string)$groupe, $ens, (string)$niveau));
            $this->stats['matieres_ajoutees']++;
            if ($ens) { $this->stats['enseignants_affectes']++; }
            $this->presentCache[$codeClasse][mb_strtoupper($abrMat, 'UTF-8')] = true;
        } else {
            $this->stats['matieres_deja']++;
            if ($ens) {
                $vide = ($ex['ref_ens'] === null || trim((string)$ex['ref_ens']) === '' || $ex['ref_ens'] === '0');
                if ($vide) {
                    $up = $this->bdd->prepare('UPDATE config_bull SET ref_ens = ? WHERE id = ?');
                    $up->execute(array($ens, $ex['id']));
                    $this->stats['enseignants_affectes']++;
                } elseif ($replaceTeacher && (string)$ex['ref_ens'] !== (string)$ens) {
                    $up = $this->bdd->prepare('UPDATE config_bull SET ref_ens = ? WHERE id = ?');
                    $up->execute(array($ens, $ex['id']));
                    $this->stats['enseignants_remplaces']++;
                }
            }
        }

        if ($withComp) {
            $sc = $this->bdd->prepare('SELECT num_compt FROM competences_matieres WHERE ref_class = ? AND ref_mat = ?');
            $sc->execute(array($codeClasse, (string)$matId));
            $have = array();
            while ($r = $sc->fetch(PDO::FETCH_NUM)) { $have[(int)$r[0]] = true; }
            $ic = $this->bdd->prepare('INSERT INTO competences_matieres (ref_class, ref_mat, num_compt, nom_compt) VALUES (?, ?, ?, ?)');
            for ($i = 1; $i <= 6; $i++) {
                if (isset($have[$i])) { continue; }
                $txt = (isset($comp[$i]) && trim($comp[$i]) !== '') ? $comp[$i] : 'Competence ' . $i;
                $ic->execute(array($codeClasse, (string)$matId, $i, $txt));
                $this->stats['competences_ajoutees']++;
            }
        }
    }

    /* ====================================================================
     *  MODE 1 : MODÈLE STANDARD (séries, cycles, sections)
     * ==================================================================== */

    /**
     * @param array $plan   plan[SEC][niveau][serie] = nombre TOTAL de classes souhaité (serie '_' = sans série)
     * @param array $cycles cycles retenus
     */
    public function applyStandard(array $plan, array $cycles, array $opts)
    {
        $completer = (bool)self::opt($opts, 'completer_existantes', true);
        $withComp  = (bool)self::opt($opts, 'competences', true);
        $replace   = (bool)self::opt($opts, 'remplacer_enseignants', false);

        foreach ($plan as $sec => $niveaux) {
            if (!$this->sectionHasModel($sec)) { $this->notes[] = "Section $sec : aucun modèle dans datas/$sec (ignorée)."; continue; }

            $this->runSqlFile($sec . '/02_referentiel.sql');       // départements + matières manquants
            $this->matCache = array(); $this->depCache = array();
            $nvInfo = array();
            foreach ($this->loadNiveaux($sec) as $r) { $nvInfo[(int)$r['niveau']] = $r; }
            $series = $this->loadSeries($sec);

            $this->runSqlFile($sec . '/03_modele_bulletin.sql');
            $modByNiv = array();
            foreach ($this->bdd->query('SELECT niveau, tag, abr_mat, nom_mat, coeff, groupe FROM tmp_modele')->fetchAll(PDO::FETCH_ASSOC) as $m) {
                $modByNiv[(int)$m['niveau']][] = $m;
            }
            $compByKey = array();
            if ($withComp && is_file($this->datas . '/' . $sec . '/04_competences.sql')) {
                $this->runSqlFile($sec . '/04_competences.sql');
                foreach ($this->bdd->query('SELECT niveau, abr_mat, num, texte FROM tmp_compet')->fetchAll(PDO::FETCH_ASSOC) as $c) {
                    $compByKey[(int)$c['niveau'] . '|' . $c['abr_mat']][(int)$c['num']] = $c['texte'];
                }
            }
            $equiv = array();
            if (is_file($this->datas . '/' . $sec . '/06_equivalences.sql')) {
                $this->runSqlFile($sec . '/06_equivalences.sql');
                foreach ($this->bdd->query('SELECT abr_mat, abr_equiv FROM tmp_equiv')->fetchAll(PDO::FETCH_ASSOC) as $e) {
                    $equiv[mb_strtoupper($e['abr_mat'], 'UTF-8')][] = mb_strtoupper($e['abr_equiv'], 'UTF-8');
                }
            }

            foreach ($niveaux as $niv => $parSerie) {
                $niv = (int)$niv;
                if (!isset($nvInfo[$niv]) || !in_array((int)$nvInfo[$niv]['cycle'], $cycles, true)) { continue; }
                $ss = isset($series[$niv]) ? $series[$niv] : array();
                $serieInfo = array();
                foreach ($ss as $s) { $serieInfo[$s['serie'] === '' ? '_' : $s['serie']] = $s; }
                $groups = $this->groupClasses($sec, $niv, $nvInfo[$niv]['prefixe'], $ss);
                $allCanon = $this->canonSet($sec);
                $cycle = (int)$nvInfo[$niv]['cycle'];

                foreach ($parSerie as $sk => $souhait) {
                    if (!isset($serieInfo[$sk])) { continue; }
                    $souhait = max(0, min(20, (int)$souhait));
                    $s = $serieInfo[$sk];
                    $serie = $s['serie'];
                    $exist = isset($groups[$serie]) ? $groups[$serie] : array();
                    $codes = array(); foreach ($exist as $e) { $codes[] = $e['code_class']; }
                    $this->stats['classes_existantes'] += count($exist);

                    // classes manquantes (doublons évités : 6e = 6EME, 2ndeC = 2nde C)
                    $base = ($serie !== '') ? $nvInfo[$niv]['prefixe'] . ' ' . $serie : $nvInfo[$niv]['prefixe'];
                    $K = self::canonKey($base);
                    $besoin = $souhait - count($exist);
                    $nouveaux = array();
                    for ($i = 1; $besoin > 0 && $i <= 60; $i++) {
                        $cands = ($i === 1) ? array($K, $K . '1') : array($K . $i);
                        $pris = false;
                        foreach ($cands as $cd) { if (isset($allCanon[$cd])) { $pris = true; } }
                        if ($pris) { continue; }
                        $nom = ($souhait === 1) ? $base : $base . ' ' . $i;
                        $code = $this->createClass($nom, $niv, $sec);
                        $allCanon[self::canonKey($nom)] = $code;
                        $codes[] = $code; $nouveaux[] = $code; $besoin--;
                    }

                    $cibles = $completer ? $codes : $nouveaux;
                    if (empty($cibles)) { continue; }
                    $tags = array_map('trim', explode(',', $s['tags']));
                    $lignes = array();
                    foreach ((isset($modByNiv[$niv]) ? $modByNiv[$niv] : array()) as $m) {
                        if (in_array($m['tag'], $tags, true)) { $lignes[$m['abr_mat'] . '|' . $m['nom_mat']] = $m; }
                    }
                    if (empty($lignes)) { $this->notes[] = "$sec niveau $niv : aucune matière dans le modèle (datas/$sec/03_modele_bulletin.sql)."; continue; }

                    foreach ($cibles as $code) {
                        $present = $this->presentAbrs($code);
                        foreach ($lignes as $m) {
                            $mat = $this->findMatiere($m['abr_mat'], $m['nom_mat']);
                            if (!$mat) { continue; }
                            $ab = mb_strtoupper($m['abr_mat'], 'UTF-8');
                            $eq = isset($equiv[$ab]) ? $equiv[$ab] : array();
                            $deja = false;
                            foreach ($eq as $x) { if (isset($present[$x])) { $deja = true; } }
                            if ($deja) { $this->stats['matieres_equivalentes']++; continue; }
                            $ens = $this->teacherFor($mat, $cycle, $opts);
                            $comp = isset($compByKey[$niv . '|' . $m['abr_mat']]) ? $compByKey[$niv . '|' . $m['abr_mat']] : array();
                            $this->completeMatiere($code, $niv, $mat['id'], $mat['abr_mat'], $m['coeff'], $m['groupe'], $ens, $comp, $withComp, $replace);
                        }
                    }
                }
                if (!empty($groups['?'])) {
                    $this->notes[] = "$sec niveau $niv : " . count($groups['?']) . " classe(s) existante(s) non rattachée(s) à une série du modèle (laissée(s) intacte(s)).";
                }
            }
        }
        return $this->report();
    }

    /* ====================================================================
     *  MODE 2 : REPRISE DE L'ANNÉE PRÉCÉDENTE (base de données ou fichier .sql)
     * ==================================================================== */

    public function findDumpFiles()
    {
        $res = array();
        $patterns = array($this->root . '/gescoapc_*.sql', $this->root . '/datas/*.sql', $this->root . '/datas/dumps/*.sql', $this->root . '/Model/gescoapc_*.sql');
        foreach ($patterns as $p) {
            foreach ((array)glob($p) as $f) {
                if (is_file($f) && basename($f) !== '_enseignant_modele.sql') {
                    $res[] = array('path' => $f, 'nom' => str_replace($this->root . '/', '', str_replace('\\', '/', $f)), 'taille' => filesize($f), 'mtime' => filemtime($f));
                }
            }
        }
        usort($res, function ($a, $b) { return $b['mtime'] <=> $a['mtime']; });
        return array_values($res);
    }

    /** Bases « gescoapc_* » autres que la base courante (années précédentes). */
    public function listPreviousDatabases()
    {
        $out = array();
        try {
            $cur = (string)$this->bdd->query('SELECT DATABASE()')->fetchColumn();
            foreach ($this->bdd->query("SHOW DATABASES LIKE 'gescoapc%'")->fetchAll(PDO::FETCH_NUM) as $r) {
                if ($r[0] !== $cur && preg_match('/^gescoapc[A-Za-z0-9_\-]*$/', $r[0])) { $out[] = $r[0]; }
            }
        } catch (Throwable $e) { /* pas de droit SHOW DATABASES : on ignore */ }
        rsort($out);
        return $out;
    }

    private function readSource($id)
    {
        $id = (string)$id;
        if (strncmp($id, 'd:', 2) === 0) {
            $name = substr($id, 2);
            if (!in_array($name, $this->listPreviousDatabases(), true)) { throw new RuntimeException('Base de données inconnue.'); }
            return $this->loadFromDb($name);
        }
        if (preg_match('/^f(\d+)$/', $id, $m)) {
            $list = $this->findDumpFiles();
            if (!isset($list[(int)$m[1]])) { throw new RuntimeException('Fichier de sauvegarde inconnu.'); }
            return $this->parseDump($list[(int)$m[1]]['path']);
        }
        throw new RuntimeException('Source inconnue.');
    }

    private function loadFromDb($name)
    {
        $d = array();
        foreach (array('classes', 'config_bull', 'competences_matieres', 'matieres', 'departements', 'admins') as $t) {
            try {
                $d[$t] = $this->bdd->query('SELECT * FROM `' . str_replace('`', '', $name) . '`.`' . $t . '`')->fetchAll(PDO::FETCH_ASSOC);
            } catch (Throwable $e) { $d[$t] = array(); }
        }
        return $d;
    }

    private static function scanQuote($s, &$q, &$esc)
    {
        $n = strlen($s);
        for ($i = 0; $i < $n; $i++) {
            $c = $s[$i];
            if ($q !== '') {
                if ($esc) { $esc = false; continue; }
                if ($c === '\\') { $esc = true; continue; }
                if ($c === $q) { $q = ''; }
            } elseif ($c === '"' || $c === "'") { $q = $c; }
        }
    }

    private static function parseTuples($s, $pos, array $cols)
    {
        $rows = array(); $n = strlen($s); $nc = count($cols);
        $map = array('n' => "\n", 'r' => "\r", 't' => "\t", '0' => "\0", 'Z' => chr(26));
        while ($pos < $n) {
            while ($pos < $n && $s[$pos] !== '(' && $s[$pos] !== ';') { $pos++; }
            if ($pos >= $n || $s[$pos] === ';') { break; }
            $pos++;
            $vals = array();
            while ($pos < $n) {
                while ($pos < $n && ctype_space($s[$pos])) { $pos++; }
                if ($pos >= $n) { break; }
                $c = $s[$pos];
                if ($c === '"' || $c === "'") {
                    $q = $c; $pos++; $v = '';
                    while ($pos < $n) {
                        $ch = $s[$pos];
                        if ($ch === '\\' && $pos + 1 < $n) { $nx = $s[$pos + 1]; $v .= isset($map[$nx]) ? $map[$nx] : $nx; $pos += 2; continue; }
                        if ($ch === $q) {
                            if ($pos + 1 < $n && $s[$pos + 1] === $q) { $v .= $q; $pos += 2; continue; }
                            $pos++; break;
                        }
                        $v .= $ch; $pos++;
                    }
                    $vals[] = $v;
                } else {
                    $start = $pos;
                    while ($pos < $n && $s[$pos] !== ',' && $s[$pos] !== ')') { $pos++; }
                    $tok = trim(substr($s, $start, $pos - $start));
                    $vals[] = (strcasecmp($tok, 'NULL') === 0) ? null : $tok;
                }
                while ($pos < $n && ctype_space($s[$pos])) { $pos++; }
                if ($pos < $n && $s[$pos] === ',') { $pos++; continue; }
                if ($pos < $n && $s[$pos] === ')') { $pos++; break; }
            }
            if (count($vals) === $nc) { $rows[] = array_combine($cols, $vals); }
        }
        return $rows;
    }

    private function parseDump($path)
    {
        $want = array('classes', 'config_bull', 'competences_matieres', 'matieres', 'departements', 'admins');
        $data = array_fill_keys($want, array());
        $fh = fopen($path, 'rb');
        if (!$fh) { throw new RuntimeException('Lecture du fichier impossible.'); }
        while (($line = fgets($fh)) !== false) {
            if (strncmp($line, 'INSERT INTO `', 13) !== 0) { continue; }
            if (!preg_match('/^INSERT INTO `([^`]+)`/', $line, $m) || !in_array($m[1], $want, true)) { continue; }
            $table = $m[1];
            $stmt = $line; $q = ''; $esc = false;
            self::scanQuote($line, $q, $esc);
            while (!($q === '' && substr(rtrim($stmt), -1) === ';')) {
                $more = fgets($fh);
                if ($more === false) { break; }
                $stmt .= $more;
                self::scanQuote($more, $q, $esc);
            }
            if (!preg_match('/\(([^)]*)\)\s*VALUES/i', $stmt, $mm, PREG_OFFSET_CAPTURE)) { continue; }
            $cols = array();
            foreach (explode(',', $mm[1][0]) as $c) { $cols[] = trim($c, " `\t\r\n"); }
            $start = $mm[0][1] + strlen($mm[0][0]);
            foreach (self::parseTuples($stmt, $start, $cols) as $row) { $data[$table][] = $row; }
        }
        fclose($fh);
        return $data;
    }

    private static function clean($s) { return trim(preg_replace('/\s+/u', ' ', (string)$s)); }

    public function previewSource($id)
    {
        $d = $this->readSource($id);
        if (empty($d['classes'])) { throw new RuntimeException('Aucune classe trouvée dans cette source.'); }
        $nbMat = array();
        foreach ($d['config_bull'] as $r) { $nbMat[$r['ref_class']] = (isset($nbMat[$r['ref_class']]) ? $nbMat[$r['ref_class']] : 0) + 1; }
        $out = array(); $setCache = array();
        foreach ($d['classes'] as $c) {
            $niv = (int)$c['ref_class_niveau'];
            $sec = $c['class_session'];
            if (!isset($setCache[$sec])) { $setCache[$sec] = $this->canonSet($sec); }
            $out[] = array('code' => $c['code_class'], 'nom' => $c['nom_class'], 'niveau' => $niv, 'section' => $sec,
                'cycle' => self::cycleOf($niv), 'nb_mat' => isset($nbMat[$c['code_class']]) ? $nbMat[$c['code_class']] : 0,
                'existe' => isset($setCache[$sec][self::canonKey($c['nom_class'])]));
        }
        usort($out, function ($a, $b) { return array($a['section'], $a['niveau'], $a['nom']) <=> array($b['section'], $b['niveau'], $b['nom']); });
        return array('classes' => $out);
    }

    private function mapTeacherFromSource($login, array $d, array &$cache)
    {
        if ($login === null || trim($login) === '' || $login === '0') { return null; }
        if (array_key_exists($login, $cache)) { return $cache[$login]; }
        $st = $this->bdd->prepare('SELECT login FROM admins WHERE login = ? LIMIT 1');
        $st->execute(array($login));
        if ($st->fetchColumn()) { return $cache[$login] = $login; }

        $src = null;
        foreach ($d['admins'] as $a) { if ((string)$a['login'] === (string)$login) { $src = $a; break; } }
        if (!$src) { $this->notes[] = "Enseignant $login introuvable dans la source : matière laissée sans enseignant."; return $cache[$login] = null; }
        if (!in_array($src['role'], array('ens', 'esn'), true)) {
            $this->notes[] = 'Compte « ' . $src['username'] . ' » (rôle ' . $src['role'] . ') non repris comme enseignant : à affecter manuellement.';
            return $cache[$login] = null;
        }
        $s2 = $this->bdd->prepare("SELECT login FROM admins WHERE username = ? AND role IN ('ens','esn') ORDER BY id LIMIT 1");
        $s2->execute(array($src['username']));
        $l2 = $s2->fetchColumn();
        if ($l2) { return $cache[$login] = $l2; }

        $depId = null;
        foreach ($d['departements'] as $dep) {
            if ((string)$dep['id'] === (string)$src['ref_dep']) { $depId = $this->ensureDepartement($dep['nom_dep'], $dep['ref_session'], $dep['abr_dep']); break; }
        }
        $newLogin = $login;
        $chk = $this->bdd->prepare('SELECT 1 FROM admins WHERE login = ? LIMIT 1');
        $chk->execute(array($newLogin));
        if ($chk->fetch()) { $newLogin = $this->randomCode(4, 'admins', 'login'); }
        $ins = $this->bdd->prepare('INSERT INTO admins (civilite, username, login, password, role, ref_dep) VALUES (?, ?, ?, ?, ?, ?)');
        $ins->execute(array($src['civilite'], $src['username'], $newLogin, $newLogin, $src['role'], $depId));
        $this->stats['enseignants_crees']++;
        return $cache[$login] = $newLogin;
    }

    /**
     * Copie fidèle de la configuration de l'année précédente (classes, matières, coefficients, groupes, enseignants, compétences),
     * puis, si demandé, ajout du modèle standard UNIQUEMENT pour les niveaux absents de la source (niveaux suivants).
     *
     * @param array $stdPlan  plan standard (voir applyStandard) utilisé pour les niveaux suivants
     */
    public function applySource($id, array $codes, array $opts, array $stdPlan = array(), array $cycles = array())
    {
        $withComp = (bool)self::opt($opts, 'competences', true);
        $withTeach = (bool)self::opt($opts, 'enseignants', true);
        $replace = (bool)self::opt($opts, 'remplacer_enseignants', false);
        $d = $this->readSource($id);

        $byCode = array(); foreach ($d['classes'] as $c) { $byCode[$c['code_class']] = $c; }
        $matById = array(); foreach ($d['matieres'] as $m) { $matById[$m['id']] = $m; }
        $depById = array(); foreach ($d['departements'] as $x) { $depById[$x['id']] = $x; }
        $cfgBy = array(); foreach ($d['config_bull'] as $r) { $cfgBy[$r['ref_class']][] = $r; }
        $cmpBy = array(); foreach ($d['competences_matieres'] as $r) { $cmpBy[$r['ref_class'] . '|' . $r['ref_mat']][(int)$r['num_compt']] = self::clean($r['nom_compt']); }

        $matMap = array(); $teachCache = array(); $canon = array();
        foreach ($codes as $code) {
            if (!isset($byCode[$code])) { continue; }
            $c = $byCode[$code];
            $niv = (int)$c['ref_class_niveau']; $sec = $c['class_session'];
            if (!isset($canon[$sec])) { $canon[$sec] = $this->canonSet($sec); }
            $k = self::canonKey($c['nom_class']);
            if (isset($canon[$sec][$k])) { $newCode = $canon[$sec][$k]; $this->stats['classes_existantes']++; }
            else { $newCode = $this->createClass($c['nom_class'], $niv, $sec); $canon[$sec][$k] = $newCode; }

            foreach ((isset($cfgBy[$code]) ? $cfgBy[$code] : array()) as $cfg) {
                $oldMat = $cfg['ref_mat'];
                if (!isset($matById[$oldMat])) { $this->notes[] = "Matière #$oldMat inconnue dans la source (ignorée)."; continue; }
                if (!isset($matMap[$oldMat])) {
                    $m = $matById[$oldMat];
                    $dep = isset($depById[$m['ref_depart']]) ? $depById[$m['ref_depart']] : null;
                    $depId = $dep ? $this->ensureDepartement($dep['nom_dep'], $dep['ref_session'], $dep['abr_dep']) : $m['ref_depart'];
                    $matMap[$oldMat] = $this->ensureMatiere($m['abr_mat'], $m['nom_mat'], $depId);
                }
                $mat = $matMap[$oldMat];
                $ens = $withTeach ? $this->mapTeacherFromSource($cfg['ref_ens'], $d, $teachCache) : null;
                $comp = isset($cmpBy[$code . '|' . $oldMat]) ? $cmpBy[$code . '|' . $oldMat] : array();
                $this->completeMatiere($newCode, $niv, $mat['id'], $mat['abr_mat'], $cfg['coeff_mat'], $cfg['group_mat'], $ens, $comp, $withComp, $replace);
            }
        }

        // Niveaux suivants : modèle standard seulement là où la source n'a AUCUNE classe
        if (!empty($stdPlan)) {
            $couverts = array();
            foreach ($d['classes'] as $c) { $couverts[$c['class_session'] . '|' . (int)$c['ref_class_niveau']] = true; }
            $plan = array();
            foreach ($stdPlan as $sec => $nv) {
                foreach ($nv as $niv => $ps) {
                    if (!isset($couverts[$sec . '|' . (int)$niv])) { $plan[$sec][$niv] = $ps; }
                }
            }
            if (!empty($plan)) { $this->applyStandard($plan, $cycles, $opts); }
            else { $this->notes[] = 'Aucun niveau absent de la source : rien à ajouter depuis le modèle standard.'; }
        }
        return $this->report();
    }

    public function report() { return array('stats' => $this->stats, 'notes' => array_values(array_unique($this->notes))); }
}
