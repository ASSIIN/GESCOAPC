<?php
    session_start();   
    require_once 'core/require.php'; 
    require_once 'Model/connexion.php';

    if (!isset($_SESSION['user'])) {
        session_unset();
        session_destroy();
        header('location: index.php');    
        exit();
    }

    if (($_SESSION['user_role'] != "admin") && ($_SESSION['user_role'] != "pcpl")) {
        if ($_SESSION['user_role'] == "caisse") {
            header('location: menu_classes.php');    
            exit();
        } else {
            header('location: poste_de_saisie.php?trim=t1');   
            exit();
        }
    }
    
    // Vérification de la validité de la classe demandée
    if (isset($_GET['id'])) {
        $ckcls = $class->CkExistingCode($_GET['id']);
        if (($_GET['id'] == "") || ($ckcls == false)) {
            header('location: menu_classes.php');    
            exit();
        } else {
            $ref_classe = htmlspecialchars($_GET['id']);
        }
    } else {
        $startcls = $class->getStartClasseCode();
        if ($startcls == null) {
            header('location: menu_classes.php');
            exit();
        } else {
            $ref_classe = $startcls;
        }
    }

    $etb->ShowEtb();
    $etb->ckexneE(); 
    $class->ShowClassInfos($ref_classe);
    $nbmat = $class->NombreMatbyCls($ref_classe);
    $nnPP = $class->ShowNom_Cls_Master($ref_classe);
    $nbcoeff = $class->NombreCoeffbyCls($ref_classe);
    $nbclasses = $class->NombreClasses();

    $nextcls = $class->getNextClasseCode($ref_classe);
    $precls = $class->getPreClasseCode($ref_classe);
?>
<!DOCTYPE html>
<html lang="fr">
  <head>
     <script>
         // Script d'interception anti-flash blanc
         document.documentElement.setAttribute("data-theme", localStorage.getItem("theme") || "light");
     </script>
     <?php Config::head(); ?>
     <title>GESCOAPC | Configuration Bulletins</title>
     
     <style>
         @media (max-width: 768px) {
             .fixed-top-mobile {
                 position: relative !important;
                 top: 0 !important;
                 margin-left: 0 !important;
                 width: 100% !important;
                 padding: 10px !important;
             }
             .main-content-wrapper {
                 margin-left: 0 !important;
                 padding: 15px !important;
                 padding-top: 80px !important;
             }
         }
     </style>
  </head>
  <body>
    <div class="wrapper">
      
      <!-- Menu latéral réutilisable -->
      <?php include 'core/sidebar.php'; ?>  
       
      <div class="main-content-wrapper">
        
        <!-- Barre supérieure de navigation adaptative -->
        <div class="mobile-navbar-fixed p-3 mb-4 rounded shadow-sm border">
            <div class="row align-items-center g-2">
                
                <div class="col-auto d-md-none">
                    <button class="btn btn-outline-dark btn-sm" id="toggleMobileMenu"><i class="fa fa-bars fa-lg"></i></button>
                </div>
                
                <div class="col-12 col-md-4">
                    <span class="badge bg-secondary px-3 py-2 fs-6">Section : <?php echo $_SESSION['class_session']; ?></span>
                    <button type="button" class="btn btn-sm btn-outline-primary ms-2 fw-bold" data-bs-toggle="modal" data-bs-target="#clone"><i class="fa fa-copy me-1"></i>Cloner la config</button>
                </div>
                  
                <div class="col-12 col-md-8 d-flex justify-content-md-end justify-content-between align-items-center gap-3">
                    <?php if ($precls != null): ?>
                        <a href="config_bull.php?id=<?php echo $precls; ?>" class="btn btn-sm btn-outline-success fw-bold"><i class="fa fa-arrow-left me-1"></i>Précédent</a>
                    <?php else: ?>
                        <button class="btn btn-sm btn-outline-secondary fw-bold" disabled><i class="fa fa-arrow-left me-1"></i>Précédent</button>
                    <?php endif; ?>

                    <h4 class="m-0 fw-bolder text-primary text-uppercase" style="letter-spacing:0.5px;"><?php echo $_SESSION['nom_class']; ?></h4>

                    <?php if ($nextcls != null): ?>
                        <a href="config_bull.php?id=<?php echo $nextcls; ?>" class="btn btn-sm btn-outline-success fw-bold">Suivant<i class="fa fa-arrow-right ms-1"></i></a>
                    <?php else: ?>
                        <button class="btn btn-sm btn-outline-secondary fw-bold" disabled>Suivant<i class="fa fa-arrow-right ms-1"></i></button>
                    <?php endif; ?>
                </div>

            </div>
        </div>

        <!-- Corps de configuration -->
        <div class="container-fluid p-0">
            <div class="row g-4">
                
                <!-- Formulaire d'ajout local de matière -->
                <div class="col-12 col-lg-4">
                    <div class="card p-3 shadow-sm border-0">
                        <h5 class="fw-bold mb-3 text-primary"><i class="fa fa-plus-circle me-2"></i>Associer une Matière</h5>
                        <form action="Controler/classes/add_mat_classe.php" method="post">
                            <input type="hidden" name="ref_class" value="<?php echo $ref_classe; ?>">
                            
                            <div class="mb-3">
                                <label for="mat" class="form-label small fw-bold text-secondary">Sélectionner la matière</label>
                                <select class="form-select form-select-sm" name="mat" id="mat" required>
                                    <option value="">Choisir...</option>
                                    <?php $mat->SelectMatieres(); ?> 
                                </select>
                            </div>
                      
                            <div class="row g-2 mb-3">
                                <div class="col-7">
                                    <label for="groupe" class="form-label small fw-bold text-secondary">Groupe Bulletin</label>
                                    <select id="groupe" name="groupe" class="form-select form-select-sm" required>
                                        <option value="">Sélectionner...</option>
                                        <option value="1">1er Groupe (Fondamental)</option>
                                        <option value="2">2e Groupe (Complémentaire)</option>
                                        <option value="3">3e Groupe (Professionnel)</option>
                                    </select>
                                </div>
                                <div class="col-5">
                                    <label for="coefficient" class="form-label small fw-bold text-secondary">Coefficient</label>
                                    <input type="number" id="coefficient" name="coeff" class="form-control form-control-sm text-center font-monospace fw-bold" required min="1" max="20" step="0.5">
                                </div>
                            </div>

                            <div class="mb-4">
                                <label for="ens" class="form-label small fw-bold text-secondary">Enseignant titulaire</label>
                                <select id="ens" name="ens" class="form-select form-select-sm" required>
                                    <option value="">Choisir...</option>
                                    <?php $user->SelectTeacher(); ?> 
                                </select>
                            </div>
                            
                            <button type="submit" class="btn btn-sm btn-primary w-100 fw-bold py-2 shadow-sm"><i class="fa fa-check-circle me-2"></i>Valider l'association</button>
                        </form>
                    </div>
                </div>

                <!-- Tableau récapitulatif des matières affectées -->
                <div class="col-12 col-lg-8">
                    <div class="card p-3 shadow-sm border-0">
                        <div class="d-flex justify-content-between align-items-center mb-3 flex-wrap gap-2">
                            <h5 class="fw-bold m-0 text-primary"><i class="fa fa-list-alt me-2"></i>Matières configurées</h5>
                            <div class="small fw-bold border rounded px-3 py-1 bg-light text-secondary">
                                Matières : <span class="text-primary me-2"><?php echo $nbmat; ?></span>
                                Coeff Global : <span class="text-danger"><?php echo $nbcoeff; ?></span>
                            </div>
                        </div>
                        
                        <div class="table-responsive w-100">
                            <table class="table table-striped table-hover align-middle text-center mb-0">
                                <thead class="text-white table-dark-custom">
                                    <tr style="font-size: 0.9em;">
                                        <th style="width: 55px;">#</th>
                                        <th class="text-start" style="padding-left:15px;">DISCIPLINE / ENSEIGNEMENT</th>
                                        <th style="width: 70px;">COEFF</th>
                                        <th style="width: 110px;">GROUPE</th>
                                        <th class="text-start">ENSEIGNANT CHARGÉ</th>
                                        <th style="width: 100px;">ACTIONS</th>
                                    </tr>
                                </thead>
                                <tbody style="font-size: 0.88em; font-weight: 500;">
                                    <?php $class->ShowEdit_Bul($_SESSION['code_class']); ?>
                                </tbody>
                                                            </table>
                        </div>
                    </div>
                </div>

            </div>
        </div>

      </div>
    </div>

    <!-- Modal de Clonage / Duplication de configuration -->
    <div class="modal fade" id="clone" tabindex="-1" aria-labelledby="cloneModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content border-0">
                <div class="modal-header text-white" style="background-color: #0764a8;">
                    <h5 class="modal-title fw-bold" id="cloneModalLabel"><i class="fa fa-copy me-2"></i>Dupliquer la Configuration</h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <form action="Controler/classes/clone_add_mat_classe.php" method="post">
                    <div class="modal-body p-4" style="background-color: var(--bg-main);">
                        <p class="text-muted small mb-3">Cette action copiera l'ensemble des matières et coefficients de la classe actuelle vers les cibles choisies.</p>
                        <input type="hidden" name="ref_class" value="<?php echo $ref_classe; ?>">
                        
                        <div class="mb-3">
                            <label for="type_clone" class="form-label small fw-bold text-secondary">Cible de la duplication</label>
                            <select id="type_clone" name="type" class="form-select" required> 
                                <option value="nv">Toutes les classes du même niveau</option>
                                <option value="all">Absolument toutes les classes de l'établissement</option>
                            </select>
                        </div>     
                    </div>
                    <div class="modal-footer border-top-0 pt-0">
                        <button type="button" class="btn btn-secondary px-3 btn-sm" data-bs-dismiss="modal">Annuler</button>
                        <button type="submit" class="btn btn-success px-4 btn-sm fw-bold" style="background-color: #19784f; border: none;"><i class="fa fa-exchange me-1"></i>Lancer la fusion</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <?php Config::scriptJs(); ?>

    <!-- Moteurs de contrôle de l'interface graphique et menu tactile -->
    <script type="text/javascript">
      $(document).ready(function() {
          // Activation du focus sur le menu des classes dans la Sidebar
          $(".sidebar-menu li").removeClass("active");
          $(".sidebar-menu li[data-page='classes']").addClass("active");

          // Gestion du tiroir tactile mobile (Burger menu)
          $("#toggleMobileMenu").on("click", function(e) {
              e.stopPropagation();
              $("#sidebarMenu").toggleClass("active");
          });

          $(document).on("click", function() {
              $("#sidebarMenu").removeClass("active");
          });
      });
    </script>
  </body>
</html>

