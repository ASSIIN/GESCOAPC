<?php
    session_start();
    require_once 'core/require.php';
    require_once 'Model/connexion.php';
    if (!isset($_SESSION['user'])) {
        session_unset();
        session_destroy();
        header('location: index.php');
        exit();
    }
    // Même règle d'accès que la page des matières
    if (($_SESSION['user_role'] != "admin") and ($_SESSION['user_role'] != "cs") and ($_SESSION['user_role'] != "pcpl")) {
        header('location: poste_de_saisie.php?trim=t1');
        exit();
    }
    $etb->ShowEtb();
    $etb->CkLE();
    $etb->ckexneE();

    // ---------- Données ----------
    $bdd = $GLOBALS['bdd'];
    if (!function_exists("fv")) { function fv($s) { return htmlspecialchars(html_entity_decode(str_ireplace('&AMP;', '&', (string)$s), ENT_QUOTES, 'UTF-8'), ENT_QUOTES, 'UTF-8'); } }

    $departements = $bdd->query('SELECT d.id, d.nom_dep, d.abr_dep, d.ref_session,
                                   (SELECT COUNT(*) FROM matieres m WHERE m.ref_depart = d.id) AS nb_mat,
                                   (SELECT COUNT(*) FROM admins a WHERE a.ref_dep = d.id AND a.role IN (\'ens\',\'esn\')) AS nb_ens
                                 FROM departements d WHERE d.id >= 1 ORDER BY d.nom_dep ASC')->fetchAll(PDO::FETCH_ASSOC);
    $sessions = $bdd->query('SELECT abr_sess, nom_sess FROM sess WHERE id >= 1 ORDER BY id ASC')->fetchAll(PDO::FETCH_ASSOC);

    $nbdep = count($departements);
    $secCount = array(); $vides = 0; $totMat = 0;
    foreach ($departements as $d) {
        $secCount[$d['ref_session']] = isset($secCount[$d['ref_session']]) ? $secCount[$d['ref_session']] + 1 : 1;
        if ((int)$d['nb_mat'] === 0) { $vides++; }
        $totMat += (int)$d['nb_mat'];
    }
    ksort($secCount);
?>
<!DOCTYPE html>
<html lang="fr">
  <head>
    <?php Config::head(); ?>
    <link rel="stylesheet" href="css/catalogue.css">
    <title>GESCOAPC | Départements</title>
  </head>

<body>
    <?php include 'core/sidebar.php'; ?>

    <div class="main-content-wrapper cat-page theme-dep">
        <div class="mobile-navbar-fixed p-3 mb-4 rounded shadow-sm border">
            <div class="row align-items-center g-2">
                <div class="col-auto d-md-none">
                    <button class="btn btn-outline-dark btn-sm" id="toggleMobileMenu" type="button"><i class="fa fa-bars fa-lg"></i></button>
                </div>
                <div class="col">
                    <h4 class="m-0 fw-bold text-primary text-uppercase"><i class="fa fa-sitemap me-2"></i>Départements
                        <span class="badge bg-danger ms-2 font-monospace"><?php echo $nbdep; ?></span></h4>
                </div>
            </div>
        </div>

        <div class="container-fluid p-0">

            <div class="cat-hero">
                <div class="hero-icon"><i class="fa fa-sitemap"></i></div>
                <div>
                    <h1>Départements pédagogiques</h1>
                    <p>Regroupez les matières par département et par section (SFG, SAG, SFT, SAT).</p>
                </div>
                <div class="hero-actions">
                    <button type="button" class="btn btn-hero" data-bs-toggle="modal" data-bs-target="#addDep"><i class="fa fa-plus-circle me-2"></i>Ajouter un département</button>
                </div>
            </div>

            <div class="row g-3 mb-3">
                <div class="col-6 col-lg-3"><div class="cat-stat"><span class="ico" style="background:rgba(11,122,117,.14);color:#0b7a75"><i class="fa fa-sitemap"></i></span>
                    <div><div class="val"><?php echo $nbdep; ?></div><div class="lab">Départements</div></div></div></div>
                <div class="col-6 col-lg-3"><div class="cat-stat"><span class="ico" style="background:rgba(59,76,202,.14);color:#3b4cca"><i class="fa fa-book"></i></span>
                    <div><div class="val"><?php echo $totMat; ?></div><div class="lab">Matières rattachées</div></div></div></div>
                <div class="col-6 col-lg-3"><div class="cat-stat"><span class="ico" style="background:rgba(7,100,168,.14);color:#0764a8"><i class="fa fa-layer-group"></i></span>
                    <div><div class="val"><?php echo count($secCount); ?></div><div class="lab">Sections</div></div></div></div>
                <div class="col-6 col-lg-3"><div class="cat-stat"><span class="ico" style="background:rgba(255,193,7,.2);color:#b58100"><i class="fa fa-folder-open"></i></span>
                    <div><div class="val"><?php echo $vides; ?></div><div class="lab">Sans matière</div></div></div></div>
            </div>

            <div class="cat-card">
                <div class="cat-toolbar">
                    <div class="search"><i class="fa fa-search"></i>
                        <input type="search" id="q" class="form-control form-control-sm" placeholder="Rechercher un département ou un libellé…"></div>
                    <div class="cat-chips" id="chips">
                        <button type="button" class="cat-chip active" data-sec="">Toutes</button>
                        <?php foreach ($secCount as $s => $n): ?>
                            <button type="button" class="cat-chip" data-sec="<?php echo htmlspecialchars($s); ?>"><?php echo htmlspecialchars($s); ?> · <?php echo $n; ?></button>
                        <?php endforeach; ?>
                    </div>
                    <span class="cat-count" id="count"></span>
                </div>

                <div class="cat-scroll">
                    <table class="cat-table" id="tbl">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th class="sortable" data-k="nom">Nom <span class="arr">▲</span></th>
                                <th class="sortable" data-k="abr">Libellé <span class="arr">▲</span></th>
                                <th class="sortable" data-k="sec">Section <span class="arr">▲</span></th>
                                <th class="sortable m-hide" data-k="nb">Matières <span class="arr">▲</span></th>
                                <th class="m-hide">Enseignants</th>
                                <th class="text-end">Actions</th>
                            </tr>
                        </thead>
                        <tbody id="tab-data">
                        <?php $i = 0; foreach ($departements as $d): $i++; ?>
                            <tr data-sec="<?php echo htmlspecialchars($d['ref_session']); ?>" data-nom="<?php echo fv(mb_strtolower($d['nom_dep'], 'UTF-8')); ?>"
                                data-abr="<?php echo fv(mb_strtolower($d['abr_dep'], 'UTF-8')); ?>" data-nb="<?php echo (int)$d['nb_mat']; ?>">
                                <td class="idx"><?php echo $i; ?></td>
                                <td class="nom"><?php echo $d['nom_dep']; ?></td>
                                <td><span class="code"><?php echo $d['abr_dep'] !== '' ? $d['abr_dep'] : '—'; ?></span></td>
                                <td><span class="sec-badge sec-<?php echo htmlspecialchars($d['ref_session']); ?>"><?php echo htmlspecialchars($d['ref_session']); ?></span></td>
                                <td class="m-hide"><?php echo (int)$d['nb_mat'] > 0 ? '<span class="pill ok"><i class="fa fa-book"></i>' . (int)$d['nb_mat'] . '</span>' : '<span class="pill warn">Aucune</span>'; ?></td>
                                <td class="m-hide"><span class="pill"><i class="fa fa-chalkboard-user"></i><?php echo (int)$d['nb_ens']; ?></span></td>
                                <td class="actions">
                                    <button type="button" class="btn-ico edit" title="Modifier" data-bs-toggle="modal" data-bs-target="#editDep"
                                        data-id="<?php echo (int)$d['id']; ?>" data-nom="<?php echo fv($d['nom_dep']); ?>" data-abr="<?php echo fv($d['abr_dep']); ?>" data-sess="<?php echo htmlspecialchars($d['ref_session']); ?>"><i class="fa fa-pen"></i></button>
                                    <button type="button" class="btn-ico del" title="Supprimer" data-bs-toggle="modal" data-bs-target="#delDep"
                                        data-id="<?php echo (int)$d['id']; ?>" data-nom="<?php echo fv($d['nom_dep']); ?>" data-nb="<?php echo (int)$d['nb_mat']; ?>"><i class="fa fa-trash"></i></button>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                        </tbody>
                    </table>
                    <div class="cat-empty" id="empty"><i class="fa fa-magnifying-glass fa-2x mb-2 d-block"></i>Aucun département ne correspond à votre recherche.</div>
                </div>
            </div>

            <?php Footers::TDfoot(); ?>
        </div>
    </div>

    <!-- ===== MODAL : AJOUTER ===== -->
    <div class="modal fade cat-modal theme-dep" id="addDep" tabindex="-1" aria-labelledby="addDepLabel" aria-hidden="true">
      <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
          <div class="modal-header"><h5 class="modal-title" id="addDepLabel"><i class="fa fa-plus-circle me-2"></i>Ajouter un département</h5>
            <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Fermer"></button></div>
          <form action="Controler/departs/adddep.php" method="post">
            <div class="modal-body">
              <div class="mb-3"><label class="form-label" for="add_sess">Section</label>
                <select id="add_sess" class="form-select" name="session" required>
                  <?php foreach ($sessions as $s): ?><option value="<?php echo htmlspecialchars($s['abr_sess']); ?>"><?php echo htmlspecialchars($s['abr_sess']) . ' — ' . $s['nom_sess']; ?></option><?php endforeach; ?>
                </select></div>
              <div class="row g-3">
                <div class="col-8"><label class="form-label" for="add_nom">Nom</label><input type="text" class="form-control" id="add_nom" name="nom_dep" maxlength="50" required></div>
                <div class="col-4"><label class="form-label" for="add_abr">Libellé</label><input type="text" class="form-control" id="add_abr" name="abr_dep" maxlength="25"></div>
              </div>
            </div>
            <div class="modal-footer"><button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Annuler</button>
              <button type="submit" class="btn btn-primary px-4 fw-bold"><i class="fa fa-save me-2"></i>Enregistrer</button></div>
          </form>
        </div>
      </div>
    </div>

    <!-- ===== MODAL : MODIFIER (une seule, pré-remplie) ===== -->
    <div class="modal fade cat-modal theme-dep" id="editDep" tabindex="-1" aria-labelledby="editDepLabel" aria-hidden="true">
      <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
          <div class="modal-header"><h5 class="modal-title" id="editDepLabel"><i class="fa fa-pen me-2"></i>Modifier le département</h5>
            <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Fermer"></button></div>
          <form action="Controler/departs/updDep.php" method="post">
            <input type="hidden" name="iddep" id="edit_id">
            <div class="modal-body">
              <div class="mb-3"><label class="form-label" for="edit_sess">Section</label>
                <select id="edit_sess" class="form-select" name="session">
                  <?php foreach ($sessions as $s): ?><option value="<?php echo htmlspecialchars($s['abr_sess']); ?>"><?php echo htmlspecialchars($s['abr_sess']) . ' — ' . $s['nom_sess']; ?></option><?php endforeach; ?>
                </select></div>
              <div class="row g-3">
                <div class="col-8"><label class="form-label" for="edit_nom">Nom</label><input type="text" class="form-control" id="edit_nom" name="nom_dep" maxlength="50" required></div>
                <div class="col-4"><label class="form-label" for="edit_abr">Libellé</label><input type="text" class="form-control" id="edit_abr" name="abr_dep" maxlength="25"></div>
              </div>
            </div>
            <div class="modal-footer"><button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Annuler</button>
              <button type="submit" class="btn btn-primary px-4 fw-bold"><i class="fa fa-save me-2"></i>Enregistrer</button></div>
          </form>
        </div>
      </div>
    </div>

    <!-- ===== MODAL : SUPPRIMER (une seule) ===== -->
    <div class="modal fade cat-modal" id="delDep" tabindex="-1" aria-labelledby="delDepLabel" aria-hidden="true">
      <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
          <div class="modal-header danger"><h5 class="modal-title" id="delDepLabel"><i class="fa fa-trash me-2"></i>Supprimer le département</h5>
            <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Fermer"></button></div>
          <div class="modal-body">
            <p class="mb-2">Département : <b class="text-danger" id="del_nom"></b></p>
            <div class="alert alert-danger small mb-0" id="del_block" style="display:none"></div>
            <p class="mb-0 small text-muted" id="del_info">Action irréversible.</p>
          </div>
          <div class="modal-footer"><button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Annuler</button>
            <a href="#" id="del_link" class="btn btn-danger px-4 fw-bold"><i class="fa fa-trash me-2"></i>Supprimer définitivement</a></div>
        </div>
      </div>
    </div>

    <?php Config::scriptJs(); ?>
    <script type="text/javascript">
    (function () {
        function $(id) { return document.getElementById(id); }
        var rows = Array.prototype.slice.call(document.querySelectorAll('#tab-data tr'));
        var state = { q: '', sec: '', sort: 'nom', dir: 1 };

        function apply() {
            var shown = 0, i = 0;
            rows.forEach(function (tr) {
                var hay = tr.getAttribute('data-nom') + ' ' + tr.getAttribute('data-abr');
                var ok = (state.q === '' || hay.indexOf(state.q) !== -1) && (state.sec === '' || tr.getAttribute('data-sec') === state.sec);
                tr.style.display = ok ? '' : 'none';
                if (ok) { shown++; tr.querySelector('.idx').textContent = ++i; }
            });
            $('count').textContent = shown + ' / ' + rows.length + ' département(s)';
            $('empty').classList.toggle('show', shown === 0);
        }
        function sortRows() {
            var tb = $('tab-data'), k = state.sort, d = state.dir;
            rows.sort(function (a, b) {
                var x = a.getAttribute('data-' + k), y = b.getAttribute('data-' + k);
                if (k === 'nb') { return (parseInt(x, 10) - parseInt(y, 10)) * d; }
                return x.localeCompare(y, 'fr') * d;
            }).forEach(function (tr) { tb.appendChild(tr); });
            document.querySelectorAll('#tbl thead th.sortable').forEach(function (th) {
                var on = th.getAttribute('data-k') === k; th.classList.toggle('sorted', on);
                th.querySelector('.arr').textContent = on && d === -1 ? '▼' : '▲';
            });
            apply();
        }
        $('q').addEventListener('input', function () { state.q = this.value.trim().toLowerCase(); apply(); });
        $('chips').addEventListener('click', function (e) {
            var b = e.target.closest('.cat-chip'); if (!b) { return; }
            document.querySelectorAll('#chips .cat-chip').forEach(function (c) { c.classList.remove('active'); });
            b.classList.add('active'); state.sec = b.getAttribute('data-sec'); apply();
        });
        document.querySelectorAll('#tbl thead th.sortable').forEach(function (th) {
            th.addEventListener('click', function () {
                var k = th.getAttribute('data-k');
                if (state.sort === k) { state.dir = -state.dir; } else { state.sort = k; state.dir = 1; }
                sortRows();
            });
        });

        $('editDep').addEventListener('show.bs.modal', function (e) {
            var b = e.relatedTarget; if (!b) { return; }
            $('edit_id').value = b.getAttribute('data-id'); $('edit_nom').value = b.getAttribute('data-nom');
            $('edit_abr').value = b.getAttribute('data-abr'); $('edit_sess').value = b.getAttribute('data-sess');
        });
        // Suppression : bloquée tant que le département contient des matières (évite des matières orphelines)
        $('delDep').addEventListener('show.bs.modal', function (e) {
            var b = e.relatedTarget; if (!b) { return; }
            var nb = parseInt(b.getAttribute('data-nb'), 10) || 0, link = $('del_link'), blk = $('del_block');
            $('del_nom').textContent = b.getAttribute('data-nom');
            if (nb > 0) {
                blk.style.display = ''; blk.innerHTML = '<i class="fa fa-ban me-1"></i>Ce département contient <b>' + nb + ' matière(s)</b>. Déplacez-les vers un autre département (ou supprimez-les) avant de le supprimer.';
                link.classList.add('disabled'); link.setAttribute('aria-disabled', 'true'); link.setAttribute('href', '#'); $('del_info').style.display = 'none';
            } else {
                blk.style.display = 'none'; $('del_info').style.display = '';
                link.classList.remove('disabled'); link.removeAttribute('aria-disabled');
                link.setAttribute('href', 'Controler/departs/delDep.php?id=' + encodeURIComponent(b.getAttribute('data-id')));
            }
        });

        sortRows();
    })();
    </script>
</body>
</html>
