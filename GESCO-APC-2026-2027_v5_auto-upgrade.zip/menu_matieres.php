<?php
    session_start();   
	require_once 'core/require.php'; 
	require_once 'Model/connexion.php';
     if (!isset($_SESSION['user'])) {
    session_unset();
    session_destroy();
    header('location: index.php');    
    }
    if (($_SESSION['user_role']!="admin") and ($_SESSION['user_role']!="cs") and ($_SESSION['user_role']!="pcpl")) {
       header('location: poste_de_saisie.php?trim=t1');    
    }
    $etb->ShowEtb();
    $etb->CkLE();
    $etb->ckexneE();
    $nbmat=$mat->NombreMat();
?>

<!DOCTYPE html>
<html>
  <head>
   <?php Config::head(); ?>
    <title>GESCOAPC| MATIERES</title>
  </head>

<body>
    <div class="wrapper">
      <!-- Sidebar -->

      <!-- Inclusion du menu de navigation externe réutilisable -->
      <?php include 'core/sidebar.php'; ?>  
       
<div class="main-content-wrapper">
        <!-- Barre supérieure de navigation adaptative -->
        <div class="mobile-navbar-fixed p-3 mb-4 rounded shadow-sm border">
            <div class="row align-items-center g-2">
                <div class="col-auto d-md-none">
                    <button class="btn btn-outline-dark btn-sm" id="toggleMobileMenu"><i class="fa fa-bars fa-lg"></i></button>
                </div>
                <div class="col-12 col-md">
                    <h4 class="m-0 fw-bold text-primary text-uppercase">Toutes les matières (<?php echo $nbmat; ?>)</h4>
                </div>
                <div class="col-12 col-md-auto d-flex justify-content-md-end">
                    <button type="button" class="btn btn-primary btn-sm me-2" data-bs-toggle="modal" data-bs-target="#addclasse" data-whatever="@mdo">Ajouter</button>
                    <input class="form-control form-control-sm" id="search" type="text" placeholder="&#xF002; Recherche ou Tri" style="font-family: Arial, FontAwesome">
                </div>
            </div>
        </div>
                <div class="row mt-5">
                    <div class="col-md-12 col-lg-12 col-sm-12 mt-5">
                        <div class="white-box">
                            
                            <div class="table-responsive table-sm">
                                <table class="table">
                                    <thead>
                                        <tr>
                                            <th>#</th>
                                            <th>NOM</th>
                                            <th>LIBELE</th>
                                            <th>REF DEP</th>
                                            <th>EDIT</th>
                                            <th>DEL</th>
                                        </tr>
                                    </thead>
                                    <tbody class="table-hover" id="tab-data">
                                       <!--  <tr>
                                            <td>1</td>
                                            <td class="txt-oflo">Elite admin</td>
                                            <td>SALE</td>
                                            <td class="txt-oflo">
                                                <a href="" class="waves-effect"><i class="fa fa-user fa-edit" aria-hidden="true"></i></a></td>
                                            <td><span class="text-success">$24</span></td>
                                        </tr> -->
                                        <?php  $mat-> ShowAllMat(); ?>
                                        
                            
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- ============================================================== -->
                <!-- Gestion des Classes -->

                 <div class="row">
       

                      <div class="modal fade" id="addclasse" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                      <div class="modal-dialog modal-lg" role="document">
                        <div class="modal-content">
                          <div class="modal-header">
                            <h4 class="modal-title" id="exampleModalLabel">Ajouter une Matière</h4>
                            <button type="button" class="close" data-bs-dismiss="modal" aria-label="Close">
                              <span aria-hidden="true">&times;</span>
                            </button>
                          </div>
                          <div class="modal-body">
                            <div class="container-fluid">
                                <div class="row">
                                    <div class="col-md-12">
                                        <form action="Controler/matieres/addMat.php" method="post" >                           
                                          <label for="inputState">Choisir un département:</label>
                                             <select id="inputState" class="form-control" name="ref_dep" required>
                                              <option value="">Choisir...</option>
                                               <?php  $dep->SelectDep(); ?>                           
                                            </select>
                                    </div>
                                </div>
                                <div class="row mb-3"> 
                                    <div class="col-md-8">
                                        <label for="inputEmail4">Nom:</label>
                                        <input type="text" class="form-control" id="nom_mat" name="nom_mat"  maxlength="25"   required>
                                    </div>                           
                                    <div class="col-md-4 ">
                                          <label for="inputEmail4">Libele:</label>
                                          <input type="text" class="form-control" id="abr_mat" name="abr_mat"  maxlength="15" >
                                    </div>
                                </div>
                                <div class="modal-footer"> 
                                    <button type="submit" class="btn btn-primary">Enrégistrer</button>
                                    <button type="button" class="btn btn-danger" data-bs-dismiss="modal">Annuler</button>
                                  </form>
                                  </div>
                              </div>
                           
                          </div>
                        </div>
                      </div>
                </div>
        </div>
                
            </div>
           
        <?php 
            Footers::TDfoot();
        ?>
        </div>
        <!-- ============================================================== -->
        <!-- End Page Content -->
        <!-- ============================================================== -->
    </div>


		<?php 
		 	Config::scriptJs();
		?>
        <script type="text/javascript">
            $('#exampleModal').on('show.bs.modal', function (event) {
  var button = $(event.relatedTarget) // Button that triggered the modal
  var recipient = button.data('whatever') // Extract info from data-* attributes
  // If necessary, you could initiate an AJAX request here (and then do the updating in a callback).
  // Update the modal's content. We'll use jQuery here, but you could use a data binding library or other methods instead.
  var modal = $(this)
  modal.find('.modal-title').text('New message to ' + recipient)
  modal.find('.modal-body input').val(recipient)
})
        </script>

         <script>

$(document).ready(function(){
  $("#search").on("keyup", function() {
    var value = $(this).val().toLowerCase();
    $("#tab-data tr").filter(function() {
      $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
    });
  });
});
</script>
	</body>
</html>
