<?php
    session_start();
    require_once 'core/require.php';
    require_once 'Model/connexion.php';
    if (!isset($_SESSION['user'])) {
        session_unset();
        session_destroy();
        header('location: index.php');
        exit();
    }
    if (($_SESSION['user_role'] != "admin") and ($_SESSION['user_role'] != "cs") and ($_SESSION['user_role'] != "pcpl")) {
        header('location: poste_de_saisie.php?trim=t1');
        exit();
    }
    $etb->ShowEtb();
    $etb->CkLE();
    $etb->ckexneE();

    // ---------- Données ----------
    $bdd = $GLOBALS['bdd'];
    // Valeur « brute » pour un champ de formulaire (la base stocke du texte déjà échappé) : évite le double échappement à l'enregistrement
    if (!function_exists("fv")) { function fv($s) { return htmlspecialchars(html_entity_decode(str_ireplace('&AMP;', '&', (string)$s), ENT_QUOTES, 'UTF-8'), ENT_QUOTES, 'UTF-8'); } }

    $usage = array();   // nombre de classes qui utilisent chaque matière
    foreach ($bdd->query('SELECT ref_mat, COUNT(*) AS n FROM config_bull GROUP BY ref_mat')->fetchAll(PDO::FETCH_ASSOC) as $u) { $usage[(string)$u['ref_mat']] = (int)$u['n']; }

    $matieres = $bdd->query('SELECT m.id, m.abr_mat, m.nom_mat, m.ref_depart, d.nom_dep, d.abr_dep, d.ref_session
                             FROM matieres m LEFT JOIN departements d ON d.id = m.ref_depart WHERE m.id >= 1 ORDER BY m.nom_mat ASC')->fetchAll(PDO::FETCH_ASSOC);
    $departements = $bdd->query('SELECT id, nom_dep, ref_session FROM departements WHERE id >= 1 ORDER BY ref_session ASC, nom_dep ASC')->fetchAll(PDO::FETCH_ASSOC);

    $nbmat = count($matieres);
    $secCount = array(); $depUsed = array(); $nbInutilisees = 0;
    foreach ($matieres as $m) {
        $s = $m['ref_session'] ? $m['ref_session'] : '—';
        $secCount[$s] = isset($secCount[$s]) ? $secCount[$s] + 1 : 1;
        $depUsed[(string)$m['ref_depart']] = true;
        if (empty($usage[(string)$m['id']])) { $nbInutilisees++; }
    }
    ksort($secCount);
?>
<!DOCTYPE html>
<html lang="fr">
  <head>
    <?php Config::head(); ?>
    <link rel="stylesheet" href="css/catalogue.css">
    <title>GESCOAPC | Matières</title>
  </head>

<body>
    <?php include 'core/sidebar.php'; ?>

    <div class="main-content-wrapper cat-page theme-mat">
        <!-- Barre supérieure -->
        <div class="mobile-navbar-fixed p-3 mb-4 rounded shadow-sm border">
            <div class="row align-items-center g-2">
                <div class="col-auto d-md-none">
                    <button class="btn btn-outline-dark btn-sm" id="toggleMobileMenu" type="button"><i class="fa fa-bars fa-lg"></i></button>
                </div>
                <div class="col">
                    <h4 class="m-0 fw-bold text-primary text-uppercase"><i class="fa fa-book-open me-2"></i>Matières
                        <span class="badge bg-danger ms-2 font-monospace"><?php echo $nbmat; ?></span></h4>
                </div>
            </div>
        </div>

        <div class="container-fluid p-0">

            <!-- Bandeau -->
            <div class="cat-hero">
                <div class="hero-icon"><i class="fa fa-book-open"></i></div>
                <div>
                    <h1>Catalogue des matières</h1>
                    <p>Créez, modifiez et classez les matières par département et par section.</p>
                </div>
                <div class="hero-actions">
                    <button type="button" class="btn btn-hero" data-bs-toggle="modal" data-bs-target="#addMat"><i class="fa fa-plus-circle me-2"></i>Ajouter une matière</button>
                </div>
            </div>

            <!-- Statistiques -->
            <div class="row g-3 mb-3">
                <div class="col-6 col-lg-3"><div class="cat-stat"><span class="ico" style="background:rgba(59,76,202,.14);color:#3b4cca"><i class="fa fa-book"></i></span>
                    <div><div class="val"><?php echo $nbmat; ?></div><div class="lab">Matières</div></div></div></div>
                <div class="col-6 col-lg-3"><div class="cat-stat"><span class="ico" style="background:rgba(11,122,117,.14);color:#0b7a75"><i class="fa fa-sitemap"></i></span>
                    <div><div class="val"><?php echo count($depUsed); ?></div><div class="lab">Départements utilisés</div></div></div></div>
                <div class="col-6 col-lg-3"><div class="cat-stat"><span class="ico" style="background:rgba(25,135,84,.15);color:#198754"><i class="fa fa-school"></i></span>
                    <div><div class="val"><?php echo $nbmat - $nbInutilisees; ?></div><div class="lab">Utilisées en classe</div></div></div></div>
                <div class="col-6 col-lg-3"><div class="cat-stat"><span class="ico" style="background:rgba(255,193,7,.2);color:#b58100"><i class="fa fa-circle-pause"></i></span>
                    <div><div class="val"><?php echo $nbInutilisees; ?></div><div class="lab">Sans classe</div></div></div></div>
            </div>

            <!-- Tableau -->
            <div class="cat-card">
                <div class="cat-toolbar">
                    <div class="search"><i class="fa fa-search"></i>
                        <input type="search" id="q" class="form-control form-control-sm" placeholder="Rechercher une matière, un libellé, un département…"></div>
                    <select id="fDep" class="form-select form-select-sm" aria-label="Filtrer par département">
                        <option value="">Tous les départements</option>
                        <?php foreach ($departements as $d): ?>
                            <option value="<?php echo (int)$d['id']; ?>"><?php echo $d['nom_dep'] . ' (' . $d['ref_session'] . ')'; ?></option>
                        <?php endforeach; ?>
                    </select>
                    <div class="cat-chips" id="chips">
                        <button type="button" class="cat-chip active" data-sec="">Toutes</button>
                        <?php foreach ($secCount as $s => $n): ?>
                            <button type="button" class="cat-chip" data-sec="<?php echo htmlspecialchars($s); ?>"><?php echo htmlspecialchars($s); ?> · <?php echo $n; ?></button>
                        <?php endforeach; ?>
                    </div>
                    <span class="cat-count" id="count"></span>
                </div>

                <div class="cat-scroll">
                    <table class="cat-table" id="tbl">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th class="sortable" data-k="nom">Nom <span class="arr">▲</span></th>
                                <th class="sortable" data-k="abr">Libellé <span class="arr">▲</span></th>
                                <th class="sortable" data-k="dep">Département <span class="arr">▲</span></th>
                                <th class="sortable m-hide" data-k="nb">Classes <span class="arr">▲</span></th>
                                <th class="text-end">Actions</th>
                            </tr>
                        </thead>
                        <tbody id="tab-data">
                        <?php $i = 0; foreach ($matieres as $m): $i++;
                            $nb = isset($usage[(string)$m['id']]) ? $usage[(string)$m['id']] : 0;
                            $sec = $m['ref_session'] ? $m['ref_session'] : ''; ?>
                            <tr data-dep="<?php echo (int)$m['ref_depart']; ?>" data-sec="<?php echo htmlspecialchars($sec); ?>"
                                data-nom="<?php echo fv(mb_strtolower($m['nom_mat'], 'UTF-8')); ?>" data-abr="<?php echo fv(mb_strtolower($m['abr_mat'], 'UTF-8')); ?>"
                                data-depn="<?php echo fv(mb_strtolower((string)$m['nom_dep'], 'UTF-8')); ?>" data-nb="<?php echo $nb; ?>">
                                <td class="idx"><?php echo $i; ?></td>
                                <td class="nom"><?php echo $m['nom_mat']; ?></td>
                                <td><span class="code"><?php echo $m['abr_mat'] !== '' ? $m['abr_mat'] : '—'; ?></span></td>
                                <td><?php echo $m['nom_dep'] ? $m['nom_dep'] : '<span class="pill warn"><i class="fa fa-triangle-exclamation"></i>Sans département</span>'; ?>
                                    <?php if ($sec): ?><span class="sec-badge sec-<?php echo htmlspecialchars($sec); ?> ms-1"><?php echo htmlspecialchars($sec); ?></span><?php endif; ?></td>
                                <td class="m-hide"><?php echo $nb > 0 ? '<span class="pill ok"><i class="fa fa-school"></i>' . $nb . ' classe(s)</span>' : '<span class="pill">Aucune</span>'; ?></td>
                                <td class="actions">
                                    <button type="button" class="btn-ico edit" title="Modifier" data-bs-toggle="modal" data-bs-target="#editMat"
                                        data-id="<?php echo (int)$m['id']; ?>" data-nom="<?php echo fv($m['nom_mat']); ?>" data-abr="<?php echo fv($m['abr_mat']); ?>" data-dep="<?php echo (int)$m['ref_depart']; ?>"><i class="fa fa-pen"></i></button>
                                    <button type="button" class="btn-ico del" title="Supprimer" data-bs-toggle="modal" data-bs-target="#delMat"
                                        data-id="<?php echo (int)$m['id']; ?>" data-nom="<?php echo fv($m['nom_mat']); ?>" data-nb="<?php echo $nb; ?>"><i class="fa fa-trash"></i></button>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                        </tbody>
                    </table>
                    <div class="cat-empty" id="empty"><i class="fa fa-magnifying-glass fa-2x mb-2 d-block"></i>Aucune matière ne correspond à votre recherche.</div>
                </div>
            </div>

            <?php Footers::TDfoot(); ?>
        </div>
    </div>

    <!-- ===== MODAL : AJOUTER ===== -->
    <div class="modal fade cat-modal theme-mat" id="addMat" tabindex="-1" aria-labelledby="addMatLabel" aria-hidden="true">
      <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
          <div class="modal-header"><h5 class="modal-title" id="addMatLabel"><i class="fa fa-plus-circle me-2"></i>Ajouter une matière</h5>
            <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Fermer"></button></div>
          <form action="Controler/matieres/addMat.php" method="post">
            <div class="modal-body">
              <div class="mb-3"><label class="form-label" for="add_dep">Département</label>
                <select id="add_dep" class="form-select" name="ref_dep" required>
                  <option value="">Choisir...</option>
                  <?php foreach ($departements as $d): ?><option value="<?php echo (int)$d['id']; ?>"><?php echo $d['nom_dep'] . ' — ' . $d['ref_session']; ?></option><?php endforeach; ?>
                </select></div>
              <div class="row g-3">
                <div class="col-8"><label class="form-label" for="add_nom">Nom</label><input type="text" class="form-control" id="add_nom" name="nom_mat" maxlength="50" required></div>
                <div class="col-4"><label class="form-label" for="add_abr">Libellé</label><input type="text" class="form-control" id="add_abr" name="abr_mat" maxlength="25" placeholder="ex. ENG"></div>
              </div>
            </div>
            <div class="modal-footer"><button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Annuler</button>
              <button type="submit" class="btn btn-primary px-4 fw-bold"><i class="fa fa-save me-2"></i>Enregistrer</button></div>
          </form>
        </div>
      </div>
    </div>

    <!-- ===== MODAL : MODIFIER (une seule, pré-remplie) ===== -->
    <div class="modal fade cat-modal theme-mat" id="editMat" tabindex="-1" aria-labelledby="editMatLabel" aria-hidden="true">
      <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
          <div class="modal-header"><h5 class="modal-title" id="editMatLabel"><i class="fa fa-pen me-2"></i>Modifier la matière</h5>
            <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Fermer"></button></div>
          <form action="Controler/matieres/updMat.php" method="post">
            <input type="hidden" name="ref_mat" id="edit_id">
            <div class="modal-body">
              <div class="mb-3"><label class="form-label" for="edit_dep">Département</label>
                <select id="edit_dep" class="form-select" name="ref_dep">
                  <option value="">Conserver le département actuel</option>
                  <?php foreach ($departements as $d): ?><option value="<?php echo (int)$d['id']; ?>"><?php echo $d['nom_dep'] . ' — ' . $d['ref_session']; ?></option><?php endforeach; ?>
                </select></div>
              <div class="row g-3">
                <div class="col-8"><label class="form-label" for="edit_nom">Nom</label><input type="text" class="form-control" id="edit_nom" name="nom_mat" maxlength="50" required></div>
                <div class="col-4"><label class="form-label" for="edit_abr">Libellé</label><input type="text" class="form-control" id="edit_abr" name="abr_mat" maxlength="25"></div>
              </div>
            </div>
            <div class="modal-footer"><button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Annuler</button>
              <button type="submit" class="btn btn-primary px-4 fw-bold"><i class="fa fa-save me-2"></i>Enregistrer</button></div>
          </form>
        </div>
      </div>
    </div>

    <!-- ===== MODAL : SUPPRIMER (une seule) ===== -->
    <div class="modal fade cat-modal" id="delMat" tabindex="-1" aria-labelledby="delMatLabel" aria-hidden="true">
      <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
          <div class="modal-header danger"><h5 class="modal-title" id="delMatLabel"><i class="fa fa-trash me-2"></i>Supprimer la matière</h5>
            <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Fermer"></button></div>
          <div class="modal-body">
            <p class="mb-2">Matière : <b class="text-danger" id="del_nom"></b></p>
            <div class="alert alert-warning small mb-2" id="del_warn" style="display:none"></div>
            <p class="mb-0 small text-muted">La configuration des bulletins et les compétences liées à cette matière seront supprimées pour toutes les classes. <b>Action irréversible.</b></p>
          </div>
          <div class="modal-footer"><button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Annuler</button>
            <a href="#" id="del_link" class="btn btn-danger px-4 fw-bold"><i class="fa fa-trash me-2"></i>Supprimer définitivement</a></div>
        </div>
      </div>
    </div>

    <?php Config::scriptJs(); ?>
    <script type="text/javascript">
    (function () {
        function $(id) { return document.getElementById(id); }
        var rows = Array.prototype.slice.call(document.querySelectorAll('#tab-data tr'));
        var state = { q: '', dep: '', sec: '', sort: 'nom', dir: 1 };

        function apply() {
            var shown = 0, i = 0;
            rows.forEach(function (tr) {
                var hay = tr.getAttribute('data-nom') + ' ' + tr.getAttribute('data-abr') + ' ' + tr.getAttribute('data-depn');
                var ok = (state.q === '' || hay.indexOf(state.q) !== -1) && (state.dep === '' || tr.getAttribute('data-dep') === state.dep) && (state.sec === '' || tr.getAttribute('data-sec') === state.sec);
                tr.style.display = ok ? '' : 'none';
                if (ok) { shown++; tr.querySelector('.idx').textContent = ++i; }
            });
            $('count').textContent = shown + ' / ' + rows.length + ' matière(s)';
            $('empty').classList.toggle('show', shown === 0);
        }
        function sortRows() {
            var tb = $('tab-data'), k = state.sort, d = state.dir;
            rows.sort(function (a, b) {
                var x = a.getAttribute('data-' + (k === 'dep' ? 'depn' : k)), y = b.getAttribute('data-' + (k === 'dep' ? 'depn' : k));
                if (k === 'nb') { return (parseInt(x, 10) - parseInt(y, 10)) * d; }
                return x.localeCompare(y, 'fr') * d;
            }).forEach(function (tr) { tb.appendChild(tr); });
            document.querySelectorAll('#tbl thead th.sortable').forEach(function (th) {
                var on = th.getAttribute('data-k') === k; th.classList.toggle('sorted', on);
                th.querySelector('.arr').textContent = on && d === -1 ? '▼' : '▲';
            });
            apply();
        }
        $('q').addEventListener('input', function () { state.q = this.value.trim().toLowerCase(); apply(); });
        $('fDep').addEventListener('change', function () { state.dep = this.value; apply(); });
        $('chips').addEventListener('click', function (e) {
            var b = e.target.closest('.cat-chip'); if (!b) { return; }
            document.querySelectorAll('#chips .cat-chip').forEach(function (c) { c.classList.remove('active'); });
            b.classList.add('active'); state.sec = b.getAttribute('data-sec'); apply();
        });
        document.querySelectorAll('#tbl thead th.sortable').forEach(function (th) {
            th.addEventListener('click', function () {
                var k = th.getAttribute('data-k');
                if (state.sort === k) { state.dir = -state.dir; } else { state.sort = k; state.dir = 1; }
                sortRows();
            });
        });

        // Modal « Modifier » pré-remplie
        $('editMat').addEventListener('show.bs.modal', function (e) {
            var b = e.relatedTarget; if (!b) { return; }
            $('edit_id').value = b.getAttribute('data-id'); $('edit_nom').value = b.getAttribute('data-nom');
            $('edit_abr').value = b.getAttribute('data-abr'); $('edit_dep').value = b.getAttribute('data-dep');
        });
        // Modal « Supprimer »
        $('delMat').addEventListener('show.bs.modal', function (e) {
            var b = e.relatedTarget; if (!b) { return; }
            var nb = parseInt(b.getAttribute('data-nb'), 10) || 0;
            $('del_nom').textContent = b.getAttribute('data-nom');
            $('del_link').setAttribute('href', 'Controler/matieres/delMat.php?id=' + encodeURIComponent(b.getAttribute('data-id')));
            var w = $('del_warn');
            if (nb > 0) { w.style.display = ''; w.innerHTML = '<i class="fa fa-triangle-exclamation me-1"></i>Cette matière est utilisée dans <b>' + nb + ' classe(s)</b>.'; } else { w.style.display = 'none'; }
        });

        sortRows();
    })();
    </script>
</body>
</html>
