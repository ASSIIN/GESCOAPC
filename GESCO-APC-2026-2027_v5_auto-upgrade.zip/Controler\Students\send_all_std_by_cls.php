<?php
	session_start();
	require_once '../../Model/connexion.php';
	require_once '../../core/require.php'; 

	// Sécurité : connexion obligatoire + rôles autorisés (page de promotion d'élèves)
	if (!isset($_SESSION['user']) || !in_array($_SESSION['user_role'] ?? '', array('admin', 'pcpl', 'cs', 'sg'))) {
		header('location: ../../index.php');
		exit;
	}

	$cls_form=trim((string)($_POST['cls_from'] ?? ''));
	$cls_to=trim((string)($_POST['cls_to'] ?? ''));
	if ($cls_form==='' || $cls_to==='') {
		header('location: ../../home.php?p=0');
		exit;
	}

	$bdd = $GLOBALS['bdd'];	
	$n=0;

	// ============================================================
	// CORRECTION : les anciennes requêtes visaient des tables
	// inexistantes ("unite_a_...", "table_note_par_..."). La
	// promotion s'appuie ici sur le schéma réel :
	//   - table_note_par_trim1..3 et table_note_par_triman
	//   - table_note_par_mat_eval1..6
	//   - eleves
	// ============================================================

	// 1) Transfert des moyennes trimestrielles et annuelles
	foreach (array('1','2','3','an') as $trim) 
	{
		$req_trim = 'UPDATE table_note_par_trim'.$trim.' SET ref_cls = ? WHERE ref_cls = ?';
		$rep_trim = $bdd->prepare($req_trim);
		if ($rep_trim->execute(array($cls_to, $cls_form))) {
			$n++;
		}
	}

	// 2) Transfert des notes par évaluation
	for ($seq=1; $seq<=6; $seq++) 
	{
		$req_seq = 'UPDATE table_note_par_mat_eval'.$seq.' SET ref_cls = ? WHERE ref_cls = ?';
		$rep_seq = $bdd->prepare($req_seq);
		$rep_seq->execute(array($cls_to, $cls_form));
	}

	// 3) Mise à jour de la classe des élèves
	$req0 = 'UPDATE eleves SET ref_class = ? WHERE ref_class = ?';
	$rep0 = $bdd->prepare($req0);
	$rep0->execute(array($cls_to, $cls_form));

	header('location: ../../home.php?cls='.urlencode($cls_to).'&ok='.(int)$n);
	exit;
?>