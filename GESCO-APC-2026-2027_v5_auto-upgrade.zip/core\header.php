<?php
/** Navigation historique conservée comme façade vers le composant unifié. */
class Head
{
    public static function Menu($role = null): void
    {
        include __DIR__ . '/sidebar.php';
    }

    public static function HeadMobile(): void
    {
        include __DIR__ . '/sidebar.php';
    }

    public static function simpleHead($role = null): void
    {
        include __DIR__ . '/sidebar.php';
    }

}
?>
