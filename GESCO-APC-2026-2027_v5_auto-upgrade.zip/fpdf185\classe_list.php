<?php
session_start();
require_once '../Model/connexion.php';
require_once '../core/require.php';
 if (!isset($_SESSION['user'])) {
    session_unset();
    session_destroy();
    header('location: ../index.php');    
    }
 $etb->ShowEtb();
 if (!isset($_GET['refcls']) and !isset($_GET['option']) and !isset($_GET['niveau']) and !isset($_GET['session'])) {
	header('location: ../impression.php');
 }
 if ($_GET['option']=='notelist') {
 	$_SESSION['notelist_refcls']=$_GET['refcls'];

 	header('location: fiche_r_note.php');
 }else if($_GET['option']=='listsess'){
 	$_SESSION['list_session']=$_GET['session'];
	header('location: list_sess.php');
 }
 else if($_GET['option']=='listnv'){
 	$_SESSION['listnv']=$_GET['niveau'];
	header('location: list_nv.php');
 }
  else if($_GET['option']=='alllist'){
 	$_SESSION['all_list']=$_GET['option'];
	header('location: all_list.php');
 }
else if($_GET['option']=='crt_c'){
  	$_SESSION['crt_c']=$_GET['refcls'];
	// CORRECTION : carte_cls.php inexistant → carte scolaire (card_cls.php)
	header('location: card_cls.php?cls='.urlencode($_GET['refcls']).'&mdl=1');
	exit;
 }

$refcls= htmlspecialchars($_GET['refcls']);
require('fpdf.php');
$pdf = new FPDF();

class PDF extends FPDF
{
// En-tête
function Header()
{
	 $this->SetY(15);
    // Logo
    $this->Image('../plugins/images/'.$_SESSION['logo_etb'].'',10,6,30);
    // Police Arial gras 15
    $this->SetFont('Arial','B',15);
    // Décalage à droite
    $this->Cell(80);
    // Titre
    $this->Cell(30,10,'Titre',1,0,'C');
    // Saut de ligne
    $this->Ln(20);
}

// Pied de page
function Footer()
{
    // Positionnement à 1,5 cm du bas
    $this->SetY(-15);
    // Police Arial italique 8
    $this->SetFont('Arial','I',8);
    // Numéro de page
    $this->Cell(0,10,'Page '.$this->PageNo().'/{nb}',0,0,'C');
}
}


//code for print data

		 $bdd = $GLOBALS['bdd'];
			$reponse = $bdd->query('SELECT * FROM eleves where ref_class="'.$refcls.'" order by nom_std asc');

			$i=1;
			$eff=0;
			$pdf->AddPage();
			$pdf->AliasNBPages();
			/*En-tête*/
				$pdf->SetFont('Times','',8);
				$pdf->Image('../plugins/images/'.$_SESSION['logo_etb'].'',90,15,30);
				$pdf->Cell(70,4,'REPUBLIQUE DU CAMEROUN',0,0,'C');
				$pdf->Cell(50,4,'',0,0);
				$pdf->Cell(70,4,'REPUBLIC OF CAMEROON',0,1,'C');

				$pdf->Cell(70,4,'Paix-Travail-Patrie',0,0,'C');
				$pdf->Cell(50,4,'',0,0);
				$pdf->Cell(70,4,'Peace-Work-Fatherland',0,1,'C');

				$pdf->Cell(70,4, utf8_to_cp1252("".$_SESSION['minist_etb_fr'].""),0,0,'C');
				$pdf->Cell(50,4,'',0,0);
				$pdf->Cell(70,4,utf8_to_cp1252(''.$_SESSION['minist_etb_en'].''),0,1,'C');

				$pdf->Cell(70,4,utf8_to_cp1252("".$_SESSION['region_etb_fr'].""),0,0,'C');
				$pdf->Cell(50,4,'',0,0);
				$pdf->Cell(70,4,utf8_to_cp1252(''.$_SESSION['region_etb_en'].''),0,1,'C');

				$pdf->Cell(70,4,utf8_to_cp1252(''.$_SESSION['depart_etb_fr'].''),0,0,'C');
				$pdf->Cell(50,4,'',0,0);
				$pdf->Cell(70,4,utf8_to_cp1252(''.$_SESSION['depart_etb_en'].''),0,1,'C');
				$pdf->SetFont('Times','B',10);
				$pdf->Cell(70,6,utf8_to_cp1252(''.$_SESSION['nom_etb_fr'].''),0,0,'C');
				$pdf->Cell(50,6,'',0,0);
				$pdf->Cell(70,6,utf8_to_cp1252(''.$_SESSION['nom_etb_en'].''),0,1,'C');
				$pdf->SetFont('Times','',8);
				$pdf->Cell(70,5,utf8_to_cp1252(''.$_SESSION['code_pste_etb'].' / '.$_SESSION['tel_etb'].''),0,0,'C');
				$pdf->Cell(50,5,'',0,0);
				$pdf->Cell(70,5,utf8_to_cp1252(''.$_SESSION['code_pste_etb'].'/ '.$_SESSION['tel_etb'].''),0,1,'C');
				$pdf->SetFont('Times','',8);
				$pdf->Cell(70,4,utf8_to_cp1252(''.$_SESSION['email_etb'].''),0,0,'C');
				$pdf->Cell(50,4,'',0,0);
				$pdf->Cell(70,4,utf8_to_cp1252(''.$_SESSION['email_etb'].''),0,1,'C');
					$pdf->Ln();
					$pdf->SetFont('Times','I',12);
					$pdf->Cell(65,5,'',0,0);
					$pdf->Cell(60,5,utf8_to_cp1252(''.$_SESSION['code_im_etb'].''),0,0,'C');
					$pdf->Ln();
					$pdf->Ln();
			/*FIN En-tête*/
			//Titre 
				$pdf->SetFont('Times','I',10);
				$pdf->Cell(50,5,'',0,0,'C');
				$pdf->Cell(60,5,'ANNEE SCOLAIRE/SCHOOL ',0,0,'R');
				$pdf->SetFont('Times','B',12);
				$pdf->Cell(40,5,''.$_SESSION['school_year'].'',0,0,'L');
				$pdf->Cell(40,5,'',0,1,'C');
				
					$pdf->SetFont('Times','B',12);
					$pdf->SetFillColor(171,177,186);
					$pdf->SetFillColor(217,245,254);
					$pdf->Cell(20,6,'',0,0,'C');
					$pdf->Cell(150,6,'LISTE PAR CLASSE/CLASS LIST',1,0,'C',1);
					$pdf->Cell(20,6,'',0,1,'C');
					$pdf->Ln();


				$class->CkClasseByCode($refcls);
				$nbstd=$class->NbrStudentByClass($refcls);
				$nbM=$class->NbrBySexeByClass($refcls,'M');
				$nbF=$class->NbrBySexeByClass($refcls,'F');
				$nomcls=$_SESSION['nom_class'];
				$niveaucls=$_SESSION['ref_class_niveau'];

				$pdf->Cell(50,4,"Classe: $nomcls",1,0,'L');
				$pdf->Cell(30,4,"Code: $refcls",1,0,'L');
				$pdf->Cell(30,4,"Niveau: $niveaucls",1,0,'C');
				$pdf->Cell(43,4,"Effectif: $nbstd",1,0,'C');
				$pdf->Cell(20,4,"M: $nbM",1,0,'C');
				$pdf->Cell(20,4,"F: $nbF",1,0,'C');
				$pdf->Ln();
			
			$pdf->SetFont('Times','B',9);
				$pdf->Ln();
					$pdf->Cell(10,6,utf8_to_cp1252('N°'),1,0);
					$pdf->Cell(20,6, utf8_to_cp1252('N° INSCRIPT'),1,0);
					$pdf->Cell(22,6,'MATRICULE',1,0);
					$pdf->Cell(61,6,utf8_to_cp1252('Noms_et_Prénoms/Full_Name'),1,0);
					$pdf->Cell(10,6,'Sexe',1,0);
					$pdf->Cell(10,6,'Red',1,0);
					$pdf->Cell(22,6,utf8_to_cp1252('Né(e)le/Born'),1,0);
					$pdf->Cell(38,6,'Lieu_de_nais/Place',1,0);
			 
			while($row = $reponse->fetch(PDO::FETCH_ASSOC)) 
			{
				$Nom=htmlspecialchars($row['nom_std']);
				$Nom=strtoupper($Nom);
				$Nom=substr($Nom, 0,36);
				$date_nais_fr= date('d/m/Y ',strtotime($row['date_nais']));
				/*$row['mat_std'];
				$row['nom_prenom_std']
				$row['sexe_std']
				$row['date_nais']
				$row['lieu_nais']*/
				$pdf->SetFont('Arial','',9);
				$pdf->Ln();
					$pdf->Cell(10,5,$i,1,0);
					$pdf->Cell(20,5,utf8_to_cp1252(''.$_SESSION['pre_matr'].''.$row['mat_std'].''),1,0,'C');
					$pdf->Cell(22,5,utf8_to_cp1252(''.$row['cni_std'].''),1,0,'C');
					$pdf->Cell(61,5,utf8_to_cp1252($Nom),1,0);
					$pdf->Cell(10,5,utf8_to_cp1252($row['sexe_std']),1,0,'C');
					$pdf->Cell(10,5,utf8_to_cp1252($row['statut']),1,0,'C');
					$pdf->Cell(22,5,utf8_to_cp1252($date_nais_fr),1,0,'C');
					$pdf->SetFont('Arial','',8);
					$pdf->Cell(38,5,utf8_to_cp1252($row['lieu_nais']),1,0);
					$pdf->SetFont('Arial','',9);
					$i++;
				}
				 $eff=$i;
				$pdf->SetXY(123,271);
$pdf->Cell(0,3,'Page '.$pdf->PageNo().'/{nb}',0,1,'C');
$pdf->Output('MARKS_SHEET_ '.$nomcls.'.pdf','I');
$pdf->Close();
?>
