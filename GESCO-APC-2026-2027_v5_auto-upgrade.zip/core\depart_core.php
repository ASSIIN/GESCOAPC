<?php 
	/**
	 * 
	 */
	class MyDeparts
	{
		private $nom_dep, $ref_session, $abr_dep;
		
		function __construct()
		{
			# code...
		}

		public function setNom_dep($value)
		{
			$this->nom_dep = $value;
		}
		public function getNom_dep()
		{
			return $this->nom_dep;
		}

		
		public function setRef_session($value)
		{
			$this->ref_session = $value;
		}
		public function getRef_session()
		{
			return $this->ref_session;
		}

		public function setAbr_dep($value)
		{
			$this->abr_dep = $value;
		}
		public function getAbr_dep()
		{
			return $this->abr_dep;
		}

	
		public function AddDep()
		{
			$bdd = $GLOBALS['bdd'];
	

			$req = "INSERT INTO departements (nom_dep, ref_session, abr_dep) VALUES(?, ?, ?)" ;

				$rep = $bdd->prepare($req);
				if ($rep->execute( array($this->nom_dep, $this->ref_session, $this->abr_dep))) {
					return true;
				}
				else{
					return false;
				}
			}

		public function CkClasseByCode($code)
		{
			$bdd = $GLOBALS['bdd'];
			// CORRECTION : requête préparée + colonnes réelles de `classes` (code_class / id)
			$stmt = $bdd->prepare('SELECT id, nom_class, ref_class_niveau, class_session, code_class FROM classes WHERE code_class = ? LIMIT 1');
			$stmt->execute(array($code));
			$row = $stmt->fetch(PDO::FETCH_ASSOC);
			if ($row) {
				$_SESSION['id_cls'] = $row['id'];
				$_SESSION['nom_class'] = $row['nom_class'];
				$_SESSION['ref_class_niveau'] = $row['ref_class_niveau'];
				$_SESSION['class_session'] = $row['class_session'];
				$_SESSION['code_class'] = $row['code_class'];
			}
		}
		
		
		
		public function ShowAllDep()
		{
			$bdd = $GLOBALS['bdd'];
			$i=0;
			$nt=0;
			$reponse = $bdd->query('SELECT * FROM departements where id>=1 order by nom_dep asc');
			while($row = $reponse->fetch(PDO::FETCH_ASSOC)) 
			{
				$i++;

				echo '
				<tr>
				<td id="id">'.$i.'</td>
                <td class="txt-oflo">'.$row['nom_dep'].'</td>
                <td>'.$row['abr_dep'].'</td>
                <td>'.$row['ref_session'].'</td>
                <td>
                 <button type="button" class="btn btn-info btn-sm ml-2" data-bs-toggle="modal" data-bs-target="#mod_edit'.$row['id'].'" data-whatever="@mdo"><i class="fa fa-edit fa-1x" aria-hidden="true"></i></button>
                  
					<div class="modal fade" id="mod_edit'.$row['id'].'" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                      <div class="modal-dialog" role="document">
                        <div class="modal-content">
                          <div class="modal-header">
                            <h5 class="modal-title" id="exampleModalLabel">Modifier le departement</h5>
														<button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Fermer"></button>
                          </div>
                          <div class="modal-body">
                            <div class="container-fluid">
                                <div class="row">
                                    <div class="col-md-12">
                                        <form action="Controler/departs/updDep.php" method="post" >
                                         <input type="text" class="form-control " id="iduser" name="iddep"  value="'.$row['id'].'" hidden="true" >
		                                   
                                          <label for="inputState">Choisir une session: <i style="color:#e63f32">'.$row['ref_session'].'</i></label>
                                             <select id="inputState" class="form-control" name="session" >
                                               ';
                                              $this->SelectSessions();
                                              echo'                           
                                            </select>
                                    </div>
                                </div>
                                <div class="row mb-3"> 
                                    <div class="col-md-8">
                                        <label for="inputEmail4">Nom  : <i style="color:#e63f32">'.$row['nom_dep'].'</i></label>
                                        <input type="text" class="form-control" id="nom_dep" name="nom_dep"  maxlength="50" >
                                    </div>                           
                                    <div class="col-md-4 ">
                                          <label for="inputEmail4">Libele: <i style="color:#e63f32">'.$row['abr_dep'].'</i></label>
                                          <input type="text" class="form-control" id="prenom_std" name="abr_dep"  maxlength="15"  >
                                    </div>
                                </div>
                                <div class="row text-right"> 
                                    <button type="submit" class="btn btn-primary">Enrégistrer</button>
                                    <button type="button" class="btn btn-danger" data-bs-dismiss="modal">Annuler</button>
                                  </form>
                                  </div>
                              </div>
                        </div>
					</div></td>

					<td>
                 <button type="button" class="btn btn-danger btn-sm ml-2" data-bs-toggle="modal" data-bs-target="#mod_del'.$row['id'].'" data-whatever="@mdo"><i class="fa fa-remove fa-1x" aria-hidden="true"></i></button>
                  
					<div class="modal fade" id="mod_del'.$row['id'].'" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                      <div class="modal-dialog modal-lg" role="document">
                        <div class="modal-content">
                          <div class="modal-header">
                            <h5 class="modal-title" id="exampleModalLabel">SUPPRIMER LA CLASSE</h5>
														<button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Fermer"></button>
                          </div>
                          <div class="modal-body">
                          		<h5 class="modal-title" id="exampleModalLabel">Nom de la classe: '.$row['nom_dep'].' <br>Voulez-vous supprimmer cet Département y compris la liste des matières inclus et les paramètres de cette classe? Cette action est irréversible.</h5>
                          		<a href="Controler/departs/delDep.php?id='.$row['id'].'" ><button  class="btn btn-primary">Oui</button></a>                  
                                       
                                </div>
                                <div class="modal-footer">
                                 
                               
                                	<button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Annuler</button>
                          		</div>
                        </div>
					</div></td>
                </tr>
				';
					
			}
			$nt=$i;
			$i=0;
				
		}

			public function SelectSessions()
		{
			$bdd = $GLOBALS['bdd'];
			$i=0;
			$nt=0;
			$reponse = $bdd->query('SELECT * FROM sess where id>=1 order by id asc');
			while($row = $reponse->fetch(PDO::FETCH_ASSOC)) 
			{
				$i++;

				echo '<option value="'.$row['abr_sess'].'">'.$i.' - '.$row['nom_sess'].'</option>';
				}
		}

			public function SelectDep()
		{
			$bdd = $GLOBALS['bdd'];
			$i=0;
			$nt=0;
			$reponse = $bdd->query('SELECT * FROM departements where id>=1 order by nom_dep asc');
			while($row = $reponse->fetch(PDO::FETCH_ASSOC)) 
			{
				$i++;

				echo '<option value="'.$row['id'].'">'.$i.' - '.$row['nom_dep'].' - ('.$row['ref_session'].')</option>';
				}
		}

			public function SelectMatByCls($cl)
		{
			$i=0;
			$nt=0;
			$bdd = $GLOBALS['bdd'];
			$reponse = $bdd->query("SELECT * FROM config_bull where ref_class='".$cl."' order by group_mat asc ");
			while($row = $reponse->fetch(PDO::FETCH_ASSOC)) 
			{
				$i++;

				$nom_mat=$this->ReturnNom_matByIdname($row['ref_mat']);

				echo '<option value="'.$row['ref_mat'].'">'.$i.' - '.$nom_mat.'</option>';
				}
		}

		public function ReturnNom_matByIdname($id)
		{
			$bdd = $GLOBALS['bdd'];
			$reponse = $bdd->query('SELECT * FROM matieres where id='.$id.'');
			while($row = $reponse->fetch(PDO::FETCH_ASSOC)) 
			{
				return $row['nom_mat'];
			}
		}

		public function ReturnNom_DepByIdname($id)
		{
			$bdd = $GLOBALS['bdd'];
			$reponse = $bdd->query('SELECT * FROM departements where id='.$id.'');
			while($row = $reponse->fetch(PDO::FETCH_ASSOC)) 
			{
				return $row['nom_dep'];
			}
		}

		public function ReturnLib_DepByIdname($id)
		{
			$bdd = $GLOBALS['bdd'];
			$reponse = $bdd->query('SELECT * FROM departements where id='.$id.'');
			while($row = $reponse->fetch(PDO::FETCH_ASSOC)) 
			{
				return $row['abr_dep'];
			}
		}



		public function InclusSelectDep()
		{
			$bdd = $GLOBALS['bdd'];
			$i=0;
			$nt=0;
			$reponse = $bdd->query('SELECT * FROM departements where id>=1 order by nom_dep asc');
			while($row = $reponse->fetch(PDO::FETCH_ASSOC)) 
			{
				$i++;

				$inclus= '<option value="'.$row['id'].'">'.$i.' - '.$row['nom_dep'].' - ('.$row['ref_session'].')</option>';
				return $inclus;
				}
		}
	

		public function NombreDep()
		{
			$n=0;
			$ntotal=0;
			$bdd = $GLOBALS['bdd'];
			$reponse = $bdd->query("SELECT * FROM departements where id>=1 ");

			while($row = $reponse->fetch(PDO::FETCH_ASSOC)) 
			{ 
					$n++;
			}
				$ntotal= $n;
				return $ntotal;
		}

		public function CkExistingCode($code)
		{

			$bdd = $GLOBALS['bdd'];	

			$reponse = $bdd->query('SELECT * FROM classes where code_class="'.$code.'" ');
			while (($row = $reponse->fetch(PDO::FETCH_ASSOC))) 
			{
				return true;
			}
		}

		public function delDep($code)
		{
			$bdd = $GLOBALS['bdd'];

			$req = 'DELETE FROM departements WHERE id=?';
			$rep = $bdd->prepare($req);
			if($rep->execute(array($code)))
			{
				return true;
			}else{
				return false;
			}
		}


}
	$dep = new MyDeparts();

?>
