-- 1. Création de la table de stockage de la licence locale (schéma signé INOFIB)
CREATE TABLE IF NOT EXISTS `config_licence` (
  `id` int NOT NULL AUTO_INCREMENT,
  `cle_licence` LONGTEXT NOT NULL,
  `statut_activation` varchar(50) DEFAULT 'inactif',
  `install_id` varchar(64) DEFAULT NULL,
  `cle_publique` LONGTEXT DEFAULT NULL,
  `debut_licence` date DEFAULT NULL,
  `fin_licence` date DEFAULT NULL,
  `nb_poste` int NOT NULL DEFAULT 1,
  `dernier_controle` datetime DEFAULT CURRENT_TIMESTAMP,
  `dernier_sync` datetime DEFAULT NULL,
  `dernier_sync_essai` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unq_install_id` (`install_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

UPDATE `etablissement` SET `school_year` = '2025/2026' WHERE `id` >= 0;