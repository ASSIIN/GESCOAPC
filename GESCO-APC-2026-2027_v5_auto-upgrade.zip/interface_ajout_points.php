<?php
    session_start();   
  require_once 'core/require.php'; 
  require_once 'Model/connexion.php';
     if (!isset($_SESSION['user'])) {
    session_unset();
    session_destroy();
    header('location: index.php');    
    }
   
$id_ens = $_SESSION['login'];
$user_role = $_SESSION['user_role'];

// Génère un nouveau jeton unique chaque fois que la page est chargée ou rafraîchie
if (empty($_SESSION['last_token'])) {
    // PHP crée ici une chaîne de caractères aléatoire unique
    $_SESSION['last_token'] = bin2hex(random_bytes(16)); 
}

// Nous rendons ce jeton disponible pour le JavaScript
$csrf_token = $_SESSION['last_token'];

// Récupération des paramètres GET actuels pour maintenir l'état de l'interface
$trim = $_GET['trim'] ?? null;
$ref_class = $_GET['ref_class'] ?? null;
$ref_mat = $_GET['ref_mat'] ?? null;
  
?>

<!DOCTYPE html>
<html>
  <head>
   <?php Config::head(); ?>
    <title>GESCOAPC| AJOUTER POINTS BONUS</title>
    <style type="text/css">
        
       
         /* Positionnement fixe pour l'alerte en haut de la page */
        #message_status_container {
            position: fixed; /* Reste visible même en scrollant */
            top: 5px;
            left: 25%;
            right: 10px;
            z-index: 1050; /* S'assure qu'elle est au-dessus de tout le reste (comme les modaux) */
            padding: 10px; /* Espace autour de l'alerte */
        }
   
    </style>
  </head>

<body>
    <div class="wrapper">
      <!-- Sidebar et Menu (inchangés par rapport à votre code original) -->

      <!-- Inclusion du menu de navigation externe réutilisable -->
      <?php include 'core/sidebar.php'; ?>  

<div class="main-content-wrapper">
        <!-- Barre supérieure de navigation adaptative -->
        <div class="mobile-navbar-fixed p-3 mb-4 rounded shadow-sm border">
            <div class="row align-items-center g-2">
                <div class="col-auto d-md-none">
                    <button class="btn btn-outline-dark btn-sm" id="toggleMobileMenu"><i class="fa fa-bars fa-lg"></i></button>
                </div>
                <div class="col-12 col-md">
                    <h4 class="m-0 fw-bold text-primary text-uppercase">Ajout des points</h4>
                </div>
            </div>
        </div>
            <div id="message_status_container">
                <div id="alerts" class="mt-4">
                </div>
            </div>
              
                
     <div class="container my-4 overflow-y">
   
    <div class="row mt-5 pt-4 ">
        <h4 class="ml-2">1. Sélectionner le trimestre, la classe et la matière</h4>
        <!-- Colonne 1 : Liste des trimestres -->
        <div class="col-md-2">
            <div class="card">
                <div class="card-header">Trimestres</div>
                <div class="card-body">
                    <div class="list-group">
                        <a href="interface_ajout_points.php?trim=t1" class="list-group-item list-group-item-action <?= ($trim == 't1') ? 'active' : ''; ?>">Trim 1</a>
                        <a href="interface_ajout_points.php?trim=t2" class="list-group-item list-group-item-action <?= ($trim == 't2') ? 'active' : ''; ?>">Trim 2</a>
                        <a href="interface_ajout_points.php?trim=t3" class="list-group-item list-group-item-action <?= ($trim == 't3') ? 'active' : ''; ?>">Trim 3</a>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Colonne 2 : Liste des classes -->
        <div class="col-md-2">
            <div class="card">
                <div class="card-header">Classes</div>
                <div class="card-body">
                    <div class="list-group" id="list-classes">
                        <?php if ($trim) : ?>
                             <?php 
                             // Charge les classes pour ce trimestre spécifique
                             $class->SelectClsList_byNote_by_User_AjoutPoint($id_ens, $trim);
                             ?> 
                        <?php else : ?>
                            <p class="text-muted">Sélectionnez un trimestre.</p>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Colonne 3 : Liste des matières -->
        <div class="col-md-3">
            <div class="card">
                <div class="card-header">Matières</div>
                <div class="card-body">
                    <div class="list-group" id="list-matieres">
                        <?php if ($trim && $ref_class) : 
                           // Charge les matières pour cette classe et ce trimestre spécifique
                           $class->SelectMatCls_Note_by_User_by_trim_AjoutPoint($id_ens, $trim, $ref_class);
                           ?>
                        <?php else : ?>
                            <p class="text-muted">Sélectionnez un trimestre et une classe.</p>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
        
         <!-- Colonne 4 : Compétences / Points à ajouter (FORMULAIRE DE SAISIE) -->
        <div class="col-md-5">
            <div class="card">
                <div class="card-header">COMPETENCES / Points</div>
                <div class="card-body">
                    <div id="form-container">
                        <?php if ($trim && $ref_class && $ref_mat) :
                            if ($trim=='t1') { $listEval='<option value="1" >COMP1</option><option value="2" >COMP2</option>'; } 
                            elseif ($trim=='t2') { $listEval='<option value="3" >COMP3</option><option value="4" >COMP4</option>'; }
                            elseif ($trim=='t3') { $listEval='<option value="5" >COMP5</option><option value="6" >COMP6</option>'; } else { $listEval=''; }
                           ?>
                               <div class="row">
                                  <div class="col-6 col-sm-6">
                                    <label for="selectEval" class="form-label">Évaluation</label>
                                    <select class="form-select" id="selectEval" required>
                                     <option value="">Choisir...</option>
                                     <?= $listEval ?>
                                   </select>
                                   </div>
                                   <div class="col-6 col-sm-6">
                                <label for="inputPoints" class="form-label">Points à Ajouter</label>
                                <input type="hidden" id="inputClassRef" value="<?= htmlspecialchars($ref_class) ?>">
                                <input type="hidden" id="inputMatRef" value="<?= htmlspecialchars($ref_mat) ?>"> 
                                <input type="number" class="form-control mb-2" id="inputPoints" required min="0.1" step="0.1"> 
                                </div>
                                <div class="col-12 col-sm-12 text-center" id="btn_ok_r" >
                                  <label for="addPointsButton" class="form-label">Opération</label><br>
                                      <button class="btn btn-primary" id="addPointsButton" type="button">Confirmer l'ajout</button>
                                  </div>
                                </div>
                           <?php else : ?>
                            <p class="text-muted">Sélectionnez un trimestre, une classe et une matière.</p>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
    </div>
    </div>



</div>

      <!-- End Sidebar -->
    <?php 
      Config::scriptJs();
    ?>
   <script>
    // Rendre le token accessible en JavaScript depuis PHP
    const operationToken = "<?php echo $csrf_token; ?>";
    const alertsContainer = $('#alerts'); // Utilisation de jQuery pour sélectionner le conteneur

    // Fonction utilitaire pour afficher les alertes Bootstrap 5
    function displayAlert(message, type) {
        // Nettoie l'ancien contenu
        alertsContainer.empty(); 
        
        // Crée l'alerte Bootstrap 5 en utilisant jQuery
        const alertHtml = `
            <div class="alert alert-${type} alert-dismissible fade show" role="alert">
                ${message}
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        `;
        
        // Ajoute l'alerte au conteneur
        alertsContainer.append(alertHtml);
    }

    // Attache un gestionnaire d'événement au clic sur le bouton #addPointsButton
    // Nous utilisons $(document).ready() pour nous assurer que le DOM est chargé
    $(document).ready(function() {
        $('#addPointsButton').on('click', function(e) {
            e.preventDefault(); // Empêche le comportement de soumission de formulaire par défaut (même s'il n'y a pas de <form> réel)

            const $button = $(this);
            $button.prop('disabled', true); // Désactive le bouton immédiatement

            // Récupération des données depuis les inputs HTML en utilisant jQuery
            const dataToSend = {
                ref_class: $('#inputClassRef').val(), 
                ref_mat: $('#inputMatRef').val(), 
                ref_eval: $('#selectEval').val(),
                point_a_ajouter: parseFloat($('#inputPoints').val()),
                token: operationToken 
            };
            
            // Validation de base avant l'envoi
            if (!dataToSend.ref_eval || isNaN(dataToSend.point_a_ajouter) || dataToSend.point_a_ajouter <= 0) {
                displayAlert("Veuillez choisir une évaluation et entrer un nombre de points valide (supérieur à 0).", 'warning');
                $button.prop('disabled', false); // Réactive le bouton si la validation client échoue
                return;
            }

            // Envoi de la requête POST via jQuery Ajax
            $.ajax({
                url: 'ajouter_points.php', // Assurez-vous que ce chemin est correct
                method: 'POST',
                contentType: 'application/json', // Indique au serveur que nous envoyons du JSON
                data: JSON.stringify(dataToSend), // Convertit l'objet JS en chaîne JSON
                dataType: 'json', // S'attend à recevoir du JSON en retour
                
                success: function(data) {
                    // Gère l'affichage du résultat dans le div #alerts
                    if (data.status === 'success') {
                        displayAlert(data.message, 'success');
                    } else if (data.status === 'info') {
                        displayAlert(data.message, 'info');
                    } else { // 'error'
                        displayAlert(data.message, 'danger');
                    }
                    // Le bouton reste désactivé après une réponse réussie (token consommé)
                },
                error: function(xhr, status, error) {
                    // Gère les erreurs de communication réseau ou serveur
                    console.error('Erreur Ajax:', status, error, xhr.responseText);
                    displayAlert("Une erreur de communication réseau est survenue. Détails dans la console (F12).", 'danger');
                    // $button.prop('disabled', false); // Optionnel: réactiver si erreur réseau pure
                }
            });
        });
    });
</script>

    <script type="text/javascript">
      $(document).ready(function() {


    // Code existant pour gérer les clics "active" sur les listes (inchangé)
    document.querySelectorAll('.list-group-item').forEach(item => {
        item.addEventListener('click', function(event) {
            const listGroup = this.closest('.list-group');
            listGroup.querySelectorAll('.list-group-item').forEach(el => {
                el.classList.remove('active');
            });
            this.classList.add('active');
        });
    });

    // Code existant pour pré-sélectionner la classe/matière active en fonction de l'URL
    var urlParams = new URLSearchParams(window.location.search);
    var classeUrl = urlParams.get('ref_class');
    var matiereUrl = urlParams.get('ref_mat');

    if (classeUrl) {
        $('#list-classes .list-group-item').each(function() {
            if ($(this).attr('href').includes('ref_class=' + classeUrl)) {
                $(this).addClass('active');
            }
        });
    }
    if (matiereUrl) {
         $('#list-matieres .list-group-item').each(function() {
            if ($(this).attr('href').includes('ref_mat=' + matiereUrl)) {
                $(this).addClass('active');
            }
        });
    }
});
    </script>
</body>
</html>
