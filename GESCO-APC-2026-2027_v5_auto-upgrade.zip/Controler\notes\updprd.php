<?php
	session_start();
	require_once '../../Model/connexion.php';
	require_once '../../core/require.php'; 
	if (!isset($_POST['1'])) {
		$eva1="";	
	} else{
		$eva1=$_POST['1'];
	}

	if (!isset($_POST['2'])) {
		$eva2="";		
	} else{
		$eva2=$_POST['2'];
	}

	if (!isset($_POST['3'])) {
		$eva3="";		
	} else{
		$eva3=$_POST['3'];
	}

	if (!isset($_POST['4'])) {
		$eva4="";		
	} else{
		$eva4=$_POST['4'];
	}

	if (!isset($_POST['5'])) {
		$eva5="";		
	} else{
		$eva5=$_POST['5'];
	}

	if (!isset($_POST['6'])) {
		$eva6="";	
	} else{
		$eva6=$_POST['6'];
	}
	
	$elt= array('1' =>$eva1 , '2' =>$eva2 , '3' =>$eva3 , '4' =>$eva4, '5' =>$eva5 ,'6' =>$eva6);

	foreach ($elt as $key => $value) 
	{

		//echo $key.' -- '.$value.'<br>';

		if ($value!="") {
		$statut='O';
		$id=(int)$key;
		$bdd = $GLOBALS['bdd'];	
		$req ='UPDATE  evaluations SET statut= ? where id='.$id.'';
		$rep = $bdd->prepare($req);
		$rep->execute(array($statut));
			
		}
		else{
			$statut='N';
			$id=(int)$key;
		$bdd = $GLOBALS['bdd'];	
		$req ='UPDATE  evaluations SET statut= ? where id='.$id.'';
		$rep = $bdd->prepare($req);
		$rep->execute(array($statut));

		}
	
		
	  }
	  header('location: ../../general_setting.php');	
		
?>