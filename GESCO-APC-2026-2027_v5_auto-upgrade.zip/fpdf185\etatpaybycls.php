<?php
session_start();
require_once '../Model/connexion.php';
require_once '../core/require.php';
 if (!isset($_SESSION['user'])) {
    session_unset();
    session_destroy();
    header('location: ../index.php');    
    }
 $etb->ShowEtb();

$refcls= htmlspecialchars($_GET['refcls']);
//Virifions si la classes Existe
       $ckcls=$class->CkExistingCode($_GET['refcls']);
        if (($_GET['refcls']=="") or ($ckcls==false)) {
        header('location: ../gestion_fin.php');    
      }
require('fpdf.php');
$pdf = new FPDF();

class PDF extends FPDF
{
// En-tête
function Header()
{
	 $this->SetY(15);
    // Logo
    $this->Image('../plugins/images/'.$_SESSION['logo_etb'].'',10,6,30);
    // Police Arial gras 15
    $this->SetFont('Arial','B',15);
    // Décalage à droite
    $this->Cell(80);
    // Titre
    $this->Cell(30,10,'Titre',1,0,'C');
    // Saut de ligne
    $this->Ln(20);
}

// Pied de page
function Footer()
{
    // Positionnement à 1,5 cm du bas
    $this->SetY(-15);
    // Police Arial italique 8
    $this->SetFont('Arial','I',8);
    // Numéro de page
    $this->Cell(0,10,'Page '.$this->PageNo().'/{nb}',0,0,'C');
}
}
$pdf->AliasNBPages();
$pdf->AddPage();
//code for print data

		 $bdd = $GLOBALS['bdd'];
			$reponse = $bdd->query('SELECT id, nom_std, lieu_nais, sexe_std, mat_std, ref_class,statut,cni_std,  DATE_FORMAT(date_nais, \'%d/%m/%Y \') AS date_fr FROM eleves where ref_class="'.$refcls.'" order by nom_std asc');

			$i=1;
			$eff=0;
			/*En-tête*/
				$pdf->SetFont('Times','',8);
				$pdf->Image('../plugins/images/'.$_SESSION['logo_etb'].'',90,15,30);
				$pdf->Cell(70,4,'REPUBLIQUE DU CAMEROUN',0,0,'C');
				$pdf->Cell(50,4,'',0,0);
				$pdf->Cell(70,4,'REPUBLIC OF CAMEROON',0,1,'C');

				$pdf->Cell(70,4,'Paix-Travail-Patrie',0,0,'C');
				$pdf->Cell(50,4,'',0,0);
				$pdf->Cell(70,4,'Peace-Work-Fatherland',0,1,'C');

				$pdf->Cell(70,4, utf8_to_cp1252("".$_SESSION['minist_etb_fr'].""),0,0,'C');
				$pdf->Cell(50,4,'',0,0);
				$pdf->Cell(70,4,utf8_to_cp1252(''.$_SESSION['minist_etb_en'].''),0,1,'C');

				$pdf->Cell(70,4,utf8_to_cp1252("".$_SESSION['region_etb_fr'].""),0,0,'C');
				$pdf->Cell(50,4,'',0,0);
				$pdf->Cell(70,4,utf8_to_cp1252(''.$_SESSION['region_etb_en'].''),0,1,'C');

				$pdf->Cell(70,4,utf8_to_cp1252(''.$_SESSION['depart_etb_fr'].''),0,0,'C');
				$pdf->Cell(50,4,'',0,0);
				$pdf->Cell(70,4,utf8_to_cp1252(''.$_SESSION['depart_etb_en'].''),0,1,'C');
				$pdf->SetFont('Times','B',10);
				$pdf->Cell(70,6,utf8_to_cp1252(''.$_SESSION['nom_etb_fr'].''),0,0,'C');
				$pdf->Cell(50,6,'',0,0);
				$pdf->Cell(70,6,utf8_to_cp1252(''.$_SESSION['nom_etb_en'].''),0,1,'C');
				$pdf->SetFont('Times','',8);
				$pdf->Cell(70,5,utf8_to_cp1252(''.$_SESSION['code_pste_etb'].' / '.$_SESSION['tel_etb'].''),0,0,'C');
				$pdf->Cell(50,5,'',0,0);
				$pdf->Cell(70,5,utf8_to_cp1252(''.$_SESSION['code_pste_etb'].'/ '.$_SESSION['tel_etb'].''),0,1,'C');
				$pdf->SetFont('Times','',8);
				$pdf->Cell(70,4,utf8_to_cp1252(''.$_SESSION['email_etb'].''),0,0,'C');
				$pdf->Cell(50,4,'',0,0);
				$pdf->Cell(70,4,utf8_to_cp1252(''.$_SESSION['email_etb'].''),0,1,'C');
					$pdf->Ln();
					$pdf->SetFont('Times','I',12);
					$pdf->Cell(65,5,'',0,0);
					$pdf->Cell(60,5,utf8_to_cp1252(''.$_SESSION['code_im_etb'].''),0,0,'C');
					$pdf->Ln();
					$pdf->Ln();
			/*FIN En-tête*/
						$today= date('d/m/Y');
					$pdf->SetFont('Times','B',12);
					$pdf->SetFillColor(171,177,186);
					$pdf->Cell(20,6,'',0,0,'C');
					$pdf->Cell(150,6,'ETATS DE PAIEMENTS / PAYMENT STATEMENTS',1,0,'C',1);
					$pdf->Ln();
					$pdf->SetTextColor(255,2,2);
					$pdf->SetFont('Times','B',11);
					$pdf->Cell(60,4,'',0,0,'C');
					$pdf->Cell(70,4,utf8_to_cp1252('Du/From  '.$today.''),0,1,'C');
					$pdf->Cell(60,4,'',0,0,'C');
					$pdf->Ln();
					$pdf->SetTextColor(0,0,0);
					$pdf->SetFont('Times','B',12);

					/* Initier les paramètres*/
					$nv=$fin->ReturnClasseNiveauByCode($refcls);
					$sess=$fin->ReturnClasseSessionByCode($refcls);
					$ps=$fin->Return_Ps_Nv($nv,$sess);
					if ($ps!=0) {				
					$ps= number_format($ps,0,",",".");				
					}
			 

				$class->CkClasseByCode($refcls);
				$nbstd=$class->NbrStudentByClass($refcls);
				$nbM=$class->NbrBySexeByClass($refcls,'M');
				$nbF=$class->NbrBySexeByClass($refcls,'F');
				$nomcls=$_SESSION['nom_class'];
				$niveaucls=$_SESSION['ref_class_niveau'];

				$pdf->Cell(50,6,"Classe: $nomcls",1,0,'L');
				$pdf->Cell(30,6,"Code: $refcls",1,0,'L');
				$pdf->Cell(21,6,"Eff: $nbstd",1,0,'C');
				$pdf->Cell(40,6,"Pension/School fees",1,0,'C');
				$pdf->Cell(45,6,"$ps FCFA",1,0,'C');
				$pdf->Ln();
			
			$pdf->SetFont('Times','B',10);
				$pdf->Ln();
					$pdf->Cell(8,6,utf8_to_cp1252('#'),1,0, 'C');
					$pdf->Cell(20,6,utf8_to_cp1252('N° Inscipt'),1,0, 'C');
					$pdf->Cell(20,6,'Matricule',1,0, 'C');
					$pdf->Cell(70,6,utf8_to_cp1252('Noms_et_Prénoms/Full_Name'),1,0, 'C');
					$pdf->Cell(25,6,utf8_to_cp1252('Payé/Paid'),1,0, 'C');
					$pdf->Cell(20,6,utf8_to_cp1252('Rms/Discnt'),1,0, 'C');
					$pdf->Cell(25,6,utf8_to_cp1252('Reste/Unpaid'),1,0, 'C');
					$g_ps=0;
					$g_rdt=0;
					$g_vsm=0;
					$g_reste=0;
					
			while($row = $reponse->fetch(PDO::FETCH_ASSOC)) 
			{
				$Nom=htmlspecialchars($row['nom_std']);

				$Nom=substr($Nom, 0,32);
				$Nom= str_replace("&#039;", "'", $Nom);
				
				
				$ps=$fin->Return_Ps_Nv($nv,$sess);
				$rdt=$fin->Return_All_rdt_std($row['mat_std']);
				$vsm=$fin->Return_All_vsm_std($row['mat_std']);
				$reste=$ps-$vsm-$rdt;
				if ($ps!=0) {
					$reste=$ps-$vsm-$rdt;
					$ps= number_format($ps,0,",",".");
					$rdt= number_format($rdt,0,",",".");
					$vsm= number_format($vsm,0,",",".");
					$reste= number_format($reste,0,",",".");				
					}

					$pdf->SetFont('Arial','',8);
					$pdf->Ln();
						$pdf->Cell(8,5,$i,1,0);
						$pdf->Cell(20,5,utf8_to_cp1252(''.$_SESSION['pre_matr'].''.$row['mat_std'].''),1,0,'C');

						$pdf->Cell(20,5,utf8_to_cp1252(''.$row['cni_std'].''),1,0,'C');
						$pdf->Cell(70,5,utf8_to_cp1252($Nom),1,0,'L');
						$pdf->Cell(25,5,utf8_to_cp1252($vsm),1,0,'C');
						$pdf->Cell(20,5,utf8_to_cp1252($rdt),1,0,'C');
						$pdf->Cell(25,5,utf8_to_cp1252($reste),1,0,'C');


						$ps=$fin->Return_Ps_Nv($nv,$sess);
						$rdt=$fin->Return_All_rdt_std($row['mat_std']);
						$vsm=$fin->Return_All_vsm_std($row['mat_std']);
						$reste=$ps-$vsm-$rdt;

						$g_rdt+=$rdt;
						$g_vsm+=$vsm;
						$g_reste+=$reste;
						$i++;
				}
				$g_ps=$ps*$nbstd;
				if ($ps!=0) {
					
					$g_ps= number_format($g_ps,0,",",".");
					$g_rdt= number_format($g_rdt,0,",",".");
					$g_vsm= number_format($g_vsm,0,",",".");
					$g_reste= number_format($g_reste,0,",",".");				
					}

				 
				 $pdf->SetFont('Arial','B',10);
					$pdf->Ln();
						
				$pdf->Cell(118,6,utf8_to_cp1252('Montant à verser/Total coat to pay : '.$g_ps.' FCFA'),1,0,'L');
				$pdf->Cell(25,6,utf8_to_cp1252($g_vsm),1,0,'C');
				$pdf->Cell(20,6,utf8_to_cp1252($g_rdt),1,0,'C');
				$pdf->Cell(25,6,utf8_to_cp1252($g_reste),1,0,'C');
				$pdf->SetXY(125,272);
			$pdf->Cell(0,3,'Page '.$pdf->PageNo().'/{nb}',0,1,'C');
			$pdf->Output('ETATS_PAIEMENTS_CLASS '.$nomcls.'.pdf','I');
			$pdf->Close();
?>
