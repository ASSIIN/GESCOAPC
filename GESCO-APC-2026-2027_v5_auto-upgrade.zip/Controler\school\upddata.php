<?php
session_start();

// Sécurité : la restauration d'une base est réservée aux rôles autorisés sur la page operations.php
if (!isset($_SESSION['user']) || !in_array($_SESSION['user_role'] ?? '', array('admin', 'pcpl', 'sg', 'cs'))) {
    header('location: ../../index.php');
    exit;
}

// Information de connexion à la base de données
// CORRECTION : validation stricte du nom de base (anti-injection dans le nom de base)
$con_year = preg_replace('/[^a-zA-Z0-9_-]/', '', (string)($_SESSION['con_year'] ?? ''));
$host = 'localhost';
$user = 'root';
$password = '';
$dbname = 'gescoapc_' . $con_year;

// Connexion à la base de données
$conn = new mysqli($host, $user, $password, $dbname);

// Vérifier la connexion
if ($conn->connect_error) {
    die("Connexion échouée : " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Vérifier si un fichier a été sélectionné
    if (isset($_FILES["sql_file"]) && $_FILES["sql_file"]["error"] === UPLOAD_ERR_OK) {
        $file_name = $_FILES["sql_file"]["name"];
        $file_tmp = $_FILES["sql_file"]["tmp_name"];
        $file_size = $_FILES["sql_file"]["size"];

        // CORRECTION : contrôle d'extension .sql + limite de taille (100 Mo)
        if (strtolower(substr($file_name, -4)) == ".sql" && $file_size <= 100 * 1024 * 1024) {

        	 // Supprimer toutes les tables
            $conn->query("SET FOREIGN_KEY_CHECKS = 0");
            $result = $conn->query("SHOW TABLES");
            while ($row = $result->fetch_array()) {
                // CORRECTION : nom de table échappé par des backticks (anti-injection SQL)
                $table = '`' . str_replace('`', '', $row[0]) . '`';
                $conn->query("DROP TABLE " . $table);
            }
            $conn->query("SET FOREIGN_KEY_CHECKS = 1");

            // Lire le contenu du fichier SQL
            $sql = file_get_contents($file_tmp);

            // Exécuter les requêtes SQL
            if ($conn->multi_query($sql)) {
                // Vider les jeux de résultats restants pour éviter les erreurs
                while ($conn->more_results()) {
                    if (!$conn->next_result()) { break; }
                }
                header('location: ../../operations.php?1');
            } else {
            	 header('location: ../../operations.php?0');
            }
        } else {
             header('location: ../../operations.php?ef');
        }
    } else 
    {
    	 header('location: ../../operations.php?nf');
    }
}

// Fermer la connexion
$conn->close();
?>