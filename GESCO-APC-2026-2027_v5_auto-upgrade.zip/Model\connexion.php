<?php
// Model/connexion.php

if (!isset($_SESSION['con_year']) || empty($_SESSION['con_year'])) {
    header('location: index.php');    
    exit();
}

try { 
    // Connexion PDO sécurisée à la base de l'année choisie
    $bdd = new PDO('mysql:host=localhost;dbname=gescoapc_'.$_SESSION['con_year'].';charset=utf8mb4', 'root', '');
    $bdd->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $GLOBALS['bdd'] = $bdd; // Sécurité pour s'assurer que le scope global est hydraté

    // ------------------------------------------
    // UPGRADE AUTO NON DESTRUCTIF (optionnel) :
    // n'est chargé QUE SI le fichier existe (évite le fatal
    // quand il n'est pas présent / déjà supprimé après succès).
    // Ajoute seulement les colonnes/tables manquantes,
    // jamais de DROP/DELETE/UPDATE de données.
    // ------------------------------------------
    $__auto_upgrade = __DIR__ . '/../less/auto_upgrade.php';
    if (is_file($__auto_upgrade)) {
        require_once $__auto_upgrade;
    }

    // Création / migration automatique de la table de licence (colonnes install_id, cle_publique, dates)
    $bdd->exec("CREATE TABLE IF NOT EXISTS `config_licence` (
        `id` int NOT NULL AUTO_INCREMENT,
        `cle_licence` LONGTEXT NOT NULL,
        `statut_activation` varchar(50) DEFAULT 'inactif',
        `install_id` varchar(64) DEFAULT NULL,
        `cle_publique` LONGTEXT DEFAULT NULL,
        `debut_licence` date DEFAULT NULL,
        `fin_licence` date DEFAULT NULL,
        `nb_poste` int NOT NULL DEFAULT 1,
        `dernier_controle` datetime DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (`id`),
        UNIQUE KEY `unq_install_id` (`install_id`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;");
    $bdd->exec("ALTER TABLE `config_licence` MODIFY `cle_licence` LONGTEXT NOT NULL");

    // Ajout des colonnes manquantes pour les bases créées par les anciennes versions
    $col_licence = ['install_id', 'cle_publique', 'debut_licence', 'fin_licence', 'nb_poste'];
    foreach ($col_licence as $c) {
        $chk = $bdd->query("SELECT COUNT(*) FROM information_schema.COLUMNS
            WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'config_licence' AND COLUMN_NAME = " . $bdd->quote($c));
        if ((int)$chk->fetchColumn() === 0) {
            $typ = $c === 'nb_poste' ? "int NOT NULL DEFAULT 1" : ($c === 'install_id' ? "varchar(64) DEFAULT NULL" : ($c === 'dernier_controle' ? "datetime DEFAULT CURRENT_TIMESTAMP" : "LONGTEXT DEFAULT NULL"));
            $bdd->exec("ALTER TABLE `config_licence` ADD COLUMN `$c` $typ");
        }
    }
    // Index unique sur install_id (idempotent)
    $chk = $bdd->query("SELECT COUNT(*) FROM information_schema.STATISTICS
        WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'config_licence' AND INDEX_NAME = 'unq_install_id'");
    if ((int)$chk->fetchColumn() === 0) {
        $bdd->exec("ALTER TABLE `config_licence` ADD UNIQUE KEY `unq_install_id` (`install_id`)");
    }

} catch(Exception $e) {
    die('Erreur de connexion base de données : '.$e->getMessage());
}

// Connexion MySQLi pour la rétrocompatibilité des anciens scripts de lecture
$connect = mysqli_connect("localhost", "root", "", "gescoapc_".$_SESSION['con_year']."");
?>
