<?php
session_start();
require_once '../Model/connexion.php';
require_once '../core/require.php'; 
require_once 'fpdf.php'; 

if (!isset($_SESSION['user'])) {
    session_unset();
    session_destroy();
    header('location: ../index.php');    
    }

 $etb->ShowEtb();

$trimestre = isset($_GET['trim']) ? htmlspecialchars($_GET['trim']) : '1'; 

class PDF extends FPDF {
    function Header() {
        // En-tête (votre code existant, corrigé pour les erreurs Deprecated)
        $this->SetFont('Times','',6);
        $logo_path = '../plugins/images/'.$_SESSION['logo_etb'];
        if (file_exists($logo_path)) { $this->Image($logo_path, 92, 12, 28); }
        $this->Cell(70,3,utf8_to_cp1252('REPUBLIQUE DU CAMEROUN'),0,0,'C');
        $this->Cell(50,3,'',0,0); $this->Cell(70,3,utf8_to_cp1252('REPUBLIC OF CAMEROON'),0,1,'C');
        $this->Cell(70,3,utf8_to_cp1252('Paix-Travail-Patrie'),0,0,'C');
        $this->Cell(50,3,'',0,0); $this->Cell(70,3,utf8_to_cp1252('Peace-Work-Fatherland'),0,1,'C');
        $this->Cell(70,3, utf8_to_cp1252($_SESSION['minist_etb_fr'] ?? ''),0,0,'C');
        $this->Cell(50,3,'',0,0); $this->Cell(70,3,utf8_to_cp1252($_SESSION['minist_etb_en'] ?? ''),0,1,'C');
        $this->Cell(70,3,utf8_to_cp1252($_SESSION['region_etb_fr'] ?? ''),0,0,'C');
        $this->Cell(50,3,'',0,0); $this->Cell(70,3,utf8_to_cp1252($_SESSION['region_etb_en'] ?? ''),0,1,'C');
        $this->Cell(70,3,utf8_to_cp1252($_SESSION['depart_etb_fr'] ?? ''),0,0,'C');
        $this->Cell(50,3,'',0,0); $this->Cell(70,3,utf8_to_cp1252($_SESSION['depart_etb_en'] ?? ''),0,1,'C');
        $this->SetFont('Times','B',8);
        $this->Cell(70,4,utf8_to_cp1252($_SESSION['nom_etb_fr'] ?? ''),0,0,'C');
        $this->Cell(50,3,'',0,0); $this->Cell(70,4,utf8_to_cp1252($_SESSION['nom_etb_en'] ?? ''),0,1,'C');
        $this->SetFont('Times','',6);
        $contact_info = utf8_to_cp1252(($_SESSION['code_pste_etb'] ?? '') . ' / ' . ($_SESSION['tel_etb'] ?? ''));
        $this->Cell(70,4,$contact_info,0,0,'C'); $this->Cell(50,3,'',0,0); $this->Cell(70,3,$contact_info,0,1,'C');
        $this->SetFont('Times','',6); $email_info = utf8_to_cp1252($_SESSION['email_etb'] ?? '');
        $this->Cell(70,3,$email_info,0,0,'C');
        $this->SetFont('Times','I',10); $this->Cell(50,5,utf8_to_cp1252($_SESSION['code_im_etb'] ?? ''),0,0,'C');
        $this->SetFont('Times','',6); $this->Cell(70,3,$email_info,0,1,'C');
        $this->Ln();
        $this->SetFont('Times','I',6); $this->Cell(40,3,'',0,0,'C');
        $this->Cell(60,3,utf8_to_cp1252('ANNEE SCOLAIRE'),0,0,'R');
        $this->SetFont('Times','B',10); $this->Cell(40,3,utf8_to_cp1252($_SESSION['school_year'] ?? ''),0,0,'L');
        $this->Cell(40,3,'',0,1,'C');
        $this->Ln(10); 
    }

    function Footer() {
        $this->SetY(-15); $this->SetFont('Arial','I',8);
        $this->Cell(0,10,utf8_to_cp1252('Page ').$this->PageNo().'/{nb}',0,0,'C');
    }
    
    function CustomTable($header, $data, $widths) {
        $this->SetFont('Arial','B',9);
        for($i=0; $i<count($header); $i++) {
            $this->Cell($widths[$i], 7, utf8_to_cp1252($header[$i]), 1, 0, 'C');
        }
        $this->Ln();
        
        $this->SetFont('Arial','',8);
        foreach($data as $row) {
            for($i=0; $i<count($row); $i++) {
                $align = ($header[$i] == 'Moyenne' || strpos($header[$i], '%') !== false || strpos($header[$i], 'Gen') !== false) ? 'R' : 'L';
                if ($header[$i] == 'Rang' || $header[$i] == 'Inscrits' || $header[$i] == 'Comp.' || $header[$i] == 'Nb Moy' || $header[$i] == 'Nb >= 10' || $header[$i] == 'Nbre 1er' || $header[$i] == 'T.H.') $align = 'C';
                
                $cellValue = $row[$i] ?? ''; 
                $this->Cell($widths[$i], 6, utf8_to_cp1252($cellValue), 1, 0, $align);
            }
            $this->Ln();
        }
    }
}

$pdf = new PDF();
$pdf->AliasNbPages();
$pdf->AddPage();

// --- Ajout du grand titre général avec bordure ---
$pdf->SetFont('Arial','B',14);
$pdf->Cell(0,10,utf8_to_cp1252("STATISTIQUES GLOBALES - TRIMESTRE ".$trimestre),1,1,'C');
$pdf->Ln(5);

// --- (Le reste du code de génération du PDF...) ---

// --- 1. Top 5 et Bottom 5 de l'Établissement (Session/Trimestre) ---
$widths_5_cols = array(20,110, 20, 20, 20, 40); 
$top5_etab = $class->getTopStudents(5, NULL, $trimestre);
$bottom5_etab = $class->getBottomStudents(5, NULL, $trimestre);
$pdf->Cell(0,8,utf8_to_cp1252("5 - 1er - Établissement (Trimestre ".$trimestre.")"),0,1);
$header = array('N_Inscipt', 'Nom & Prénom', 'Moyenne', 'Rang', 'Classe');
$data_top = array_map(function($r){ 

    return [$_SESSION['pre_matr'].''.$r['mat_std'], $r['nom'], number_format($r['moy'] ?? 0, 2), $r['rang'] ?? 'N/A', $r['nom_class']]; 
}, $top5_etab);
$pdf->CustomTable($header, $data_top, $widths_5_cols);
$pdf->Ln(5);
$pdf->Cell(0,8,utf8_to_cp1252("5 Der - Établissement (Trimestre ".$trimestre.")"),0,1);
$data_bottom = array_map(function($r){ 
    return [$r['mat_std'], $r['nom'], number_format($r['moy'] ?? 0, 2), $r['rang'] ?? 'N/A', $r['nom_class']]; 
}, $bottom5_etab);
$pdf->CustomTable($header, $data_bottom, $widths_5_cols);
$pdf->Ln(10);


// --- 2. Taux de Réussite par Classe et Global ---
$widths_2_cols = array(110, 50);
$success_rates_classes = $class->getSuccessRatesByCls($trimestre);
$global_rate = $class->getGlobalSuccessRate($trimestre);
$pdf->Cell(0,8,utf8_to_cp1252("Taux de Réussite (Trimestre ".$trimestre.")"),0,1);
$header_taux = array('Classe', 'Taux de Réussite (%)');
$data_taux = array_map(function($r){ return [$r['nom_class'], number_format($r['taux_reussite'] ?? 0,2)]; }, $success_rates_classes);
$pdf->CustomTable($header_taux, $data_taux, $widths_2_cols);
$pdf->Ln(5);
$pdf->SetFont('Arial','B',12);
$pdf->Cell(80,8,utf8_to_cp1252("Taux Global Établissement"),1,0);
$pdf->Cell(40,8,number_format($global_rate ?? 0, 2) . " %",1,1);
$pdf->Ln(10);


// --- 3. Classements Détaillés par Classe ---
$pdf->Ln(5);
$all_classes = $class->getAllClasses(); 
$widths_5_cols = array(20, 110, 20, 10, 30);
$header = array('N_Inscipt', 'Nom & Prénom', 'Moyenne', 'Rang', 'Classe');

foreach ($all_classes as $class_info) {
    // ... (Logique de la boucle foreach inchangée) ...
    $code_classe = $class_info['code_class'];
    $nom_classe = $class_info['nom_class'];
    $top5_cls = $class->getTopStudents(5, $code_classe, $trimestre);
    $bottom5_cls = $class->getBottomStudents(5, $code_classe, $trimestre);

    if (!empty($top5_cls) || !empty($bottom5_cls)) {
        if ($pdf->GetY() + 80 > $pdf->GetPageHeight() - 20) {
            $pdf->AddPage();
            $pdf->Ln(10);
            $pdf->SetFont('Arial','B',12);
            $pdf->Cell(0,10,utf8_to_cp1252("CLASSEMENTS DÉTAILLÉS PAR CLASSE "),0,1,'C');
        }
        $pdf->Ln(8);
        $pdf->SetFont('Arial','B',10);
        $pdf->Cell(0, 6, utf8_to_cp1252("Classe : " . $nom_classe), 0, 1);
        $pdf->SetFont('Arial','',10);
        
        $pdf->Cell(0, 6, utf8_to_cp1252("5 - 1er :"), 0, 1);
        $data_top_cls = array_map(function($r){ 
            return [$_SESSION['pre_matr'].''.$r['mat_std'], $r['nom'], number_format($r['moy'] ?? 0,2), $r['rang'] ?? 'N/A', $r['nom_class']]; 
        }, $top5_cls);
        $pdf->CustomTable($header, $data_top_cls, $widths_5_cols);
        $pdf->Ln(5);

        $pdf->Cell(0, 6, utf8_to_cp1252("5 - Der :"), 0, 1);
        $data_bottom_cls = array_map(function($r){ 
            return [$_SESSION['pre_matr'].''.$r['mat_std'], $r['nom'], number_format($r['moy'] ?? 0,2), $r['rang'] ?? 'N/A', $r['nom_class']]; 
        }, $bottom5_cls);
        $pdf->CustomTable($header, $data_bottom_cls, $widths_5_cols);
    }
}


// --- 4. Statistiques Globales par Classes ---
$pdf->Ln(15);
$pdf->SetFont('Arial','B',12);
$pdf->Cell(0,10,utf8_to_cp1252("STATISTIQUES GÉNÉRALES PAR CLASSE (Trimestre ".$trimestre.")"),0,1,'C');

$all_classes = $class->getAllClasses();

// Définition des largeurs pour ce grand tableau (11 colonnes)
// LA CORRECTION EST ICI : 11 éléments dans le tableau de largeurs.
// Total ~190mm
$widths_stats_cols = array(35, 15, 15, 15, 20, 20, 20, 15, 15, 15); 
$header_stats = array('Classe', 'Inscrits', 'Comp.', 'Nb >= 10', 'Taux %', 'Moy Gen', 'Moy 1er', 'Moy Der', 'Nbre 1er', 'T.H.');

$data_stats = [];

foreach ($all_classes as $class_info) {
    $stats = $class->getDetailedClassStats($class_info['code_class'], $trimestre);
    
    if ($stats) {
        $data_stats[] = [
            $class_info['nom_class'],
            $stats['total_inscrits'],         
            $stats['inscrits_composant'],     
            $stats['nbre_reussite'] ?? 0,          
            number_format($stats['taux_reussite'] ?? 0, 1),
            number_format($stats['moyenne_generale_classe'] ?? 0, 2),
            number_format($stats['moyenne_premier'] ?? 0, 2),
            number_format($stats['moyenne_dernier'] ?? 0, 2),
            $stats['nbre_premier_classe'] ?? 0,
            $stats['nbre_tableau_honneur'] ?? 0
        ];
    }
}

$pdf->Ln(5);

// Utilisation de la fonction CustomTable avec les largeurs et données statistiques
$pdf->CustomTable($header_stats, $data_stats, $widths_stats_cols);


$pdf->Output();
?>
