<?php 
	/**
	 * 
	 */
	class MyOperation
	{
		private $nom_class, $ref_class_niveau, $class_session, $code_class;
		
		function __construct()
		{
			# code...
		}

		/**
		 * CORRECTION : division protégée contre la division par zéro.
		 */
		private function safeDiv($num, $den)
		{
			$num = (float)$num;
			$den = (float)$den;
			return ($den > 0) ? $num / $den : 0.0;
		}

		public function setNom_class($value)
		{
			$this->nom_class = $value;
		}
		public function getNom_class()
		{
			return $this->nom_class;
		}

		
		public function setRef_class_niveau($value)
		{
			$this->ref_class_niveau = $value;
		}
		public function getRef_class_niveau()
		{
			return $this->ref_class_niveau;
		}

		public function setClass_session($value)
		{
			$this->class_session = $value;
		}
		public function getClass_session()
		{
			return $this->class_session;
		}

		public function setCode_class($value)
		{
			$this->code_class = $value;
		}
		public function getCode_class()
		{
			return $this->code_class;
		}


		public function SelectClsbySession($ss)
		{
			$bdd = $GLOBALS['bdd'];
			$i=0;
			$nt=0;
			$reponse = $bdd->query('SELECT * FROM classes where class_session="'.$ss.'" order by ref_class_niveau asc');
			while($row = $reponse->fetch(PDO::FETCH_ASSOC)) 
			{

				echo'<div class="col-md-2 mb-3" style="background-color:#e7e501">
	                    <div class="dropdown" style="background-color:#e7e501">
	                      <button class="btn dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-expanded="false" style="background-color:#1a784f;color:white">
	                       '.$row['nom_class'].' 
	                      </button>
	                      <div class="dropdown-menu" style="background-color:#1a784f; color:white">
	                      	<a class="dropdown-item my-2" href="Controler/calculs/moyenne.php?cls='.$row['code_class'].'&trim=1" style="color:#e7e501">Moyenne TRIM 1</a>
	                    
	                  	 	<a class="dropdown-item my-2" href="Controler/calculs/moyenne.php?cls='.$row['code_class'].'&trim=2" style="color:#e7e501">Moyenne TRIM 2</a>
	                  	 	
	                       <a class="dropdown-item my-2" href="Controler/calculs/moyenne.php?cls='.$row['code_class'].'&trim=3" style="color:#e7e501">Moyenne TRIM 3</a>

	                       <a class="dropdown-item my-2" href="Controler/calculs/moyenne_an.php?cls='.$row['code_class'].'&trim=an" style="color:#e7e501">Moyenne ANNUEL</a>
	                        
	                      </div>
	                    </div>
                    </div>
				';
				}
					
			}

			public function Print_BULClsbySession($ss)
		{
			$bdd = $GLOBALS['bdd'];
			$i=0;
			$nt=0;
			$reponse = $bdd->query('SELECT * FROM classes where class_session="'.$ss.'" order by ref_class_niveau asc');
			while($row = $reponse->fetch(PDO::FETCH_ASSOC)) 
			{

				echo'<div class="col-md-4 mb-3" style="background-color:#e7e501">
	                    <div class="dropdown" style="background-color:#e7e501">
	                      <button class="btn dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-expanded="false" style="background-color:#1a784f; color:white">
	                       '.$row['nom_class'].' 
	                      </button>
	                      <div class="dropdown-menu" style="background-color:#1a784f; color:white">
	                        <a class="dropdown-item my-2" href="fpdf185/bul_cls.php?cls='.$row['code_class'].'&trim=1">TRIM 1
	                        </a>
	                 		 <a class="dropdown-item my-2" href="fpdf185/bul_cls.php?cls='.$row['code_class'].'&trim=2">TRIM 2</a>
	                 		  <a class="dropdown-item my-2" href="fpdf185/bul_cls.php?cls='.$row['code_class'].'&trim=3">TRIM 3</a>

	                 		   <a class="dropdown-item my-2" href="Controler/calculs/moyenne.php?cls='.$row['code_class'].'&trim=an">ANNUEL </a>  


	                        
	                      </div>
	                    </div>
                    </div>
				';
				}
					
			}
		

		public function ShowInfosStd_for_Note_by_Mat($cls,$mat,$seq)
		{
			$bdd = $GLOBALS['bdd'];

				$nom_cls=$this->ShowCls_namebyID($cls);
				$nom_mat=$this->ShowMat_namebyID($mat);

				echo '</tbody>
                        </table>
                             </div>
                            </div>
                     <div class="col-md-4 mt-5">
                        <h2 class="fw-bolder">POSTE DE SAISIE DE NOTE</h2>
                        <p class="text-primary">CLASSE: '.$nom_cls.' </p>
                        <p class="text-primary">MATIERE: '.$nom_mat.'</p>
                        <p class="text-primary">EVAL: '.$seq.'</p>
                        <button type="submit" class="btn btn-primary">Enrégistrer</button>
                    </form>
                    </div>                 
				'
				;
					
			}

			public function ShowNoteStd_by_MatCls($cls,$mat,$seq,$std)
		{
			$bdd = $GLOBALS['bdd'];
			$i=0;
			$nt=0;
			$reponse = $bdd->query('SELECT * FROM table_note_par_mat_eval'.$seq.' where (ref_cls="'.$cls.'" and ref_mat="'.$mat.'" and ref_eval="'.$seq.'" and ref_std="'.$std.'") order by note asc');
			while($row = $reponse->fetch(PDO::FETCH_ASSOC)) 
			{
				return $row['note'];
				}
		}

		public function CheckAbsStd_by_Cls($cls,$std,$trim)
		{
			$bdd = $GLOBALS['bdd'];
			// SÉCURISÉ : requête préparée anti-injection SQL
			$stmt = $bdd->prepare('SELECT id FROM absences WHERE ref_cls = ? AND ref_std = ? AND ref_trim = ? LIMIT 1');
			$stmt->execute(array($cls, $std, $trim));
			return (bool)$stmt->fetch();
		}

		public function ShowAbsStd_by_Cls($cls,$std,$trim)
		{
			$bdd = $GLOBALS['bdd'];
			// SÉCURISÉ : requête préparée anti-injection SQL
			$stmt = $bdd->prepare('SELECT heure FROM absences WHERE ref_cls = ? AND ref_std = ? AND ref_trim = ? LIMIT 1');
			$stmt->execute(array($cls, $std, $trim));
			$row = $stmt->fetch(PDO::FETCH_ASSOC);
			return $row ? $row['heure'] : '';
		}

		public function ShowMoy_by_Cls($cls,$trim)
		{
			$bdd = $GLOBALS['bdd'];
			$i=0;
			$nt=0;
			$reponse = $bdd->query('SELECT avg(moy) as moy_general FROM table_note_par_trim'.$trim.' where (ref_cls="'.$cls.'" and ref_trim="'.$trim.'" and classer="Y")');
			while($row = $reponse->fetch(PDO::FETCH_ASSOC)) 
			{
				return $row['moy_general'];
			}
		}

		public function ShowMoy_std_Cls_trim($cls,$trim,$std)
		{
			$bdd = $GLOBALS['bdd'];
			$i=0;
			$nt=0;
			$reponse = $bdd->query('SELECT moy FROM table_note_par_trim'.$trim.' where (ref_std="'.$std.'" and ref_cls="'.$cls.'" and ref_trim="'.$trim.'" and classer="Y")');
			while($row = $reponse->fetch(PDO::FETCH_ASSOC)) 
			{
				return $row['moy'];
			}
		}

		public function ShowMoy_1er_Cls($cls,$trim)
		{
			$bdd = $GLOBALS['bdd'];
			$i=0;
			$nt=0;
			$reponse = $bdd->query('SELECT max(moy) as moy_1er FROM table_note_par_trim'.$trim.' where (ref_cls="'.$cls.'" and ref_trim="'.$trim.'" and classer="Y")');
			while($row = $reponse->fetch(PDO::FETCH_ASSOC)) 
			{
				return $row['moy_1er'];
			}
		}

		public function ShowMoy_dern_Cls($cls,$trim)
		{
			$bdd = $GLOBALS['bdd'];
			$i=0;
			$nt=0;
			$reponse = $bdd->query('SELECT min(moy) as moy_dern FROM table_note_par_trim'.$trim.' where (ref_cls="'.$cls.'" and ref_trim="'.$trim.'" and classer="Y")');
			while($row = $reponse->fetch(PDO::FETCH_ASSOC)) 
			{
				return $row['moy_dern'];
			}
		}

		public function ShowNbre_TH_Cls($cls,$trim)
		{
			$bdd = $GLOBALS['bdd'];
			$i=0;
			$nt=0;
			$mar=12;
			$reponse = $bdd->query('SELECT * FROM table_note_par_trim'.$trim.' where (ref_cls="'.$cls.'" and ref_trim="'.$trim.'" and classer="Y")');
			while($row = $reponse->fetch(PDO::FETCH_ASSOC)) 
			{
				if ($row['moy']>=12) {
					$nt++;
				}
			}
			return $nt;
		}

		public function Ck_ExistMoy_by_Cls($cls,$trim)
		{
			$bdd = $GLOBALS['bdd'];
			$i=0;
			$nt=0;
			$reponse = $bdd->query('SELECT * FROM table_note_par_trim'.$trim.' where ((ref_cls="'.$cls.'" and ref_trim="'.$trim.'") and (classer="Y"))');
			while($row = $reponse->fetch(PDO::FETCH_ASSOC)) 
			{
				return true;
			}
		}

		public function ShowNbStd_for_TauxR_by_Cls($cls,$trim,$marge)
		{
			$bdd = $GLOBALS['bdd'];
			$i=0;
			$nt=0;
			$reponse = $bdd->query('SELECT count(moy) as nbmoy FROM table_note_par_trim'.$trim.' where (ref_cls="'.$cls.'" and ref_trim="'.$trim.'" and classer="Y" and moy>='.$marge.')');
			while($row = $reponse->fetch(PDO::FETCH_ASSOC)) 
			{
				return $row['nbmoy'];
			}
		}

		public function SelectCoef_by_MatCls($cls,$mat)
		{
			$bdd = $GLOBALS['bdd'];
			// SÉCURISÉ : requête préparée anti-injection SQL
			$reponse = $bdd->prepare('SELECT coeff_mat FROM config_bull WHERE ref_class = ? AND ref_mat = ? ORDER BY id ASC LIMIT 1');
			$reponse->execute(array($cls, $mat));
			$row = $reponse->fetch(PDO::FETCH_ASSOC);
			return $row ? (float)$row['coeff_mat'] : 0.0;
		}

		public function SelectGrp_by_MatCls($cls,$mat)
		{
			$bdd = $GLOBALS['bdd'];
			// SÉCURISÉ : requête préparée anti-injection SQL
			$reponse = $bdd->prepare('SELECT group_mat FROM config_bull WHERE ref_class = ? AND ref_mat = ? ORDER BY id ASC LIMIT 1');
			$reponse->execute(array($cls, $mat));
			$row = $reponse->fetch(PDO::FETCH_ASSOC);
			return $row ? (int)$row['group_mat'] : 0;
		}


		public function CalculMoy_by_MatCls($cls,$std,$eval,$ng1,$ng2,$ng3,$nq)
		{

			// CORRECTION SQL : l'ancienne écriture visait la table inexistante
			// "moy_seq_1_std" et utilisait la variable $ref_cls non définie
			// (le paramètre se nomme $cls). Aucune table ne stocke les moyennes
			// par évaluation : elles sont recalculées à la volée par
			// ShowMoy_Seq_Std() pour les bulletins. La méthode renvoie donc
			// désormais les quatre valeurs de groupes calculées.
			return array(
				'moy_g1'  => (float)$ng1,
				'moy_g2'  => (float)$ng2,
				'moy_g3'  => (float)$ng3,
				'moy_seq' => (float)$nq
			);
		}

		public function CalculMoy_Seq_by_Std_by_MatCls($cls,$seq,$std)
		{
			$bdd = $GLOBALS['bdd'];
			$i=0;
			$nt=0;
			$noteg1=0.0;
			$noteg2=0.0;
			$noteg3=0.0;
			$noteseq=0.0;
			$reponse2 = $bdd->query('SELECT * FROM table_note_par_mat_eval'.$seq.' where (ref_cls="'.$cls.'" and  ref_eval="'.$seq.'" and ref_std="'.$std.'")');
			while($row = $reponse2->fetch(PDO::FETCH_ASSOC)) 
			{
				
					$coeff=$this->SelectCoef_by_MatCls($cls,$row['ref_mat']);
					$grp=$this->SelectGrp_by_MatCls($cls,$row['ref_mat']);
					if($grp==1) 
					{
						$note1=(float)$row['note_x_coeff'];
						$noteg1+=$note1;

					}
					elseif ($grp==2) {
						$note2=(float)$row['note_x_coeff'];
						$noteg2+=$note2;
					}
					elseif ($grp==3) {
						$note3=(float)$row['note_x_coeff'];
						$noteg3+=$note3;
					}
			}
			$noteseq=$noteg1+$noteg2+$noteg3;
			// CORRECTION : retourne les groupes calculés (plus aucune écriture
			// vers la table inexistante moy_seq_1_std).
			return $this->CalculMoy_by_MatCls($cls,$std,$seq,$noteg1,$noteg2,$noteg3,$noteseq);
				
		}

		public function ShowEdit_Bul($code)
		{
			$bdd = $GLOBALS['bdd'];
			$i=0;
			$nt=0;
			$reponse = $bdd->query('SELECT * FROM config_bull where ref_class="'.$code.'" order by group_mat asc');
			while($row = $reponse->fetch(PDO::FETCH_ASSOC)) 
			{
				$i++;
				$nom_ens=$this->ShowUsernamebyID($row['ref_ens']);

				echo '
				<tr>
				<td id="id">'.$i.'</td>
                <td class="txt-oflo">'.$row['nom_mat'].'</td>
                <td>'.$row['coeff_mat'].'</td>
                <td>'.$row['group_mat'].'</td>
                 <td>'.$nom_ens.'</td>
               
                <td>
                 <button type="button" class="btn btn-danger btn-sm ml-2" data-bs-toggle="modal" data-bs-target="#mod_del'.$row['id'].'" data-whatever="@mdo">Supprimer <i class="fa fa-user fa-remove" aria-hidden="true"></i></button>
                  
					<div class="modal fade" id="mod_del'.$row['id'].'" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                      <div class="modal-dialog" role="document">
                        <div class="modal-content">
                          <div class="modal-header">
                            <h5 class="modal-title" id="exampleModalLabel">SUPPRIMER CETTE MATIERE</h5>
														<button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Fermer"></button>
                          </div>
                          <div class="modal-body">
                          		<h5 class="modal-title" id="exampleModalLabel">Nom de la matière: '.$row['nom_mat'].' <br>Voulez-vous supprimmer ? Cette action est irréversible.</h5>
                          		<a href="Controler/classes/del_mat_classe.php?id='.$row['id'].'&refcls='.$code.'" ><button  class="btn btn-primary">Oui</button></a>                  
                                       
                                </div>
                                <div class="modal-footer">
                                 
                               
                                	<button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Annuler</button>
                          		</div>
                        </div>
					</div></td>
                </tr>
				';
					
			}
			$nt=$i;
			$i=0;
				
		}

		public function Show_Ens_Class_and_Mat($code)
		{
			$bdd = $GLOBALS['bdd'];
			$i=0;
			$nt=0;
			$reponse = $bdd->query('SELECT * FROM config_bull where ref_ens="'.$code.'" order by group_mat asc');
			while($row = $reponse->fetch(PDO::FETCH_ASSOC)) 
			{
				$i++;
				$nom_cls=$this->ShowCls_namebyID($row['ref_class']);

				echo '
				
                 <button type="button" class="btn btn-danger btn-sm ml-2" data-bs-toggle="modal" data-bs-target="#mod_del'.$row['id'].'" data-whatever="@mdo">'.$row['id'].'<i class="fa fa-user fa-remove" aria-hidden="true"></i></button>
                  
					<div class="modal fade" id="mod_del'.$row['id'].'" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                      <div class="modal-dialog" role="document">
                        <div class="modal-content">
                          <div class="modal-header">
                            <h5 class="modal-title" id="exampleModalLabel">SUPPRIMER CETTE MATIERE</h5>
														<button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Fermer"></button>
                          </div>
                          <div class="modal-body">
                          		<h5 class="modal-title" id="exampleModalLabel">Nom de la matière: '.$row['nom_mat'].' <br>Voulez-vous supprimmer ? Cette action est irréversible.</h5>
                          		<a href="Controler/classes/del_mat_classe.php?id='.$row['id'].'&refcls='.$code.'" ><button  class="btn btn-primary">Oui</button></a>                  
                                       
                                </div>
                                <div class="modal-footer">
                                 
                               
                                	<button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Annuler</button>
                          		</div>
                        </div>
					</div></td>
                </tr>
				';
					
			}
			$nt=$i;
			$i=0;
				
		}

		public function ShowPeriodesEval()
		{
			$bdd = $GLOBALS['bdd'];
			$i=0;
			$nt=0;
			$reponse = $bdd->query('SELECT * FROM evaluations where id>=0 order by nom_seq asc');
			while($row = $reponse->fetch(PDO::FETCH_ASSOC)) 
			{
				$i++;
				if ($row['statut']=="O") {
					echo '<div class="form-check form-switch">
	                      	<label class="form-check-label" for="flexSwitchCheckChecked">'.$row['nom_seq'].'</label>
	                      	<input class="form-check-input" type="checkbox" role="switch" id="flexSwitchCheckChecked" name="'.$row['id'].'" value="'.$row['id'].'" checked>
                    		</div>';
				}
				else{
					echo '<div class="form-check form-switch">
	                      	<label class="form-check-label" for="flexSwitchCheckDefault">'.$row['nom_seq'].'</label>
	                      	<input class="form-check-input" type="checkbox" role="switch" id="flexSwitchCheckDefault" name="'.$row['id'].'" value="'.$row['id'].'">
                    		</div>
                            ';

				}

				
				}
		}
	


			

		public function NombreMatbyCls($cls)
		{
			$n=0;
			$ntotal=0;
			$bdd = $GLOBALS['bdd'];
			$reponse = $bdd->query("SELECT * FROM config_bull where ref_class='".$cls."' ");

			while($row=$reponse->fetch(PDO::FETCH_ASSOC)) 
			{ 
					$n++;
			}
				$ntotal= $n;
				return $ntotal;
		}

		public function NombreCoeffbyCls($cls)
		{
			$n=0;
			$ntotal=0;
			$val='';
			$i=0;

			$bdd = $GLOBALS['bdd'];
			$reponse = $bdd->query("SELECT * FROM config_bull where ref_class='".$cls."' ");

			while($row=$reponse->fetch(PDO::FETCH_ASSOC)) 
			{ 
					$val=$row['coeff_mat'];
					$i=(int)$val;
					$n+=$i;
			}
				$ntotal= $n;
				return $ntotal;
		}

		public function NombreCoeffbyStd_Cls($cls,$trim,$std)
		{
			$n=0;
			$ntotal=0;
			$val='';
			$i=0;

			$bdd = $GLOBALS['bdd'];
			$reponse = $bdd->query('SELECT * FROM table_note_par_mat_eval'.$trim.' where ((ref_cls="'.$cls.'") and (ref_std="'.$std.'") and (ref_eval="'.$trim.'"))');

			while($row=$reponse->fetch(PDO::FETCH_ASSOC)) 
			{ 
				if ($row['note']>=0) {
					
				 $c= $this->SelectCoef_by_MatCls($cls,$row['ref_mat']);
					$i=(int)$c;
					$n+=$i;			
					}
			}	
			return $n;
		}


		public function UdpCoeffbyStd_Cls($cls,$seq,$std,$mat,$coef)
		{

			$bdd = $GLOBALS['bdd'];
			$req1 ='UPDATE table_note_par_mat_eval'.$seq.' SET coef= ? where((ref_cls="'.$cls.'") and (ref_mat="'.$mat.'") and (ref_eval="'.$seq.'") and (ref_std="'.$std.'"))';
			$rep1 = $bdd->prepare($req1);
			$rep1->execute(array($coef));
							
			}

		public function ShowRang_Std($cls,$std,$trim)
		{
			
			$bdd = $GLOBALS['bdd'];
			$reponse = $bdd->query('SELECT * FROM table_note_par_trim'.$trim.' where ((ref_cls="'.$cls.'") and (ref_std="'.$std.'"))');
					$rang='';
					while(($row = $reponse->fetch(PDO::FETCH_ASSOC))) 
					{
						if ($row['classer']=='Y') {
							$rang=$row['rang'];
							return $rang;
						}else
						{
							$rang='NC';
							return $rang;
						}

		
					}
		}

		public function ShowRang_Std_Eval($cls,$std,$ev,$t_coef)
		{
		 	
		 	$tab_rang=array();

		 	$bdd = $GLOBALS['bdd'];
			$reponse0 = $bdd->query('SELECT * FROM eleves where ref_class="'.$cls.'" order by nom_std asc');
			while($row0 = $reponse0->fetch(PDO::FETCH_ASSOC)) 
			{
				$bdd=$GLOBALS['bdd'];
			 	$reponse = $bdd->query('SELECT sum(note_x_coeff) as total_pt FROM table_note_par_mat_eval'.$ev.' where ((ref_cls="'.$cls.'") and (ref_eval="'.$ev.'") and (ref_std="'.$row0['mat_std'].'"))');
					$rang=0;
					while(($row = $reponse->fetch(PDO::FETCH_ASSOC))) 
					{
						$cf_cls=$this->NombreCoeffbyCls($cls);
						$cf_cls=(float)$cf_cls;
						$t_pt=(float)$row['total_pt'];
						$t_c=(float)$t_coef;
						$marg=$this->safeDiv($t_c,$cf_cls);						

						if ($marg>=$GLOBALS['MargeCoeff_trim']) 
						{						
							$moy_seq=$this->safeDiv($t_pt,$t_c);
							$moy_seq=round($moy_seq,2);
						}
						else{
							$moy_seq=0;
						}
					}

					$tab_rang[''.$row0['mat_std'].'']=$moy_seq;
				}
						arsort($tab_rang);
						$n=0;
						foreach ($tab_rang as $key => $value) 
						{
							$n++;
							if ($key==$std) {
								break;
								
							}
						}

						$rang=$n;

						return $rang;

						
		}

		public function ShowTH_by_Eval($cls,$ev)
		{
		 	
		 	$tab_rang=array();
		 	$rang=0;
			$i=0;
			$Tot_moy=0;
			$nbTH=0;
			$Moy_G=0;

		 	$bdd = $GLOBALS['bdd'];
			$reponse0 = $bdd->query('SELECT * FROM eleves where ref_class="'.$cls.'" order by nom_std asc');
			while($row0 = $reponse0->fetch(PDO::FETCH_ASSOC)) 
			{
				$bdd=$GLOBALS['bdd'];
			 	$reponse = $bdd->query('SELECT sum(note_x_coeff) as total_pt FROM table_note_par_mat_eval'.$ev.' where ((ref_cls="'.$cls.'") and (ref_eval="'.$ev.'") and (ref_std="'.$row0['mat_std'].'"))');
					
				$tp_c_std=$this->ShowTotalCoeff_Seq_Std($cls,$row0['mat_std'],$ev);
					while(($row = $reponse->fetch(PDO::FETCH_ASSOC))) 
					{
						$cf_cls=$this->NombreCoeffbyCls($cls);
						$cf_cls=(float)$cf_cls;
						$t_pt=(float)$row['total_pt'];
						$t_c=(float)$tp_c_std;
						$marg=$this->safeDiv($t_c,$cf_cls);						

						if ($marg>=$GLOBALS['MargeCoeff_trim']) 
						{	
							$i++;					
							$moy_seq=$this->safeDiv($t_pt,$t_c);
							$moy_seq=round($moy_seq,2);
							$Tot_moy+=$moy_seq;

							if ($moy_seq>=12) {
								$nbTH++;
							}

						}
						else{
							$moy_seq=0;
						}
					}

				}
				if ($i>0 and $Tot_moy>0) 
				{

					$Moy_G=$this->safeDiv($Tot_moy,$i);
					$Moy_G=round($Moy_G,2);
						
				}
				else{
					$Moy_G=0;
				}

					return $nbTH;

						
		}

		public function ShowMoyG_by_Eval($cls,$ev)
		{
		 	
		 	$tab_rang=array();
		 	$rang=0;
			$i=0;
			$Tot_moy=0;
			$nbTH=0;
			$Moy_G=0;

		 	$bdd = $GLOBALS['bdd'];
			$reponse0 = $bdd->query('SELECT * FROM eleves where ref_class="'.$cls.'" order by nom_std asc');
			while($row0 = $reponse0->fetch(PDO::FETCH_ASSOC)) 
			{
				$bdd=$GLOBALS['bdd'];
			 	$reponse = $bdd->query('SELECT sum(note_x_coeff) as total_pt FROM table_note_par_mat_eval'.$ev.' where ((ref_cls="'.$cls.'") and (ref_eval="'.$ev.'") and (ref_std="'.$row0['mat_std'].'"))');
					$tp_c_std=$this->ShowTotalCoeff_Seq_Std($cls,$row0['mat_std'],$ev);
					while(($row = $reponse->fetch(PDO::FETCH_ASSOC))) 
					{
						$cf_cls=$this->NombreCoeffbyCls($cls);
						$cf_cls=(float)$cf_cls;
						$t_pt=(float)$row['total_pt'];
						$t_c=(float)$tp_c_std;
						$marg=$this->safeDiv($t_c,$cf_cls);						

						if ($marg>=$GLOBALS['MargeCoeff_trim']) 
						{	
							$i++;					
							$moy_seq=$this->safeDiv($t_pt,$t_c);
							$moy_seq=round($moy_seq,2);
							$Tot_moy+=$moy_seq;

							if ($moy_seq>=12) {
								$nbTH++;
							}

						}
						else{
							$moy_seq=0;
						}
					}

				}
				if ($i>0 and $Tot_moy>0) 
				{

					$Moy_G=$this->safeDiv($Tot_moy,$i);
					$Moy_G=round($Moy_G,2);
						
				}
				else{
					$Moy_G=0;
				}

					return $Moy_G;

						
		}

		public function ShowNbClasser_by_Eval($cls,$ev)
		{
		 	
		 	$tab_rang=array();
		 	$rang=0;
			$i=0;
			$Tot_moy=0;
			$nbTH=0;
			$Moy_G=0;

		 	$bdd = $GLOBALS['bdd'];
			$reponse0 = $bdd->query('SELECT * FROM eleves where ref_class="'.$cls.'" order by nom_std asc');
			while($row0 = $reponse0->fetch(PDO::FETCH_ASSOC)) 
			{
				$bdd=$GLOBALS['bdd'];
			 	$reponse = $bdd->query('SELECT sum(note_x_coeff) as total_pt FROM table_note_par_mat_eval'.$ev.' where ((ref_cls="'.$cls.'") and (ref_eval="'.$ev.'") and (ref_std="'.$row0['mat_std'].'"))');
					$tp_c_std=$this->ShowTotalCoeff_Seq_Std($cls,$row0['mat_std'],$ev);
					while(($row = $reponse->fetch(PDO::FETCH_ASSOC))) 
					{
						$cf_cls=$this->NombreCoeffbyCls($cls);
						$cf_cls=(float)$cf_cls;
						$t_pt=(float)$row['total_pt'];
						$t_c=(float)$tp_c_std;
						$marg=$this->safeDiv($t_c,$cf_cls);						

						if ($marg>=$GLOBALS['MargeCoeff_trim']) 
						{	
							$i++;					
							$moy_seq=$this->safeDiv($t_pt,$t_c);
							$moy_seq=round($moy_seq,2);
							$Tot_moy+=$moy_seq;

							if ($moy_seq>=12) {
								$nbTH++;
							}

						}
						else{
							$moy_seq=0;
						}
					}

				}
				if ($i>0 and $Tot_moy>0) 
				{

					$Moy_G=$this->safeDiv($Tot_moy,$i);
					$Moy_G=round($Moy_G,2);
						
				}
				else{
					$Moy_G=0;
				}

					return $i;

						
		}

		public function ShowNbMoy_by_Eval($cls,$ev,$marge)
		{
		 	
		 	$tab_rang=array();
		 	$rang=0;
			$i=0;
			$Tot_moy=0;
			$nbTH=0;
			$Moy_G=0;
			$nbmoy=0;

		 	$bdd = $GLOBALS['bdd'];
			$reponse0 = $bdd->query('SELECT * FROM eleves where ref_class="'.$cls.'" order by nom_std asc');
			while($row0 = $reponse0->fetch(PDO::FETCH_ASSOC)) 
			{
				$bdd=$GLOBALS['bdd'];
			 	$reponse = $bdd->query('SELECT sum(note_x_coeff) as total_pt FROM table_note_par_mat_eval'.$ev.' where ((ref_cls="'.$cls.'") and (ref_eval="'.$ev.'") and (ref_std="'.$row0['mat_std'].'"))');
					$tp_c_std=$this->ShowTotalCoeff_Seq_Std($cls,$row0['mat_std'],$ev);
					while(($row = $reponse->fetch(PDO::FETCH_ASSOC))) 
					{
						$cf_cls=$this->NombreCoeffbyCls($cls);
						$cf_cls=(float)$cf_cls;
						$t_pt=(float)$row['total_pt'];
						$t_c=(float)$tp_c_std;
						$marg=$this->safeDiv($t_c,$cf_cls);						

						if ($marg>=$GLOBALS['MargeCoeff_trim']) 
						{	
							$i++;					
							$moy_seq=$this->safeDiv($t_pt,$t_c);
							$moy_seq=round($moy_seq,2);
							$Tot_moy+=$moy_seq;

							if ($moy_seq>=12) {
								$nbTH++;
							}

						}
						else{
							$moy_seq=0;
						}

						if ($moy_seq>=$marge) {
							$nbmoy++;
						}
					}

				}
				if ($i>0 and $Tot_moy>0) 
				{

					$Moy_G=$this->safeDiv($Tot_moy,$i);
					$Moy_G=round($Moy_G,2);
						
				}
				else{
					$Moy_G=0;
				}

					return $nbmoy;

						
		}

		public function ShowMoyPosition_by_Eval($cls,$ev,$ps)
		{
		 	
		 	$tab_rang=array();
		 	$rang=0;
			$i=0;
			$Tot_moy=0;
			$nbTH=0;
			$Moy_G=0;

		
		 	$bdd = $GLOBALS['bdd'];
			$reponse0 = $bdd->query('SELECT * FROM eleves where ref_class="'.$cls.'" order by nom_std asc');
			while($row0 = $reponse0->fetch(PDO::FETCH_ASSOC)) 
			{
				$bdd=$GLOBALS['bdd'];
			 	$reponse = $bdd->query('SELECT sum(note_x_coeff) as total_pt FROM table_note_par_mat_eval'.$ev.' where ((ref_cls="'.$cls.'") and (ref_eval="'.$ev.'") and (ref_std="'.$row0['mat_std'].'"))');
					$tp_c_std=$this->ShowTotalCoeff_Seq_Std($cls,$row0['mat_std'],$ev);
					while(($row = $reponse->fetch(PDO::FETCH_ASSOC))) 
					{
						$cf_cls=$this->NombreCoeffbyCls($cls);
						$cf_cls=(float)$cf_cls;
						$t_pt=(float)$row['total_pt'];
						$t_c=(float)$tp_c_std;
						$marg=$this->safeDiv($t_c,$cf_cls);						

						if ($marg>=$GLOBALS['MargeCoeff_trim']) 
						{	
							$i++;					
							$moy_seq=$this->safeDiv($t_pt,$t_c);
							$moy_seq=round($moy_seq,2);
							$Tot_moy+=$moy_seq;

							if ($moy_seq>=12) {
								$nbTH++;
							}

						}
						else{
							$moy_seq=0;
						}
					}

					if ($moy_seq>0) 
					{
						$tab_rang[''.$row0['mat_std'].'']=$moy_seq;
					}
				
				}

					if (count($tab_rang) > 0) {
					if ($ps=='1er') {
						$outps=max($tab_rang);
					}
					else{
						$outps=min($tab_rang);
					}
				} else {
					// CORRECTION : max()/min() sur un tableau vide lève une ValueError en PHP 8
					$outps=0;
				}
						

					return $outps;

						
		}

		public function ShowMoy_Std($cls,$std,$trim)
		{
			
			$bdd = $GLOBALS['bdd'];
			$reponse = $bdd->query('SELECT * FROM table_note_par_trim'.$trim.' where ((ref_cls="'.$cls.'") and (ref_std="'.$std.'") and (ref_trim="'.$trim.'") )');
					$rang='';
					while(($row = $reponse->fetch(PDO::FETCH_ASSOC))) 
					{
						
						return $row['moy'];
		
					}
		}


		public function SelectNoteStd_by_MatCls($cls,$mat,$seq,$std)
		{
			$bdd = $GLOBALS['bdd'];
			$i=0;
			$nt=0;
			$pasden=NULL;
			$reponse = $bdd->query('SELECT * FROM table_note_par_mat_eval'.$seq.' where (ref_cls="'.$cls.'" and ref_mat="'.$mat.'" and ref_eval="'.$seq.'" and ref_std="'.$std.'") order by note asc');
			while($row = $reponse->fetch(PDO::FETCH_ASSOC)) 
			{
				if ($row['note']!=NULL) {
					return $row['note'];
				}
				else{
					return $pasden;
				}
			}
			
				
		}

		public function ShowMoy_Seq_Std($cls,$std,$seq,$t_coef)
		{
			
			$bdd = $GLOBALS['bdd'];
			$reponse = $bdd->query('SELECT sum(note_x_coeff) as total_pt FROM table_note_par_mat_eval'.$seq.' where ((ref_cls="'.$cls.'") and (ref_std="'.$std.'") and (ref_eval="'.$seq.'"))');
					$rang='';
					while(($row = $reponse->fetch(PDO::FETCH_ASSOC))) 
					{
						$cf_cls=$this->NombreCoeffbyCls($cls);
						$cf_cls=(float)$cf_cls;
						$t_pt=(float)$row['total_pt'];
						$t_c=(float)$t_coef;
						$marg=$this->safeDiv($t_c,$cf_cls);						
						if ($marg>=$GLOBALS['MargeCoeff_trim']) 
						{						
							$moy_seq=$this->safeDiv($t_pt,$t_c);
							$moy_seq=round($moy_seq,2);
						}
						else{
							$moy_seq=0;
						}
						
						return $moy_seq;
		
					}
		}

		public function ShowTotalPoints_Seq_Std($cls,$std,$seq)
		{
			
			$bdd = $GLOBALS['bdd'];
			$reponse = $bdd->query('SELECT sum(note_x_coeff) as total_pt FROM table_note_par_mat_eval'.$seq.' where ((ref_cls="'.$cls.'") and (ref_std="'.$std.'") and (ref_eval="'.$seq.'"))');
					$rang='';
					while(($row = $reponse->fetch(PDO::FETCH_ASSOC))) 
					{
						$t_pt=(float)$row['total_pt'];					
						return $t_pt;
					}
		}

		public function ShowTotalCoeff_Seq_Std($cls,$std,$seq)
		{
			
			$bdd = $GLOBALS['bdd'];
			$reponse = $bdd->query('SELECT sum(coef) as total_coef FROM table_note_par_mat_eval'.$seq.' where ((ref_cls="'.$cls.'") and (ref_std="'.$std.'") and (ref_eval="'.$seq.'"))');
					$rang='';
					while(($row = $reponse->fetch(PDO::FETCH_ASSOC))) 
					{
						$t_c=(float)$row['total_coef'];
						return $t_c;
					}
		}

		public function ShowClasser_Std($cls,$std,$trim)
		{
			
			$bdd = $GLOBALS['bdd'];
			$reponse = $bdd->query('SELECT * FROM table_note_par_trim'.$trim.' where ((ref_cls="'.$cls.'") and (ref_std="'.$std.'"))');
					
					while(($row = $reponse->fetch(PDO::FETCH_ASSOC))) 
					{
						
						return $row['classer'];
					}


		}

		public function ShowAllOpt()
		{
			$bdd = $GLOBALS['bdd'];
			$i=0;
			$nt=0;
			$nv="";
			$reponse = $bdd->query('SELECT id, ref_user, ref_nom, ref_role, DATE_FORMAT(last_con, \'%d/%m/%Y à %H:%i:%s\') AS date_fr FROM his_con where id>=0 order by last_con desc limit 30');
			while($row = $reponse->fetch(PDO::FETCH_ASSOC)) 
			{
			   $i++;
			    
				echo '
				<tr>
				<td id="id">'.$i.'</td>             
                <td>'.$row['ref_user'].'</td>
                <td>'.$row['ref_nom'].'</td>
                <td class="txt-oflo">'.$row['ref_role'].'</td>
                <td>'.$row['date_fr'].'</td>
                	
                </tr>
				';
					
			}
			$nt=$i;
			$i=0;
				
		}

		public function NbrStudentClasserByClass($cls,$trim)
		{
			
			$bdd = $GLOBALS['bdd'];
			$reponse = $bdd->query('SELECT * FROM table_note_par_trim'.$trim.' where (ref_cls="'.$cls.'")');
					$i=0;
					$n=0;
					while(($row = $reponse->fetch(PDO::FETCH_ASSOC))) 
					{

						if ($row['classer']=='Y') {
							$i++;
						}				
					}
					$n=$i;
					return $n;
		}


		public function NombreClasses()
		{
			$n=0;
			$ntotal=0;
			$bdd = $GLOBALS['bdd'];
			$reponse = $bdd->query("SELECT * FROM classes where id>=1 ");

			while($row = $reponse->fetch(PDO::FETCH_ASSOC)) 
			{ 
					$n++;
			}
				$ntotal= $n;
				return $ntotal;
		}

		public function NbrStudentByClass($code)
		{

			$bdd = $GLOBALS['bdd'];	
			$i=0;
			$n=0;
			$reponse = $bdd->query('SELECT * FROM eleves where ref_class="'.$code.'"  ');
			while (($row = $reponse->fetch(PDO::FETCH_ASSOC))) 
			{
				$i++;

			}
			$n=$i;
			return $n;
		}

		public function NbrBySexeByClass($code,$sexe)
		{

			$bdd = $GLOBALS['bdd'];	
			$i=0;
			$n=0;
			$reponse = $bdd->query('SELECT * FROM eleves where ref_class="'.$code.'"  ');
			while (($row = $reponse->fetch(PDO::FETCH_ASSOC))) 
			{
				if ($row['sexe_std']==$sexe) {
					$i++;
				}			

			}
			$n=$i;
			return $n;
		}

		public function NbrSdt_Notes_ON_by_Cls($code,$ev,$mat)
		{

			$bdd = $GLOBALS['bdd'];	
			$i=0;
			$n=0;
			$reponse = $bdd->query('SELECT * FROM table_note_par_mat_eval'.$ev.' where (ref_cls="'.$code.'") and (ref_eval="'.$ev.'") and (ref_mat="'.$mat.'") ');
			while (($row = $reponse->fetch(PDO::FETCH_ASSOC))) 
			{

				$i++;

			}
			$n=$i;
			return $n;
		}

		public function CkExistingCode($code)
		{

			$bdd = $GLOBALS['bdd'];	

			$reponse = $bdd->query('SELECT * FROM classes where code_class="'.$code.'" ');
			while (($row = $reponse->fetch(PDO::FETCH_ASSOC))) 
			{
				return true;
			}
		}

		public function delClasse($code)
		{
			$bdd = $GLOBALS['bdd'];

			$req = 'DELETE FROM classes WHERE code_class=?';
			$rep = $bdd->prepare($req);
			if($rep->execute(array($code)))
			{
				return true;
			}else{
				return false;
			}
		}

		public function delMatbyClasse($id,$cls)
		{
			$bdd = $GLOBALS['bdd'];

			// CORRECTION : récupère la matière concernée avant suppression puis
			// efface les compétences avec les bons paramètres (ref_class=$cls, ref_mat=$ref_mat).
			$stmt_find = $bdd->prepare('SELECT ref_mat FROM config_bull WHERE id = ? LIMIT 1');
			$stmt_find->execute(array($id));
			$row_find = $stmt_find->fetch(PDO::FETCH_ASSOC);
			$ref_mat = ($row_find ? $row_find['ref_mat'] : '');

			$req = 'DELETE FROM config_bull WHERE id=? ';
			$rep = $bdd->prepare($req);
			if($rep->execute(array($id)))
			{
				if ($ref_mat !== '') {
					$reqi = 'DELETE FROM competences_matieres WHERE ref_class=? AND ref_mat=? ';
					$repi = $bdd->prepare($reqi);
					$repi->execute(array($cls, $ref_mat));
				}

				return true;
			}else{
				return false;
			}
		}

		public function delVsmtbyClasse($cls)
		{
			$bdd = $GLOBALS['bdd'];

			$reponse = $bdd->query('SELECT * FROM eleves where ref_class="'.$cls.'"  ');
			while (($row = $reponse->fetch(PDO::FETCH_ASSOC))) 
			{
				$bdd = $GLOBALS['bdd'];
				$req = 'DELETE FROM versements WHERE ref_std=? ';
				$rep = $bdd->prepare($req);
				$rep->execute(array($row['mat_std']));
			}
			
		 }

		 public function delRemisesbyClasse($cls)
		{
			$bdd = $GLOBALS['bdd'];

			$reponse = $bdd->query('SELECT * FROM eleves where ref_class="'.$cls.'"  ');
			while (($row = $reponse->fetch(PDO::FETCH_ASSOC))) 
			{
				$bdd = $GLOBALS['bdd'];
				$req = 'DELETE FROM remises WHERE ref_std=? ';
				$rep = $bdd->prepare($req);
				$rep->execute(array($row['mat_std']));
			}
			
		 }


}
	$opt = new MyOperation();

?>