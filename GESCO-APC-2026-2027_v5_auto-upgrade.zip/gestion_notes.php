<?php
    session_start();   
	require_once 'core/require.php'; 
	require_once 'Model/connexion.php';
     if (!isset($_SESSION['user'])) {
    session_unset();
    session_destroy();
    header('location: index.php');    
    }

    $etb->ShowEtb();
    $etb->CkLE();
    $etb->ckexneE();
?>

<!DOCTYPE html>
<html>
	<head>
	 <?php Config::head(); ?>
		<title>Ndalère Tools|Notes</title>

    <style type="text/css">
      .slimscrollsidebar>ul,li{
        font-size: 0.9em;
      }
    </style>
	</head>

<body class="fix-header">
     <!-- #header -->
     <?php Head::SimpleHead($_SESSION['user_role']); ?>    
        <!-- Page Content -->
        <!-- ============================================================== -->
        <div id="page-wrapper">
            <div class="container-fluid">

 
                <div class="row">
                    <div class="accordion" id="accordionExample">
                      <div class="accordion-item">
                        <h2 class="accordion-header">
                          <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#collapseOne" aria-expanded="false" aria-controls="collapseOne">
                            <h2 class="fw-bolder" >Poste de Saisie </h2>
                          </button>
                        </h2>
                        <div id="collapseOne" class="accordion-collapse collapse show" data-bs-parent="#accordionExample">
                          <div class="accordion-body">
                            <strong><div class="container-fluid">                               
                                <div class="row">
                                   <div class="col-md-4 ">
                                     <h5 class="fw-bolder" >NOM DE L'ETABLISSEMENT</h5>
                                    </div>
                                  <div class="col-md-4">
                                    <form action="Controler/school/updetb.php" method="post" enctype=multipart/form-data >  
                                                          
                                        <label for="inputEmail4"><i style="color:#e63f32"><?php echo $_SESSION['nom_etb_fr']; ?> </i></label>

                                        <input type="text" class="form-control col-4 text-uppercase" id="nom_etb_fr" name="nom_etb_fr"  maxlength="50">
                                    </div>

                                    <div class="col-md-4 ">
                                          <label for="inputEmail4"> <i style="color:#e63f32"><?php echo $_SESSION['nom_etb_en']; ?> </i></label>
                                          <input type="text" class="form-control col-4 text-uppercase" id="nom_etb_en" name="nom_etb_en"  maxlength="50" >
                                    </div>   
                                   </div>
                                   <div class="row">
                                     <div class="col-md-4 ">
                                     <h5 class="fw-bolder" >MINISTERE</h5>
                                    </div>
                                    <div class="col-md-4 ">
                                          <label for="inputEmail4"> <i style="color:#e63f32"><?php echo $_SESSION['minist_etb_fr']; ?> </i></label>
                                          <input type="text" class="form-control col-4 text-uppercase" id="minist_etb_fr" name="minist_etb_fr"  maxlength="50" >
                                    </div>                         
                                    
                                    <div class="col-md-4">
                                     <label for="inputEmail4"><i style="color:#e63f32"><?php echo $_SESSION['minist_etb_en']; ?> </i></label>
                                          <input type="text" class="form-control col-4 text-uppercase" id="minist_etb_en" name="minist_etb_en"  maxlength="50" >
                                          
                                      </select>
                                     </div>
                                     </div>                           
                                  <div class="row ">
                                   <div class="col-md-4 ">
                                     <h5 class="fw-bolder" >REGION</h5>
                                    </div>                  
                                    <div class="col-md-4 ">
                                        <label for="inputEmail4">:<i style="color:#e63f32"><?php echo $_SESSION['region_etb_fr']; ?> </i></label>
                                        <input type="text" class="form-control" id="region_etb_fr" name="region_etb_fr"  >
                                    </div>
                                    <div class="col-md-4 ">
                                        <label for="inputEmail4"><i style="color:#e63f32"><?php echo $_SESSION['region_etb_en']; ?> </i></label>
                                        <input type="text" class="form-control text-uppercase" id="region_etb_en" name="region_etb_en"  maxlength="50"  >
                                    </div>
                                </div>
                               
                                  <div class="row ">
                                   <div class="col-md-4 ">
                                     <h5 class="fw-bolder" >DEPARTEMENT</h5>
                                    </div>                  
                                    <div class="col-md-4 ">
                                        <label for="inputEmail4"><i style="color:#e63f32"><?php echo $_SESSION['depart_etb_fr']; ?> </i></label>
                                        <input type="text" class="form-control" id="depart_etb_fr" name="depart_etb_fr"  >
                                    </div>
                                    <div class="col-md-4 ">
                                        <label for="inputEmail4"><i style="color:#e63f32"><?php echo $_SESSION['depart_etb_en']; ?> </i></label>
                                        <input type="text" class="form-control text-uppercase" id="depart_etb_en" name="depart_etb_en"  maxlength="50"  >
                                    </div>
                                </div>

                                 <div class="row ">
                                   <div class="col-md-4 ">
                                     <h5 class="fw-bolder">BOITE POSTALE/ TELEPHONE</h5>
                                    </div>                  
                                    <div class="col-md-4 ">
                                        <label for="inputEmail4"><i style="color:#e63f32"><?php echo $_SESSION['code_pste_etb']; ?> </i></label>
                                        <input type="text" class="form-control" id="code_pste_etb" name="code_pste_etb"  >
                                    </div>
                                    <div class="col-md-4 ">
                                        <label for="inputEmail4"><i style="color:#e63f32"><?php echo $_SESSION['tel_etb']; ?> </i></label>
                                        <input type="text" class="form-control text-uppercase" id="tel_etb" name="tel_etb"  maxlength="50"  >
                                    </div>
                                </div>

                                 <div class="row mb-2">
                                   <div class="col-md-4 ">
                                     <h5 class="fw-bolder" >MATRICULE / EMAIL</h5>
                                    </div>                  
                                    <div class="col-md-4 ">
                                        <label for="inputEmail4"><i style="color:#e63f32"><?php echo $_SESSION['code_im_etb']; ?> </i></label>
                                        <input type="text" class="form-control" id="code_im_etb" name="code_im_etb"  >
                                    </div>
                                    <div class="col-md-4 ">
                                        <label for="inputEmail4"><i style="color:#e63f32"><?php echo $_SESSION['email_etb']; ?> </i></label>
                                        <input type="text" class="form-control text-uppercase" id="email_etb" name="email_etb"  maxlength="50"  >
                                    </div>
                                </div>

                                <div class="row mb-4">
                                 <div class="col-md-4 ">
                                     <h5 class="fw-bolder" >LOGO + SIGNATURE DU PRINCIPAL Fichier PNG ou JPG de (128x128)</h5>
                                    </div>                     
                                    <div class="col-md-4 ">
                                        <div class="card w-100" style="max-width: 27rem;"><label for="inputEmail4">LOGO</label>
                                          <img src="plugins/images/<?php echo $_SESSION['logo_etb']; ?>" class="card-img-center text-center" alt="photo" width="135px" height="120px">
                                          <div class="card-body">
                                        <input type="file" class="form-control " id="support1" name="support1"  >
                                        </div>
                                      </div>
                                    </div>
                                    <div class="col-md-4 ">
                                        <div class="card w-100" style="max-width: 27rem;"><label for="inputEmail4">SIGNATURE</label>
                                           <img src="plugins/images/<?php echo $_SESSION['sign_respo_etb']; ?>" class="card-img-left" alt="photo"  width="135px" height="120px">
                                          <div class="card-body">
                                             
                                        <input type="file" class="form-control " id="support2" name="support2"  >
                                        </div>
                                      </div>
                                    </div>
</div>
                                 <div class="row mb-2 align-items-center">
                                    <div class="col-md-4 ">
                                      <h5 class="fw-bolder" >CACHET SUR LES BULLETINS</h5>
                                     </div>                  
                                     <div class="col-md-4 ">
                                         <label for="inputEmail4"><i style="color:#e63f32"><?php echo ($_SESSION['p_ch'] ?? 'N') === 'O' ? 'Afficher le cachet' : 'Ne pas afficher le cachet'; ?> </i></label>
                                         <select class="form-select" id="p_ch" name="p_ch">
                                           <option value="N" <?php echo ($_SESSION['p_ch'] ?? 'N') === 'O' ? '' : 'selected'; ?>>NON — masquer le cachet</option>
                                           <option value="O" <?php echo ($_SESSION['p_ch'] ?? 'N') === 'O' ? 'selected' : ''; ?>>OUI — imprimer le cachet de l'établissement</option>
                                         </select>
                                     </div>
                                 </div>
                                 <div class="row text-right"> 
                                    <button type="submit" class="btn btn-primary">Enrégistrer</button>
                                  </form>
                                  </div>
                              </div>
                          </div>
                        </div>
                      </div>
                      <div class="accordion-item">
                        <h2 class="accordion-header">
                          <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
                           <h2 class="fw-bolder" >PARAMETRE DES DROITS</h2>
                          </button>
                        </h2>
                        <div id="collapseTwo" class="accordion-collapse collapse" data-bs-parent="#accordionExample">
                          <div class="accordion-body">
                            <strong>Définir les droits aux utilisateurs</strong>
                            <form action="Controler/admins/updroleuser.php" method="post" enctype=multipart/form-data>
                                <div class="row">
                                    <div class=" col-10 col-sm-6">
                                        <label for="exampleInputEmail1" class="form-label">Utilisateur</label>
                                        <select class="form-select form-select-lg mb-2" aria-label=".form-select-lg example" name="user">
                                          <option value="" >Choisir...</option>
                                             <?php $user->SelectTeacherAndRole(); ?> 
                                        </select>
                                    </div>
                                    <div class="col-10 col-sm-4">
                                        <label for="exampleInputEmail1" class="form-label">Rôle</label>

                                       <select id="inputState" class="form-control" name="user_role" required>
                                        <option value="" >Choisir...</option>
                                         <option value="ens">Enseignat</option>
                                        <option value="pcpl">Principal</option>
                                        <option value="admin">Administrateur</option>
                                        <option value="caisse">Caissier</option>
                                         </select>
                                    </div>
                                    <div class="col-10 col-sm-2">
                                        <label for="exampleInputEmail1" class="form-label">Opération</label>
                                        <button class="btn btn-primary" type="submit">Enregistrer</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                      </div>
                      <div class="accordion-item">
                        <h2 class="accordion-header">
                          <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
                            <h2 class="fw-bolder" >Activer/Désactiver les périodes</h2>
                          </button>
                        </h2>
                        <div id="collapseThree" class="accordion-collapse collapse" data-bs-parent="#accordionExample">
                          <div class="accordion-body">
                            <strong>This is the third item's accordion body.</strong> It is hidden by default, until the collapse plugin adds the appropriate classes that we use to style each element. These classes control the overall appearance, as well as the showing and hiding via CSS transitions. You can modify any of this with custom CSS or overriding our default variables. It's also worth noting that just about any HTML can go within the <code>.accordion-body</code>, though the transition does limit overflow.
                          </div>
                        </div>
                      </div>
                    </div>
                </div>
                <!-- ============================================================== -->
                <!-- Gestion des Classes -->

                 <div class="row">
       

                    <div class="modal fade" id="addclasse" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                      <div class="modal-dialog" role="document">
                        <div class="modal-content">
                          <div class="modal-header">
                            <h5 class="modal-title" id="exampleModalLabel">Ajouter une classe</h5>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                              <span aria-hidden="true">&times;</span>
                            </button>
                          </div>
                          <div class="modal-body">
                           <form action="Controler/classes/addclasse.php" method="post" >
                                <div class="form-row">
                                    <div class="form-group col-4 ">
                                        <label for="inputEmail4">Nom de la classe: </label>
                                        <input type="text" class="form-control" id="nom_class" name="nom_class"  maxlength="10"   required>
                                    </div>
                                    <div class="form-group col-4 ">
                                        <label for="inputState">Niveau</label>
                                         <select id="inputState" class="form-control" name="niveau" required>
                                            <option >Choisir...</option>
                                            <option value="1">6EME / F1 / 1E_AN</option>
                                            <option value="2">5EME / F2 / 2E_AN</option>
                                            <option value="3">4EME / F3 / 3E_AN</option>
                                            <option value="4">3EME / F4 / 4E_AN</option>
                                            <option value="5">2NDE / F5 </option>
                                            <option value="6">1ERE / L6 </option>
                                            <option value="7">TLE / U6 </option>
                                        
                                        </select>
                                    </div>

                                    <div class="form-group col-4  ">
                                            <label for="inputState">Section</label>
                                            <select id="inputState" class="form-control" name="session"  required="true" required>
                                                <option >Choisir...</option>
                                                <option value="SFG">SF E.Général</option>
                                                <option value="SAG">SA E.Général</option>
                                                <option value="SFT">SF E.Technique</option>
                                                <option value="SAT">SA E.Technique</option>
                                            </select>
                                    </div>
                                       <button type="submit" class="btn btn-primary">Enrégistrer</button>
                                </form>
                                </div>
  
                                </div>
                                <div class="modal-footer">
                                    
                                 
                                <button type="button" class="btn btn-secondary" data-dismiss="modal">Annuler</button>
                          </div>
                        </div>
                      </div>
                </div>
        </div>
                
            </div>
           
        <?php 
            Footers::TDfoot();
        ?>
        </div>
        <!-- ============================================================== -->
        <!-- End Page Content -->
        <!-- ============================================================== -->
    </div>


		<?php 
		 	Config::scriptJs();
		?>
        <script type="text/javascript">
            $('#exampleModal').on('show.bs.modal', function (event) {
  var button = $(event.relatedTarget) // Button that triggered the modal
  var recipient = button.data('whatever') // Extract info from data-* attributes
  // If necessary, you could initiate an AJAX request here (and then do the updating in a callback).
  // Update the modal's content. We'll use jQuery here, but you could use a data binding library or other methods instead.
  var modal = $(this)
  modal.find('.modal-title').text('New message to ' + recipient)
  modal.find('.modal-body input').val(recipient)
})
        </script>
	</body>
</html>