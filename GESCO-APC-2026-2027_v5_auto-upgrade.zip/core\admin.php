<?php 
/**
 * Classe de Gestion des Administrateurs et Authentifications
 * Projet: GESCO-APC
 * Mise à jour de sécurité - INOFIB 2026
 */
class MyAdmins
{
    private $login, $password;
    
    function __construct()
    {
        # code...
    }

    public function setLogin($value)
    {
        $this->login = $value;
    }
    public function getLogin()
    {
        return $this->login;
    }

    public function setPassword($value)
    {
        $this->password = $value;
    }
    public function getPassword()
    {
        return $this->password;
    }

    /**
     * Méthode unique et sécurisée d'authentification demandée par check.php
     * Gère à la fois le hachage sécurisé BCRYPT et l'ancien format texte brut
     */
    public function authentifier($login, $password) {
        $bdd = $GLOBALS['bdd'];	
        
        // Préparation de la requête pour bloquer les injections SQL
        $stmt = $bdd->prepare('SELECT * FROM admins WHERE login = ? LIMIT 1');
        $stmt->execute(array($login));
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($row) {
            // Double vérification : accepte les mots de passe BCRYPT de production
            // ET les mots de passe en clair pour la phase de développement/test
            if (password_verify($password, $row['password']) || $password === $row['password']) {
                
                // Hydratation des variables de session nécessaires à l'application
                $_SESSION['user'] = $row['id'];
                $_SESSION['login'] = $row['login'];
                $_SESSION['user_role'] = $row['role'];
                $_SESSION['username'] = $row['username'];
                $_SESSION['password'] = $row['password'];
                
                return true;
            }
        }
        return false;
    }

    public function AddAdmin()
    {
        $bdd = $GLOBALS['bdd'];	

        $req ='INSERT INTO admins (login, password) VALUES(?, ?)';
        $rep = $bdd->prepare($req);
        $rep->execute(array($this->login, $this->password));
        if ($rep) {
            return true;
        } else {
            return false;
        }
    }

    public function UpdAdmin($id)
    {
        $bdd = $GLOBALS['bdd'];	
        // SÉCURISÉ : requête préparée anti-injection SQL
        $req ='UPDATE admins SET login= ?, password= ? where id=?';
        $rep = $bdd->prepare($req);
        $rep->execute(array($this->login, $this->password, $id));
        if ($rep) {
            return true;
        } else {
            return false;
        }
    }

    /**
     * Ancienne méthode conservée temporairement pour la rétrocompatibilité des anciens scripts
     */
    public function ckconM($login)
    {
        $bdd = $GLOBALS['bdd'];	
        // SÉCURISÉ : requête préparée anti-injection SQL
        $rep = $bdd->prepare('SELECT * FROM admins where login=?');
        $rep->execute(array($login));
        $reponse = $rep;
        if(($row = $reponse->fetch(PDO::FETCH_ASSOC)))
        {
            $_SESSION['user'] =$row['id'];
            $_SESSION['login'] =$row['login'];
            $_SESSION['user_role'] =$row['role'];
            $_SESSION['username'] =$row['username'];
            $_SESSION['password'] =$row['password'];

            return true;
        } else {
            session_unset();
            session_destroy();
            header('location: index.php');
            return false;
        }
    }

    /**
     * Ancienne méthode conservée temporairement pour la rétrocompatibilité des anciens scripts
     */
    public function ckconP($pw)
    {
        $bdd = $GLOBALS['bdd'];	
        // SÉCURISÉ : requête préparée anti-injection SQL
        $rep = $bdd->prepare('SELECT * FROM admins where password=?');
        $rep->execute(array($pw));
        $reponse = $rep;
        if(($row = $reponse->fetch(PDO::FETCH_ASSOC)))
        {	
            return true;
        } else {
            session_unset();
            session_destroy();
            header('location: index.php');
            return false;
        }
    }

    public function ShowAdmin($id)
    {
        $bdd = $GLOBALS['bdd'];	
        // CORRECTION : la recherche se fait par LOGIN (tous les appels passent $_SESSION['login'])
        // SÉCURISÉ : requête préparée anti-injection SQL
        $rep = $bdd->prepare('SELECT * FROM admins where login=?');
        $rep->execute(array($id));
        $reponse = $rep;
        while (($row = $reponse->fetch(PDO::FETCH_ASSOC))) 
        {
            $_SESSION['login'] =$row['login'];
            $_SESSION['role'] =$row['role'];
            $_SESSION['master_cls'] =$row['master_cls'];
            $_SESSION['password'] =$row['password'];
        }
    }

    public function delAdmin($id)
    {
        $bdd = $GLOBALS['bdd'];

        $req = "DELETE FROM admins WHERE id= ? ";
        $rep = $bdd->prepare($req);
        if($rep->execute(array($id))){
            return true;
        } else {
            return false;
        }
    }
}

// Instanciation de la variable globale appelée par le contrôleur check.php
$admin = new MyAdmins();
?>
