﻿<?php
    session_start();   
	require_once 'core/require.php'; 
	require_once 'Model/connexion.php';
     if (!isset($_SESSION['user'])) {
    session_unset();
    session_destroy();
    header('location: index.php');    
    }
    $admin->ShowAdmin($_SESSION['login']);
    $nbclasses=$class->NombreClasses();
    $etb->ShowEtb();
    $etb->CkLE();
    $etb->ckexneE();

$id_ens = $_SESSION['login'];
$user_role = $_SESSION['user_role'];
$e1=0;
$e2=0;
$nom_trim='';
?>

<!DOCTYPE html>
<html>
  <head>
   <?php Config::head(); ?>
    <title>GESCOAPC| Classes</title>
  </head>

<body data-imprimable="1">
    <div class="wrapper">
      <!-- Sidebar -->

      <!-- Inclusion du menu de navigation externe réutilisable -->
<?php include 'core/sidebar.php'; ?>  

    <?php if (isset($_GET['ref_class']) and isset($_GET['ref_mat']) and isset($_GET['trim']) and isset($_GET['ref_std'])) 
    {
      $nom_cls=$class->ShowCls_namebyID($_GET['ref_class']);
      $nom_mat=$class->ShowMat_namebyID($_GET['ref_mat']);

      if (htmlspecialchars($_GET['trim'])=='t1') 
      {
        $e1=1;
        $e2=2;
        $nom_trim='TRIM 1';
      }
      elseif(htmlspecialchars($_GET['trim'])=='t2') {
        $e1=3;
        $e2=4;
        $nom_trim='TRIM 2';
      }
      elseif (htmlspecialchars($_GET['trim'])=='t3') 
      {
        $e1=5;
        $e2=6;
        $nom_trim='TRIM 3';
      }
      else{
         header('location: poste_de_saisie_std.php?trim=t1');  
      }
    }
    ?>

<div class="main-content-wrapper">
        <!-- Barre supérieure de navigation adaptative -->
        <div class="mobile-navbar-fixed p-3 mb-4 rounded shadow-sm border">
            <div class="row align-items-center g-2">
                <div class="col-auto d-md-none">
                    <button class="btn btn-outline-dark btn-sm" id="toggleMobileMenu"><i class="fa fa-bars fa-lg"></i></button>
                </div>
                <div class="col-12 col-md">
                    <h4 class="m-0 fw-bold text-primary text-uppercase">Saisie des notes par élève</h4>
                </div>
                <div class="col-12 col-md-auto d-flex justify-content-md-end flex-wrap gap-1">
                    <a href="poste_de_saisie_std.php?trim=t1&ref_class=<?php echo $_GET['ref_class'];?>&ref_mat=<?php echo $_GET['ref_mat'];?> " class="btn btn-outline-danger btn-sm">Retour <i class="ms-2 fa fa-arrow-left"></i></a>
                    <a href="gestion_notes_by_mat_std.php?trim=<?php echo $_GET['trim'] ;?>&ref_class=<?php echo $_GET['ref_class'] ;?>&ref_mat=<?php echo $_GET['ref_mat'] ;?>&ref_std=<?php echo $_GET['ref_std'] ;?>" class="btn btn-outline-success btn-sm">Actualiser <i class="ms-2 fa fa-refresh"></i></a>
                </div>
            </div>
        </div>
        <?php if (!empty($nom_trim) && !empty($nom_cls) && !empty($nom_mat)): ?>
        <div class="card border-info mb-3 shadow-sm">
            <div class="card-header bg-info text-white py-1"><h6 class="mb-0">Infos Remplacement</h6></div>
            <div class="card-body py-2">
                <small><strong>Trimestre :</strong><?php echo ' '.$nom_trim.'   //   '; ?> <strong>Classe :</strong><?php echo ' '.$nom_cls.'   //  '; ?> <strong>Matière :</strong><?php echo ' '.$nom_mat; ?></small>
            </div>
        </div>
        <?php else: ?>
        <div class="card border-info mb-3 shadow-sm">
            <div class="card-body py-2"><small class="text-muted">Sélectionnez trimestre, classe et matière.</small></div>
        </div>
        <?php endif; ?>

<?php 
      
echo '
      <div class="container-fluid mt-3">
       <div class="row mt-3">
    <div class="col-md-11 mt-5 py-4" style="font-size:0.7em">

    <input type="hidden" id="ref_class" value="'.htmlspecialchars($_GET['ref_class']).'">
    <input type="hidden" id="ref_mat" value="'.htmlspecialchars($_GET['ref_mat']).'">
    <input type="hidden" id="ref_eval1" value="'.$e1.'">
    <input type="hidden" id="ref_eval2" value="'.$e2.'">
    
    <div style="max-height: 500px; overflow-y: auto;">
        <table class="table-custom table-custom-striped table-custom-hover table-sm">
            <thead class="table-dark" >
                <tr >
                    <th>#</th>
                    <th class="col-mat">N_Inscript</th>
                     <th class="col-mat">Matricule</th>
                    <th class="col-eleve">Nom Élève</th>
                     <th>Sexe</th>
                    <th class="col-eval">COMPT '.$e1.'</th>
                    <th class="col-eval">COMPT '.$e2.'</th>
                </tr>
            </thead>
            <tbody id="table-notes" >';
            $class->ShowStd_for_Notes_by_Mat_by_Trim_std($_GET['ref_class'],$_GET['ref_mat'],$_GET['trim'],$_GET['ref_std']);

        
               echo'
            </tbody>
        </table>
    </div>
</div>

</div>';
?>

    <?php 
      Config::scriptJs();
    ?>

    
    <script type="text/javascript">
      $(document).ready(function() {

    
    // Optionnel : Si vous voulez pré-sélectionner la classe active en fonction de l'URL
    var urlParams = new URLSearchParams(window.location.search);
    var classe = urlParams.get('ref_class');
    if (classe) {
        $('#list-classes .list-group-item').each(function() {
            if ($(this).attr('href').includes('ref_class=' + classe)) {
                $(this).addClass('active');
            }
        });
    }
});
    </script>

<script type="text/javascript">

  $(document).ready(function() {
    $('.note-input').on('change', function() {
        var $row = $(this).closest('tr');
        var id_eleve = $row.data('id-eleve');
        var ref_class = $('#ref_class').val();
        var ref_mat = $('#ref_mat').val();
        var ref_eval1 = $('#ref_eval1').val();
        var ref_eval2 = $('#ref_eval2').val();

        // Récupérer les notes et coefs pour les deux évaluations
        var note1 = $row.find('.note1').val();
        var coef1 = $row.find('.note1').closest('td').find('.coef-input').val();
        var note2 = $row.find('.note2').val();
        var coef2 = $row.find('.note2').closest('td').find('.coef-input').val();

        // Validation des notes
        var errorMessage = '';
        if (!isValidNote(note1)) {
            errorMessage += 'La note de la 1ERE COMPT est invalide. Elle doit être entre 0 et 20 (ou -1 pour absent).<br>';
        }
        if (!isValidNote(note2)) {
            errorMessage += 'La note de la 2E COMPT est invalide. Elle doit être entre 0 et 20 (ou -1 pour absent).<br>';
        }

        if (errorMessage) {
            showAlert('danger', errorMessage);
            return; // Arrêter l'envoi si les notes sont invalides
        }

        // Préparer les données à envoyer
        var data = {
            ref_class: ref_class,
            ref_mat: ref_mat,
            id_eleve: id_eleve,
            notes: [
                { ref_eval: ref_eval1, note: note1, coef: coef1 },
                { ref_eval: ref_eval2, note: note2, coef: coef2 }
            ]
        };

        // Envoi AJAX
        $.ajax({
            url: 'enregistrer_note_ajax.php',
            type: 'POST',
            data: data,
            dataType: 'json', // Attente d'une réponse JSON
            success: function(response) {
                if (response.status === 'success') {
                    showAlert('success', response.message);
                } else {
                    showAlert('danger', response.message);
                }
            },
            error: function(xhr, status, error) {
                showAlert('danger', 'Erreur lors de l\'enregistrement des notes. Veuillez réessayer.');
            }
        });
    });
});

                                    
function isValidNote(note) {
  if (note!='') {
      note= parseFloat(note);

    return note == -1 || (note >= 0 && note <= 20 && !isNaN(note));
}
  }
   

                                                       
function isValidNote(note) {
   if (note!='') {
    note = parseFloat(note);
    return note == -1 || (note >= 0 && note <= 20 && !isNaN(note));
  }
}

// Fonction pour afficher un message d'alerte Bootstrap
function showAlert(type, message) {
    var alertHtml = '<div class="alert alert-' + type + ' alert-dismissible fade show" role="alert">' +
                    message +
                    '<button type="button" class="close" data-dismiss="alert" aria-label="Close">' +
                        '<span aria-hidden="true">&times;</span>' +
                    '</button>' +
                '</div>';
    $('#message-container').html(alertHtml);
                                                                    
    setTimeout(function() {
        $('.alert').alert('close');
    }, 5000);
}
 /*$(document).ready(function() {
    $('.note-input').on('change', function() {
        var $row = $(this).closest('tr');
        var id_eleve = $row.data('id-eleve');
        var ref_class = $('#ref_class').val();
        var ref_mat = $('#ref_mat').val();
        var ref_eval1 = $('#ref_eval1').val();
        var ref_eval2 = $('#ref_eval2').val();
        
        // Récupérer les notes et coefs pour les deux évaluations
        var note1 = $row.find('.note1').val();
        var coef1 = $row.find('.note1').closest('td').find('.coef-input').val();
        var note2 = $row.find('.note2').val();
        var coef2 = $row.find('.note2').closest('td').find('.coef-input').val();

        // Préparer les données à envoyer
        var data = {
            ref_class: ref_class,
            ref_mat: ref_mat,
            id_eleve: id_eleve,
            notes: [
                { ref_eval: ref_eval1, note: note1, coef: coef1 },
                { ref_eval: ref_eval2, note: note2, coef: coef2 }
            ]
        };




        // Envoi AJAX
        $.ajax({
            url: 'enregistrer_note_ajax.php',
            type: 'POST',
            data: data,
            success: function(response) {
                console.log('Notes enregistrées :', response);
                $('#message-container').html('<div class="alert alert-success">Notes enregistrées avec succès !</div>');
            },
            error: function(xhr, status, error) {
                console.error('Erreur lors de l\'enregistrement des notes :', error);
                $('#message-container').html('<div class="alert alert-danger">Erreur lors de l\'enregistrement des notes. Veuillez réessayer.</div>');
            }
        });
    });
});*/
</script>


</body>
</html>
