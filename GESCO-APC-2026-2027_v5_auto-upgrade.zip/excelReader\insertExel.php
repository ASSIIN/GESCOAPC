<?php
   session_start(); 
	require_once '../Model/connexion.php';
	require_once '../vendor/autoload.php';
	 require_once '../core/require.php';
	use PhpOffice\PhpSpreadsheet\IOFactory;
	use PhpOffice\PhpSpreadsheet\Spreadsheet;
	use PhpOffice\PhpSpreadsheet\Writer\Xlsx;
	use PhpOffice\PhpSpreadsheet\Shared\Date;

	// Sécurité : connexion obligatoire
	if (!isset($_SESSION['user'])) {
		header('location: ../index.php');
		exit;
	}

	// CORRECTION : classe contrôlée (matricule + existence)
	$ref_cls= trim((string)($_POST['classe'] ?? ''));
	if ($ref_cls==='' || !$class->CkExistingCode($ref_cls)) {
		header('location: ../home.php');
		exit;
	}
	$ok=0;
	$n=0;
	$i=0;	
   
if (isset($_FILES['excel'])) 
{
    $tmp_name = $_FILES['excel']['tmp_name'];

   // Charger le fichier
    $reader = IOFactory::createReaderForFile($tmp_name);
    $spreadsheet = $reader->load($tmp_name);

    // Accéder aux données
    $sheet = $spreadsheet->getActiveSheet();
    $data = $sheet->toArray();

    // Insérer les données dans la base de données
    foreach ($data as $index => $row) 
    {
        // Ignorer la ligne d'en-tête
        if ($index == 0) {
            continue;
        }

        else
        {


		$i++;
		 /* Generation du code*/
		 $bdd = $GLOBALS['bdd'];
		 $lastMat=0;	

		$reponse0 = $bdd->query('SELECT * FROM eleves order by id desc limit 1');
		while(($row0 = $reponse0->fetch(PDO::FETCH_ASSOC))) 
		{
			$lastMat=(int)$row0['id'];
		}
	       // CORRECTION : condition toujours vraie (le test $lastMat!=NULL est inutile)
	       if ($lastMat>0)
	       {
       	 	$NumMat=(int)$lastMat;  
       	   $NumMat++;
       	   $codeswift="0000";
       	   $codeN=$codeswift.$NumMat;
       	   $code=substr($codeN,-4);
	       }
	       else{
	       	$NumMat=1;
       	   $codeswift="0000";
       	   $codeN=$codeswift.$NumMat;
       	   $code=substr($codeN,-4);

	       }
			$nom_std = $row[0];
	        $cni_std = $row[1];
			$sexe_std = $row[2];
			$dateString= $row[3];
		/*Convertions*/

			// CORRECTION : $date_nais toujours défini (sinon erreur undefined variable)
			$date_nais='';
			if (!empty($dateString)) 
			{
			    $formats = ['d/m/Y', 'm/d/Y', 'Y-m-d'];
			    foreach ($formats as $format) {
			        $dateTime = DateTime::createFromFormat($format, $dateString);
			        if ($dateTime !== false) {
			             $date_nais=$dateTime->format('Y-m-d');
			        }
			    }
			    // Si aucun format n'a fonctionné, on conserve la valeur brute
			    if ($date_nais==='') { $date_nais=trim((string)$dateString); }
			}
		    else
		    {
		    	
	    	      $date_nais=date('Y-m-d', strtotime('- 15 years'));	       

		    }
		
		$lieu_nais = $row[4];	
		/*Convertions*/
		if ($nom_std!=NULL) {
			$nom_std=mb_strtoupper($nom_std);
		}
		else
		{
			$nom_std='';
		}
		if ($cni_std==NULL) {
			$cni_std='';
		}

		if ($lieu_nais!=NULL) {
			$lieu_nais=mb_strtoupper($lieu_nais);
		}
		else{
			$lieu_nais='';
		}

		if ($sexe_std!=NULL) {
			$sexe_std=mb_strtoupper($sexe_std);
		}
		else{
			$sexe_std='';
		}

		

		//echo $nom_std.' - '.$cni_std.' - '.$nom_prenom_std.' - '.$date_nais.' - '.$lieu_nais.' - '.$sexe_std.' - '.$code.' - '.$ref_cls.'<br>';

		$bdd = $GLOBALS['bdd'];
				$doube=false;	
				// SÉCURISÉ : requête préparée anti-injection SQL
				$stmt_d = $bdd->prepare('SELECT id FROM eleves WHERE
					( nom_std=? AND date_nais=? ) OR
					( cni_std=? AND date_nais=? ) OR
					( mat_std=? ) OR
					( nom_std=? AND date_nais=? AND lieu_nais=? ) OR
					( cni_std=? AND date_nais=? AND lieu_nais=? )
					ORDER BY id DESC LIMIT 1');
				$stmt_d->execute(array($nom_std, $date_nais, $cni_std, $date_nais, $code, $nom_std, $date_nais, $lieu_nais, $cni_std, $date_nais, $lieu_nais));
				if ($stmt_d->fetch()) {
					$doube=true;
				}

				if ($doube) {
					echo 'L\'élève '.htmlspecialchars((string)$nom_std).' Existe déjà dans cette classe<br>
					<a href="../home.php"> RETOUR</a>';
					$n++;
					continue;
				}

				else
				{
					/* Age minimum*/

					 $age_min=date('Y-m-d H:i:s', strtotime('- 7 years'));
					 if ($date_nais>$age_min or $nom_std=='') {

					$n++;
					continue;
					 	
					 }
					 else if($std->CkExistingMatricule($cni_std))
					 {
					 	$n++;
					continue;
					 }
					 else
					 {
					 	$bdd = $GLOBALS['bdd'];	
						$req = "INSERT INTO eleves (nom_std, cni_std, date_nais, lieu_nais, sexe_std, mat_std, ref_class) VALUES(?, ?, ?, ?, ?, ?, ?)" ;
						$rep = $bdd->prepare($req);
						if($rep->execute(array($nom_std, $cni_std, $date_nais, $lieu_nais, $sexe_std, $code, $ref_cls)))
						{
							$ok++;
						}
						else{
							echo 'Erreur ligne '.$i.'  Verifiez la Colonne Date est au format Standard <br><a href="../home.php"> RETOUR</a>';
						}
					 }
					
				}	
				
			}
			
	    }
       header('location: ../home.php?cls='.urlencode($ref_cls).'&ok='.(int)$ok.'&n='.(int)$n);
   }
	 else 
	 {
	 	header('location: ../home.php?cls='.urlencode($ref_cls).'&ok='.(int)$ok.'&n='.(int)$n);
	 }

				
?>