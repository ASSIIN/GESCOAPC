<?php
session_start();
require_once '../Model/connexion.php';
require_once '../core/require.php';
 if (!isset($_SESSION['user'])) {
    session_unset();
    session_destroy();
    header('location: ../index.php');    
    }
 $etb->ShowEtb();
 if (!isset($_GET['cls']) and !isset($_GET['type'])) {
	header('location: ../impression.php');
 }
 if ($_GET['type']=='ps') {
 	header('location: cert_ps.php?cls='.$_GET['cls'].'&type='.$_GET['type'].'');
 }else if($_GET['type']=='pb'){
 	header('location: cert_pb.php?cls='.$_GET['cls'].'&type='.$_GET['type'].'');
 }

$refcls= htmlspecialchars($_GET['cls']);
$class->CkClasseByCode($refcls);
$nomcls=$_SESSION['nom_class'];
require('fpdf.php');

	 
  $pdf = new FPDF();

class PDF extends FPDF
{
// En-tête
function Header()
{  $this->Image('../plugins/images/'.$_SESSION['logo_etb'].'',10,6,30);
    // Police Arial gras 15
    $this->SetFont('Arial','B',15);
    // Décalage à droite
    $this->Cell(80);
    // Titre
    $this->Cell(30,10,'Titre',1,0,'C');
    // Saut de ligne
    $this->Ln(20);
}

// Pied de page
function Footer()
{
    // Positionnement à 1,5 cm du bas
    $this->SetY(-15);
    // Police Arial italique 8
    $this->SetFont('Arial','I',8);
    // Numéro de page
    $this->Cell(0,10,'Page '.$this->PageNo().'/{nb}',0,0,'C');
}
}
$pdf->AliasNBPages();

//code for print data



	 $bdd = $GLOBALS['bdd'];
		$reponse = $bdd->query('SELECT id, nom_std, lieu_nais, sexe_std, mat_std, ref_class,statut, cni_std,  DATE_FORMAT(date_nais, \'%d/%m/%Y \') AS date_fr FROM eleves where ref_class="'.$refcls.'" order by nom_std asc');
		while($row = $reponse->fetch(PDO::FETCH_ASSOC)) 
		{
			$pdf->AddPage();
			$pdf->AliasNBPages();

		$i=1;
		$eff=0;
		/*En-tête*/
			$pdf->SetFont('Times','',8);
			$pdf->Image('../plugins/images/'.$_SESSION['logo_etb'].'',90,15,30);
			$pdf->Cell(70,4,'REPUBLIQUE DU CAMEROUN',0,0,'C');
			$pdf->Cell(50,4,'',0,0);
			$pdf->Cell(70,4,'REPUBLIC OF CAMEROON',0,1,'C');

			$pdf->Cell(70,4,'Paix-Travail-Patrie',0,0,'C');
			$pdf->Cell(50,4,'',0,0);
			$pdf->Cell(70,4,'Peace-Work-Fatherland',0,1,'C');

			$pdf->Cell(70,4, utf8_to_cp1252("".$_SESSION['minist_etb_fr'].""),0,0,'C');
			$pdf->Cell(50,4,'',0,0);
			$pdf->Cell(70,4,utf8_to_cp1252(''.$_SESSION['minist_etb_en'].''),0,1,'C');

			$pdf->Cell(70,4,utf8_to_cp1252("".$_SESSION['region_etb_fr'].""),0,0,'C');
			$pdf->Cell(50,4,'',0,0);
			$pdf->Cell(70,4,utf8_to_cp1252(''.$_SESSION['region_etb_en'].''),0,1,'C');

			$pdf->Cell(70,4,utf8_to_cp1252(''.$_SESSION['depart_etb_fr'].''),0,0,'C');
			$pdf->Cell(50,4,'',0,0);
			$pdf->Cell(70,4,utf8_to_cp1252(''.$_SESSION['depart_etb_en'].''),0,1,'C');
			$pdf->SetFont('Times','B',10);
			$pdf->Cell(70,6,utf8_to_cp1252(''.$_SESSION['nom_etb_fr'].''),0,0,'C');
			$pdf->Cell(50,6,'',0,0);
			$pdf->Cell(70,6,utf8_to_cp1252(''.$_SESSION['nom_etb_en'].''),0,1,'C');
			$pdf->SetFont('Times','',8);
			$pdf->Cell(70,5,utf8_to_cp1252(''.$_SESSION['code_pste_etb'].' / '.$_SESSION['tel_etb'].''),0,0,'C');
			$pdf->Cell(50,5,'',0,0);
			$pdf->Cell(70,5,utf8_to_cp1252(''.$_SESSION['code_pste_etb'].'/ '.$_SESSION['tel_etb'].''),0,1,'C');
			$pdf->SetFont('Times','',8);
			$pdf->Cell(70,4,utf8_to_cp1252(''.$_SESSION['email_etb'].''),0,0,'C');
			$pdf->Cell(50,4,'',0,0);
			$pdf->Cell(70,4,utf8_to_cp1252(''.$_SESSION['email_etb'].''),0,1,'C');
				$pdf->Ln();
				$pdf->SetFont('Times','I',12);
				$pdf->Cell(65,5,'',0,0);
				$pdf->Cell(60,5,utf8_to_cp1252(''.$_SESSION['code_im_etb'].''),0,0,'C');
				$pdf->Ln();
				$pdf->Ln();
		/*FIN En-tête*/
		//Titre 
			$pdf->SetFont('Times','I',10);
			$pdf->Cell(50,5,'',0,0,'C');
			$pdf->Cell(60,5,'ANNEE SCOLAIRE/SCHOOL YEAR',0,0,'R');
			$pdf->SetFont('Times','B',12);
			$pdf->Cell(40,5,''.$_SESSION['school_year'].'',0,0,'L');
			$pdf->Cell(40,5,'',0,1,'C');
			$pdf->Ln();
				$pdf->SetFont('Times','B',15);
				$pdf->SetFillColor(38,189,237);
				$pdf->Cell(20,10,'',0,0,'C');
				$pdf->Cell(150,10,'CERTIFICAT DE SCOLARITE / SCHOOL CERTIFICATE',1,0,'C',0);
				$pdf->Cell(20,10,'',0,1,'C');
				$pdf->Ln();


			
			
		$Nom=htmlspecialchars($row['nom_std']);
		$Nom=mb_strtoupper($Nom);

		$lieu_nais = str_replace("&#039;", "'", $row['lieu_nais']);
		$Nom = str_replace("&#039;", "'", $Nom);
		/*$row['mat_std'];
		$row['nom_prenom_std']
		$row['sexe_std']
		$row['date_nais']
		$row['lieu_nais']*/
		$pdf->SetFont('Times','B',12);

		$pdf->SetFont('Times','',13);
		$pdf->Ln();
			$pdf->MultiCell(190,10,utf8_to_cp1252('            Je soussigné, M/Mme '.$_SESSION['nom_respo_etb'].', Proviseur/ Directeur / Principal, du (de l\' ) '.$_SESSION['nom_etb_fr'].', certifie que l\'élève '.$Nom.' né(e) le '.$row['date_fr'].' à '.$lieu_nais.', de matricule '.$row['cni_std'].' est inscrit(e)  par le n° '.$_SESSION['pre_matr'].''.$row['mat_std'].',  dans la classe de [ '.$nomcls.' ] au sein notre établissement au titre de l\'année scolaire '.$_SESSION['school_year'].'.'),0,0);
			$pdf->Ln();
			$pdf->Ln();
		$pdf->MultiCell(180,10,utf8_to_cp1252('En foi de quoi le présent certificat lui est délivré pour servir et valoir ce que de droit.'),0,'R');
		    $pdf->Ln();
			$pdf->Ln();
			$pdf->Ln();
			$pdf->Ln();
			
			$pdf->SetFont('Times','',12);
			$pdf->Cell(92,5,'',0,0,'C');
			$pdf->Cell(60,5,utf8_to_cp1252($_SESSION['ville_etb'].', le/on _______________'),0,0);
			$pdf->Ln();

			$pdf->Cell(92,5,'',0,0,'C');
			$pdf->Cell(60,5,utf8_to_cp1252('Le Proviseur (Directeur) / The Principal,'),0,0);

			$pdf->Ln();
			$pdf->Ln();
			$pdf->Ln();
			$pdf->Ln();
			$pdf->Ln();
			$pdf->Ln();
			$pdf->Ln();
			
			// Décalage à droite
		    $pdf->SetX(7);
		    $data=date('d/m/Y à H:i:s');
		    $data_cm=date('d/m/Y à H:i:s', strtotime('+1 hour'));
		    
		    $pdf->SetFont('Times','I',9);

		  
			$pdf->SetFont('Times','I',9);
			$pdf->Cell(40,5,'',0,0,'C');
			$pdf->Cell(100,5,utf8_to_cp1252('___________________________________________________________'),0,0,'C');
			$pdf->Cell(40,5,'',0,0,'C');
			$pdf->Ln();
			$pdf->Cell(50,5,'',0,0,'C');
			$pdf->Cell(40,5, utf8_to_cp1252("Imprimé le / Print on the:"),0,0,'C',0);		     
		    $pdf->Cell(15,5, utf8_to_cp1252($data_cm.''),0,0,'L',0);
			$pdf->Cell(40,5,'',0,0,'C');
			//$pdf->SetXY(123,271);
			//$pdf->Cell(0,3,'Page '.$pdf->PageNo().'/{nb}',0,1,'C');
		}	
$pdf->Output('CERT_SCOLARITE_ '.$nomcls.'.pdf','I');
$pdf->Close();
?>
