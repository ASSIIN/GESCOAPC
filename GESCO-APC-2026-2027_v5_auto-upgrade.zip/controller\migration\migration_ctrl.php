<?php
/**
 * Contrôleur de migration annuelle des élèves (LOGIQUE SERVEUR UNIQUEMENT).
 * Projet: GESCO-APC
 *
 * Le formulaire est dans operations.php. Ce fichier traite les actions puis
 * redirige vers operations.php avec un message flash. Il ne produit aucun HTML.
 */
session_start();
require_once __DIR__ . '/../../core/config.php';
require_once __DIR__ . '/../../core/classes_core.php';
require_once __DIR__ . '/../../core/std_core.php';
require_once __DIR__ . '/../../core/migration/migration.php';

$_SESSION['user_opt'] = "Migration";

if (!isset($_SESSION['user']) || !in_array($_SESSION['user_role'], ['admin', 'pcpl', 'sg'])) {
    session_unset();
    session_destroy();
    header('location: ../../index.php');
    exit();
}

$flash_type = 'info';
$flash_message = '';
$migration_result = null;

$action = $_POST['action'] ?? '';

if ($action === 'perform_migration' && isset($_POST['current_year']) && isset($_POST['next_year'])) {
    $current_year = htmlspecialchars($_POST['current_year']);
    $next_year = htmlspecialchars($_POST['next_year']);
    $niveau = htmlspecialchars($_POST['niveau'] ?? '');
    $session = htmlspecialchars($_POST['session'] ?? '');
    $moy_min = floatval($_POST['moy_min'] ?? 8);
    $multi = isset($_POST['multi_classes']) && (string)$_POST['multi_classes'] === '1';
    $confirm = isset($_POST['confirm_irreversible']) && (string)$_POST['confirm_irreversible'] === '1';

    if (!$confirm) {
        $flash_message = "Migration refusée : vous devez cocher la case de confirmation (opération irréversible).";
        $flash_type = 'danger';
        $migration_result = ['success' => false, 'migrated_classes' => [], 'skipped_classes' => [], 'errors' => ['Confirmation requise.']];
    } else {
        try {
            $manager = new MigrationManager($current_year, $next_year);
            $result = $manager->migrate($moy_min, $niveau, $session, $multi, $_SESSION['login'] ?? null);

            if (!empty($result['migrated_classes'])) {
                $manager->logMigration($_SESSION['login'] ?? '', $current_year, $next_year, $result, $moy_min);
            }

            $migration_result = $result;

            if ($result['success'] && !empty($result['migrated_classes'])) {
                $flash_message = "Migration effectuée : " . count($result['migrated_classes']) . " classe(s) migrée(s), " . ($result['stats']['total_students'] ?? 0) . " élève(s) transféré(s). Migration VERROUILLÉE.";
                $flash_type = 'success';
            } elseif (!empty($result['errors'])) {
                $flash_message = implode(' | ', array_slice($result['errors'], 0, 3));
                $flash_type = 'warning';
            } else {
                $flash_message = "Aucune classe migrée (vérifiez les filtres).";
                $flash_type = 'info';
            }
        } catch (RuntimeException $e) {
            $flash_message = "Erreur critique: " . $e->getMessage();
            $flash_type = 'danger';
        }
    }
} elseif ($action === 'restore_migration') {
    $current_year = htmlspecialchars($_POST['current_year'] ?? ($_SESSION['con_year'] ?? ''));
    $next_year = htmlspecialchars($_POST['next_year'] ?? '');
    $run_id = (int)($_POST['run_id'] ?? 0);
    $confirm = isset($_POST['confirm_restore']) && (string)$_POST['confirm_restore'] === '1';

    if (!$confirm) {
        $flash_message = "Restauration refusée : cochez la case de confirmation.";
        $flash_type = 'danger';
    } elseif ($run_id <= 0) {
        $flash_message = "Restauration impossible : migration introuvable.";
        $flash_type = 'danger';
    } else {
        try {
            $manager = new MigrationManager($current_year, $next_year);
            $r = $manager->restoreMigration($run_id);
            if ($r['success']) {
                $flash_message = "Restauration effectuée : {$r['students_restored']} élève(s) retiré(s) de la base suivante, {$r['classes_removed']} classe(s) supprimée(s). Migration déverrouillée.";
                $flash_type = 'success';
            } else {
                $flash_message = implode(' | ', $r['errors']);
                $flash_type = 'danger';
            }
        } catch (RuntimeException $e) {
            $flash_message = "Erreur critique: " . $e->getMessage();
            $flash_type = 'danger';
        }
    }
} elseif ($action === 'check_next_year') {
    $current_year = htmlspecialchars($_POST['current_year'] ?? '');
    $next_year = htmlspecialchars($_POST['next_year'] ?? '');
    if ($current_year && $next_year) {
        try {
            $manager = new MigrationManager($current_year, $next_year);
            $check = $manager->checkNextYearReady();
            $_SESSION['migration_check'] = $check;
            $flash_message = "Base {$next_year} : " . ($check['exists'] ? count($check['classes']) . " classe(s) déjà présente(s)." : "Base inexistante - à créer avant migration.");
            $flash_type = $check['exists'] ? 'info' : 'warning';
        } catch (RuntimeException $e) {
            $flash_message = "Erreur: " . $e->getMessage();
            $flash_type = 'danger';
        }
    }
} else {
    header('location: ../../operations.php');
    exit();
}

$_SESSION['migration_flash'] = [
    'type' => $flash_type,
    'message' => $flash_message,
    'result' => $migration_result,
];

header('location: ../../operations.php');
exit();
