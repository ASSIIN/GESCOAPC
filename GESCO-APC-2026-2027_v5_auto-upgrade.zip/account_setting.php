<?php
    session_start();   
	require_once 'core/require.php'; 
	require_once 'Model/connexion.php';
     if (!isset($_SESSION['user']) and $_SESSION['user_role']!="admin") {
    session_unset();
    session_destroy();
    header('location: index.php');    
    }

    $flashMessage = isset($_GET['i']) ? 'Vérifiez les mots de passe ancien et nouveau, puis recommencez. Contactez votre administration en cas d’oubli.' : null;

    $etb->ShowEtb();
    $etb->CkLE();
    $etb->ckexneE();
?>
<!DOCTYPE html>
<html>
  <head>
   <?php Config::head(); ?>
    <title>GESCOAPC| PARAMETRE</title>
  </head>

<body>
    <?php if (!empty($flashMessage)) Config::toast($flashMessage, 'warning'); ?>
    <div class="wrapper">
      <!-- Sidebar -->

      <!-- Inclusion du menu de navigation externe réutilisable -->
      <?php include 'core/sidebar.php'; ?>  
       
<div class="main-content-wrapper">
        <!-- Barre supérieure de navigation adaptative -->
        <div class="mobile-navbar-fixed p-3 mb-4 rounded shadow-sm border">
            <div class="row align-items-center g-2">
                <div class="col-auto d-md-none">
                    <button class="btn btn-outline-dark btn-sm" id="toggleMobileMenu"><i class="fa fa-bars fa-lg"></i></button>
                </div>
                <div class="col-12 col-md">
                    <h4 class="m-0 fw-bold text-primary text-uppercase">MODIFIER LES PARAMETRES DE CONNEXION</h4>
                </div>
            </div>
        </div>

        <div class="container-fluid">
            <div class="row mt-4">
                <div class="col-lg-10 col-xl-8">
                    <div class="card shadow-sm">
                        <div class="card-header bg-primary text-white py-2">
                            <h5 class="m-0 fw-bold">Modifier mon Mot de passe</h5>
                        </div>
                        <div class="card-body">
                            <form action="Controler/admins/updpwuser.php" method="post" class="row g-3">
                                <input type="text" class="form-control text-uppercase" id="login" name="login" value="<?php echo $_SESSION['login']; ?> " hidden="true">
                                <input type="text" class="form-control text-uppercase" id="lpw" name="lpw" value="<?php echo $_SESSION['password']; ?> " hidden="true">
                                <div class="col-md-4">
                                    <label for="l_pw" class="form-label">Ancien mot de passe</label>
                                    <input type="text" class="form-control text-uppercase" id="l_pw" name="l_pw" maxlength="8">
                                </div>
                                <div class="col-md-4">
                                    <label for="new_pw1" class="form-label">Nouveau mot de passe</label>
                                    <input type="text" class="form-control text-uppercase" id="new_pw1" name="new_pw1" maxlength="8">
                                </div>
                                <div class="col-md-4">
                                    <label for="new_pw2" class="form-label">Confirmer le nouveau</label>
                                    <input type="text" class="form-control text-uppercase" id="new_pw2" name="new_pw2" maxlength="8">
                                </div>
                                <div class="col-12">
                                    <button type="submit" class="btn btn-primary">Enregistrer</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <?php 
            Footers::TDfoot();
        ?>
        <!-- ============================================================== -->
        <!-- End Page Content -->
        <!-- ============================================================== -->
    </div>

    <?php 
      Config::scriptJs();
    ?>
  </body>
</html>