<?php
    session_start();
    require_once 'core/require.php';
    require_once 'Model/connexion.php';
    require_once 'core/migration/migration.php';
    $_SESSION['user_opt']="Opérations";
    if (!isset($_SESSION['user']) || !in_array($_SESSION['user_role'], array('admin', 'pcpl', 'sg', 'cs'))) {
        session_unset();
        session_destroy();
        header('location: index.php');
        exit();
    }
    if ($_SESSION['user_role']=="caisse") {
        header('location: home.php');
        exit();
    }
    if ($_SESSION['user_role']=="ens") {
        header('location: poste_de_saisie.php?trim=t1');
        exit();
    }
    $etb->ShowEtb();
    $etb->ckexneE();

    $next_year = '';
    $con_year = $_SESSION['con_year'] ?? '';
    $parts = explode('_', $con_year);
    if (count($parts) === 2 && is_numeric($parts[0]) && is_numeric($parts[1])) {
        $next_year = ((int)$parts[0] + 1) . '_' . ((int)$parts[1] + 1);
    }

    $locked_run = null;
    $migration_history = [];
    $years = [];
    try {
        $years = MigrationManager::getAvailableYears();
        if ($next_year !== '') {
            $mgr_lock = new MigrationManager($con_year, $next_year);
            $locked_run = $mgr_lock->getLockedRun();
            $migration_history = $mgr_lock->getMigrationHistory();
        }
    } catch (Exception $e) {
        $locked_run = null;
    }

    $migration_flash = $_SESSION['migration_flash'] ?? null;
    unset($_SESSION['migration_flash']);
?>
<!DOCTYPE html>
<html>
  <head>
    <?php Config::head(); ?>
    <title>GESCOAPC| Classes</title>
  </head>
<body>
    <div class="wrapper">
      <?php include 'core/sidebar.php'; ?>

<div class="main-content-wrapper">
        <div class="mobile-navbar-fixed p-3 mb-4 rounded shadow-sm border">
            <div class="row align-items-center g-2">
                <div class="col-auto d-md-none">
                    <button class="btn btn-outline-dark btn-sm" id="toggleMobileMenu"><i class="fa fa-bars fa-lg"></i></button>
                </div>
                <div class="col-12 col-md">
                    <h4 class="m-0 fw-bold text-primary text-uppercase">Opérations & historique</h4>
                </div>
            </div>
        </div>
        <!-- End Sidebar -->
<div class="container-fluid mt-3">

    <?php if (!empty($migration_flash['message'])): ?>
    <div class="alert alert-<?= htmlspecialchars($migration_flash['type'] ?? 'info') ?> alert-dismissible fade show" role="alert">
        <i class="fa-solid fa-circle-info me-1"></i><?= htmlspecialchars($migration_flash['message']) ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Fermer"></button>
    </div>
    <?php endif; ?>

       <!-- ===== SAUVEGARDE / RESTAURATION ===== -->
       <div class="row g-3 mb-4">
           <div class="col-lg-5">
               <div class="card shadow-sm h-100">
                   <div class="card-header bg-secondary text-white py-2">
                       <h5 class="m-0 fw-bold"><i class="fa-solid fa-database me-2"></i>Opérations sur la base de données</h5>
                   </div>
                   <div class="card-body">
                       <h6 class="fw-bold text-uppercase small text-muted mb-1">Sauvegarde au format SQL</h6>
                       <p class="text-muted small">Téléchargez une copie complète de la base actuelle (fichier .sql).</p>
                       <form action="Controler/school/dbdownload.php" method="GET">
                           <button type="submit" class="btn btn-primary w-100">
                               <i class="fa-solid fa-download me-1"></i> Sauvegarder
                           </button>
                       </form>
                   </div>
               </div>
           </div>
           <div class="col-lg-7">
               <div class="card shadow-sm h-100">
                   <div class="card-header bg-success text-white py-2">
                       <h5 class="m-0 fw-bold"><i class="fa-solid fa-rotate-left me-2"></i>Restaurer à partir d'un fichier SQL</h5>
                   </div>
                   <div class="card-body">
                       <p class="text-danger fw-bold small mb-2">
                           <i class="fa-solid fa-triangle-exclamation me-1"></i>Attention : effectuez une sauvegarde avant chaque restauration.
                       </p>
                       <form action="Controler/school/upddata.php" method="POST" enctype="multipart/form-data">
                           <div class="row align-items-end g-2">
                               <div class="col-md-8">
                                   <label class="form-label small">Fichier SQL (restauration)</label>
                                   <input type="file" class="form-control" name="sql_file" accept=".sql">
                               </div>
                               <div class="col-md-4">
                                   <button type="submit" class="btn btn-success w-100">
                                       <i class="fa-solid fa-rotate-right me-1"></i> Restaurer
                                   </button>
                               </div>
                           </div>
                       </form>
                   </div>
               </div>
           </div>
       </div>

       <?php
       $currentDate = new DateTime();
       $currentMonth = $currentDate->format('m');
       if ($_SESSION['School_year1']==$_SESSION['postan'] and $currentMonth >= 6) {
       ?>
       <!-- ===== MIGRATION ANNUELLE ===== -->
       <div class="card shadow-sm mb-4 border-start border-danger border-4">
           <div class="card-header bg-primary text-white py-2">
               <h5 class="m-0 fw-bold">
                   <i class="fa-solid fa-people-arrows me-2"></i>MIGRATION ANNUELLE DES ÉLÈVES
                   <span class="badge bg-danger ms-2"><i class="fa-solid fa-triangle-exclamation me-1"></i>Opérations irréversibles</span>
               </h5>
           </div>
           <div class="card-body">
               <?php if ($locked_run !== null): ?>
               <div class="alert alert-warning border-start border-danger border-4">
                   <div class="d-flex flex-wrap align-items-center justify-content-between gap-2">
                       <div>
                           <h6 class="fw-bold mb-1"><i class="fa-solid fa-lock me-2"></i>Migration verrouillée</h6>
                           <div class="small">
                               Effectuée le <strong><?= htmlspecialchars($locked_run['created_at'] ?? '') ?></strong>
                               par <strong><?= htmlspecialchars($locked_run['user_login'] ?? '') ?></strong> :
                               <strong><?= (int)($locked_run['total_students'] ?? 0) ?></strong> élève(s) transféré(s) vers
                               <strong><?= htmlspecialchars($locked_run['next_year'] ?? '') ?></strong>.
                           </div>
                       </div>
                       <form action="controller/migration/migration_ctrl.php" method="POST" class="m-0"
                             onsubmit="return confirm('Restaurer cette migration ? Tous les élèves transférés seront retirés de la base suivante.');">
                           <input type="hidden" name="action" value="restore_migration">
                           <input type="hidden" name="current_year" value="<?= htmlspecialchars($locked_run['current_year'] ?? '') ?>">
                           <input type="hidden" name="next_year" value="<?= htmlspecialchars($locked_run['next_year'] ?? '') ?>">
                           <input type="hidden" name="run_id" value="<?= (int)($locked_run['id'] ?? 0) ?>">
                           <div class="form-check mb-2">
                               <input class="form-check-input" type="checkbox" name="confirm_restore" value="1" id="confirm_restore_op" required>
                               <label class="form-check-label small text-danger fw-bold" for="confirm_restore_op">Je confirme la restauration</label>
                           </div>
                           <button type="submit" class="btn btn-danger btn-sm w-100">
                               <i class="fa-solid fa-rotate-left me-1"></i> Restaurer / Annuler
                           </button>
                       </form>
                   </div>
               </div>
               <?php endif; ?>
               <p class="text-danger fw-bold small mb-3">
                   ASSUREZ-VOUS D'AVOIR CLÔTURÉ L'ANNÉE SCOLAIRE EN COURS (moyennes annuelles saisies) AVANT D'EFFECTUER LA MIGRATION.
               </p>
               <form action="controller/migration/migration_ctrl.php" method="POST">
                   <div class="row g-3">
                       <div class="col-md-2">
                           <label for="mig_year_src" class="form-label fw-bold">ANNÉE SOURCE</label>
                           <select id="mig_year_src" class="form-select" name="current_year" required>
                               <option value="<?= htmlspecialchars($_SESSION['con_year'] ?? '25_26') ?>"><?= htmlspecialchars($_SESSION['con_year'] ?? '25_26') ?></option>
                           </select>
                       </div>
                       <div class="col-md-2">
                           <label for="mig_year_dst" class="form-label fw-bold">NOUVELLE ANNÉE</label>
                           <select id="mig_year_dst" class="form-select" name="next_year" required>
                               <option value="<?= htmlspecialchars($next_year) ?>"><?= htmlspecialchars($next_year) ?></option>
                           </select>
                       </div>
                       <div class="col-md-2">
                           <label for="mig_niveau" class="form-label fw-bold">NIVEAU</label>
                           <select id="mig_niveau" class="form-select" name="niveau">
                               <option value="">Tous</option>
                               <option value="1">6EME / F1 / 1ERE ANNEE</option>
                               <option value="2">5EME / F2 / 2EME ANNEE</option>
                               <option value="3">4EME / F3 / 3EME ANNEE</option>
                               <option value="4">3EME / F4 / 4EME ANNEE</option>
                               <option value="5">2NDE / F5 / PROBATOIRE</option>
                               <option value="6">1ERE / L6 / PREMIERE</option>
                               <option value="7">TLE / U6 / TERMINALE</option>
                           </select>
                       </div>
                       <div class="col-md-2">
                           <label for="mig_session" class="form-label fw-bold">SECTION</label>
                           <select id="mig_session" class="form-select" name="session">
                               <option value="ALL">Toutes</option>
                               <option value="SFG">SF Générale</option>
                               <option value="SAG">SA Générale</option>
                               <option value="SFT">SF Technique</option>
                               <option value="SAT">SA Technique</option>
                           </select>
                       </div>
                       <div class="col-md-2">
                           <label class="form-label fw-bold">SEUIL RÉUSSITE</label>
                           <select id="mig_moy_min" class="form-select" name="moy_min">
                               <option value="8">8,00</option>
                               <option value="8.5">8,50</option>
                               <option value="9">9,00</option>
                               <option value="9.5">9,50</option>
                               <option value="10" selected>10,00</option>
                               <option value="10.5">10,50</option>
                               <option value="11">11,00</option>
                               <option value="11.5">11,50</option>
                               <option value="12">12,00</option>
                           </select>
                       </div>
                       <div class="col-md-2">
                           <label class="form-label fw-bold">PLUSIEURS CLASSES</label>
                           <div class="form-check form-switch mt-2">
                               <input class="form-check-input" type="checkbox" name="multi_classes" value="1" id="multi_classes_op" checked>
                               <label class="form-check-label small" for="multi_classes_op">Oui / Non</label>
                           </div>
                           <small class="text-muted">Oui : une classe par série pour le niveau suivant</small>
                       </div>
                       <div class="col-12">
                           <div class="form-check">
                               <input class="form-check-input" type="checkbox" name="confirm_irreversible" value="1" id="confirm_irreversible_op" required>
                               <label class="form-check-label text-danger fw-bold" for="confirm_irreversible_op">Je confirme : opération IRREVERSIBLE (moyennes annuelles obligatoires)</label>
                           </div>
                       </div>
                       <div class="col-12">
                           <?php if ($locked_run !== null): ?>
                               <button type="button" class="btn btn-secondary w-100" disabled>
                                   <i class="fa-solid fa-lock me-1"></i> MIGRATION VERROUILLÉE — restaurez d'abord la migration précédente
                               </button>
                           <?php else: ?>
                               <button type="submit" class="btn btn-danger w-100" name="action" value="perform_migration">
                                   <i class="fa-solid fa-people-arrows me-1"></i> MIGRER
                               </button>
                           <?php endif; ?>
                       </div>
                   </div>
               </form>
           </div>
       </div>

       <!-- ===== VERIFICATION PREALABLE ===== -->
       <div class="row g-3 mb-4">
           <div class="col-lg-5">
               <div class="card shadow-sm h-100">
                   <div class="card-header bg-info text-white py-2">
                       <h5 class="m-0 fw-bold"><i class="fa-solid fa-magnifying-glass me-2"></i>Vérification préalable</h5>
                   </div>
                   <div class="card-body">
                       <p class="text-muted small mb-3">Vérifie que la base de la nouvelle année existe et liste ses classes.</p>
                       <form action="controller/migration/migration_ctrl.php" method="POST">
                           <input type="hidden" name="action" value="check_next_year">
                           <div class="row g-2">
                               <div class="col-6">
                                   <label class="form-label small fw-bold">ANNÉE SOURCE</label>
                                   <select name="current_year" class="form-select form-select-sm">
                                       <?php foreach ($years as $y): ?>
                                           <option value="<?= htmlspecialchars($y) ?>" <?= ($y === ($_SESSION['con_year'] ?? '')) ? 'selected' : '' ?>><?= htmlspecialchars($y) ?></option>
                                       <?php endforeach; ?>
                                   </select>
                               </div>
                               <div class="col-6">
                                   <label class="form-label small fw-bold">NOUVELLE ANNÉE</label>
                                   <select name="next_year" class="form-select form-select-sm">
                                       <?php foreach ($years as $y): ?>
                                           <option value="<?= htmlspecialchars($y) ?>" <?= ($y === $next_year) ? 'selected' : '' ?>><?= htmlspecialchars($y) ?></option>
                                       <?php endforeach; ?>
                                   </select>
                               </div>
                           </div>
                           <button type="submit" class="btn btn-outline-info btn-sm w-100 mt-3">
                               <i class="fa fa-check-circle me-1"></i> Vérifier la base suivante
                           </button>
                       </form>
                   </div>
               </div>
           </div>
       </div>

       <!-- ===== RESULTATS DE LA MIGRATION ===== -->
       <?php if (!empty($migration_flash['result']) && (!empty($migration_flash['result']['migrated_classes']) || !empty($migration_flash['result']['errors']))): ?>
       <?php $mr = $migration_flash['result']; ?>
       <div class="card shadow-sm mb-4">
           <div class="card-header bg-success text-white py-2">
               <h5 class="m-0 fw-bold"><i class="fa-solid fa-chart-column me-2"></i>Résultats de la migration</h5>
           </div>
           <div class="card-body">
               <div class="row g-2 mb-3">
                   <div class="col-6 col-md-3"><div class="border rounded text-center p-2"><div class="fs-4 fw-bold text-primary"><?= count($mr['migrated_classes']) ?></div><div class="small text-muted">Classes</div></div></div>
                   <div class="col-6 col-md-3"><div class="border rounded text-center p-2"><div class="fs-4 fw-bold text-primary"><?= (int)($mr['stats']['total_students'] ?? 0) ?></div><div class="small text-muted">Élèves</div></div></div>
                   <div class="col-6 col-md-3"><div class="border rounded text-center p-2"><div class="fs-4 fw-bold text-primary"><?= count($mr['skipped_classes']) ?></div><div class="small text-muted">Ignorées</div></div></div>
                   <div class="col-6 col-md-3"><div class="border rounded text-center p-2"><div class="fs-4 fw-bold text-primary"><?= count($mr['errors']) ?></div><div class="small text-muted">Erreurs</div></div></div>
               </div>

               <?php if (!empty($mr['errors'])): ?>
               <div class="alert alert-danger">
                   <h6 class="fw-bold"><i class="fa-solid fa-triangle-exclamation me-1"></i>Classes ne pouvant pas être migrées</h6>
                   <ul class="mb-0 small">
                       <?php foreach ($mr['errors'] as $err): ?>
                           <li><?= htmlspecialchars($err) ?></li>
                       <?php endforeach; ?>
                   </ul>
               </div>
               <?php endif; ?>

               <?php if (!empty($mr['migrated_classes'])): ?>
               <div class="table-responsive">
                   <table class="table table-striped table-sm align-middle">
                       <thead class="table-primary"><tr><th>#</th><th>Classe Source</th><th>Série</th><th>Classe Cible</th><th>Admis</th><th>Redoublants</th><th>Élèves Migrés</th><th>Déjà Existants</th></tr></thead>
                       <tbody>
                           <?php foreach ($mr['migrated_classes'] as $i => $mc): ?>
                           <tr>
                               <td><?= $i + 1 ?></td>
                               <td><?= htmlspecialchars($mc['nom']) ?> (<?= htmlspecialchars($mc['code']) ?>)</td>
                               <td><?= htmlspecialchars($mc['serie'] ?? '') ?></td>
                               <td><?= htmlspecialchars($mc['target'] ?? '') ?></td>
                               <td><?= $mc['students_admis'] ?? $mc['students_migrated'] ?></td>
                               <td><?= $mc['students_redoubles'] ?? 0 ?></td>
                               <td><?= $mc['students_migrated'] ?></td>
                               <td><?= $mc['students_skipped'] ?></td>
                           </tr>
                           <?php endforeach; ?>
                       </tbody>
                   </table>
               </div>
               <?php endif; ?>
           </div>
       </div>
       <?php endif; ?>

       <!-- ===== HISTORIQUE DES MIGRATIONS ===== -->
       <?php if (!empty($migration_history)): ?>
       <div class="card shadow-sm mb-4">
           <div class="card-header bg-secondary text-white py-2">
               <h5 class="m-0 fw-bold"><i class="fa-solid fa-clock-rotate-left me-2"></i>Historique des migrations</h5>
           </div>
           <div class="card-body">
               <div class="table-responsive">
                   <table class="table table-striped table-sm align-middle">
                       <thead class="table-secondary"><tr><th>#</th><th>Utilisateur</th><th>De</th><th>A</th><th>Classes</th><th>Élèves</th><th>Date</th></tr></thead>
                       <tbody>
                           <?php foreach ($migration_history as $i => $h): ?>
                           <tr>
                               <td><?= $i + 1 ?></td>
                               <td><?= htmlspecialchars($h['user_login'] ?? '') ?></td>
                               <td><?= htmlspecialchars($h['current_year'] ?? '') ?></td>
                               <td><?= htmlspecialchars($h['next_year'] ?? '') ?></td>
                               <td><?= htmlspecialchars($h['total_classes'] ?? 0) ?></td>
                               <td><?= htmlspecialchars($h['total_students'] ?? 0) ?></td>
                               <td><?= htmlspecialchars($h['date_migration'] ?? '') ?></td>
                           </tr>
                           <?php endforeach; ?>
                       </tbody>
                   </table>
               </div>
           </div>
       </div>
       <?php endif; ?>
       <?php } ?>

       <!-- ===== HISTORIQUE DES OPERATIONS ===== -->
       <div class="card shadow-sm mb-4">
           <div class="card-header bg-info text-white py-2">
               <h5 class="m-0 fw-bold"><i class="fa-solid fa-clock-rotate-left me-2"></i>HISTORIQUE DES OPERATIONS</h5>
           </div>
           <div class="card-body">
               <p class="text-muted small mb-2">Historique des 30 dernières connexions</p>
               <div class="table-wrapper-scroll-y my-search-scrollbar" style="max-height: 600px">
                   <table class="table table-hover table-striped align-middle mb-0">
                       <thead class="table-info">
                           <tr><th>#</th><th>Login</th><th>Utilisateur</th><th>Role</th><th>Dernière Opération</th><th>Dernière Connexion</th></tr>
                       </thead>
                       <tbody><?php $opt->ShowAllOpt(); ?></tbody>
                   </table>
               </div>
           </div>
       </div>

   </div>
          </div>
          </div>

    <?php Config::scriptJs(); ?>
	</body>
</html>