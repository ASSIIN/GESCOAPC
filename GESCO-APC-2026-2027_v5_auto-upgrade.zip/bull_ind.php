<?php
    session_start();   
	require_once 'core/require.php'; 
	require_once 'Model/connexion.php';
     if (!isset($_SESSION['user'])) {
    session_unset();
    session_destroy();
    header('location: index.php');    
    }
   // $admin->ShowAdmin($_SESSION['login']);
    $nbclasses=$class->NombreClasses();
    $etb->ShowEtb();
    $etb->CkLE();
    $etb->ckexneE();
     
$id_ens = $_SESSION['login'];
$user_role = $_SESSION['user_role'];
$e1="";
$e2="";
    
?>

<!DOCTYPE html>
<html>
  <head>
   <?php Config::head(); ?>
    <title>GESCOAPC| BULL INDIVIDUEL</title>
  </head>

<body>
    <div class="wrapper">
      <!-- Sidebar -->

      <!-- Inclusion du menu de navigation externe réutilisable -->
      <?php include 'core/sidebar.php'; ?>  

<div class="main-content-wrapper">
        <!-- Barre supérieure de navigation adaptative -->
        <div class="mobile-navbar-fixed p-3 mb-4 rounded shadow-sm border">
            <div class="row align-items-center g-2">
                <div class="col-auto d-md-none">
                    <button class="btn btn-outline-dark btn-sm" id="toggleMobileMenu"><i class="fa fa-bars fa-lg"></i></button>
                </div>
                <div class="col-12 col-md">
                    <h4 class="m-0 fw-bold text-primary text-uppercase">Bulletin individuel</h4>
                </div>
            </div>
        </div>
        <!-- <?php //$class->SelectCls_Note_by_User($id_ens);?> -->
     <div class="container my-4 overflow-y">
   
    <div class="row mt-5 pt-4 ">
        <!-- Colonne 1 : Liste des trimestres -->
        <h4 class=" text-center">Sélectionner l'élève::::</h4>
        <div class="col-md-4">
            <div class="card">
                <div class="card-header">TRIM</div>
                <div class="card-body">
                    <div class="list-group">

                       <?php if (isset($_GET['trim']) && isset($_GET['refcls']) ) : 
                           $trim=htmlspecialchars($_GET['trim']);
                            $refbul= substr($trim, 1, 1);
                            echo '<a href="bull_ind.php?trim='.$_GET['trim'].'&refcls='.$_GET['refcls'].'" class="list-group-item list-group-item-action '.$_GET['trim'].'== "t1") ? "active" : "";">Trim  '.$refbul.'</a>';
                           else : ?>
                            <p class="text-muted">Sélectionnez un trimestre </p>
                        <?php endif; ?>
                       
                    </div>
                </div>
            </div>
        </div>
        
      
       
        <div class="col-md-4">
            <div class="card">
                <div class="card-header">ELEVE</div>
                <div class="card-body">
                    <div class="list-group">
                        <?php if (isset($_GET['trim']) && isset($_GET['refcls']) ) : 
                           $class->SelectStd_byCls_by_trim($_GET['trim'],$_GET['refcls']);
                           ?>
                         
                        <?php else : ?>
                            <p class="text-muted">Sélectionnez un trimestre et une classe.</p>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
    

</div>

      <!-- End Sidebar -->
    <?php 
      Config::scriptJs();
    ?>

    <script type="text/javascript">
      document.addEventListener('DOMContentLoaded', function() {
    // Gérer le clic sur les éléments de la liste
    document.querySelectorAll('.list-group-item').forEach(item => {
        item.addEventListener('click', function(event) {
            // Retirer la classe 'active' de tous les éléments de la même liste
            const listGroup = this.closest('.list-group');
            listGroup.querySelectorAll('.list-group-item').forEach(el => {
                el.classList.remove('active');
                el.classList.add('fade');
                setTimeout(() => {
                    el.classList.remove('fade');
                }, 300);
            });
            
            // Ajouter la classe 'active' à l'élément cliqué avec un effet de fade-in
            this.classList.add('fade');
            this.classList.add('active');
            setTimeout(() => {
                this.classList.remove('fade');
            }, 300);
        });
    });
});
    </script>
    <script type="text/javascript">
      $(document).ready(function() {
  
    
    // Optionnel : Si vous voulez pré-sélectionner la classe active en fonction de l'URL
    var urlParams = new URLSearchParams(window.location.search);
    var classe = urlParams.get('ref_class');
    if (classe) {
        $('#list-classes .list-group-item').each(function() {
            if ($(this).attr('href').includes('ref_class=' + classe)) {
                $(this).addClass('active');
            }
        });
    }
});
    </script>



</body>
</html>