<?php
	session_start();
	require_once '../../../Model/connexion.php';
	require_once '../../../core/require.php'; 	
	$ref_std= htmlspecialchars($_POST['ref_std']);
	$ref_cls= htmlspecialchars($_POST['ref_cls']);
	$vsm_c= htmlspecialchars($_POST['vsm_std']);
	if (htmlspecialchars($_POST['val_remise'])==null) {
		$remise=0;
	}
	else{
		$remise= htmlspecialchars($_POST['val_remise']);
	}
	if (!isset($_POST['print'])) {
		$print="non";
	}else{
		$print= htmlspecialchars($_POST['print']);
	}
	
        /* Generation du Id vsm*/
       $lastvsm=$fin->IncrimIDvsmt();
       if ($lastvsm!="")
       {
       	  $Numvsm=(int)$lastvsm;  
       	   $Numvsm++;
       	   $codeswift2="0000";
       	   $codeN2=$codeswift2.$Numvsm;
       	   $id_vsm=substr($codeN2,-4);
       }
       else{
       		$lastvsm="1";
       	 	$Numvsm=(int)$lastvsm;  
       	   $Numvsm++;
       	   $codeswift2="0000";
       	   $codeN2=$codeswift2.$Numvsm;
       	   $id_vsm=substr($codeN2,-4);
       }
        
		$nv=$fin->ReturnClasseNiveauByCode($ref_cls);
		$sess=$fin->ReturnClasseSessionByCode($ref_cls);
		$ps=$fin->Return_Ps_Nv($nv,$sess);
		$rdt=$fin->Return_All_rdt_std($ref_std);
		$vsm=$fin->Return_All_vsm_std($ref_std);
		$reste=$ps-$vsm-$rdt;
		if ($ps!=0) {
			
			if ($reste==0 or $reste<$vsm_c or $reste<0  ) {
				header('location: ../../../gestion_fin.php?ep=0');
				
			}
			else{

				$bdd = $GLOBALS['bdd'];

				$req = 'INSERT INTO versements (ref_std, prix_vsm, id_vsm) VALUES(?, ?, ?)' ;

				$rep = $bdd->prepare($req);
				if ($rep->execute(array($ref_std, $vsm_c, $id_vsm))) {

					if ($remise!=0) 
					{
						$bdd = $GLOBALS['bdd'];

						$req3 = 'INSERT INTO remises (ref_std, prix_rms, ref_vsm) VALUES(?, ?, ?)' ;
						$rep3 = $bdd->prepare($req3);
						$rep3->execute(array($ref_std, $remise, $id_vsm));
						
					}
					if ($print=="oui") {
						header('location: ../../../fpdf185/print_recu.php?id='.$id_vsm.'&std='.$ref_std.'');
					}
					else{
						header('location: ../../../gestion_fin.php');
					}
					
				}
			
				}
		
			}
		else{
				header('location: ../../../gestion_fin.php?f
					=0');
			}

		
?>