<?php
session_start();
require_once '../../Model/connexion.php';
require_once '../../core/require.php'; 	

$cls = filter_input(INPUT_GET, 'cls', FILTER_SANITIZE_SPECIAL_CHARS);
$trim = filter_input(INPUT_GET, 'trim', FILTER_SANITIZE_NUMBER_INT);

if ($cls && $trim) {
    $bdd = $GLOBALS['bdd'];

    // 1. Paramétrage des périodes (Correction du bug trim 2 qui pointait vers rang_trim1)
    $config_trim = [
        '1' => ['eval1' => '1', 'eval2' => '2'],
        '2' => ['eval1' => '3', 'eval2' => '4'],
        '3' => ['eval1' => '5', 'eval2' => '6']
    ];

    $eval1 = $config_trim[$trim]['eval1'] ?? '5';
    $eval2 = $config_trim[$trim]['eval2'] ?? '6';
    $table_trim = "table_note_par_trim" . $trim;

    // 2. Récupération des élèves de la classe
    $stmt0 = $bdd->prepare('SELECT mat_std FROM eleves WHERE ref_class = ?');
    $stmt0->execute([$cls]);

    while ($row0 = $stmt0->fetch(PDO::FETCH_ASSOC)) {
        $Totalcoeff = 0;
        $Totalpoint = 0;
        $std_id = $row0['mat_std'];

        // 3. Parcours des matières configurées pour cette classe
        $stmt1 = $bdd->prepare('SELECT ref_mat, coeff_mat FROM config_bull WHERE ref_class = ? ORDER BY group_mat ASC');
        $stmt1->execute([$cls]);

        while ($row1 = $stmt1->fetch(PDO::FETCH_ASSOC)) {
            $cknote1 = $class->SelectNoteStd_by_MatCls($cls, $row1['ref_mat'], $eval1, $std_id);
            $cknote2 = $class->SelectNoteStd_by_MatCls($cls, $row1['ref_mat'], $eval2, $std_id);
            $coeff_matiere_brut = $row1['coeff_mat'];

            // --- TA LOGIQUE DE CALCUL ---
            $notes_valides_numeriques = array_filter([$cknote1, $cknote2], fn($v) => is_numeric($v));
            $nombre_notes = count($notes_valides_numeriques);
            $coeff_num = is_numeric($coeff_matiere_brut) ? (float)$coeff_matiere_brut : NULL;

            if ($nombre_notes > 0 && is_numeric($coeff_num)) {
                $coeff = round($coeff_num, 2);
                $moy_matiere = array_sum($notes_valides_numeriques) / $nombre_notes;
                $moy_matiere = round($moy_matiere, 2);
                $total_matiere = round($moy_matiere * $coeff, 2);

                // MISE À JOUR DES TOTAUX GÉNÉRAUX
                $Totalcoeff += $coeff;
                $Totalpoint += $total_matiere;
            }
        }

        // 4. Calcul de la moyenne générale et insertion
        $moyenne_generale = ($Totalcoeff > 0) ? round($Totalpoint / $Totalcoeff, 2) : 0;

        $check = $bdd->prepare("SELECT COUNT(*) FROM $table_trim WHERE ref_std = ?");
        $check->execute([$std_id]);
        $exists = $check->fetchColumn();

        if ($exists) {
            $req = "UPDATE $table_trim SET total_note = ?, total_coef = ?, moy = ? WHERE ref_std = ?";
            $bdd->prepare($req)->execute([$Totalpoint, $Totalcoeff, $moyenne_generale, $std_id]);
        } else {
            $req = "INSERT INTO $table_trim (ref_trim, ref_cls, ref_std, total_note, total_coef, moy) VALUES (?, ?, ?, ?, ?, ?)";
            $bdd->prepare($req)->execute([$trim, $cls, $std_id, $Totalpoint, $Totalcoeff, $moyenne_generale]);
        }

        // 5. Gestion du statut "classer"
        $t_coef = (float)$opt->NombreCoeffbyStd_Cls($cls, $trim, $std_id);
        $classer_status = ($Totalcoeff > 0 && ($t_coef / $Totalcoeff) >= $GLOBALS['MargeCoeff_trim']) ? 'Y' : 'N';
        $bdd->prepare("UPDATE $table_trim SET classer = ? WHERE ref_std = ?")->execute([$classer_status, $std_id]);
    }

    // 6. CALCUL DES RANGS (Optimisé : après avoir calculé toutes les moyennes)
    $stmtRank = $bdd->prepare("SELECT ref_std FROM $table_trim WHERE ref_cls = ? ORDER BY moy DESC");
    $stmtRank->execute([$cls]);
    $n = 1;
    while ($rowR = $stmtRank->fetch(PDO::FETCH_ASSOC)) {
        $bdd->prepare("UPDATE $table_trim SET rang = ? WHERE ref_std = ? AND ref_cls = ?")
            ->execute([$n++, $rowR['ref_std'], $cls]);
    }

    header('location: ../../calculs_notes.php?status=success');
    exit();
} else {
    echo "Erreur : Paramètres manquants.";
}
