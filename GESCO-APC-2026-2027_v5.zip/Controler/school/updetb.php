<?php
	session_start();
	require_once '../../Model/connexion.php';
	require_once '../../core/require.php';
	require_once __DIR__ . '/photo_securite.php';

	// Sécurité : page réservée aux rôles autorisés sur general_setting.php (admin / pcpl)
	if (!isset($_SESSION['user']) || !in_array($_SESSION['user_role'] ?? '', array('admin', 'pcpl'))) {
		header('location: ../../index.php');
		exit;
	}

	// Sauvegarde une image (logo / signature) après validation par signature
	// binaire. Retourne le nom de fichier canonique (logo.png, logo.jpg,
	// signature.png, signature.jpg) ; false si format refusé ; null si aucun
	// fichier n'a été envoyé ou si la copie a échoué.
	function updetb_sauver_image_etab($fichierEnvoye, $base)
	{
		if (empty($fichierEnvoye['name']) || ($fichierEnvoye['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK) {
			return null;
		}
		// Validation du TYPE RÉEL (signature binaire), pas de la seule extension.
		$type = gesco_type_image($fichierEnvoye['tmp_name']);
		if ($type !== 'png' && $type !== 'jpg') {
			return false;
		}
		$dossier = __DIR__ . "/../../plugins/images/";
		$fichier = $base . '.' . $type;
		// On déplace d'abord le nouveau fichier (ne détruit jamais l'ancien
		// si le transfert échoue), puis on supprime la variante d'extension
		// opposée pour garder un seul nom canonique (logo.png / logo.jpg…).
		if (!move_uploaded_file($fichierEnvoye['tmp_name'], $dossier . $fichier)) {
			return null;
		}
		foreach (array('png', 'jpg') as $ext) {
			if ($ext === $type) { continue; }
			$p = $dossier . $base . '.' . $ext;
			if (file_exists($p) && is_file($p)) {
				@unlink($p);
			}
		}
		return $fichier;
	}

	// Le nom de l'établissement en FRANÇAIS est volontairement OMIS : il est lié
	// à la licence et ne doit jamais être modifié depuis cette page.
	// Le nom en anglais (nom_etb_en) reste, lui, modifiable.
	$nom_etb_en = htmlspecialchars($_POST['nom_etb_en'] ?? '');
	$minist_etb_fr = htmlspecialchars($_POST['minist_etb_fr'] ?? '');
	$minist_etb_en = htmlspecialchars($_POST['minist_etb_en'] ?? '');
	$region_etb_fr = htmlspecialchars($_POST['region_etb_fr'] ?? '');
	$region_etb_en = htmlspecialchars($_POST['region_etb_en'] ?? '');
	$depart_etb_fr = htmlspecialchars($_POST['depart_etb_fr'] ?? '');
	$depart_etb_en = htmlspecialchars($_POST['depart_etb_en'] ?? '');
	$tel_etb = htmlspecialchars($_POST['tel_etb'] ?? '');
	$email_etb = htmlspecialchars($_POST['email_etb'] ?? '');
	$code_pste_etb = htmlspecialchars($_POST['code_pste_etb'] ?? '');
	$code_im_etb = htmlspecialchars($_POST['code_im_etb'] ?? '');
	$ville_etb = htmlspecialchars($_POST['ville_etb'] ?? '');
	$slogan_etb = htmlspecialchars($_POST['slg'] ?? '');
	$pre_matr = htmlspecialchars($_POST['pre_matr'] ?? '');
	$nom_respo_etb = htmlspecialchars($_POST['nom_respo_etb'] ?? '');

	// CORRECTION : paramètre « cachet sur bulletin » (p_ch) — valeur O / N uniquement
	$p_ch = (($_POST['p_ch'] ?? '') === 'O') ? 'O' : 'N';

	/* conversion des apostrophes html + mise en majuscules */
	foreach (array('minist_etb_fr', 'minist_etb_en', 'region_etb_fr', 'region_etb_en',
	              'depart_etb_fr', 'depart_etb_en',
	              'ville_etb', 'slogan_etb', 'nom_etb_en') as $champ) {
		$$champ = str_replace("&#039;", "'", $$champ);
	}
	$minist_etb_fr = mb_strtoupper($minist_etb_fr);
	$minist_etb_en = mb_strtoupper($minist_etb_en);
	$region_etb_fr = mb_strtoupper($region_etb_fr);
	$region_etb_en = mb_strtoupper($region_etb_en);
	$depart_etb_fr = mb_strtoupper($depart_etb_fr);
	$depart_etb_en = mb_strtoupper($depart_etb_en);
	$ville_etb = mb_strtoupper($ville_etb);
	$pre_matr = mb_strtoupper($pre_matr);
	$nom_etb_en = mb_strtoupper($nom_etb_en);

	/* Traitement des images d'abord (logo + signature) : résultat en variable */
	$logo_etb = updetb_sauver_image_etab($_FILES['support1'] ?? null, 'logo');
	$sign_respo_etb = updetb_sauver_image_etab($_FILES['support2'] ?? null, 'signature');

	/* Ajoute la valeur au tableau des champs texte (si une image a été sauvée) */
	if (is_string($logo_etb)) {
		$logo_etb_saved = $logo_etb;
	} else {
		$logo_etb_saved = null;
	}
	if (is_string($sign_respo_etb)) {
		$sign_respo_etb_saved = $sign_respo_etb;
	} else {
		$sign_respo_etb_saved = null;
	}

	$elt = array(
		'nom_etb_en' => $nom_etb_en,
		'minist_etb_fr' => $minist_etb_fr,
		'minist_etb_en' => $minist_etb_en,
		'region_etb_fr' => $region_etb_fr,
		'region_etb_en' => $region_etb_en,
		'depart_etb_fr' => $depart_etb_fr,
		'depart_etb_en' => $depart_etb_en,
		'tel_etb' => $tel_etb,
		'email_etb' => $email_etb,
		'code_im_etb' => $code_im_etb,
		'code_pste_etb' => $code_pste_etb,
		'ville_etb' => $ville_etb,
		'slogan_etb' => $slogan_etb,
		'pre_matr' => $pre_matr,
		'nom_respo_etb' => $nom_respo_etb,
	);
	// CORRECTION : seuls les champs réellement remplis sont mis à jour.
	// Un champ laissé vide ne modifie plus la valeur existante en base.
	$elt = array_filter($elt, function ($v) {
		return trim((string)$v) !== '';
	});
	// Le cachet sur bulletin (sélecteur O/N) est toujours explicite.
	$elt['p_ch'] = $p_ch;
	// Les images (logo / signature) ne sont ajoutées que si un fichier a été
	// réellement déposé et sauvegardé (déjà filtré : null si aucun transfert).
	if ($logo_etb_saved !== null) { $elt['logo_etb'] = $logo_etb_saved; }
	if ($sign_respo_etb_saved !== null) { $elt['sign_respo_etb'] = $sign_respo_etb_saved; }

	$bdd = $GLOBALS['bdd'];
	foreach ($elt as $key => $value) {
		if ($key === 'pre_matr') {
			$val = (mb_strtoupper($value) === 'OFF') ? null : $value;
			$bdd->prepare('UPDATE etablissement SET ' . $key . ' = ? WHERE id >= 0')->execute(array($val));
			continue;
		}
		$bdd->prepare('UPDATE etablissement SET ' . $key . ' = ? WHERE id >= 0')->execute(array($value));
	}

	// CORRECTION : resynchronisation de la session (les champs d'en-tête sont
	// relus depuis $_SESSION par general_setting.php).
	$row = $bdd->query('SELECT nom_etb_fr, nom_etb_en, ville_etb, tel_etb, email_etb,
	                                slogan_etb, logo_etb, sign_respo_etb, p_ch FROM etablissement LIMIT 1')->fetch(PDO::FETCH_ASSOC);
	if ($row) {
		foreach ($row as $k => $v) {
			$_SESSION[$k] = $v;
		}
	}

	$flag = ($logo_etb === false || $sign_respo_etb === false) ? '&imgerr=1' : '&saved=1';
	header('location: ../../general_setting.php?' . ltrim($flag, '&'));
	exit;