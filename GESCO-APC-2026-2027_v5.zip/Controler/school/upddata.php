<?php
session_start();

// Sécurité : la restauration d'une base est réservée aux rôles autorisés sur la page operations.php
if (!isset($_SESSION['user']) || !in_array($_SESSION['user_role'] ?? '', array('admin', 'pcpl', 'sg', 'cs'))) {
    header('location: ../../index.php');
    exit;
}

// Information de connexion à la base de données
// CORRECTION : validation stricte du nom de base (anti-injection dans le nom de base)
$con_year = preg_replace('/[^a-zA-Z0-9_-]/', '', (string)($_SESSION['con_year'] ?? ''));
$host = 'localhost';
$user = 'root';
$password = '';
$dbname = 'gescoapc_' . $con_year;

// Racine de l'application (fichiers des élèves / logo / cachets)
$appRoot = dirname(__DIR__, 2);
require_once __DIR__ . '/nettoyer_photos.php';

// Connexion à la base de données
$conn = new mysqli($host, $user, $password, $dbname);

// Vérifier la connexion
if ($conn->connect_error) {
    die("Connexion échouée : " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Vérifier si un fichier a été sélectionné
    if (isset($_FILES["sql_file"]) && $_FILES["sql_file"]["error"] === UPLOAD_ERR_OK) {
        $file_name = $_FILES["sql_file"]["name"];
        $file_tmp = $_FILES["sql_file"]["tmp_name"];
        $file_size = $_FILES["sql_file"]["size"];
        $ext = strtolower(pathinfo($file_name, PATHINFO_EXTENSION));

        // CORRECTION : contrôle d'extension .sql/.zip + limite de taille (300 Mo)
        if (in_array($ext, array('sql', 'zip'), true) && $file_size <= 300 * 1024 * 1024) {

            $sql_contenu = '';

            // ----- Extraction du contenu SQL (+ fichiers) depuis un .zip -----
            if ($ext === 'zip') {
                require_once $appRoot . DIRECTORY_SEPARATOR . 'less' . DIRECTORY_SEPARATOR . 'mini_zip.php';

                if (class_exists('ZipArchive')) {
                    $zip = new ZipArchive();
                    if ($zip->open($file_tmp) !== true) {
                        header('location: ../../operations.php?ef');
                        exit;
                    }
                    $racineImages = str_replace('\\', '/', $appRoot . '/plugins/images/');
                    for ($i = 0; $i < $zip->numFiles; $i++) {
                        $stat = $zip->statIndex($i);
                        $nameZip = ltrim(str_replace('\\', '/', (string)$stat['name']), '/');
                        if (substr($nameZip, -1) === '/') {
                            continue; // entrée dossier
                        }
                        $lower = strtolower($nameZip);
                        if (substr($lower, -4) === '.sql' && $sql_contenu === '') {
                            $sql_contenu = $zip->getFromIndex($i);
                            continue;
                        }
                        if (strpos($nameZip, 'plugins/images/') === 0) {
                            // Restauration sécurisée des fichiers : on refuse toute
                            // écriture hors de plugins/images/ (anti zip-slip).
                            $absFichier = str_replace('/', DIRECTORY_SEPARATOR, $nameZip);
                            $destPath = $appRoot . DIRECTORY_SEPARATOR . $absFichier;
                            $destNorm = str_replace('\\', '/', $destPath);
                            $realBase = realpath($appRoot . '/plugins/images');
                            $baseNorm = str_replace('\\', '/', $realBase !== false ? $realBase : $appRoot . '/plugins/images');
                            if ($destNorm !== $baseNorm && strpos($destNorm, $baseNorm . '/') === 0) {
                                $contenuFichier = $zip->getFromIndex($i);
                                if ($contenuFichier === false && $stat['size'] > 0) {
                                    continue;
                                }
                                $dirDest = dirname($destPath);
                                if (!is_dir($dirDest) && !@mkdir($dirDest, 0775, true)) {
                                    continue;
                                }
                                if ($contenuFichier !== false) {
                                    file_put_contents($destPath, $contenuFichier);
                                }
                            }
                        }
                    }
                    $zip->close();
                } else {
                    // Repli sans ZipArchive : mini-zip PHP pur
                    $extrait = gesco_zip_extraire_fichiers($file_tmp, $appRoot, 'plugins/images');
                    $sql_contenu = $extrait['sql'];
                }
                if ($sql_contenu === '') {
                    header('location: ../../operations.php?ef');
                    exit;
                }
            } else {
                // ----- Fichier SQL directement -----
                $sql_contenu = file_get_contents($file_tmp);
            }

            // Nettoyage des noms d'images altérés par un antislash
            gesco_nettoyer_photos($appRoot . DIRECTORY_SEPARATOR . 'plugins' . DIRECTORY_SEPARATOR . 'images');

            // Supprimer toutes les tables
            $conn->query("SET FOREIGN_KEY_CHECKS = 0");
            $result = $conn->query("SHOW TABLES");
            while ($row = $result->fetch_array()) {
                // CORRECTION : nom de table échappé par des backticks (anti-injection SQL)
                $table = '`' . str_replace('`', '', $row[0]) . '`';
                $conn->query("DROP TABLE " . $table);
            }
            $conn->query("SET FOREIGN_KEY_CHECKS = 1");

            // Exécuter les requêtes SQL
            // Nettoyage défensif : retirer tout caractère parasite après le dernier point-virgule
            $sql_nettoye = $sql_contenu;
            $trimmed = rtrim($sql_nettoye);
            if (($posLast = strrpos($trimmed, ';')) !== false) {
                $apres = substr($trimmed, $posLast + 1);
                $apresTrim = trim($apres);
                if ($apresTrim === '' || preg_match('/^[A-Za-z]$/', $apresTrim)) {
                    $sql_nettoye = substr($trimmed, 0, $posLast + 1);
                } else {
                    $sql_nettoye = $trimmed . ';';
                }
            }
            // Supprimer tout résidu non SQL (lettres seules) après ';'
            $sql_nettoye = preg_replace('/;\s*[A-Za-z]\s*$/u', ';', $sql_nettoye);

            if ($conn->multi_query($sql_nettoye !== '' ? $sql_nettoye : $sql_contenu)) {
                // Vider les jeux de résultats restants pour éviter les erreurs
                while ($conn->more_results()) {
                    if (!$conn->next_result()) { break; }
                }
                header('location: ../../operations.php?1');
            } else {
                header('location: ../../operations.php?0');
            }
        } else {
            header('location: ../../operations.php?ef');
        }
    } else {
        header('location: ../../operations.php?nf');
    }
}

// Fermer la connexion
$conn->close();