<?php
/**
 * Nettoyage des noms de fichiers images altérés par un antislash
 * (fichiers non reconnus comme images dans plugins/images).
 * Idempotent : renomme les entrées dont le nom commence par un
 * séparateur ou contient un antislash, puis les réécrit proprement.
 */
if (!function_exists('gesco_nettoyer_photos')) {

    function gesco_nettoyer_photos($racine)
    {
        $corriges = array();
        if (!is_dir($racine)) {
            return $corriges;
        }
        $queue = array($racine);
        while ($queue) {
            $dir = array_shift($queue);
            $items = @scandir($dir);
            if ($items === false) { continue; }
            foreach ($items as $e) {
                if ($e === '.' || $e === '..') { continue; }
                $chemin = $dir . DIRECTORY_SEPARATOR . $e;

                $base = ltrim(str_replace('\\', '/', $e), '/');
                $base = str_replace('/', '_', $base);
                if ($base === '') { continue; }

                if ($base !== $e) {
                    $nouv = $dir . DIRECTORY_SEPARATOR . $base;
                    $racineNouv = pathinfo($base, PATHINFO_FILENAME);
                    $extNouv = pathinfo($base, PATHINFO_EXTENSION);
                    $k = 1;
                    while (file_exists($nouv)) {
                        $nouv = $dir . DIRECTORY_SEPARATOR . $racineNouv . '_' . $k . ($extNouv !== '' ? '.' . $extNouv : '');
                        $k++;
                    }
                    if (@rename($chemin, $nouv)) {
                        $corriges[] = $chemin . ' -> ' . $nouv;
                        $e = $base;
                    }
                }

                if (is_dir($dir . DIRECTORY_SEPARATOR . $e)) {
                    $queue[] = $dir . DIRECTORY_SEPARATOR . $e;
                }
            }
        }
        return $corriges;
    }
}