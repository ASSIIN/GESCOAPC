<?php
/**
 * Sécurisation des images de l'établissement (logo, signature/cachet, QR)
 * et des photos d'élèves : détection du type réel par signature binaire,
 * génération d'un PNG de remplacement en PHP pur (aucune extension GD
 * requise) et réparation des fichiers corrompus qui « ne s'ouvrent pas ».
 */

if (!function_exists('gesco_type_image')) {
    // Retourne 'png' | 'jpg' | 'gif' | 'bmp' | 'webp' | 'ico' | '' (fichier
    // illisible / format inconnu / inexistant) selon les octets de signature.
    function gesco_type_image($chemin)
    {
        if (!is_file($chemin)) { return ''; }
        $h = @file_get_contents($chemin, false, null, 0, 16);
        if ($h === false || $h === '') { return ''; }
        $b = ord($h[0]);
        if ($b === 0x89 && substr($h, 1, 3) === 'PNG') { return 'png'; }
        if ($b === 0xFF && ord($h[1] ?? 0) === 0xD8 && ord($h[2] ?? 0) === 0xFF) { return 'jpg'; }
        if ($b === 0x47 && substr($h, 1, 5) === 'IF89' . "\0") { return 'gif'; }
        if ($b === 0x47 && substr($h, 1, 5) === 'IF87' . "\0") { return 'gif'; }
        if ($b === 0x42 && ord($h[1] ?? 0) === 0x4D) { return 'bmp'; }
        if (substr($h, 0, 4) === 'RIFF' && substr($h, 8, 4) === 'WEBP') { return 'webp'; }
        if ($b === 0x00 && ord($h[1] ?? 0) === 0x00 && (ord($h[2] ?? 0) === 0x01 || ord($h[2] ?? 0) === 0x02) && ord($h[3] ?? 0) === 0x00) { return 'ico'; }
        return '';
    }
}

if (!function_exists('gesco_placeholder_png_bytes')) {
    // PNG RGB solide de remplacement (octets bruts) : pur PHP, sans GD.
    function gesco_placeholder_png_bytes($l = 128, $h = 128, $r = 222, $g = 231, $b = 238)
    {
        $raw = '';
        $px = pack('CCC', $r & 0xFF, $g & 0xFF, $b & 0xFF);
        $row = "\x00" . str_repeat($px, $l);
        for ($y = 0; $y < $h; $y++) { $raw .= $row; }
        $idat = gzcompress($raw, 9);
        if ($idat === false) { return false; }

        // Table CRC32 (polynôme zlib standard, ordre d'écriture big-endian)
        $crcTab = array();
        for ($n = 0; $n < 256; $n++) {
            $c = $n;
            for ($k = 0; $k < 8; $k++) {
                $c = ($c & 1) ? (0xEDB88320 ^ ($c >> 1)) : ($c >> 1);
            }
            $crcTab[$n] = $c;
        }
        $crc32 = function ($data) use (&$crcTab) {
            $c = 0xFFFFFFFF;
            $len = strlen($data);
            for ($i = 0; $i < $len; $i++) {
                $c = $crcTab[($c ^ ord($data[$i])) & 0xFF] ^ ($c >> 8);
            }
            return pack('N', $c ^ 0xFFFFFFFF);
        };
        $chunk = function ($type, $data) use ($crc32) {
            return pack('N', strlen($data)) . $type . $data . $crc32($type . $data);
        };

        // 8 bits, couleur truecolor (type 2), pas d'entrelacement
        $ihdr = pack('NNCCCCC', $l, $h, 8, 2, 0, 0, 0);
        return "\x89PNG\r\n\x1a\n"
              . $chunk('IHDR', $ihdr)
              . $chunk('IDAT', $idat)
              . $chunk('IEND', '');
    }
}

if (!function_exists('gesco_placeholder_png')) {
    // Écrit un PNG RGB solide (remplaçant minimal) à l'emplacement donné.
    function gesco_placeholder_png($chemin, $l = 128, $h = 128, $r = 222, $g = 231, $b = 238)
    {
        $png = gesco_placeholder_png_bytes($l, $h, $r, $g, $b);
        if ($png === false || @file_put_contents($chemin, $png) === false) { return false; }
        return gesco_type_image($chemin) === 'png';
    }
}

if (!function_exists('gesco_reparer_image')) {
    // Remplace par un PNG valide tout fichier image inexistant ou dont la
    // signature binaire est invalide (fichier « qui ne s'ouvre pas »).
    // Retourne true si le fichier final est une image valide.
    function gesco_reparer_image($chemin)
    {
        if (gesco_type_image($chemin) !== '') {
            return true; // déjà valide
        }
        return gesco_placeholder_png($chemin);
    }
}

if (!function_exists('gesco_image_valide')) {
    // true si le fichier est une vraie image PNG ou JPEG.
    function gesco_image_valide($chemin)
    {
        $t = gesco_type_image($chemin);
        return ($t === 'png' || $t === 'jpg');
    }
}