<?php
session_start();

// Évite que le serveur HTTP ne re-compresse la réponse (l'archive est déjà
// compacte) : une réponse compressée deux fois serait refusée à la décompression.
if (function_exists('apache_setenv')) { @apache_setenv('no-gzip', '1'); }
@ini_set('zlib.output_compression', 'Off');

// Sécurité : la sauvegarde de la base est réservée aux rôles autorisés sur la page operations.php
if (!isset($_SESSION['user']) || !in_array($_SESSION['user_role'] ?? '', array('admin', 'pcpl', 'sg', 'cs'))) {
    header('location: ../../index.php');
    exit;
}

// CORRECTION : validation stricte du nom de base (anti-injection dans le nom de base / en-tête)
$con_year = preg_replace('/[^a-zA-Z0-9_-]/', '', (string)($_SESSION['con_year'] ?? ''));
if ($con_year === '') {
    header('location: ../../operations.php?ef');
    exit;
}

$mysqlUserName      = 'root';
$mysqlPassword      = '';
$mysqlHostName      = 'localhost';
$DbName             = 'gescoapc_' . $con_year;

$sql_dump = Export_Database_SQL($mysqlHostName, $mysqlUserName, $mysqlPassword, $DbName);

$avec_photos = !empty($_POST['avec_photos']);

if (!$avec_photos) {
    // Téléchargement simple du fichier SQL (comportement historique)
    $backup_name = $DbName . date('HisdmY') . '.sql';
    header('Content-Type: application/octet-stream');
    header("Content-Transfer-Encoding: Binary");
    header('Content-disposition: attachment; filename="' . $backup_name . '"');
    echo $sql_dump;
    exit;
}

// =====================================================================
// Sauvegarde complète : dump SQL + fichiers (photos élèves, logo,
// cachet/signature) regroupés dans un fichier .zip.
// (ZipArchive si présent, sinon mini-zip PHP pur — pas d'extension requise)
// =====================================================================
$now        = date('HisdmY');
$appRoot    = dirname(__DIR__, 2);            // => racine GESCO-APC
$imagesRoot = $appRoot . DIRECTORY_SEPARATOR . 'plugins' . DIRECTORY_SEPARATOR . 'images';

$nom_zip = $DbName . '_avec_photos_' . $now . '.zip';
$fichierZip = tempnam(sys_get_temp_dir(), 'gesco_') . '.zip';

$entreesZip = array();

// 1) Dump SQL à la racine du zip
$entreesZip[] = array('nom' => $DbName . '_' . $now . '.sql', 'contenu' => $sql_dump);

// 2) Photos des élèves (dossier plugins/images/imgstd)
$nb_photos = sauvegarde_preparer_dossier($imagesRoot . DIRECTORY_SEPARATOR . 'imgstd', 'plugins/images/imgstd', $entreesZip);
if ($nb_photos === 0) {
    // Dossier des photos vide : on place un garde-fou lisible
    $entreesZip[] = array('nom' => 'plugins/images/imgstd/LISEZMOI.txt', 'contenu' => "Aucune photo d'élève n'est enregistrée pour le moment.\n");
}

// 3) Logo, cachet/signature et QR code de l'établissement (racine images)
foreach (glob($imagesRoot . DIRECTORY_SEPARATOR . 'logo.*') ?: array() as $f) {
    $entreesZip[] = array('nom' => 'plugins/images/' . basename($f), 'fichier' => $f);
}
foreach (glob($imagesRoot . DIRECTORY_SEPARATOR . 'signature.*') ?: array() as $f) {
    $entreesZip[] = array('nom' => 'plugins/images/' . basename($f), 'fichier' => $f);
}
foreach (glob($imagesRoot . DIRECTORY_SEPARATOR . 'qrcode.*') ?: array() as $f) {
    $entreesZip[] = array('nom' => 'plugins/images/' . basename($f), 'fichier' => $f);
}

require_once $appRoot . DIRECTORY_SEPARATOR . 'Controler' . DIRECTORY_SEPARATOR . 'school' . DIRECTORY_SEPARATOR . 'photo_securite.php';

// Fichiers image corrompus (ex. logo/signature/QR illisibles) : on les
// remplace par un PNG de substitution valide pour que le zip, une fois
// décompressé, ne contienne que des images qui s'ouvrent réellement.
foreach ($entreesZip as $i => $e) {
    if (isset($e['fichier']) && gesco_type_image($e['fichier']) === '') {
        $placeholder = gesco_placeholder_png_bytes(128, 128);
        if ($placeholder !== false) {
            $entreesZip[$i] = array('nom' => $e['nom'], 'contenu' => $placeholder);
        }
    }
}

$zip_ok = false;
if (class_exists('ZipArchive')) {
    $zip = new ZipArchive();
    if ($zip->open($fichierZip, ZipArchive::CREATE | ZipArchive::OVERWRITE) === true) {
        $zip_ok = true;
        foreach ($entreesZip as $e) {
            if (isset($e['contenu'])) { $zip->addFromString($e['nom'], $e['contenu']); }
            else { $zip->addFile($e['fichier'], $e['nom']); }
        }
        $zip->close();
    }
} else {
    require_once $appRoot . DIRECTORY_SEPARATOR . 'less' . DIRECTORY_SEPARATOR . 'mini_zip.php';
    $zip_ok = gesco_zip_creer($fichierZip, $entreesZip);
}

if (!$zip_ok) {
    // Repli prudent : si le zip échoue, on renvoie au moins le dump SQL
    $backup_name = $DbName . $now . '.sql';
    header('Content-Type: application/octet-stream');
    header("Content-Transfer-Encoding: Binary");
    header('Content-disposition: attachment; filename="' . $backup_name . '"');
    echo $sql_dump;
    exit;
}

header('Content-Type: application/zip');
header("Content-Transfer-Encoding: Binary");
header('Content-disposition: attachment; filename="' . $nom_zip . '"');
header('Content-Length: ' . filesize($fichierZip));
readfile($fichierZip);
@unlink($fichierZip);
exit;

// ---------------------------------------------------------------------
// Génère le dump SQL complet d'une base (retourne le contenu, sans HTTP).
// ---------------------------------------------------------------------
function Export_Database_SQL($host, $user, $pass, $name)
{
    $mysqli = new mysqli($host, $user, $pass, $name);
    if ($mysqli->connect_error) {
        die('Erreur de connexion base de données : ' . $mysqli->connect_error);
    }
    $mysqli->select_db($name);
    $mysqli->query("SET NAMES 'utf8'");

    $queryTables = $mysqli->query('SHOW TABLES');
    $target_tables = array();
    while ($row = $queryTables->fetch_row()) {
        $target_tables[] = $row[0];
    }

    $content = '';
    foreach ($target_tables as $table) {
        $result        = $mysqli->query('SELECT * FROM `' . $table . '`');
        $fields_amount = $result->field_count;
        $fields_col    = $result->fetch_fields();
        $rows_num      = $mysqli->affected_rows;
        $res           = $mysqli->query('SHOW CREATE TABLE `' . $table . '`');
        $TableMLine    = $res->fetch_row();

        $content .= "\n\n" . $TableMLine[1] . ";\n\n";

        for ($i = 0, $st_counter = 0; $i < $fields_amount; $i++, $st_counter = 0) {
            while ($row = $result->fetch_row()) {
                if ($st_counter % 500 == 0 || $st_counter == 0) {
                    $content .= "\nINSERT INTO `$table` (";
                    $i = 0;
                    foreach ($fields_col as $field) {
                        $i++;
                        if ($i < $fields_amount) {
                            $content .= "`" . $field->name . "`, ";
                        } else {
                            $content .= "`" . $field->name . "`";
                        }
                    }
                    $content .= ")  VALUES";
                }

                $content .= "\n(";
                $tab_tp_col = array();
                $ii = 0;
                foreach ($fields_col as $fieldi) {
                    $tab_tp_col[$ii] = $fieldi->type;
                    $ii++;
                }

                for ($j = 0; $j < $fields_amount; $j++) {
                    if (isset($row[$j])) {
                        $val = $row[$j];
                        if ($j == 0 || $tab_tp_col[$j] == "double" || $tab_tp_col[$j] == "float" || $tab_tp_col[$j] == "int") {
                            $content .= $row[$j];
                        } else {
                            $content .= '"' . $mysqli->real_escape_string($row[$j]) . '"';
                        }
                    } else {
                        $content .= 'NULL';
                    }
                    if ($j < ($fields_amount - 1)) {
                        $content .= ',';
                    }
                }
                $content .= ")";
                if ((($st_counter + 1) % 500 == 0 && $st_counter != 0) || $st_counter + 1 == $rows_num) {
                    $content .= ";";
                } else {
                    $content .= ",";
                }
                $st_counter = $st_counter + 1;
            }
        }
        $content .= "\n\n\n";
    }
    $mysqli->close();

    return $content;
}

// ---------------------------------------------------------------------
// Prépare la liste des entrées d'un dossier (chemins relatifs conservés).
// Remplit $entreesZip en place et retourne le nombre de fichiers ajoutés.
// ---------------------------------------------------------------------
function sauvegarde_preparer_dossier($racineAbsolue, $prefixeZip, array &$entreesZip)
{
    if (!is_dir($racineAbsolue)) {
        return 0;
    }
    $n = 0;
    $it = new RecursiveIteratorIterator(
        new RecursiveDirectoryIterator($racineAbsolue, FilesystemIterator::SKIP_DOTS)
    );
    foreach ($it as $fichier) {
        if (!$fichier->isFile()) {
            continue;
        }
        // Normalisation du nom relatif : on supprime tout séparateur
        // parasite en tête et on convertit \ en / (les \ ne doivent pas
        // figurer dans les entrées du zip, sinon les fichiers ne sont
        // plus reconnus comme images à la restauration).
        $rel = substr($fichier->getPathname(), strlen(rtrim($racineAbsolue, '\\/')));
        $rel = str_replace('\\', '/', $rel);
        $rel = trim($rel, '/');
        if ($rel === '') {
            continue;
        }
        $entreesZip[] = array('nom' => $prefixeZip . '/' . $rel, 'fichier' => $fichier->getPathname());
        $n++;
    }
    return $n;
}