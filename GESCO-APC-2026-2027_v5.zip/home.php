<?php 
  session_start();   
  require_once 'core/require.php'; 
  require_once 'Model/connexion.php';

  if (!isset($_SESSION['user'])) {
      session_unset();
      session_destroy();
      header('location: index.php');    
      exit();
  }

  // Filtrage strict des rôles autorisés sur le tableau de bord d'administration
  if (($_SESSION['user_role'] != "admin") && ($_SESSION['user_role'] != "cs") && ($_SESSION['user_role'] != "pcpl") && ($_SESSION['user_role'] != "caisse") && ($_SESSION['user_role'] != "ens")) {
      header('location: poste_de_saisie.php?trim=t1');    
      exit();
  }

  $nbstd = $class->NbrStudentByAll();
  $nbM_all = $class->NbrBySexeByAll('M');
  $nbF_all = $class->NbrBySexeByAll('F');
  $ckcls = false;
  $nom_allcls = "TOUTES";

  // Validation et sécurisation du filtrage par classe via URL
  if (isset($_GET['cls'])) {
      $ckcls = $class->CkExistingCode($_GET['cls']);
      if (($ckcls == false) && ($_GET['cls'] != 'all')) {
          header('location: home.php?cls=all');    
          exit();
      } else {
          $nbstd_cls = $class->NbrStudentByClass($_GET['cls']);
          $nom_cls = $class->ReturnNomCls_by_Code($_GET['cls']);
          $nbM = $class->NbrBySexeByClass($_GET['cls'], 'M');
          $nbF = $class->NbrBySexeByClass($_GET['cls'], 'F');
      }
  }
  
  $etb->ShowEtb();
  $etb->ckexneE(); // Vérification de l'intégrité de la structure scolaire
  $nbstd = $std->NombreSTD();
?>
<!DOCTYPE html>
<html lang="fr">
  <head>
     <script>
         // Script d'interception immédiate pour empêcher le flash blanc au chargement
         document.documentElement.setAttribute("data-theme", localStorage.getItem("theme") || "light");
     </script>
     <?php Config::head(); ?>
     <!-- Correctif CSS réutilisable externe pour la priorité absolue des modaux -->
     <link rel="stylesheet" href="assets/css/modals-fix.css">
     <title>GESCOAPC | Élèves</title>
     
     <style>
         /* Styles responsives spécifiques et uniques à la page home */
         @media (max-width: 768px) {
             .fixed-top-mobile {
                 position: relative !important;
                 top: 0 !important;
                 margin-left: 0 !important;
                 width: 100% !important;
                 padding: 10px !important;
             }
             .main-content-wrapper {
                 margin-left: 0 !important;
                 padding: 15px !important;
                 padding-top: 80px !important;
             }
             .btn-group-mobile {
                 width: 100%;
                 margin-bottom: 10px;
             }
             .btn-group-mobile .btn {
                 width: 100%;
             }
         }
     </style>
  </head>
  <body>

    <!-- Inclusion du menu de navigation externe réutilisable -->
    <?php include 'core/sidebar.php'; ?>  

    <!-- Conteneur principal de l'application -->
    <div class="main-content-wrapper">
        
        <!-- Barre supérieure de recherche et filtres (Sticky Mobile) -->
        <div class="mobile-navbar-fixed p-3 mb-4 rounded shadow-sm border">
            <div class="row align-items-center g-2">
                
                <!-- Bouton d'ouverture du menu tiroir sur smartphone -->
                <div class="col-auto d-md-none">
                    <button class="btn btn-outline-dark btn-sm" id="toggleMobileMenu"><i class="fa-solid fa-bars fa-lg"></i></button>
                </div>
                
                <!-- Recherche rapide et boutons d'actions contextuels -->
                <div class="col col-md-4 d-flex gap-1">
                    <input class="form-control form-control-sm" id="input-std" type="text" placeholder="&#xF002; Rechercher un élève..." style="font-family: Arial, FontAwesome; min-width: 180px;">
                    <button type="button" class="btn btn-sm btn-success text-white" data-bs-toggle="modal" data-bs-target="#addstd" title="Inscrire un élève"><i class="fa-solid fa-plus"></i></button>
                    <button type="button" class="btn btn-sm btn-primary" data-bs-toggle="modal" data-bs-target="#importstd" title="Importer un lot Excel"><i class="fa-solid fa-upload"></i></button>
                </div>

                <!-- Sélecteur de classe et affichage dynamique des statistiques d'effectifs -->
                <div class="col-12 col-md-8 d-flex justify-content-md-end justify-content-between align-items-center gap-2 flex-wrap btn-group-mobile">
                    <div class="btn-group btn-sm">
                        <button class="btn btn-sm btn-outline-primary dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                          Filtrer par classe
                        </button>           
                        <ul class="dropdown-menu dropdown-menu-end shadow" style="max-height: 250px; overflow-y: auto;">
                            <li><a class="dropdown-item fw-bold text-primary" href="home.php?cls=all">Toutes les Classes</a></li>
                            <li><hr class="dropdown-divider"></li>
                            <?php $std->LinkClassesNames(); ?>
                        </ul>
                    </div>

                    <div class="stats-badge px-3 py-1 small border fw-bold rounded-pill">
                        <?php if ($ckcls): ?>
                            Classe: <span class="text-primary me-2"><?php echo $nom_cls; ?></span> 
                            Eff: <span class="text-danger me-2"><?php echo $nbstd_cls; ?></span> 
                            G: <span class="text-success me-2"><?php echo $nbM; ?></span> 
                            F: <span class="text-info"><?php echo $nbF; ?></span>
                        <?php else: ?>
                            Classe: <span class="text-primary me-2"><?php echo $nom_allcls; ?></span> 
                            Total: <span class="text-danger me-2"><?php echo $nbstd; ?></span> 
                            G: <span class="text-success me-2"><?php echo $nbM_all; ?></span> 
                            F: <span class="text-info"><?php echo $nbF_all; ?></span>
                        <?php endif; ?>
                    </div>
                </div>

            </div>
        </div>

        <!-- Zone d'alerte pour les conflits d'insertion système -->
        <div class="container-fluid p-0 mb-3">
          <?php
          if (isset($_GET['exist'])) {
              echo '<div class="alert alert-danger alert-dismissible fade show shadow-sm rounded-3 py-2 small" role="alert">
                      <i class="fa fa-exclamation-triangle me-2"></i><strong>Erreur d\'identification !</strong> Un élève possède déjà ce numéro de matricule au sein de la base de données.
                      <button type="button" class="btn-close py-2" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>';
          } 
          ?>
        </div>

        <!-- Section Tableau Responsive Filtré -->
        <div class="card border-0 shadow-sm">
            <div class="table-responsive w-100">
                <table class="table table-striped table-hover align-middle text-center mb-0">
                    <thead class="text-white table-dark-custom">
                        <tr style="font-size: 0.9em;">
                            <th style="width: 50px;">#</th>
                            <th style="width: 120px;">N° INSC</th>
                            <th class="mobile-hide" style="width: 120px;">MATRICULE</th>
                            <th class="text-start" style="padding-left:15px;">NOM COMPLET</th>
                            <th class="mobile-hide" style="width: 80px;">SEXE</th>
                            <th class="mobile-hide" style="width: 140px;">DATE DE NAISSANCE</th>
                            <th style="width: 120px;">CLASSE</th>
                            <th style="width: 60px;">EDIT</th>
                            <th style="width: 60px;">DEL</th>
                        </tr>
                    </thead>
                    <tbody id="tab-std" style="font-size: 0.88em; font-weight: 500;">
                        <?php
                        // Chargement modulaire des lignes du tableau selon le filtre actif
                        if (!isset($_GET['cls']) || $_GET['cls'] == "all" || empty($_GET['cls'])) {
                            $std->ShowAllStd();
                        } else {
                            $std->ShowAllStdByCls($_GET['cls']); 
                        }
                        ?>
                    </tbody>
                </table>
            </div>
        </div>

    </div>

    <!-- Chargement décentralisé des formulaires modaux Bootstrap 5 -->
    <?php include 'core/modals_home.php'; ?>

    <?php Config::scriptJs(); ?>

    <script>
      document.addEventListener('DOMContentLoaded', function () {
        // Limitation dynamique des dates de naissance pour empêcher les anomalies de saisie
        var limit = (new Date().getFullYear() - 7) + '-01-01';
        document.querySelectorAll('#date_naiss_std, #date_naiss_std1, #date_naiss_std2').forEach(function (field) { field.max = limit; });
        
        // Moteur de recherche instantané à la volée dans le tableau
        var search = document.getElementById('input-std');
        if (search) {
          search.addEventListener('input', function () {
            var value = search.value.trim().toLowerCase();
            document.querySelectorAll('#tab-std tr').forEach(function (row) { row.hidden = value !== '' && row.textContent.toLowerCase().indexOf(value) === -1; });
          });
        }

        // CORRECTIF JAVASCRIPT GLOBAL POUR L'IMBRICATION DES MODALS BOOTSTRAP 5
        // Dès qu'un modal commence à s'ouvrir, il est greffé directement sur le body pour contourner les conflits de calques
        document.addEventListener('show.bs.modal', function (event) {
          const modal = event.target;

          // Vérifie si le modal n'est pas déjà directement attaché au body
          if (modal && modal.parentElement !== document.body) {
              // Déplace physiquement l'élément HTML tout en bas du body
              document.body.appendChild(modal);

              // Actualisation sécurisée de l'instance Bootstrap 5 pour éviter de perdre le contrôle du modal
              if (typeof bootstrap !== 'undefined' && bootstrap.Modal) {
                  const modalInstance = bootstrap.Modal.getInstance(modal);
                  if (modalInstance && typeof modalInstance.handleUpdate === 'function') {
                      modalInstance.handleUpdate();
                  }
              }
          }
        });
      });
</script>
</body>
