﻿<?php
    session_start();
    require_once 'core/require.php';
    require_once 'Model/connexion.php';
    if (!isset($_SESSION['user'])) {
        session_unset();
        session_destroy();
        header('location: index.php');
    }
    if (isset($ref_cls)) {
        $ref_cls = '';
    }
    $etb->ShowEtb();
    $etb->CkLE();
    $etb->ckexneE();
    $flashMessage = isset($_GET['ec']) ? 'Vérifiez si la classe existe puis réessayez.' : null;
?>
<!DOCTYPE html>
<html lang="fr">
  <head>
    <?php Config::head(); ?>
    <title>GESCOAPC | Impressions</title>
    <style>
        .impress-section { border-left: 4px solid #0764a8; }
        .impress-section .card-header { font-size: 1.05em; }
        .impress-section .form-select-lg { min-height: 42px; }
        .impress-section .op-label { font-size: 0.85em; color: var(--text-muted); }
        .impress-section .btn-impression { min-width: 140px; }
        .stat-badge { display: inline-flex; align-items: center; gap: 6px; background: var(--bg-card); border: 1px solid var(--border-color); border-radius: 8px; padding: 8px 14px; font-size: 0.85em; color: var(--text-main); }
        .stat-badge i { color: var(--primary-color); }
        @media (max-width: 768px) {
            .impress-section .card-body { padding: 1rem; }
        }
    </style>
  </head>
<body>
    <?php if (!empty($flashMessage)) Config::toast($flashMessage, 'danger'); ?>
    <?php include 'core/sidebar.php'; ?>
    <div class="main-content-wrapper">
      <div class="mobile-navbar-fixed p-3 mb-4 rounded shadow-sm border">
        <div class="d-flex align-items-center justify-content-between gap-3">
          <button type="button" class="btn btn-outline-dark btn-sm d-md-none" id="toggleMobileMenu" aria-label="Ouvrir le menu"><i class="fa fa-bars"></i></button>
          <h4 class="m-0 fw-bold text-primary text-uppercase">Impressions</h4>
        </div>
      </div>
      <div class="container-fluid p-0">
        <!-- ============================================================== -->
        <!-- TITRE + STATISTIQUES -->
        <!-- ============================================================== -->
        <div class="row mt-3 mb-4">
          <div class="col-12">
            <div class="d-flex flex-wrap align-items-center gap-3">
              <span class="stat-badge"><i class="fa fa-book"></i> 7 modules d'impression</span>
              <span class="stat-badge"><i class="fa fa-print"></i> Fiches, Bulletins, Certificats</span>
            </div>
          </div>
        </div>

        <!-- ============================================================== -->
        <!-- ACCORDÉONS D'IMPRESSION -->
        <!-- ============================================================== -->
        <div class="row">
          <div class="col-12">
            <div class="accordion" id="accordionExample">

              <!-- 1- FICHES DES ELEVES -->
              <div class="accordion-item impress-section">
                <h2 class="accordion-header">
                  <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseOne" aria-expanded="false" aria-controls="collapseOne">
                    <h5 class="fw-bolder mb-0"><i class="fa fa-file-alt me-2"></i>1- FICHES DES ÉLÈVES</h5>
                  </button>
                </h2>
                <div id="collapseOne" class="accordion-collapse collapse" data-bs-parent="#accordionExample">
                  <div class="card-body">
                    <form action="fpdf185/classe_list.php" method="GET" enctype="multipart/form-data">
                      <div class="row g-3">
                        <div class="col-12 col-sm-6 col-md-4">
                          <label class="form-label fw-bold">Option</label>
                          <select class="form-select form-select-lg" name="option" id="option" onclick="typeElt()" required>
                            <option value="">Choisir...</option>
                            <option value="clslist">Liste des élèves par classe</option>
                            <option value="notelist">Fiche de relevé des Notes</option>
                            <option value="listnv">Liste des élèves par niveau</option>
                            <option value="listsess">Liste des élèves par session</option>
                            <option value="alllist">Liste de tous les élèves</option>
                          </select>
                        </div>
                        <div class="col-12 col-sm-6 col-md-4" id="valclslist" style="display:none">
                          <label class="form-label fw-bold">Choisir une classe</label>
                          <select class="form-select form-select-lg" id="cls" name="refcls">
                            <option value="">Choisir...</option>
                            <?php $std->SelectClassesNames(); ?>
                          </select>
                        </div>
                        <div class="col-12 col-sm-6 col-md-4" id="vallistnv" style="display:none">
                          <label class="form-label fw-bold">Niveau</label>
                          <select class="form-select form-select-lg" name="niveau">
                            <option value="">Choisir...</option>
                            <?php $class->SelectNiveauCls(); ?>
                          </select>
                        </div>
                        <div class="col-12 col-sm-6 col-md-4" id="vallistsess" style="display:none">
                          <label class="form-label fw-bold">Session</label>
                          <select class="form-select form-select-lg" name="session">
                            <option value="">Choisir...</option>
                            <?php $class->SelectSessCls(); ?>
                          </select>
                        </div>
                        <div class="col-12 col-md-2 d-flex align-items-end">
                          <label class="op-label d-block mb-1">Opération</label>
                          <button type="submit" class="btn btn-primary btn-impression w-100"><i class="fa fa-print me-1"></i>Imprimer</button>
                        </div>
                      </div>
                    </form>
                  </div>
                </div>
              </div>

              <!-- 2- BULETTINS -->
              <div class="accordion-item impress-section">
                <h2 class="accordion-header">
                  <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
                    <h5 class="fw-bolder mb-0"><i class="fa fa-file-alt me-2"></i>2- BULLETINS</h5>
                  </button>
                </h2>
                <div id="collapseTwo" class="accordion-collapse collapse" data-bs-parent="#accordionExample">
                  <div class="card-body">
                    <form action="fpdf185/bul_cls.php" method="GET" enctype="multipart/form-data">
                      <div class="row g-3">
                        <div class="col-12 col-sm-6 col-md-3">
                          <label class="form-label fw-bold">Section</label>
                          <select class="form-select form-select-lg" name="sess_bul" id="sess_bul" required onchange="typeElt_Bul()">
                            <option value="">...</option>
                            <?php $class->SelectSessCls(); ?>
                          </select>
                        </div>
                        <div class="col-12 col-sm-6 col-md-3" id="cls_frg" style="display:none">
                          <label class="form-label fw-bold">Classe</label>
                          <select class="form-select form-select-lg" name="cfg">
                            <option value="">Choisir...</option>
                            <?php $class->SelectCls_by_Sess('SFG'); ?>
                          </select>
                        </div>
                        <div class="col-12 col-sm-6 col-md-3" id="cls_ang" style="display:none">
                          <label class="form-label fw-bold">Classe</label>
                          <select class="form-select form-select-lg" name="cag">
                            <option value="">Choisir...</option>
                            <?php $class->SelectCls_by_Sess('SAG'); ?>
                          </select>
                        </div>
                        <div class="col-12 col-sm-6 col-md-3" id="cls_frt" style="display:none">
                          <label class="form-label fw-bold">Classe</label>
                          <select class="form-select form-select-lg" name="cft">
                            <option value="">Choisir...</option>
                            <?php $class->SelectCls_by_Sess('SFT'); ?>
                          </select>
                        </div>
                        <div class="col-12 col-sm-6 col-md-3" id="cls_ant" style="display:none">
                          <label class="form-label fw-bold">Classe</label>
                          <select class="form-select form-select-lg" name="cat">
                            <option value="">Choisir...</option>
                            <?php $class->SelectCls_by_Sess('SAT'); ?>
                          </select>
                        </div>
                        <div class="col-12 col-sm-6 col-md-3" id="vall_trim" style="display:none">
                          <label class="form-label fw-bold">Trimestre</label>
                          <select class="form-select form-select-lg" name="vall_trim" required>
                            <option value="">...</option>
                            <option value="1">Trim 1</option>
                            <option value="2">Trim 2</option>
                            <option value="3">Trim 3</option>
                            <option value="an">Annuel</option>
                          </select>
                        </div>
                        <div class="col-12 col-sm-6 col-md-3">
                          <label class="form-label fw-bold">TYPE</label>
                          <select class="form-select form-select-lg" id="type_bul" name="type_bul" required>
                            <option value="">...</option>
                            <option value="bstd">INDIVIDUEL</option>
                            <option value="all">TOUS LES ÉLEVES</option>
                          </select>
                        </div>
                        <div class="col-12 col-md-2 d-flex align-items-end">
                          <label class="op-label d-block mb-1">Opération</label>
                          <button type="submit" class="btn btn-primary btn-impression w-100"><i class="fa fa-print me-1"></i>Imprimer</button>
                        </div>
                      </div>
                    </form>
                  </div>
                </div>
              </div>

              <!-- 3- TABLEAUX D'HONNEURS -->
              <div class="accordion-item impress-section">
                <h2 class="accordion-header">
                  <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
                    <h5 class="fw-bolder mb-0"><i class="fa fa-trophy me-2"></i>3- TABLEAUX D'HONNEURS</h5>
                  </button>
                </h2>
                <div id="collapseThree" class="accordion-collapse collapse" data-bs-parent="#accordionExample">
                  <div class="card-body">
                    <form action="fpdf185/tb_hn.php" method="GET" enctype="multipart/form-data">
                      <div class="row g-3">
                        <div class="col-12 col-sm-6 col-md-4">
                          <label class="form-label fw-bold">Classe</label>
                          <select class="form-select form-select-lg" id="Tbulcls" name="tcls">
                            <option value="">Choisir...</option>
                            <?php $std->SelectClassesNames(); ?>
                          </select>
                        </div>
                        <div class="col-12 col-sm-6 col-md-3">
                          <label class="form-label fw-bold">Trimestre</label>
                          <select class="form-select form-select-lg" name="bul" required>
                            <option value="">...</option>
                            <option value="1">Trim 1</option>
                            <option value="2">Trim 2</option>
                            <option value="3">Trim 3</option>
                          </select>
                        </div>
                        <div class="col-12 col-sm-6 col-md-3">
                          <label class="form-label fw-bold">Couleur</label>
                          <select class="form-select form-select-lg" name="f" required>
                            <option value="">...</option>
                            <option value="0">Sans fond</option>
                            <option value="1">Fond 1</option>
                            <option value="2">Fond 2</option>
                            <option value="3">Fond 3</option>
                            <option value="4">Fond 4</option>
                            <option value="5">Fond 5</option>
                          </select>
                        </div>
                        <div class="col-12 col-md-2 d-flex align-items-end">
                          <label class="op-label d-block mb-1">Opération</label>
                          <button type="submit" class="btn btn-primary btn-impression w-100"><i class="fa fa-print me-1"></i>Imprimer</button>
                        </div>
                      </div>
                    </form>
                  </div>
                </div>
              </div>

              <!-- 4- CERTIFICAT DE SCOLARITE -->
              <div class="accordion-item impress-section">
                <h2 class="accordion-header">
                  <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseFour" aria-expanded="false" aria-controls="collapseFour">
                    <h5 class="fw-bolder mb-0"><i class="fa fa-certificate me-2"></i>4- CERTIFICAT DE SCOLARITÉ</h5>
                  </button>
                </h2>
                <div id="collapseFour" class="accordion-collapse collapse" data-bs-parent="#accordionExample">
                  <div class="card-body">
                    <form action="fpdf185/cert_cls.php" method="GET" enctype="multipart/form-data">
                      <div class="row g-3">
                        <div class="col-12 col-sm-6 col-md-4">
                          <label class="form-label fw-bold">Classe</label>
                          <select class="form-select form-select-lg" id="Tbulcls" name="cls" required>
                            <option value="">Choisir...</option>
                            <?php $std->SelectClassesNames(); ?>
                          </select>
                        </div>
                        <div class="col-12 col-sm-6 col-md-4">
                          <label class="form-label fw-bold">Type d'élèves</label>
                          <select class="form-select form-select-lg" name="type" required>
                            <option value="">...</option>
                            <option value="ps">Pension Soldée</option>
                            <option value="pb">Pension Bulletin</option>
                            <option value="all">Tous les élèves</option>
                          </select>
                        </div>
                        <div class="col-12 col-md-2 d-flex align-items-end">
                          <label class="op-label d-block mb-1">Opération</label>
                          <button type="submit" class="btn btn-primary btn-impression w-100"><i class="fa fa-print me-1"></i>Imprimer</button>
                        </div>
                      </div>
                    </form>
                  </div>
                </div>
              </div>

              <!-- 5- CARTES SCOLAIRES -->
              <div class="accordion-item impress-section">
                <h2 class="accordion-header">
                  <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseFour1" aria-expanded="false" aria-controls="collapseFour1">
                    <h5 class="fw-bolder mb-0"><i class="fa fa-id-card me-2"></i>5- CARTES SCOLAIRES</h5>
                  </button>
                </h2>
                <div id="collapseFour1" class="accordion-collapse collapse" data-bs-parent="#accordionExample">
                  <div class="card-body">
                    <form action="fpdf185/card_cls.php" method="GET" enctype="multipart/form-data">
                      <div class="row g-3">
                        <div class="col-12 col-sm-6 col-md-3">
                          <label class="form-label fw-bold">Classe</label>
                          <select class="form-select form-select-lg" id="Tbulcls" name="cls" required>
                            <option value="">Choisir...</option>
                            <option value="all">Toutes les Classes</option>
                            <?php $std->SelectClassesNames(); ?>
                          </select>
                        </div>
                        <div class="col-12 col-sm-6 col-md-3">
                          <label class="form-label fw-bold">Type d'élèves</label>
                          <select class="form-select form-select-lg" name="type" required>
                            <option value="">...</option>
                            <option value="ps">Pension Soldée</option>
                            <option value="pb">Pension Bulletin</option>
                            <option value="all">Tous les élèves</option>
                          </select>
                        </div>
                        <div class="col-12 col-sm-6 col-md-3">
                          <label class="form-label fw-bold">MODÈLES</label>
                          <select class="form-select form-select-lg" name="mdl" required>
                            <option value="">...</option>
                            <option value="1">MODÈLE A</option>
                            <option value="2">MODÈLE B</option>
                            <option value="3">MODÈLE C</option>
                          </select>
                        </div>
                        <div class="col-12 col-md-2 d-flex align-items-end">
                          <label class="op-label d-block mb-1">Opération</label>
                          <button type="submit" class="btn btn-primary btn-impression w-100"><i class="fa fa-print me-1"></i>Imprimer</button>
                        </div>
                      </div>
                    </form>
                  </div>
                </div>
              </div>

              <!-- 6- PV -->
              <div class="accordion-item impress-section">
                <h2 class="accordion-header">
                  <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapse5" aria-expanded="false" aria-controls="collapse5">
                    <h5 class="fw-bolder mb-0"><i class="fa fa-gavel me-2"></i>6- PV</h5>
                  </button>
                </h2>
                <div id="collapse5" class="accordion-collapse collapse" data-bs-parent="#accordionExample">
                  <div class="card-body">
                    <form action="fpdf185/pv.php" method="GET" enctype="multipart/form-data">
                      <div class="row g-3">
                        <div class="col-12 col-sm-6 col-md-4">
                          <label class="form-label fw-bold">Option</label>
                          <select class="form-select form-select-lg" name="stat" id="stat" onclick="typeElt_Stat()" required>
                            <option value="">...</option>
                            <option value="clspv">PV par classe</option>
                            <option value="pvnv">PV par niveau</option>
                            <option value="pvsess">PV par session</option>
                          </select>
                        </div>
                        <div class="col-12 col-sm-6 col-md-3" id="valclspv" style="display:none">
                          <label class="form-label fw-bold">Choisir une classe</label>
                          <select class="form-select form-select-lg" id="cls" name="refcls">
                            <option value="">Choisir...</option>
                            <?php $std->SelectClassesNames(); ?>
                          </select>
                        </div>
                        <div class="col-12 col-sm-6 col-md-3" id="valpvnv" style="display:none">
                          <label class="form-label fw-bold">Niveau</label>
                          <select class="form-select form-select-lg" name="niveau">
                            <option value="">Choisir...</option>
                            <?php $class->SelectNiveauCls(); ?>
                          </select>
                        </div>
                        <div class="col-12 col-sm-6 col-md-3" id="valpvsess" style="display:none">
                          <label class="form-label fw-bold">Session</label>
                          <select class="form-select form-select-lg" name="session">
                            <option value="">Choisir...</option>
                            <?php $class->SelectSessCls(); ?>
                          </select>
                        </div>
                        <div class="col-12 col-sm-6 col-md-3" id="evalpv" style="display:none">
                          <label class="form-label fw-bold">Évaluations</label>
                          <select class="form-select form-select-lg" name="bul" required>
                            <option value="">...</option>
                            <option value="1">EVAL 1</option>
                            <option value="2">EVAL 2</option>
                            <option value="12">TRIM 1</option>
                            <option value="3">EVAL 3</option>
                            <option value="4">EVAL 4</option>
                            <option value="34">TRIM 2</option>
                            <option value="5">EVAL 5</option>
                            <option value="6">EVAL 6</option>
                            <option value="56">TRIM 3</option>
                          </select>
                        </div>
                        <div class="col-12 col-md-2 d-flex align-items-end">
                          <label class="op-label d-block mb-1">Opération</label>
                          <button type="submit" class="btn btn-primary btn-impression w-100"><i class="fa fa-print me-1"></i>Imprimer</button>
                        </div>
                      </div>
                    </form>
                  </div>
                </div>
              </div>

              <!-- 7- STATISTIQUES GLOBALES -->
              <div class="accordion-item impress-section">
                <h2 class="accordion-header">
                  <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapse6" aria-expanded="false" aria-controls="collapse6">
                    <h5 class="fw-bolder mb-0"><i class="fa fa-chart-bar me-2"></i>7- STATISTIQUES GLOBALES</h5>
                  </button>
                </h2>
                <div id="collapse6" class="accordion-collapse collapse" data-bs-parent="#accordionExample">
                  <div class="card-body">
                    <form action="fpdf185/stats_globales.php" method="GET" enctype="multipart/form-data">
                      <div class="row g-3">
                        <div class="col-12 col-sm-6 col-md-4">
                          <label class="form-label fw-bold">ÉVALUATION</label>
                          <select class="form-select form-select-lg" name="trim" required>
                            <option value="">...</option>
                            <option value="1">TRIM 1</option>
                            <option value="2">TRIM 2</option>
                            <option value="3">TRIM 3</option>
                            <option value="an">ANNUELLE</option>
                          </select>
                        </div>
                        <div class="col-12 col-md-2 d-flex align-items-end">
                          <label class="op-label d-block mb-1">Opération</label>
                          <button type="submit" class="btn btn-primary btn-impression w-100"><i class="fa fa-print me-1"></i>Imprimer</button>
                        </div>
                      </div>
                    </form>
                  </div>
                </div>
              </div>

            </div>
          </div>
        </div>
        <!-- ============================================================== -->
        <!-- FIN ACCORDÉONS -->
        <!-- ============================================================== -->
      </div>
    </div>

    <?php Footers::TDfoot(); ?>
    <?php Config::scriptJs(); ?>
    <script type="text/javascript">
        function typeElt() {
            var opt = document.getElementById('option').value;
            var cls = document.getElementById('valclslist');
            var nv = document.getElementById('vallistnv');
            var sess = document.getElementById('vallistsess');
            cls.style.display = 'none'; nv.style.display = 'none'; sess.style.display = 'none';
            if(opt == 'clslist') { cls.style.display = 'block'; }
            else if(opt == 'listnv') { nv.style.display = 'block'; }
            else if(opt == 'listsess') { sess.style.display = 'block'; }
        }
        function typeElt_Stat() {
            var stat = document.getElementById('stat').value;
            var clspv = document.getElementById('valclspv');
            var pvnv = document.getElementById('valpvnv');
            var pvsess = document.getElementById('valpvsess');
            var evalpv = document.getElementById('evalpv');
            clspv.style.display = 'none'; pvnv.style.display = 'none'; pvsess.style.display = 'none';
            if(stat == 'clspv') { clspv.style.display = 'block'; evalpv.style.display = 'block'; }
            else if(stat == 'pvnv') { pvnv.style.display = 'block'; evalpv.style.display = 'block'; }
            else if(stat == 'pvsess') { pvsess.style.display = 'block'; evalpv.style.display = 'block'; }
        }
        function typeElt_Bul() {
            var sess = document.getElementById('sess_bul').value;
            var cls_frg = document.getElementById('cls_frg');
            var cls_ang = document.getElementById('cls_ang');
            var cls_frt = document.getElementById('cls_frt');
            var cls_ant = document.getElementById('cls_ant');
            var trim = document.getElementById('vall_trim');
            cls_frg.style.display = 'none'; cls_ang.style.display = 'none'; cls_frt.style.display = 'none'; cls_ant.style.display = 'none'; trim.style.display = 'none';
            if(sess == 'SFG') { cls_frg.style.display = 'block'; trim.style.display = 'block'; }
            else if(sess == 'SAG') { cls_ang.style.display = 'block'; trim.style.display = 'block'; }
            else if(sess == 'SFT') { cls_frt.style.display = 'block'; trim.style.display = 'block'; }
            else if(sess == 'SAT') { cls_ant.style.display = 'block'; trim.style.display = 'block'; }
        }
        window.addEventListener('load', function() {
            typeElt(); typeElt_Stat(); typeElt_Bul();
        });
    </script>
  </body>
</html>