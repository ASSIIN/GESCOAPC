<?php
// ---------------------------------------------------------------------
// Mini archive ZIP en PHP pur (méthode STORE) — aucune extension requise
// (fonctionne même quand ZipArchive n'est pas chargé côté Apache).
// Production : fichiers (aucune compression) ; Lecture : STORE + DEFLATE.
// ---------------------------------------------------------------------

if (!function_exists('gesco_zip_creer')) {
    // $entries : liste de [ 'nom' => cheminDansZip, ('contenu' => string | 'fichier' => cheminAbsolu) ]
    function gesco_zip_creer($cheminSortie, array $entries)
    {
        $fh = @fopen($cheminSortie, 'wb');
        if (!$fh) {
            return false;
        }
        $central = '';
        $offset  = 0;
        $ecrites = 0;

        foreach ($entries as $e) {
            $nom = (string)$e['nom'];
            if ($nom === '') { continue; }
            $lenNom = strlen($nom);

            $crc = null; $taille = null; $data = null; $src = null;
            if (isset($e['contenu'])) {
                $data   = (string)$e['contenu'];
                $crc    = crc32($data);
                $taille = strlen($data);
            } else {
                $src = isset($e['fichier']) ? (string)$e['fichier'] : '';
                if ($src === '' || !is_file($src)) { continue; }
                $taille = @filesize($src);
                if ($taille === false) { continue; }
                $hex = hash_file('crc32b', $src, false);
                $crc = $hex !== false ? unpack('V', hex2bin($hex))[1] : 0;
            }

            // En-tête de fichier local (flag 0x0800 : noms de fichiers UTF-8)
            $headerLocal = "PK\x03\x04" . pack('vvvvvVVVvv', 20, 0, 0x0800, 0, 0, $crc, $taille, $taille, $lenNom, 0) . $nom;
            fwrite($fh, $headerLocal);

            if ($data !== null) {
                fwrite($fh, $data);
            } else {
                $srcH = @fopen($src, 'rb');
                if ($srcH) {
                    while (!feof($srcH)) {
                        $b = fread($srcH, 1048576);
                        if ($b !== false && $b !== '') { fwrite($fh, $b); }
                    }
                    fclose($srcH);
                }
            }

            // Entrée du répertoire central (flag UTF-8 + attributs DOS « archive »)
            $central .= "PK\x01\x02" . pack('vvvvvvVVVvvvvvVV', 20, 20, 0x0800, 0, 0, 0, $crc, $taille, $taille, $lenNom, 0, 0, 0, 0, 0x0020, $offset) . $nom;
            $offset += strlen($headerLocal) + $taille;
            $ecrites++;
        }

        $cdSize = strlen($central);
        fwrite($fh, $central);
        // Fin du répertoire central (EOCD)
        fwrite($fh, "PK\x05\x06" . pack('vvvvVVv', 0, 0, $ecrites, $ecrites, $cdSize, $offset, 0));
        fclose($fh);
        return true;
    }
}

if (!function_exists('gesco_zip_lister')) {
    // Retourne la liste des entrées (métadonnées du répertoire central) ou null si zip invalide.
    function gesco_zip_lister($chemin)
    {
        if (!is_file($chemin)) { return null; }
        $fh = @fopen($chemin, 'rb');
        if (!$fh) { return null; }
        $taille = filesize($chemin);
        if ($taille < 22) { fclose($fh); return null; }

        // Localiser l'EOCD dans les 64 Ko finaux
        $lenFin = min($taille, 65557);
        fseek($fh, $taille - $lenFin);
        $fin = fread($fh, $lenFin);
        $posEocd = strrpos($fin, "PK\x05\x06");
        if ($posEocd === false) { fclose($fh); return null; }
        $eocd = unpack('vdisk/vcdDisk/vnDisk/vnTotal/VcdSize/VcdOff/vcomLen', substr($fin, $posEocd + 4, 18));
        if (!isset($eocd['nTotal'])) { fclose($fh); return null; }

        $ncd   = $eocd['nTotal'];
        $cdOff = $eocd['cdOff'];
        $cdSz  = $eocd['cdSize'];

        fseek($fh, $cdOff);
        $cd = fread($fh, $cdSz);
        $entries = array();
        $off = 0;
        for ($i = 0; $i < $ncd; $i++) {
            if (substr($cd, $off, 4) !== "PK\x01\x02") { break; }
            $h = unpack('vvmade/vvneeded/vflags/vmethod/vtime/vdate/Vcrc/Vcomp/Vuncomp/vnLen/vxLen/vcLen/vdisk/vint/Vext/VlOff', substr($cd, $off + 4, 42));
            if (!isset($h['nLen'])) { break; }
            $name = substr($cd, $off + 46, $h['nLen']);
            $entries[] = array(
                'nom'     => $name,
                'method'  => $h['method'],
                'crc'     => $h['crc'],
                'comp'    => $h['comp'],
                'uncomp'  => $h['uncomp'],
                'lOff'    => $h['lOff'],
                'nameLen' => $h['nLen'],
                'extraLen'=> $h['xLen'],
            );
            $off += 46 + $h['nLen'] + $h['xLen'] + $h['cLen'];
        }
        fclose($fh);
        return $entries;
    }
}

if (!function_exists('gesco_zip_contenu')) {
    // Retourne le contenu binaire d'une entrée (meta = entrée de gesco_zip_lister).
    function gesco_zip_contenu($chemin, array $meta)
    {
        $fh = @fopen($chemin, 'rb');
        if (!$fh) { return null; }
        if (isset($meta['lOff'])) {
            fseek($fh, $meta['lOff']);
            $lh = fread($fh, 30);
            if (substr($lh, 0, 4) !== "PK\x03\x04") { fclose($fh); return null; }
            $lu = unpack('vvflags/vmethod/vtime/vdate/Vcrc/Vcomp/Vuncomp/vnLen/vxLen', substr($lh, 4, 26));
            $dataOff = $meta['lOff'] + 30 + $lu['nLen'] + $lu['xLen'];
            fseek($fh, $dataOff);
        } else {
            // Accès direct (entrée construite manuellement)
            fseek($fh, 0);
            $dataOff = 30;
        }
        $nBytes = ((int)$meta['method'] === 8) ? (int)$meta['comp'] : (int)$meta['uncomp'];
        if ($nBytes <= 0) { fclose($fh); return ''; }
        $data = fread($fh, $nBytes);
        fclose($fh);

        if ((int)$meta['method'] === 8) {
            if (!function_exists('gzinflate')) { return null; }
            $d = @gzinflate($data);
            return $d === false ? null : $d;
        }
        return $data;
    }
}

if (!function_exists('gesco_zip_extraire_fichiers')) {
    // Extrait les entrées d'un zip vers un dossier en limitant l'écriture
    // sous $prefixeContraint (anti zip-slip). Retourne [ 'fichiers' => [...], 'sql' => string ].
    function gesco_zip_extraire_fichiers($cheminZip, $racineApp, $prefixeContraint)
    {
        $res = array('fichiers' => array(), 'sql' => '');
        $entries = gesco_zip_lister($cheminZip);
        if ($entries === null) { return $res; }

        $prefixe = str_replace('\\', '/', trim($prefixeContraint, '/'));

        foreach ($entries as $meta) {
            $nom = ltrim(str_replace('\\', '/', (string)$meta['nom']), '/');
            if (substr($nom, -1) === '/') { continue; } // entrée dossier

            $lower = strtolower($nom);
            if (substr($lower, -4) === '.sql' && $res['sql'] === '') {
                $contenu = gesco_zip_contenu($cheminZip, $meta);
                if ($contenu !== null) { $res['sql'] = $contenu; }
                continue;
            }

            if (strpos($nom, $prefixe . '/') !== 0) { continue; }

            $rel = substr($nom, strlen($prefixe) + 1);
            // Sécurité : aucun ".." ni séparateur absolu dans le chemin relatif
            if ($rel === '' || preg_match('#(^|/)\.\.(/|$)#', $rel) || preg_match('#^[a-zA-Z]:#', $rel)) {
                continue;
            }
            $dest = $racineApp . DIRECTORY_SEPARATOR . $prefixe . DIRECTORY_SEPARATOR . str_replace('/', DIRECTORY_SEPARATOR, $rel);

            // Vérification du chemin réel résolu (anti zip-slip)
            $baseReelle = realpath($racineApp . DIRECTORY_SEPARATOR . $prefixe);
            $baseNorm = str_replace('\\', '/', $baseReelle !== false ? $baseReelle : $racineApp . '/' . $prefixe);
            $destNorm = str_replace('\\', '/', $dest);
            if ($destNorm !== $baseNorm && strpos($destNorm, $baseNorm . '/') !== 0) {
                continue;
            }

            $contenu = gesco_zip_contenu($cheminZip, $meta);
            if ($contenu === null) { continue; }

            $dirDest = dirname($dest);
            if (!is_dir($dirDest) && !@mkdir($dirDest, 0775, true)) { continue; }
            // Écriture atomique : pas de fichier 0 octet en cas d'échec
            if (@file_put_contents($dest, $contenu) !== false) {
                $res['fichiers'][] = $rel;
            }
        }
        return $res;
    }
}