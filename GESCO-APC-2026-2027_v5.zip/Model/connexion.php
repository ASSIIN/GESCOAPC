<?php
// Model/connexion.php

if (!isset($_SESSION['con_year']) || empty($_SESSION['con_year'])) {
    header('location: index.php');
    exit();
}

// Nom de base validé (anti-injection dans le nom de base)
$db_suffix = preg_replace('/[^a-zA-Z0-9_-]/', '', (string)$_SESSION['con_year']);
if ($db_suffix === '') {
    header('location: index.php');
    exit();
}
$dbname = 'gescoapc_' . $db_suffix;

// ---------------------------------------------------------------------
// Création automatique de la base de l'année sélectionnée si elle
// n'existe pas encore (machine neuve, année antérieure choisie au login).
// ---------------------------------------------------------------------
if (!function_exists('gescoapc_creer_base_annee')) {
    function gescoapc_creer_base_annee($dbSuffix)
    {
        $dbSuffix = preg_replace('/[^a-zA-Z0-9_-]/', '', (string)$dbSuffix);
        if ($dbSuffix === '') {
            return false;
        }
        $dbName = 'gescoapc_' . $dbSuffix;

        $conn = new mysqli('localhost', 'root', '');
        if ($conn->connect_error) {
            return false;
        }

        $res = $conn->query("SHOW DATABASES LIKE '" . $conn->real_escape_string($dbName) . "'");
        if ($res && $res->num_rows > 0) {
            $conn->close();
            return true; // base déjà présente
        }

        $ok = false;
        if ($conn->query("CREATE DATABASE IF NOT EXISTS `$dbName` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci")) {
            $conn->select_db($dbName);

            // Import du modèle SQL du pack pour obtenir une structure complète
            // (tables + compte de démarrage) — comportement identique à checkdb.php.
            $fichModele = '';
            $candidat = __DIR__ . '/gescoapc_' . $dbSuffix . '.sql';
            if (file_exists($candidat)) {
                $fichModele = $candidat;
            } else {
                $globs = glob(__DIR__ . '/gescoapc_*.sql');
                if ($globs) { $fichModele = $globs[0]; }
            }

            if ($fichModele !== '' && file_exists($fichModele)) {
                $sqlModele = file_get_contents($fichModele);
                if ($sqlModele !== false && $conn->multi_query($sqlModele)) {
                    do {
                        if ($resu = $conn->store_result()) { $resu->free(); }
                    } while ($conn->more_results() && $conn->next_result());
                    if (!empty($conn->error)) {
                        $conn->query("DROP DATABASE IF EXISTS $dbName");
                    } else {
                        // Report de l'année scolaire choisie dans l'établissement de démarrage
                        $p = explode('_', $dbSuffix);
                        if (count($p) === 2 && is_numeric($p[0]) && is_numeric($p[1])) {
                            $libelle = '20' . $p[0] . '/' . '20' . $p[1];
                        } else {
                            $libelle = $dbSuffix;
                        }
                        $conn->query("UPDATE etablissement SET school_year = '" . $conn->real_escape_string(strip_tags($libelle)) . "' WHERE id <= 1");
                        $ok = true;
                    }
                } else {
                    $conn->query("DROP DATABASE IF EXISTS $dbName");
                }
            } else {
                $conn->query("DROP DATABASE IF EXISTS $dbName");
            }
        }
        $conn->close();
        return $ok;
    }
}

// ---------------------------------------------------------------------
// Connexion PDO + mise à jour automatique (config_licence, colonnes…).
// ---------------------------------------------------------------------
$__connexion_bdd = function () use ($dbname) {
    $bdd = new PDO('mysql:host=localhost;dbname=' . $dbname . ';charset=utf8mb4', 'root', '');
    $bdd->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $GLOBALS['bdd'] = $bdd; // Sécurité pour s'assurer que le scope global est hydraté

    // ------------------------------------------
    // UPGRADE AUTO NON DESTRUCTIF (optionnel) :
    // n'est chargé QUE SI le fichier existe (évite le fatal
    // quand il n'est pas présent / déjà supprimé après succès).
    // Ajoute seulement les colonnes/tables manquantes,
    // jamais de DROP/DELETE/UPDATE de données.
    // ------------------------------------------
    $__auto_upgrade = __DIR__ . '/../less/auto_upgrade.php';
    if (is_file($__auto_upgrade)) {
        require_once $__auto_upgrade;
    }

    // Création / migration automatique de la table de licence (colonnes install_id, cle_publique, dates)
    $bdd->exec("CREATE TABLE IF NOT EXISTS `config_licence` (
        `id` int NOT NULL AUTO_INCREMENT,
        `cle_licence` LONGTEXT NOT NULL,
        `statut_activation` varchar(50) DEFAULT 'inactif',
        `install_id` varchar(64) DEFAULT NULL,
        `cle_publique` LONGTEXT DEFAULT NULL,
        `debut_licence` date DEFAULT NULL,
        `fin_licence` date DEFAULT NULL,
        `nb_poste` int NOT NULL DEFAULT 1,
        `dernier_controle` datetime DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (`id`),
        UNIQUE KEY `unq_install_id` (`install_id`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;");
    $bdd->exec("ALTER TABLE `config_licence` MODIFY `cle_licence` LONGTEXT NOT NULL");

    // Ajout des colonnes manquantes pour les bases créées par les anciennes versions
    $col_licence = ['install_id', 'cle_publique', 'debut_licence', 'fin_licence', 'nb_poste'];
    foreach ($col_licence as $c) {
        $chk = $bdd->query("SELECT COUNT(*) FROM information_schema.COLUMNS
            WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'config_licence' AND COLUMN_NAME = " . $bdd->quote($c));
        if ((int)$chk->fetchColumn() === 0) {
            $typ = $c === 'nb_poste' ? "int NOT NULL DEFAULT 1" : ($c === 'install_id' ? "varchar(64) DEFAULT NULL" : ($c === 'dernier_controle' ? "datetime DEFAULT CURRENT_TIMESTAMP" : "LONGTEXT DEFAULT NULL"));
            $bdd->exec("ALTER TABLE `config_licence` ADD COLUMN `$c` $typ");
        }
    }
    // Index unique sur install_id (idempotent)
    $chk = $bdd->query("SELECT COUNT(*) FROM information_schema.STATISTICS
        WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'config_licence' AND INDEX_NAME = 'unq_install_id'");
    if ((int)$chk->fetchColumn() === 0) {
        $bdd->exec("ALTER TABLE `config_licence` ADD UNIQUE KEY `unq_install_id` (`install_id`)");
    }

    // Colonne « cachet sur bulletins » (p_ch) pour les bases créées par les
    // anciennes versions (idempotent).
    $chk = $bdd->query("SELECT COUNT(*) FROM information_schema.COLUMNS
        WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'etablissement' AND COLUMN_NAME = 'p_ch'");
    if ((int)$chk->fetchColumn() === 0) {
        $bdd->exec("ALTER TABLE `etablissement` ADD COLUMN `p_ch` char(1) NOT NULL DEFAULT 'N'");
    }

    return true;
};

try {
    $__connexion_bdd();
} catch (Exception $e) {
    if (stripos($e->getMessage(), 'Unknown database') === false) {
        die('Erreur de connexion base de données : ' . $e->getMessage());
    }
    // La base de l'année choisie n'existe pas : on la crée puis on retente.
    if (gescoapc_creer_base_annee($db_suffix)) {
        try {
            $__connexion_bdd();
        } catch (Exception $e2) {
            die('Erreur de connexion base de données : ' . $e2->getMessage());
        }
    } else {
        die('Erreur : impossible de créer la base de données de l\'année sélectionnée. ' . $e->getMessage());
    }
}

// Connexion MySQLi pour la rétrocompatibilité des anciens scripts de lecture
$connect = mysqli_connect("localhost", "root", "", $dbname);