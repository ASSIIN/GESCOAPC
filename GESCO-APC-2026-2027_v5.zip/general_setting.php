<?php
    session_start();   
	require_once 'core/require.php'; 
	require_once 'Model/connexion.php';
     if (!isset($_SESSION['user'])) 
     {
      session_unset();
      session_destroy();
      header('location: index.php');
    }
    if (($_SESSION['user_role']!="admin") and ($_SESSION['user_role']!="pcpl")) {
       header('location: poste_de_saisie.php?trim=t1');    
    }
    $etb->ShowEtb();
    $etb->CkLE();
    $etb->ckexneE();

    // Auto-réparation des images de l'établissement : toute image corrompue
    // (signature binaire invalide) est remplacée par un PNG de substitution
    // valide pour que le logo et la signature s'affichent toujours.
    require_once 'Controler/school/photo_securite.php';
    $img_logo_rel = ($_SESSION['logo_etb'] ?? '') ?: 'logo.png';
    $img_sign_rel = ($_SESSION['sign_respo_etb'] ?? '') ?: 'signature.png';
    $img_logo_abs = __DIR__ . '/plugins/images/' . str_replace(array('..', '/', '\\'), '', $img_logo_rel);
    $img_sign_abs = __DIR__ . '/plugins/images/' . str_replace(array('..', '/', '\\'), '', $img_sign_rel);
    if (!gesco_image_valide($img_logo_abs)) { @gesco_reparer_image($img_logo_abs); }
    if (!gesco_image_valide($img_sign_abs)) { @gesco_reparer_image($img_sign_abs); }
    $logoUrl = (is_file($img_logo_abs) && gesco_type_image($img_logo_abs) !== '') ? 'plugins/images/' . basename($img_logo_abs) : 'plugins/images/admin-logo.png';
    $signUrl = (is_file($img_sign_abs) && gesco_type_image($img_sign_abs) !== '') ? 'plugins/images/' . basename($img_sign_abs) : 'plugins/images/admin-text.png';

    $p_ch_val = ($_SESSION['p_ch'] ?? 'N') === 'O' ? 'O' : 'N';
    $saved_ok = isset($_GET['saved']);
    $img_err  = isset($_GET['imgerr']);
?>
<!DOCTYPE html>
<html lang="fr">
  <head>
   <?php Config::head(); ?>
    <title>GESCOAPC| PARAMETRES GENERAUX</title>
    <style>
        .gs-card { border-radius: .65rem; overflow: hidden; }
        .gs-card .card-header { border-bottom: 1px solid rgba(255,255,255,.25); }
        .gs-label { font-weight: 600; color: var(--text-main); }
        .gs-current { font-size: .8rem; opacity: .85; }
        .gs-current b { color: #0764a8; }
        .gs-imgbox { background: #f1f5f9; border: 1px dashed #cbd5e1; border-radius: .55rem; }
        [data-theme="dark"] .gs-imgbox { background: rgba(255,255,255,.04); border-color: rgba(255,255,255,.18); }
        .field-current { color: #e63f32; font-style: italic; }
    </style>
  </head>

<body data-imprimable="1">
    <div class="wrapper">
      <!-- Inclusion du menu de navigation externe réutilisable -->
      <?php include 'core/sidebar.php'; ?>  

<div class="main-content-wrapper">
        <!-- Barre supérieure de navigation adaptative -->
        <div class="mobile-navbar-fixed p-3 mb-4 rounded shadow-sm border">
            <div class="row align-items-center g-2">
                <div class="col-auto d-md-none">
                    <button class="btn btn-outline-dark btn-sm" id="toggleMobileMenu"><i class="fa fa-bars fa-lg"></i></button>
                </div>
                <div class="col-12 col-md">
                    <h4 class="m-0 fw-bold text-primary text-uppercase">Gestion générale des paramètres de l'établissement</h4>
                </div>
            </div>
        </div>

        <div class="container-fluid mt-3">
            <?php if ($saved_ok): ?>
                <div class="alert alert-success d-flex align-items-center shadow-sm" role="alert">
                    <i class="fa-solid fa-circle-check me-2"></i> Paramètres enregistrés avec succès.
                </div>
            <?php elseif ($img_err): ?>
                <div class="alert alert-warning d-flex align-items-center shadow-sm" role="alert">
                    <i class="fa-solid fa-triangle-exclamation me-2"></i> Logo / signature : seuls les vrais fichiers PNG ou JPG sont acceptés. Le reste des paramètres a été enregistré.
                </div>
            <?php endif; ?>

            <!-- ============================================================== -->
            <!-- PARAMETRES DE L'ENTETE -->
            <!-- ============================================================== -->
            <div class="card shadow-sm gs-card mb-4">
                <div class="card-header bg-primary text-white py-3">
                    <h5 class="m-0 fw-bold"><i class="fa-solid fa-heading me-2"></i>PARAMÈTRES DE L'EN-TÊTE</h5>
                    <div class="small text-white-50">Identité de l'établissement affichée sur les bulletins et documents officiels</div>
                </div>
                <form action="Controler/school/updetb.php" method="post" enctype="multipart/form-data">
                    <div class="card-body p-3 p-md-4">

                        <div class="row g-4">
                            <div class="col-12">
                                <h6 class="fw-bold text-uppercase text-primary border-bottom pb-1">Dénomination</h6>
                            </div>
                            <div class="col-md-6 col-lg-4">
                                <div class="form-text mb-1"><i class="fa-solid fa-lock me-1"></i>Nom (FR) lié à la licence — non modifiable.</div>
                                <label class="form-label gs-label">Nom de l'établissement (FR)</label>
                                <input type="text" class="form-control text-uppercase" value="<?php echo htmlspecialchars($_SESSION['nom_etb_fr'] ?? ''); ?>" readonly>
                            </div>
                            <div class="col-md-6 col-lg-4">
                                <label class="form-label gs-label">Nom de l'établissement (EN)</label>
                                <input type="text" class="form-control text-uppercase" id="nom_etb_en" name="nom_etb_en" maxlength="50" placeholder="<?php echo htmlspecialchars($_SESSION['nom_etb_en'] ?? ''); ?>">
                                <div class="gs-current mt-1">Actuel : <b><?php echo htmlspecialchars($_SESSION['nom_etb_en'] ?? ''); ?></b></div>
                            </div>
                            <div class="col-md-6 col-lg-4 align-self-end">
                                <div class="form-text"><i class="fa-solid fa-circle-info me-1"></i>Le nom en français est figé (lié à la licence) ; le nom en anglais reste modifiable.</div>
                            </div>

                            <div class="col-12 mt-3">
                                <h6 class="fw-bold text-uppercase text-primary border-bottom pb-1">Ministère / Région / Département</h6>
                            </div>
                            <div class="col-md-6 col-lg-4">
                                <label class="form-label gs-label">Ministère (FR)</label>
                                <input type="text" class="form-control text-uppercase" id="minist_etb_fr" name="minist_etb_fr" maxlength="50" placeholder="<?php echo htmlspecialchars($_SESSION['minist_etb_fr'] ?? ''); ?>">
                                <div class="gs-current mt-1">Actuel : <b><?php echo htmlspecialchars($_SESSION['minist_etb_fr'] ?? ''); ?></b></div>
                            </div>
                            <div class="col-md-6 col-lg-4">
                                <label class="form-label gs-label">Ministère (EN)</label>
                                <input type="text" class="form-control text-uppercase" id="minist_etb_en" name="minist_etb_en" maxlength="50" placeholder="<?php echo htmlspecialchars($_SESSION['minist_etb_en'] ?? ''); ?>">
                                <div class="gs-current mt-1">Actuel : <b><?php echo htmlspecialchars($_SESSION['minist_etb_en'] ?? ''); ?></b></div>
                            </div>
                            <div class="col-md-6 col-lg-4">
                                <label class="form-label gs-label">Région (FR)</label>
                                <input type="text" class="form-control" id="region_etb_fr" name="region_etb_fr" placeholder="<?php echo htmlspecialchars($_SESSION['region_etb_fr'] ?? ''); ?>">
                                <div class="gs-current mt-1">Actuel : <b><?php echo htmlspecialchars($_SESSION['region_etb_fr'] ?? ''); ?></b></div>
                            </div>
                            <div class="col-md-6 col-lg-4">
                                <label class="form-label gs-label">Région (EN)</label>
                                <input type="text" class="form-control text-uppercase" id="region_etb_en" name="region_etb_en" maxlength="50" placeholder="<?php echo htmlspecialchars($_SESSION['region_etb_en'] ?? ''); ?>">
                                <div class="gs-current mt-1">Actuel : <b><?php echo htmlspecialchars($_SESSION['region_etb_en'] ?? ''); ?></b></div>
                            </div>
                            <div class="col-md-6 col-lg-4">
                                <label class="form-label gs-label">Département (FR)</label>
                                <input type="text" class="form-control" id="depart_etb_fr" name="depart_etb_fr" placeholder="<?php echo htmlspecialchars($_SESSION['depart_etb_fr'] ?? ''); ?>">
                                <div class="gs-current mt-1">Actuel : <b><?php echo htmlspecialchars($_SESSION['depart_etb_fr'] ?? ''); ?></b></div>
                            </div>
                            <div class="col-md-6 col-lg-4">
                                <label class="form-label gs-label">Département (EN)</label>
                                <input type="text" class="form-control text-uppercase" id="depart_etb_en" name="depart_etb_en" maxlength="50" placeholder="<?php echo htmlspecialchars($_SESSION['depart_etb_en'] ?? ''); ?>">
                                <div class="gs-current mt-1">Actuel : <b><?php echo htmlspecialchars($_SESSION['depart_etb_en'] ?? ''); ?></b></div>
                            </div>

                            <div class="col-12 mt-3">
                                <h6 class="fw-bold text-uppercase text-primary border-bottom pb-1">Coordonnées</h6>
                            </div>
                            <div class="col-md-6 col-lg-4">
                                <label class="form-label gs-label">Boîte postale</label>
                                <input type="text" class="form-control" id="code_pste_etb" name="code_pste_etb" placeholder="<?php echo htmlspecialchars($_SESSION['code_pste_etb'] ?? ''); ?>">
                                <div class="gs-current mt-1">Actuel : <b><?php echo htmlspecialchars($_SESSION['code_pste_etb'] ?? ''); ?></b></div>
                            </div>
                            <div class="col-md-6 col-lg-4">
                                <label class="form-label gs-label">Téléphone</label>
                                <input type="text" class="form-control" id="tel_etb" name="tel_etb" maxlength="50" placeholder="<?php echo htmlspecialchars($_SESSION['tel_etb'] ?? ''); ?>">
                                <div class="gs-current mt-1">Actuel : <b><?php echo htmlspecialchars($_SESSION['tel_etb'] ?? ''); ?></b></div>
                            </div>
                            <div class="col-md-6 col-lg-4">
                                <label class="form-label gs-label">Matricule</label>
                                <input type="text" class="form-control" id="code_im_etb" name="code_im_etb" placeholder="<?php echo htmlspecialchars($_SESSION['code_im_etb'] ?? ''); ?>">
                                <div class="gs-current mt-1">Actuel : <b><?php echo htmlspecialchars($_SESSION['code_im_etb'] ?? ''); ?></b></div>
                            </div>
                            <div class="col-md-6 col-lg-4">
                                <label class="form-label gs-label">Email</label>
                                <input type="email" class="form-control" id="email_etb" name="email_etb" maxlength="50" placeholder="<?php echo htmlspecialchars($_SESSION['email_etb'] ?? ''); ?>">
                                <div class="gs-current mt-1">Actuel : <b><?php echo htmlspecialchars($_SESSION['email_etb'] ?? ''); ?></b></div>
                            </div>
                            <div class="col-md-6 col-lg-4">
                                <label class="form-label gs-label">Localité</label>
                                <input type="text" class="form-control" id="ville_etb" name="ville_etb" placeholder="<?php echo htmlspecialchars($_SESSION['ville_etb'] ?? ''); ?>">
                                <div class="gs-current mt-1">Actuel : <b><?php echo htmlspecialchars($_SESSION['ville_etb'] ?? ''); ?></b></div>
                            </div>
                            <div class="col-md-6 col-lg-4">
                                <label class="form-label gs-label">Responsable</label>
                                <input type="text" class="form-control" id="nom_respo_etb" name="nom_respo_etb" maxlength="100" placeholder="<?php echo htmlspecialchars($_SESSION['nom_respo_etb'] ?? ''); ?>">
                                <div class="gs-current mt-1">Actuel : <b><?php echo htmlspecialchars($_SESSION['nom_respo_etb'] ?? ''); ?></b></div>
                            </div>

                            <div class="col-12 mt-3">
                                <h6 class="fw-bold text-uppercase text-primary border-bottom pb-1">Pré-matricule & slogan</h6>
                            </div>
                            <div class="col-md-6 col-lg-4">
                                <label class="form-label gs-label">Pré-matricule <span class="text-muted">(OFF pour désactiver)</span></label>
                                <input type="text" class="form-control text-uppercase" id="pre_matr" name="pre_matr" maxlength="4" placeholder="<?php echo htmlspecialchars($_SESSION['pre_matr'] ?? ''); ?>">
                                <div class="gs-current mt-1">Actuel : <b><?php echo htmlspecialchars($_SESSION['pre_matr'] ?? ''); ?></b></div>
                            </div>
                            <div class="col-md-6 col-lg-4">
                                <label class="form-label gs-label">Slogan (devise)</label>
                                <input type="text" class="form-control" id="slg" name="slg" maxlength="50" placeholder="<?php echo htmlspecialchars($_SESSION['slogan_etb'] ?? ''); ?>">
                                <div class="gs-current mt-1">Actuel : <b><?php echo htmlspecialchars($_SESSION['slogan_etb'] ?? ''); ?></b></div>
                            </div>

                            <div class="col-12 mt-3">
                                <h6 class="fw-bold text-uppercase text-primary border-bottom pb-1">Logo, signature & cachet</h6>
                            </div>
                            <div class="col-md-6 col-lg-5">
                                <div class="gs-imgbox p-3 h-100">
                                    <label class="form-label gs-label fw-bold">LOGO</label>
                                    <div class="text-center mb-2">
                                        <img src="<?php echo htmlspecialchars($logoUrl); ?>" class="img-thumbnail" alt="logo" width="150" height="140" style="object-fit:contain; width:150px; height:140px;"
                                             onerror="this.onerror=null; this.src='plugins/images/admin-logo.png';">
                                    </div>
                                    <input type="file" class="form-control" id="support1" name="support1" accept=".png,.jpg">
                                    <div class="form-text">PNG ou JPG (128×128 recommandé)</div>
                                </div>
                            </div>
                            <div class="col-md-6 col-lg-5">
                                <div class="gs-imgbox p-3 h-100">
                                    <label class="form-label gs-label fw-bold">SIGNATURE / CACHET DU RESPONSABLE</label>
                                    <div class="text-center mb-2">
                                        <img src="<?php echo htmlspecialchars($signUrl); ?>" class="img-thumbnail" alt="signature" width="150" height="140" style="object-fit:contain; width:150px; height:140px;"
                                             onerror="this.onerror=null; this.src='plugins/images/admin-text.png';">
                                    </div>
                                    <input type="file" class="form-control" id="support2" name="support2" accept=".png,.jpg">
                                    <div class="form-text">PNG ou JPG (128×128 recommandé)</div>
                                </div>
                            </div>
                            <div class="col-12 col-lg-2">
                                <div class="gs-imgbox p-3 h-100 d-flex flex-column">
                                    <label class="form-label gs-label fw-bold">CACHET SUR LES BULLETINS</label>
                                    <select class="form-select" id="p_ch" name="p_ch">
                                        <option value="N" <?php echo $p_ch_val === 'O' ? '' : 'selected'; ?>>NON — masquer</option>
                                        <option value="O" <?php echo $p_ch_val === 'O' ? 'selected' : ''; ?>>OUI — imprimer</option>
                                    </select>
                                    <div class="gs-current mt-1">Actuel : <b><?php echo $p_ch_val === 'O' ? 'Afficher le cachet' : 'Ne pas afficher'; ?></b></div>
                                </div>
                            </div>
                        </div>

                        <div class="row mt-4">
                            <div class="col-12 text-end">
                                <button type="submit" class="btn btn-primary px-4"><i class="fa-solid fa-floppy-disk me-2"></i>Enregistrer</button>
                            </div>
                        </div>
                    </div>
                </form>
            </div>

            <!-- ============================================================== -->
            <!-- DROITS DES UTILISATEURS -->
            <!-- ============================================================== -->
            <div class="card shadow-sm gs-card mb-4">
                <div class="card-header bg-success text-white py-3">
                    <h5 class="m-0 fw-bold"><i class="fa-solid fa-user-shield me-2"></i>PARAMÈTRE DES DROITS</h5>
                </div>
                <div class="card-body p-3 p-md-4">
                    <p class="text-muted small mb-3">Attribuer un rôle à un utilisateur</p>
                    <form action="Controler/admins/updroleuser.php" method="post" enctype="multipart/form-data">
                        <div class="row g-3 align-items-end">
                            <div class="col-12 col-md-4 col-lg-4">
                                <label for="user" class="form-label gs-label">Utilisateur</label>
                                <select id="user" class="form-select" name="user" required>
                                    <option value="">Choisir...</option>
                                    <?php $user->SelectTeacherAndRole(); ?>
                                </select>
                            </div>
                            <div class="col-12 col-md-4 col-lg-3">
                                <label for="user_role" class="form-label gs-label">Rôle</label>
                                <select id="user_role" class="form-select" name="user_role" required>
                                    <option value="">Choisir...</option>
                                    <option value="ens">Enseignant</option>
                                    <option value="pcpl">Principal</option>
                                    <option value="admin">Administrateur</option>
                                    <option value="caisse">Caissier</option>
                                </select>
                            </div>
                            <div class="col-12 col-md-4 col-lg-2">
                                <button class="btn btn-success w-100" type="submit"><i class="fa-solid fa-check me-2"></i>Enregistrer</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>

            <!-- ============================================================== -->
            <!-- COMPETENCES -->
            <!-- ============================================================== -->
            <div class="card shadow-sm gs-card mb-4">
                <div class="card-header bg-info text-white py-3">
                    <h5 class="m-0 fw-bold"><i class="fa-solid fa-list-check me-2"></i>PÉRIODES D'ÉVALUATION (COMPÉTENCES)</h5>
                </div>
                <div class="card-body p-3 p-md-4">
                    <form action="Controler/notes/updprd.php" method="post" enctype="multipart/form-data">
                        <div class="row">
                            <div class="col-12 col-md-8 col-lg-6">
                                <fieldset>
                                    <legend class="fs-6 fw-bold gs-label">Activer / désactiver les périodes des évaluations</legend>
                                    <?php $opt->ShowPeriodesEval(); ?>
                                    <button type="submit" class="btn btn-info text-white mt-3 px-4"><i class="fa-solid fa-floppy-disk me-2"></i>Enregistrer les modifications</button>
                                </fieldset>
                            </div>
                        </div>
                    </form>
                </div>
            </div>

        </div>
    </div>
</div>

		<?php 
		 	Config::scriptJs();
		?>
	</body>
</html>