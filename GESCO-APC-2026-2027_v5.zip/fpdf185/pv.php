<?php
session_start();
require_once '../Model/connexion.php';
require_once '../core/require.php';
if (!isset($_SESSION['user'])) {
    session_unset();
    session_destroy();
    header('location: ../index.php');
}
$etb->ShowEtb();

$stat = isset($_GET['stat']) ? $_GET['stat'] : '';
$bul = isset($_GET['bul']) ? htmlspecialchars($_GET['bul']) : '';

if ($stat == 'statremp') {
    header('location: etatremp.php?ss=' . $_GET['session'] . '&trim=' . $bul);
    exit;
}

// --- Classes cibles selon le mode choisi (par classe / par niveau / par session)
$bdd = $GLOBALS['bdd'];
$classes = array();
if ($stat == 'pvnv' && isset($_GET['niveau']) && $_GET['niveau'] !== '') {
    $st = $bdd->prepare('SELECT code_class FROM classes WHERE ref_class_niveau = ? ORDER BY ref_class_niveau ASC, nom_class ASC');
    $st->execute(array($_GET['niveau']));
    while ($r = $st->fetch(PDO::FETCH_ASSOC)) { $classes[] = $r['code_class']; }
} elseif ($stat == 'pvsess' && isset($_GET['session']) && $_GET['session'] !== '') {
    $st = $bdd->prepare('SELECT code_class FROM classes WHERE class_session = ? ORDER BY ref_class_niveau ASC, nom_class ASC');
    $st->execute(array($_GET['session']));
    while ($r = $st->fetch(PDO::FETCH_ASSOC)) { $classes[] = $r['code_class']; }
} elseif (isset($_GET['refcls']) && $_GET['refcls'] !== '') {
    $classes[] = htmlspecialchars($_GET['refcls']);
}

$isEval = in_array($bul, array('1', '2', '3', '4', '5', '6'), true);
$isTrim = in_array($bul, array('12', '34', '56'), true);

// Le sélecteur d'évaluation/trimestre est obligatoire : sans lui on revient
// au centre d'impression au lieu de produire une page vide ou une erreur.
if ((!$isEval && !$isTrim) || empty($classes)) {
    header('location: ../impression.php?ec=1');
    exit;
}

$trim = '';
$ev1 = '';
$ev2 = '';
$titrep = '';
if ($isTrim) {
    if ($bul == '12') { $trim = '1'; $ev1 = '1'; $ev2 = '2'; $titrep = 'PV NOTES/MARKS REPORT : TRIM/TERM I '; }
    elseif ($bul == '34') { $trim = '2'; $ev1 = '3'; $ev2 = '4'; $titrep = 'PV NOTES/MARKS REPORT : TRIM/TERM II '; }
    else { $trim = '3'; $ev1 = '5'; $ev2 = '6'; $titrep = 'PV NOTES/MARKS REPORT : TRIM/TERM III '; }
} else {
    $titrep = 'PV NOTES/MARKS REPORT :  EVAL ' . $bul . '';
}

require('fpdf.php');
$pdf = new FPDF();

class PDF extends FPDF
{
    function Header()
    {
        $this->SetY(15);
        // Logo
        $this->Image('../plugins/images/' . $_SESSION['logo_etb'] . '', 10, 6, 30);
        // Police Arial gras 15
        $this->SetFont('Arial', 'B', 15);
        // Décalage à droite
        $this->Cell(80);
        // Titre
        $this->Cell(30, 10, 'Titre', 1, 0, 'C');
        // Saut de ligne
        $this->Ln(20);
    }

    function Footer()
    {
        // Positionnement à 1,5 cm du bas
        $this->SetY(-15);
        // Police Arial italique 8
        $this->SetFont('Arial', 'I', 8);
        // Numéro de page
        $this->Cell(0, 10, 'Page ' . $this->PageNo() . '/{nb}', 0, 0, 'C');
    }
}

$pdf->AliasNBPages();

// ---------------------------------------------------------------------------
// Rend un PV TRIMESTRIEL pour une classe (M.C1 / M.C2 / Moy T / Rang / H.abs)
// ---------------------------------------------------------------------------
function pv_rendu_trim($pdf, $refcls, $ev1, $ev2, $titrep, $trim)
{
    global $opt, $class, $std, $user, $mat;
    $pdf->AddPage('L', 'A4');
    $pdf->SetFont('Times', 'I', 8);
    $pdf->Text(10, 200, utf8_to_cp1252('By Akrymo Technology *** 656 864 099 / 678 042 612 / 658 626 661'), 0, 1, 'C');
    $pdf->Text(210, 200, 'Page ' . $pdf->PageNo() . '/{nb}', 0, 1, 'C');

    $bdd = $GLOBALS['bdd'];
    $reponse = $bdd->query('SELECT * FROM eleves where ref_class="' . $refcls . '" order by nom_std asc');

    $i = 1;
    $eff = 0;
    $NbTH = 0;

    /*En-tête*/
    $pdf->SetFont('Times', '', 8);
    $pdf->Image('../plugins/images/' . $_SESSION['logo_etb'] . '', 130, 15, 30);
    $pdf->Cell(70, 4, 'REPUBLIQUE DU CAMEROUN', 0, 0, 'C');
    $pdf->Cell(130, 4, '', 0, 0);
    $pdf->Cell(70, 4, 'REPUBLIC OF CAMEROON', 0, 1, 'C');

    $pdf->Cell(70, 4, 'Paix-Travail-Patrie', 0, 0, 'C');
    $pdf->Cell(130, 4, '', 0, 0);
    $pdf->Cell(70, 4, 'Peace-Work-Fatherland', 0, 1, 'C');

    $pdf->Cell(70, 4, utf8_to_cp1252("" . $_SESSION['minist_etb_fr'] . ""), 0, 0, 'C');
    $pdf->Cell(130, 4, '', 0, 0);
    $pdf->Cell(70, 4, utf8_to_cp1252('' . $_SESSION['minist_etb_en'] . ''), 0, 1, 'C');

    $pdf->Cell(70, 4, utf8_to_cp1252("" . $_SESSION['region_etb_fr'] . ""), 0, 0, 'C');
    $pdf->Cell(130, 4, '', 0, 0);
    $pdf->Cell(70, 4, utf8_to_cp1252('' . $_SESSION['region_etb_en'] . ''), 0, 1, 'C');

    $pdf->Cell(70, 4, utf8_to_cp1252('' . $_SESSION['depart_etb_fr'] . ''), 0, 0, 'C');
    $pdf->Cell(130, 4, '', 0, 0);
    $pdf->Cell(70, 4, utf8_to_cp1252('' . $_SESSION['depart_etb_en'] . ''), 0, 1, 'C');
    $pdf->SetFont('Times', 'B', 10);
    $pdf->Cell(70, 6, utf8_to_cp1252('' . $_SESSION['nom_etb_fr'] . ''), 0, 0, 'C');
    $pdf->Cell(130, 6, '', 0, 0);
    $pdf->Cell(70, 6, utf8_to_cp1252('' . $_SESSION['nom_etb_en'] . ''), 0, 1, 'C');
    $pdf->SetFont('Times', '', 8);
    $pdf->Cell(70, 5, utf8_to_cp1252('' . $_SESSION['code_pste_etb'] . ' / ' . $_SESSION['tel_etb'] . ''), 0, 0, 'C');
    $pdf->Cell(130, 5, '', 0, 0);
    $pdf->Cell(70, 5, utf8_to_cp1252('' . $_SESSION['code_pste_etb'] . '/ ' . $_SESSION['tel_etb'] . ''), 0, 1, 'C');
    $pdf->SetFont('Times', '', 8);
    $pdf->Cell(70, 4, utf8_to_cp1252('' . $_SESSION['email_etb'] . ''), 0, 0, 'C');
    $pdf->Cell(130, 4, '', 0, 0);
    $pdf->Cell(70, 4, utf8_to_cp1252('' . $_SESSION['email_etb'] . ''), 0, 1, 'C');
    $pdf->Ln();
    $pdf->SetFont('Times', 'I', 12);
    $pdf->Cell(100, 5, '', 0, 0);
    $pdf->Cell(60, 5, utf8_to_cp1252('' . $_SESSION['code_im_etb'] . ''), 0, 0, 'C');
    $pdf->Ln();

    /*FIN En-tête*/
    //Titre
    $pdf->SetFont('Times', 'I', 10);
    $pdf->Cell(90, 5, '', 0, 0, 'C');
    $pdf->Cell(60, 5, 'ANNEE SCOLAIRE/SCHOOL ', 0, 0, 'R');
    $pdf->SetFont('Times', 'B', 12);
    $pdf->Cell(40, 5, '' . $_SESSION['school_year'] . '', 0, 0, 'L');
    $pdf->Cell(40, 5, '', 0, 1, 'C');
    $class->CkClasseByCode($refcls);
    $nbstd = $class->NbrStudentByClass($refcls);
    $nbM = $class->NbrBySexeByClass($refcls, 'M');
    $nbF = $class->NbrBySexeByClass($refcls, 'F');
    $nomcls = $_SESSION['nom_class'];
    $niveaucls = $_SESSION['ref_class_niveau'];

    $pdf->SetFont('Times', 'B', 15);
    $pdf->SetFillColor(217, 245, 254);
    $pdf->Cell(30, 10, '', 0, 0, 'C');
    $pdf->Cell(200, 10, utf8_to_cp1252($titrep . ' ** Classe/Class : ' . $nomcls), 1, 0, 'C', 1);
    $pdf->Cell(20, 10, '', 0, 1, 'C');
    $pdf->Ln();
    $pdf->SetFont('Times', 'B', 12);
    /* STATISTIQUE*/
    $marge = 10.00;
    $moy_General = $opt->ShowMoy_by_Cls($refcls, $trim);
    $moy_General = round($moy_General, 2);
    $nb_classer = $opt->NbrStudentClasserByClass($refcls, $trim);
    $nb_moy = $opt->ShowNbStd_for_TauxR_by_Cls($refcls, $trim, $marge);
    $moy_1er = $opt->ShowMoy_1er_Cls($refcls, $trim);
    $moy_dern = $opt->ShowMoy_dern_Cls($refcls, $trim);
    $NbTH = $opt->ShowNbre_TH_Cls($refcls, $trim);
    if ($nb_classer > 0) {
        $taux_r = (float)$nb_moy * 100 / (float)$nb_classer;
        $taux_r = round($taux_r, 2);
    } else {
        $taux_r = 0;
    }
    $nabs = $nbstd - $nb_classer;
    $pdf->Cell(30, 4, "Inscr: $nbstd  ;", 0, 0, 'C');
    $pdf->Cell(25, 4, "Comp: $nb_classer  ;", 0, 0, 'L');
    $pdf->Cell(18, 4, "Abs: $nabs  ;", 0, 0, 'L');
    $pdf->Cell(42, 4, "Nbr.Moy (>=$marge) : $nb_moy  ;", 0, 0, 'C');
    $pdf->Cell(30, 4, "Taux_R: $taux_r%  ;", 0, 0, 'C');
    $pdf->Cell(25, 4, "Tb.H: $NbTH  ;", 0, 0, 'C');
    $pdf->Cell(40, 4, "Moy.Cls: $moy_General  ;", 0, 0, 'C');
    $pdf->Cell(35, 4, "Moy 1er(e): $moy_1er  ;", 0, 0, 'C');
    $pdf->Cell(35, 4, "Moy dern: $moy_dern", 0, 0, 'C');
    $pdf->Ln();

    $pdf->SetFont('Times', 'B', 9);
    $pdf->Ln();
    $pdf->Cell(10, 6, utf8_to_cp1252('N°'), 1, 0, 'C', 1);
    $pdf->Cell(22, 6, 'Matricule', 1, 0, 'C', 1);
    $pdf->Cell(55, 6, utf8_to_cp1252('Noms_et_Prénoms/Full_Name'), 1, 0, 'C', 1);
    /*Afficher la liste des matières*/
    $pdf->SetFont('Times', 'B', 7.5);
    $bdd = $GLOBALS['bdd'];
    $reponse0 = $bdd->query('SELECT * FROM config_bull where ref_class="' . $refcls . '" order by id asc');
    while ($row0 = $reponse0->fetch(PDO::FETCH_ASSOC)) {
        $refm = substr($row0['nom_mat'], 0, 5);
        $pdf->Cell(9, 6, utf8_to_cp1252($refm), 1, 0, 'L', 1);
    }
    $pdf->SetFillColor(2, 191, 109);
    $pdf->Cell(10, 6, 'M.C1', 1, 0, 'C', 1);
    $pdf->Cell(10, 6, 'M.C2', 1, 0, 'C', 1);
    $pdf->Cell(10, 6, 'Moy T', 1, 0, 'C', 1);
    $pdf->Cell(10, 6, 'Rang', 1, 0, 'C', 1);
    $pdf->Cell(10, 6, 'H.abs', 1, 0, 'C', 1);
    $pdf->Ln();
    $pdf->SetFont('Times', 'B', 7);

    $bdd = $GLOBALS['bdd'];
    $reponse1 = $bdd->query('SELECT * FROM eleves where ref_class="' . $refcls . '" order by nom_std asc');
    while ($row1 = $reponse1->fetch(PDO::FETCH_ASSOC)) {
        $pdf->Cell(10, 5, $i, 1, 0);
        $pdf->Cell(22, 5, utf8_to_cp1252($row1['cni_std']), 1, 0, 'C');
        $subnam = substr($row1['nom_std'], 0, 27);
        $pdf->Cell(55, 5, utf8_to_cp1252($subnam), 1, 0);
        $pdf->SetFont('Times', 'B', 8);
        $bdd = $GLOBALS['bdd'];
        $reponsei = $bdd->query('SELECT * FROM config_bull where ref_class="' . $refcls . '" order by id asc');
        while ($rowi = $reponsei->fetch(PDO::FETCH_ASSOC)) {
            $note1 = (float)$opt->ShowNoteStd_by_MatCls($refcls, $rowi['ref_mat'], $ev1, $row1['mat_std']);
            $note2 = (float)$opt->ShowNoteStd_by_MatCls($refcls, $rowi['ref_mat'], $ev2, $row1['mat_std']);
            if ($note1 == NULL and ($note2 != NULL or $note2 != 0)) {
                $fn2 = (float)$note2;
                $note_m = ($fn2 + $fn2) / 2;
                $total = round($note_m, 2);
            } else if ($note2 == NULL and ($note1 != NULL or $note1 != 0)) {
                $fn1 = (float)$note1;
                $note_m = ($fn1 + $fn1) / 2;
                $total = round($note_m, 2);
            } else if (($note2 != NULL or $note2 != 0) and ($note1 != NULL or $note1 != 0)) {
                $fn1 = (float)$note1;
                $fn2 = (float)$note2;
                $note_m = ($fn1 + $fn2) / 2;
                $total = round($note_m, 2);
            } else {
                $total = '-';
            }
            $pdf->Cell(9, 5, $total, 1, 0, 'C');
        }
        $t_coef1 = $opt->NombreCoeffbyStd_Cls($refcls, $ev1, $row1['mat_std']);
        $t_coef2 = $opt->NombreCoeffbyStd_Cls($refcls, $ev2, $row1['mat_std']);
        $Moy_E1 = $opt->ShowMoy_Seq_Std($refcls, $row1['mat_std'], $ev1, $t_coef1);
        $Moy_E2 = $opt->ShowMoy_Seq_Std($refcls, $row1['mat_std'], $ev2, $t_coef2);
        $rangstd = $opt->ShowRang_Std($refcls, $row1['mat_std'], $trim);
        $classer_std = $opt->ShowClasser_Std($refcls, $row1['mat_std'], $trim);
        $HeureAbs = $opt->ShowAbsStd_by_Cls($refcls, $row1['mat_std'], $trim);
        if (empty($HeureAbs)) {
            $HeureAbs = 0;
        }
        $moy_std = $opt->ShowMoy_Std($refcls, $row1['mat_std'], $trim);

        $rangstd = (string)$rangstd;
        $strrangstd = '';
        if ($rangstd == '1') {
            $strrangstd = 'er(e)';
        } elseif ($rangstd == 'NC') {
            $strrangstd = '';
        }

        if ($Moy_E1 > 0) {
            $sMoy_E1 = (string)$Moy_E1;
        } else {
            $sMoy_E1 = '--';
        }

        if ($Moy_E2 > 0) {
            $sMoy_E2 = (string)$Moy_E2;
        } else {
            $sMoy_E2 = '--';
        }

        if ($moy_std > 0) {
            $smoy_std = (string)$moy_std;
        } else {
            $smoy_std = '--';
            $strrangstd = '';
        }
        $pdf->SetFillColor(217, 245, 254);
        if ($Moy_E1 >= 12) {
            $pdf->SetFillColor(227, 242, 12);
            $pdf->Cell(10, 5, $sMoy_E1, 1, 0, 'C', 1);
        } else {
            $pdf->SetFillColor(217, 245, 254);
            $pdf->Cell(10, 5, $sMoy_E1, 1, 0, 'C', 1);
        }

        if ($Moy_E2 >= 12) {
            $pdf->SetFillColor(227, 242, 12);
            $pdf->Cell(10, 5, $sMoy_E2, 1, 0, 'C', 1);
        } else {
            $pdf->SetFillColor(217, 245, 254);
            $pdf->Cell(10, 5, $sMoy_E2, 1, 0, 'C', 1);
        }
        if ($moy_std >= 12) {
            $pdf->SetFillColor(227, 242, 12);
            $pdf->Cell(10, 5, $smoy_std, 1, 0, 'C', 1);
        } else {
            $pdf->SetFillColor(217, 245, 254);
            $pdf->Cell(10, 5, $smoy_std, 1, 0, 'C', 1);
        }
        $pdf->SetFillColor(217, 245, 254);
        $pdf->Cell(10, 5, $rangstd . $strrangstd, 1, 0, 'C', 1);
        $pdf->Cell(10, 5, $HeureAbs, 1, 0, 'C', 1);
        $pdf->Ln();
        $i++;
    }
    $pdf->Ln();
    $pdf->Ln();
    $pdf->SetFont('Times', 'B', 11);
    $pdf->MultiCell(250, 5, utf8_to_cp1252('NB: Les élèves ont un delai de 03 jours à compter de la date de l\'affichage de ce procès verbal pour apporter les pièces justificatives auprès du/des Professeur(s) conserné(s) en cas de contestation d\'une note, ou des heures d\'absence. Passé ce delai, aucune requête ne sera recevable.'), 0, 0, 'C', false);
}

// ---------------------------------------------------------------------------
// Rend un PV EVALUATION pour une classe (Total / T Cf / Moy / Rang / H.abs)
// ---------------------------------------------------------------------------
function pv_rendu_eval($pdf, $refcls, $bul, $titrep)
{
    global $opt, $class, $std, $user, $mat;
    $pdf->AddPage('L', 'A4');
    $pdf->SetFont('Times', 'I', 8);
    $pdf->Text(10, 200, utf8_to_cp1252('By GESCOPAC *** minesec'), 0, 1, 'C');
    $pdf->Text(210, 200, 'Page ' . $pdf->PageNo() . '/{nb}', 0, 1, 'C');

    $bdd = $GLOBALS['bdd'];
    $reponse = $bdd->query('SELECT * FROM eleves where ref_class="' . $refcls . '" order by nom_std asc');

    $i = 1;
    $eff = 0;
    $NbTH = 0;

    /*En-tête*/
    $pdf->SetFont('Times', '', 8);
    $pdf->Image('../plugins/images/' . $_SESSION['logo_etb'] . '', 130, 15, 30);
    $pdf->Cell(70, 4, 'REPUBLIQUE DU CAMEROUN', 0, 0, 'C');
    $pdf->Cell(130, 4, '', 0, 0);
    $pdf->Cell(70, 4, 'REPUBLIC OF CAMEROON', 0, 1, 'C');

    $pdf->Cell(70, 4, 'Paix-Travail-Patrie', 0, 0, 'C');
    $pdf->Cell(130, 4, '', 0, 0);
    $pdf->Cell(70, 4, 'Peace-Work-Fatherland', 0, 1, 'C');

    $pdf->Cell(70, 4, utf8_to_cp1252("" . $_SESSION['minist_etb_fr'] . ""), 0, 0, 'C');
    $pdf->Cell(130, 4, '', 0, 0);
    $pdf->Cell(70, 4, utf8_to_cp1252('' . $_SESSION['minist_etb_en'] . ''), 0, 1, 'C');

    $pdf->Cell(70, 4, utf8_to_cp1252("" . $_SESSION['region_etb_fr'] . ""), 0, 0, 'C');
    $pdf->Cell(130, 4, '', 0, 0);
    $pdf->Cell(70, 4, utf8_to_cp1252('' . $_SESSION['region_etb_en'] . ''), 0, 1, 'C');

    $pdf->Cell(70, 4, utf8_to_cp1252('' . $_SESSION['depart_etb_fr'] . ''), 0, 0, 'C');
    $pdf->Cell(130, 4, '', 0, 0);
    $pdf->Cell(70, 4, utf8_to_cp1252('' . $_SESSION['depart_etb_en'] . ''), 0, 1, 'C');
    $pdf->SetFont('Times', 'B', 10);
    $pdf->Cell(70, 6, utf8_to_cp1252('' . $_SESSION['nom_etb_fr'] . ''), 0, 0, 'C');
    $pdf->Cell(130, 6, '', 0, 0);
    $pdf->Cell(70, 6, utf8_to_cp1252('' . $_SESSION['nom_etb_en'] . ''), 0, 1, 'C');
    $pdf->SetFont('Times', '', 8);
    $pdf->Cell(70, 5, utf8_to_cp1252('' . $_SESSION['code_pste_etb'] . ' / ' . $_SESSION['tel_etb'] . ''), 0, 0, 'C');
    $pdf->Cell(130, 5, '', 0, 0);
    $pdf->Cell(70, 5, utf8_to_cp1252('' . $_SESSION['code_pste_etb'] . '/ ' . $_SESSION['tel_etb'] . ''), 0, 1, 'C');
    $pdf->SetFont('Times', '', 8);
    $pdf->Cell(70, 4, utf8_to_cp1252('' . $_SESSION['email_etb'] . ''), 0, 0, 'C');
    $pdf->Cell(130, 4, '', 0, 0);
    $pdf->Cell(70, 4, utf8_to_cp1252('' . $_SESSION['email_etb'] . ''), 0, 1, 'C');
    $pdf->Ln();
    $pdf->SetFont('Times', 'I', 12);
    $pdf->Cell(100, 5, '', 0, 0);
    $pdf->Cell(60, 5, utf8_to_cp1252('' . $_SESSION['code_im_etb'] . ''), 0, 0, 'C');
    $pdf->Ln();

    /*FIN En-tête*/
    //Titre
    $pdf->SetFont('Times', 'I', 10);
    $pdf->Cell(90, 5, '', 0, 0, 'C');
    $pdf->Cell(60, 5, 'ANNEE SCOLAIRE/SCHOOL ', 0, 0, 'R');
    $pdf->SetFont('Times', 'B', 12);
    $pdf->Cell(40, 5, '' . $_SESSION['school_year'] . '', 0, 0, 'L');
    $pdf->Cell(40, 5, '', 0, 1, 'C');
    $class->CkClasseByCode($refcls);
    $nbstd = $class->NbrStudentByClass($refcls);
    $nbM = $class->NbrBySexeByClass($refcls, 'M');
    $nbF = $class->NbrBySexeByClass($refcls, 'F');
    $nomcls = $_SESSION['nom_class'];
    $niveaucls = $_SESSION['ref_class_niveau'];

    $pdf->SetFont('Times', 'B', 15);
    $pdf->SetFillColor(217, 245, 254);
    $pdf->Cell(30, 10, '', 0, 0, 'C');
    $pdf->Cell(200, 10, utf8_to_cp1252($titrep . ' *** Classe/Class : ' . $nomcls), 1, 0, 'C', 1);
    $pdf->Cell(20, 10, '', 0, 1, 'C');
    $pdf->Ln();
    $pdf->SetFont('Times', 'B', 12);
    /* STATISTIQUE*/

    $marge = 10.00;

    $Tpt_std = 0;
    $t_coef_std = 0;
    $NbCoeffCls = $class->NombreCoeffbyCls($refcls);
    $moy_General = $opt->ShowMoyG_by_Eval($refcls, $bul);
    $nb_classer = $opt->ShowNbClasser_by_Eval($refcls, $bul);
    $nb_moy = $opt->ShowNbMoy_by_Eval($refcls, $bul, $marge);
    $moy_1er = $opt->ShowMoyPosition_by_Eval($refcls, $bul, '1er');
    $moy_dern = $opt->ShowMoyPosition_by_Eval($refcls, $bul, 'der');
    $NbTH = $opt->ShowTH_by_Eval($refcls, $bul);
    if ($nb_classer > 0) {
        $taux_r = (float)$nb_moy * 100 / (float)$nb_classer;
        $taux_r = round($taux_r, 2);
    } else {
        $taux_r = 0;
    }
    $nabs = $nbstd - $nb_classer;
    $pdf->Cell(30, 4, "Inscr: $nbstd  ;", 0, 0, 'C');
    $pdf->Cell(25, 4, "Comp: $nb_classer  ;", 0, 0, 'L');
    $pdf->Cell(18, 4, "Abs: $nabs  ;", 0, 0, 'L');
    $pdf->Cell(42, 4, "Nbr.Moy (>=$marge) : $nb_moy  ;", 0, 0, 'C');
    $pdf->Cell(30, 4, "Taux_R: $taux_r%  ;", 0, 0, 'C');
    $pdf->Cell(25, 4, "Tb.H: $NbTH  ;", 0, 0, 'C');
    $pdf->Cell(40, 4, "Moy.Cls: $moy_General  ;", 0, 0, 'C');
    $pdf->Cell(35, 4, "Moy 1er(e): $moy_1er  ;", 0, 0, 'C');
    $pdf->Cell(35, 4, "Moy dern: $moy_dern", 0, 0, 'C');
    $pdf->Ln();

    $pdf->SetFont('Times', 'B', 9);
    $pdf->Ln();
    $pdf->Cell(10, 6, utf8_to_cp1252('N°'), 1, 0, 'C', 1);
    $pdf->Cell(22, 6, 'Matricule', 1, 0, 'C', 1);
    $pdf->Cell(45, 6, utf8_to_cp1252('Noms_et_Prénoms/Full_Name'), 1, 0, 'C', 1);
    /*Afficher la liste des matières*/
    $pdf->SetFont('Times', 'B', 7.5);
    $bdd = $GLOBALS['bdd'];
    $reponse0 = $bdd->query('SELECT * FROM config_bull where ref_class="' . $refcls . '" order by group_mat asc');
    while ($row0 = $reponse0->fetch(PDO::FETCH_ASSOC)) {
        $refm = substr($row0['nom_mat'], 0, 5);
        $pdf->Cell(9, 6, utf8_to_cp1252($refm), 1, 0, 'L', 1);
    }
    $pdf->SetFillColor(2, 191, 109);
    $pdf->Cell(10, 6, 'Total', 1, 0, 'C', 1);
    $pdf->Cell(10, 6, 'T Cf', 1, 0, 'C', 1);
    $pdf->Cell(10, 6, 'Moy', 1, 0, 'C', 1);
    $pdf->Cell(10, 6, 'Rang', 1, 0, 'C', 1);
    $pdf->Cell(10, 6, 'H.abs', 1, 0, 'C', 1);
    $pdf->Ln();
    $pdf->SetFont('Times', 'B', 7);

    $bdd = $GLOBALS['bdd'];
    $reponse1 = $bdd->query('SELECT * FROM eleves where ref_class="' . $refcls . '" order by nom_std asc');
    while ($row1 = $reponse1->fetch(PDO::FETCH_ASSOC)) {
        $Nom = htmlspecialchars($row1['nom_std']);
        $Nom = strtoupper($Nom);
        $Nom = str_replace("&#039;", "'", $Nom);
        $Nom = substr($Nom, 0, 25);

        $date_nais_fr = date('d/m/Y ', strtotime($row1['date_nais']));
        $pdf->SetFont('Times', 'B', 7);
        $pdf->Cell(10, 5, $i, 1, 0);
        $pdf->Cell(22, 5, utf8_to_cp1252('' . $row1['cni_std'] . ''), 1, 0, 'C');
        $pdf->Cell(45, 5, utf8_to_cp1252("" . $Nom . ""), 1, 0);
        $pdf->SetFont('Times', 'B', 8);
        $bdd = $GLOBALS['bdd'];
        $reponsei = $bdd->query('SELECT * FROM config_bull where ref_class="' . $refcls . '" order by group_mat asc');
        while ($rowi = $reponsei->fetch(PDO::FETCH_ASSOC)) {
            $notei = $class->SelectNoteStd_by_MatCls($refcls, $rowi['ref_mat'], $bul, $row1['mat_std']);
            if ($notei == 21) {
                $pdf->Cell(9, 5, '--', 1, 0, 'C');
            } else {
                $pdf->Cell(9, 5, $notei, 1, 0, 'C');
            }
        }
        $tp_std = $opt->ShowTotalPoints_Seq_Std($refcls, $row1['mat_std'], $bul);
        $tp_c_std = $opt->ShowTotalCoeff_Seq_Std($refcls, $row1['mat_std'], $bul);
        $moy_std = $opt->ShowMoy_Seq_Std($refcls, $row1['mat_std'], $bul, $tp_c_std);
        $rang_std = $opt->ShowRang_Std_Eval($refcls, $row1['mat_std'], $bul, $tp_c_std);
        $classer_std = $opt->ShowClasser_Std($refcls, $row1['mat_std'], $bul);
        $HeureAbs = $opt->ShowAbsStd_by_Cls($refcls, $row1['mat_std'], $bul);
        if (empty($HeureAbs)) {
            $HeureAbs = 0;
        }

        $pdf->Cell(10, 5, $tp_std, 1, 0, 'C');
        $pdf->Cell(10, 5, $tp_c_std, 1, 0, 'C');

        $rangstd = (string)$rang_std;
        $strrangstd = '';
        if ($rangstd == '1') {
            $strrangstd = 'er(e)';
        } else {
            $strrangstd = 'e';
        }

        if ($moy_std > 0) {
            $smoy_std = (string)$moy_std;
        } else {
            $smoy_std = '--';
            $strrangstd = '';
        }

        if ($moy_std <= 0) {
            $pdf->SetFillColor(217, 245, 254);
            $pdf->Cell(10, 5, $smoy_std, 1, 0, 'C', 1);
            $pdf->SetFillColor(217, 245, 254);
            $pdf->Cell(10, 5, 'NC', 1, 0, 'C', 1);
            $pdf->Cell(10, 5, $HeureAbs, 1, 0, 'C', 1);
        } elseif ($moy_std < 12) {
            $pdf->SetFillColor(217, 245, 254);
            $pdf->Cell(10, 5, $smoy_std, 1, 0, 'C', 1);
            $pdf->SetFillColor(217, 245, 254);
            $pdf->Cell(10, 5, $rangstd . $strrangstd, 1, 0, 'C', 1);
            $pdf->Cell(10, 5, $HeureAbs, 1, 0, 'C', 1);
        } else {
            $pdf->SetFillColor(227, 242, 12);
            $pdf->Cell(10, 5, $smoy_std, 1, 0, 'C', 1);
            $pdf->SetFillColor(217, 245, 254);
            $pdf->Cell(10, 5, $rangstd . $strrangstd, 1, 0, 'C', 1);
            $pdf->Cell(10, 5, $HeureAbs, 1, 0, 'C', 1);
        }

        $pdf->Ln();
        $i++;
    }
    $pdf->Ln();
    $pdf->Ln();
    $pdf->SetFont('Times', 'B', 11);
    $pdf->MultiCell(250, 5, utf8_to_cp1252('NB: Les élèves ont un delai de 03 jours à compter de la date de l\'affichage de ce procès verbal pour apporter les pièces justificatives auprès du/des Professeur(s) conserné(s) en cas de contestation d\'une note, ou des heures d\'absence. Passé ce delai, aucune requête ne sera recevable.'), 0, 0, 'C', false);
}

// ---------------------------------------------------------------------------
// Génération du document : une page PV par classe
// ---------------------------------------------------------------------------
$compteur = 0;
foreach ($classes as $refcls) {
    if ($isEval) {
        $nbclasser = $opt->ShowNbClasser_by_Eval($refcls, $bul);
        if ($nbclasser > 0) {
            pv_rendu_eval($pdf, $refcls, $bul, $titrep);
            $compteur++;
        }
    } else {
        $exist_moy = $opt->Ck_ExistMoy_by_Cls($refcls, $trim);
        if ($exist_moy != false) {
            pv_rendu_trim($pdf, $refcls, $ev1, $ev2, $titrep, $trim);
            $compteur++;
        }
    }
}

if ($compteur == 0) {
    header('location: ../impression.php?ec=1');
    exit;
}

$pdf->Output('PV_' . $stat . '_' . $bul . '.pdf', 'I');
$pdf->Close();
?>