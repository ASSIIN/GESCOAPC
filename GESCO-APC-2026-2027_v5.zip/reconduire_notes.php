﻿<?php
    session_start();  
  require_once 'core/require.php'; 
  require_once 'Model/connexion.php';
     if (!isset($_SESSION['user'])) {
    session_unset();
    session_destroy();
    header('location: index.php');    
    }
    if (isset($ref_cls)) {
     $ref_cls='';
    }
if (!in_array($_SESSION['user_role'] ?? '', array('admin', 'cs', 'pcpl', 'ens'), true)) {
       header('location: poste_de_saisie.php?trim=t1');
       exit;
    }
    $etb->ShowEtb();
    $etb->CkLE();
     $etb->ckexneE();


?>

<!DOCTYPE html>
<html>
  <head>
   <?php Config::head(); ?>
    <title>GESCOAPC| RECONDUIRE NOTES</title>
  </head>

<body data-imprimable="1">
    <div class="wrapper">
      <!-- Sidebar -->

      <!-- Inclusion du menu de navigation externe réutilisable -->
      <?php include 'core/sidebar.php'; ?>  
       
<div class="main-content-wrapper">
        <!-- Barre supérieure de navigation adaptative -->
        <div class="mobile-navbar-fixed p-3 mb-4 rounded shadow-sm border">
            <div class="row align-items-center g-2">
                <div class="col-auto d-md-none">
                    <button class="btn btn-outline-dark btn-sm" id="toggleMobileMenu"><i class="fa fa-bars fa-lg"></i></button>
                </div>
                <div class="col-12 col-md">
                    <h4 class="m-0 fw-bold text-primary text-uppercase">Reconduire les notes</h4>
                </div>
                <div class="col-12 col-md-auto d-flex justify-content-md-end">
                    <a href="poste_de_saisie.php?trim=t1" class="btn btn-outline-danger btn-sm">Retour <i class="ms-2 fa fa-arrow-left"></i></a>
                </div>
            </div>
        </div>

<div class="container-fluid mt-4">
                <!-- ============================================================== -->
                <div class="row mt-3">
                    <div class="card shadow-sm">
                      <div class="card-header bg-primary text-white py-2">
                        <h5 class="m-0 fw-bold">Choisir une classe</h5>
                      </div>
<div class="card-body">

                    <form action="reconduire_notes.php" method="GET" enctype="multipart/form-data">
                        <div class="row">
                            <div class="col-10 col-sm-5">
                                <label for="sess_bul" class="form-label">Choisir une Section</label>
                                <select class="form-select form-select-lg mb-2" name="sess_bul" id="sess_bul" required>
                                    <option value="">...</option>
                                    <?php $class->SelectSessCls(); ?>
                                </select>
                            </div>
                            <div class="col-10 col-sm-4" id="cls_frg" style="display: none;">
                                <label for="cfg" class="form-label">Classe</label>
                                <select class="form-select form-select-lg mb-2" name="cfg">
                                    <option value="">Choisir...</option>
                                    <?php $class->SelectCls_by_Sess('SFG'); ?>
                                </select>
                            </div>
                            <div class="col-10 col-sm-4" id="cls_ang" style="display: none;">
                                <label for="cag" class="form-label">Classe</label>
                                <select class="form-select form-select-lg mb-2" name="cag">
                                    <option value="">Choisir...</option>
                                    <?php $class->SelectCls_by_Sess('SAG'); ?>
                                </select>
                            </div>
                            <div class="col-10 col-sm-4" id="cls_frt" style="display: none;">
                                <label for="cft" class="form-label">Classe</label>
                                <select class="form-select form-select-lg mb-2" name="cft">
                                    <option value="">Choisir...</option>
                                    <?php $class->SelectCls_by_Sess('SFT'); ?>
                                </select>
                            </div>
                            <div class="col-10 col-sm-4" id="cls_ant" style="display: none;">
                                <label for="cat" class="form-label">Classe</label>
                                <select class="form-select form-select-lg mb-2" name="cat">
                                    <option value="">Choisir...</option>
                                    <?php $class->SelectCls_by_Sess('SAT'); ?>
                                </select>
                            </div>
                            <div class="col-10 col-sm-2" id="btn_ok_r" style="display: none">
                                <label class="form-label">Opération</label><br>
                                <button class="btn btn-primary" type="submit">Suivant</button>
                            </div>
                        </div>
                    </form>

                    <?php  if (isset($_GET['sess_bul']))
                    {
                  
                         if ((!isset($_GET['cag']) or !isset($_GET['cfg']) or !isset($_GET['cft'])) and (!isset($_GET['cat']))) 
                         {
                            header('location: reconduire_notes.php');
                         }

                         else
                         {
                              $elt= array('cfg' =>htmlspecialchars($_GET['cfg']), 'cag' =>htmlspecialchars($_GET['cag']), 'cft' =>htmlspecialchars($_GET['cft']), 'cat' =>htmlspecialchars($_GET['cat']));
        
                              foreach ($elt as $key => $value) 
                              {
                                if ($value!="") 
                                {
                                  $refcls=$value;
                                }
                                else{
                                  continue;
                                }

                              }
                          }
                          $nom_cls=$class->ShowCls_namebyID($refcls);
                          $nom_ss=$class->ReturnNomSess_by_Code($_GET['sess_bul']);
     
                         echo '
                                <hr class="mx-2">
                                <div class="row my-4 justify-content-center text-center" style="font-size:1.2em">

                                  <div class="col-12 mx-2 text-primary">
                                    <b class="mb-4" style="color:black;font-size:1.5em">  RECONDUIRE UNE NOTE PAR COMPETENCE
                                     </b><br>
                                     <b > SECTION: '.$nom_ss.' / ClASSE: '.$nom_cls.' / CODE: '.$refcls.' </b><br><br> 
                                     <b class="mt-4" style="color:red">Attention! Cette action est irréversible. Verifiez si la matière et les competences de liason sont correctes avant de cliquer sur le bouton Confirmer. </b>
                                  </div>
                                </div>
                                <div class="row my-4 justify-content-center text-center">
                                  <div class="col-8 col-md-8">
                                      <form action="Controler/notes/recon_notes.php" method="post">
                                      <input type="text" class="form-control" id="" name="cls" value="'.$refcls.'" hidden="true" >                         
                                      <label for="inputState">DE MATIERE:</label>
                                      <select id="inputState" class="form-control" name="mat" required="true">

                                      <option value=""> Choisir... </option>
                                      
                                         ';
                                      $dep->SelectMatByCls($refcls);

                            
                                      echo '                        
                                    </select>
                                  </div>
                                  <div class="col-4 col-md-4">
                                    <label for="inputState">DE COMPT: </label>
                                     <select id="inputState" class="form-control" name="de"  required="true">
                                     <option> ... </option> ';
                                     $class->SelectActiveEval();
                                     echo '
                                    </select>
                                  </div>

                                   <div class="col-8 col-md-8">
                                    <label for="inputState">VERS MATIERE:</label>
                                      <select id="inputState" class="form-control" name="mat_to" required="true">

                                      <option value=""> Choisir... </option>
                                      
                                         ';
                                      $dep->SelectMatByCls($refcls);

                            
                                      echo '                        
                                    </select>
                                  </div>                             
                                  <div class="col-4 col-md-4">
                                    <label for="inputState">VERS COMPT: </label>
                                     <select id="inputState" class="form-control" name="vers"  required="true">
                                     <option> ... </option> ';

                                     $class->SelectActiveEval();

                                     echo '
                                     </select>
                                    </div> 
                                <div class="col-12 col-md-3"> 
                                    <label for="exampleInputEmail1" class="form-label">Opération</label><br>
                                      <button class="btn btn-primary" type="submit" name="submit" >Confirmer</button>
                                  </form>
                                  </div>
                              </div>
                           
                          </div>

                                   ';
                    } ?> 
       
 
                            
                                    
                  
                    </div>
                </div>
                <!-- ============================================================== -->
             
            </div>
                
            </div>
           
        <?php 
            Footers::TDfoot();
        ?>
        </div>
        <!-- ============================================================== -->
        <!-- End Page Content -->
        <!-- ============================================================== -->
    </div>


    <?php 
      Config::scriptJs();
    ?>
        <script type="text/javascript">


          $('#cls').click(function(){
            
              console.log(ref_cls);
               ref_cls= $('#cls').val();
                let date = new Date(Date.now() + 8640); //86400000ms = 1 jour
                date = date.toUTCString();
              //Supprime le cookie en lui passant une date d'expiration passée
                //document.cookie = 'rcls=; path=/; expires=Thu, 01 Jan 1970 00:00:00 UTC';
               //Crée ou met à jour un cookie 'user'
               document.cookie = 'rcls=' + encodeURIComponent(ref_cls) + '; path=/; expires=' + date;

               //$('#'+ref_cls+'').css('display', 'none');           
               console.log(ref_cls);
});

        </script>
         <script type="text/javascript">
             /* When the user clicks on the button,
toggle between hiding and showing the dropdown content */
function myFunction() {
  document.getElementById("myDropdown").classList.toggle("show");
}

function filterFunction() {
  var input, filter, ul, li, a, i;
  input = document.getElementById("myInput");
  filter = input.value.toUpperCase();
  div = document.getElementById("myDropdown");
  a = div.getElementsByTagName("a");
  for (i = 0; i < a.length; i++) {
    txtValue = a[i].textContent || a[i].innerText;
    if (txtValue.toUpperCase().indexOf(filter) > -1) {
      a[i].style.display = "";
    } else {
      a[i].style.display = "none";
    }
  }
}
</script>
  <script type="text/javascript">
    function typeElt() {
        var T_Elt=document.getElementById("option").value;

        if (T_Elt == "listsess") 
        {
          
          $('#vallistsess').css('display', 'block');
          $('#valclslist').css('display', 'none');
         
        }
        else if (T_Elt == "listnv")
        {
           $('#vallistnv').css('display', 'block');
           $('#vallistsess').css('display', 'none');
          $('#valclslist').css('display', 'none');
        
        }
        else if (T_Elt == "alllist"){
          $('#vallistnv').css('display', 'none');
           $('#vallistsess').css('display', 'none');
          $('#valclslist').css('display', 'none');

        }
        else {
          $('#vallistnv').css('display', 'none');
           $('#vallistsess').css('display', 'none');
          $('#valclslist').css('display', 'block');

        }
        console.log("username");
      }
</script>

 <script type="text/javascript">
    function typeElt_Stat() {
        var T_Elt=document.getElementById("stat").value;

        if (T_Elt == "pvsess") 
        {
          
          $('#valpvsess').css('display', 'block');
          $('#valclspv').css('display', 'none');
           $('#evalpv').css('display', 'none');
          $('#valpvnv').css('display', 'none');
         
        }
        else if (T_Elt == "pvnv")
        {
           $('#valpvnv').css('display', 'block');
           $('#evalpv').css('display', 'block');
           $('#valpvsess').css('display', 'none');
          $('#valclspv').css('display', 'none');
        
        }
        else if (T_Elt == "allpv"){
          $('#evalpv').css('display', 'block');
          $('#valpvnv').css('display', 'none');
           $('#valpvsess').css('display', 'none');
          $('#valclspv').css('display', 'none');

        }
        else if (T_Elt == "clspv"){
          $('#evalpv').css('display', 'block');
          $('#valpvnv').css('display', 'none');
           $('#valpvsess').css('display', 'none');
          $('#valclspv').css('display', 'block');

        }
        else if(T_Elt == "statremp"){

          $('#evalpv').css('display', 'block');
          $('#valpvnv').css('display', 'none');
           $('#valpvsess').css('display', 'block');
          $('#valclspv').css('display', 'none');

        }
        else{

          $('#evalpv').css('display', 'none');
          $('#valpvnv').css('display', 'none');
           $('#valpvsess').css('display', 'none');
          $('#valclspv').css('display', 'none');

        }
        console.log("username");
      }
</script>
        <script type="text/javascript">
        $("#sess_bul").click(function(){
        var T_Elt2 = $("#sess_bul").val();

        if (T_Elt2 == "SFG") 
        {
          
           $('#cls_frg').css('display', 'block');
            $('#cls_ang').css('display', 'none');
            $('#cls_frt').css('display', 'none');
            $('#cls_ant').css('display', 'none');
            $('#btn_ok_r').css('display', 'block');
         
        }
        else if (T_Elt2 == "SAG")
        {
           
            $('#cls_ang').css('display', 'block');
            $('#cls_frg').css('display', 'none');
            $('#cls_frt').css('display', 'none');
            $('#cls_ant').css('display', 'none');
            $('#btn_ok_r').css('display', 'block');
        }
         else if (T_Elt2 == "SFT")
        {
           
            $('#cls_ang').css('display', 'none');
            $('#cls_frg').css('display', 'none');
            $('#cls_frt').css('display', 'block');
            $('#cls_ant').css('display', 'none');
            $('#btn_ok_r').css('display', 'block');
        }
         else if (T_Elt2 == "SAT")
        {
           
            $('#cls_ang').css('display', 'none');
            $('#cls_frg').css('display', 'none');
            $('#cls_frt').css('display', 'none');
            $('#cls_ant').css('display', 'block');
            $('#btn_ok_r').css('display', 'block');
        }
        else{
           $('#cls_ang').css('display', 'none');
            $('#cls_frg').css('display', 'none');
            $('#cls_frt').css('display', 'none');
            $('#cls_ant').css('display', 'none');
            $('#vall_trim').css('display', 'none');
        }
       
      });

        

</script>
  </body>
</html>

