<?php
session_start();
require_once 'core/require.php';
require_once 'Model/checkdb.php';

// Sécurité : Si l'année de connexion n'est pas définie, on redirige vers l'index
if (!isset($_SESSION['con_year']) || empty($_SESSION['con_year'])) {
    header('location: index.php');
    exit();
}

require_once 'Model/connexion.php';
require_once 'less/licence_service.php';
$bdd = $GLOBALS['bdd'];

licence_creer_table();

// 1. Informations d'identité de l'établissement local
$stmt_info = $bdd->query("SELECT nom_etb_fr, school_year FROM etablissement LIMIT 1");
$info_etb = $stmt_info->fetch(PDO::FETCH_ASSOC);
$nom_ecole = $info_etb ? $info_etb['nom_etb_fr'] : 'Établissement non configuré';
$annee_scolaire = $info_etb ? $info_etb['school_year'] : 'Non définie';

// 2. Identifiant d'installation stable (généré une seule fois, communiqué pour l'achat)
//    Pré-remplissage possible depuis ?iid=... (récupération en cas de panne / changement d'ordinateur)
$licence = licence_lire();
$install_id = $licence ? trim($licence['install_id'] ?? '') : '';
$iid_get = trim($_GET['iid'] ?? '');
if ($install_id === '' && $iid_get !== '' && preg_match('/^[A-Za-z0-9\-_]{1,64}$/', $iid_get)) {
    $install_id = $iid_get;
}
if ($install_id === '') {
    $install_id = licence_uuid_v4();
    if ($licence) {
        $bdd->prepare("UPDATE config_licence SET install_id = ? WHERE id = ?")
            ->execute([$install_id, (int)$licence['id']]);
    } else {
        $bdd->prepare("INSERT INTO config_licence (cle_licence, statut_activation, install_id) VALUES ('', 'inactif', ?)")
            ->execute([$install_id]);
        $licence = licence_lire();
    }
}

// 3. État actuel de la licence
$etat = licence_verifier();
$licence_active = $etat['valide'];
$nom_licence_liee = $licence_active ? (string)($etat['etab_licence'] ?? $nom_ecole) : licence_nom_licence_actuelle();

// Message explicite lorsqu'un changement de nom d'établissement est détecté
function activation_message_etab($nom_licence, $nom_local)
{
    if ($nom_licence !== '' && $nom_local !== '' && $nom_licence !== $nom_local) {
        return "La licence de cette machine est liée à l'établissement « " . $nom_licence
            . " » alors que le nom actuellement configuré est « " . $nom_local . " ».\n\n"
            . "• Pour réutiliser votre licence existante : rétablissez le nom « " . $nom_licence
            . " » dans les Réglages généraux — l'ancienne licence sera restaurée automatiquement.\n"
            . "• Pour changer définitivement de nom : effectuez un nouveau paiement pour « " . $nom_local
            . " » (bouton ci-dessus), puis validez la nouvelle clé reçue par email.";
    }
    return "Le nom de l'établissement indiqué par la licence ne correspond pas à celui configuré sur cette machine. "
        . "Rétablissez le nom d'origine dans les Réglages généraux, ou obtenez une nouvelle licence sur le portail licences.inofib.com pour le nouveau nom.";
}

// 5. Traitement de l'activation / remplacement
$erreur_activation = false;
$message_activation = '';

// Déclenchement sur la présence de la clé (et non sur le bouton « activer » :
// le handler global de Config::scriptJs() désactive les boutons submit à
// l'envoi, ce qui supprime leur champ name du POST).
if (isset($_POST['cle_licence'])) {
    $cle = trim($_POST['cle_licence'] ?? '');
    $cle_publique_post = trim($_POST['cle_publique'] ?? '');
    $install_id_post = trim($_POST['install_id'] ?? '');
    $nom_etb_post = trim($_POST['nom_etb_fr'] ?? '');

    // Fichier de licence .txt importe (ou colle en entier) : on en extrait la
    // cle, la cle publique, l'install_id et le nom portes par la licence.
    $extrait = licence_extraire_txt($cle);
    if ($extrait !== null) {
        $cle = $extrait['cle'];
        if ($extrait['cle_publique'] !== '') {
            $cle_publique_post = $extrait['cle_publique'];
        }
        if ($install_id_post === '' && $extrait['install_id'] !== '') {
            $install_id_post = $extrait['install_id'];
        }
        if ($nom_etb_post === '' && $extrait['nom_etab'] !== '') {
            $nom_etb_post = $extrait['nom_etab'];
        }
    }

    // Nom proposé avec l'activation (champ « Nom exact de l'établissement »,
    // pré-rempli par l'import du fichier .txt).
    $nom_propose = trim((string)$nom_etb_post);
    if ($nom_propose !== '' && licence_texte_normalise($nom_propose) === licence_texte_normalise($nom_ecole)) {
        $nom_propose = '';
    }

    if ($install_id_post !== '') {
        $bdd->prepare("UPDATE config_licence SET install_id = ? WHERE id = ?")
            ->execute([$install_id_post, (int)$licence['id']]);
        $install_id = $install_id_post;
    }

    if ($cle === '') {
        $erreur_activation = true;
        $message_activation = 'Veuillez coller la clé de licence reçue par email ou importer le fichier .txt fourni.';
    } else {
        $controle = licence_verifier_cle_saisie($cle, $cle_publique_post);
        // Le nom local a été corrigé / est en défaut : la licence signée fait foi,
        // on aligne le nom de l'établissement sur celui qu'elle porte puis on revalide.
        if (!$controle['valide'] && ($controle['motif'] ?? '') === 'etab') {
            $nom_cible = trim((string)($controle['etab_licence'] ?? ''));
            if ($nom_cible !== '') {
                licence_maj_nom_etablissement($nom_cible);
                $nom_ecole = $nom_cible;
                $controle = licence_verifier_cle_saisie($cle, $cle_publique_post);
            }
        }
        if ($controle['valide']) {
            // La licence étant signée, on applique le nom exact proposé s'il est
            // équivalent (même nom normalisé) : il corrige l'orthographe locale.
            if ($nom_propose !== '' && licence_texte_normalise($nom_propose) === licence_texte_normalise($nom_ecole)) {
                if (licence_maj_nom_etablissement($nom_propose)) {
                    $nom_ecole = $nom_propose;
                }
            }
            licence_enregistrer($cle, $cle_publique_post, $install_id);
            unset($_SESSION['licence_verifiee']);
            $_SESSION['activation_ok'] = true;
            header('Location: index.php?lk=1');
            exit();
        } else {
            $erreur_activation = true;
            $message_activation = ($controle['motif'] === 'etab')
                ? activation_message_etab($controle['etab_licence'] ?? $nom_licence_liee, $controle['nom_local'] ?? $nom_ecole)
                : licence_motif_message($controle['motif']);
        }
    }
}

// Lien du portail reconstruit après une éventuelle correction du nom
$lien_portail = 'https://licences.inofib.com/service_gescoapc.php?install_id=' . urlencode($install_id)
    . '&nom_etab=' . urlencode($nom_ecole)
    . '&annee_scolaire=' . urlencode($annee_scolaire);

$licence = licence_lire();
$dernier_controle = $licence ? $licence['dernier_controle'] : null;
?>
<!DOCTYPE html>
<html lang="fr">
<head>
     <?php Config::head(); ?>
     <script src="assets/js/plugin/sweetalert/sweetalert.min.js"></script>
     <title>GESCO-APC | Activation Annuelle</title>

     <style>
         .glass-card {
             background: rgba(255, 255, 255, 0.9);
             backdrop-filter: blur(12px);
             -webkit-backdrop-filter: blur(12px);
             border-radius: 16px;
             box-shadow: 0 8px 32px 0 rgba(0, 0, 0, 0.2);
             border: 1px solid rgba(255, 255, 255, 0.25);
         }
         .install-box {
             background: #f0f7ff;
             border: 2px dashed #0764a8;
             border-radius: 10px;
             padding: 14px 16px;
             font-family: Consolas, monospace;
             letter-spacing: 1px;
             color: #0764a8;
             word-break: break-all;
         }
         .key-input {
             font-family: Consolas, monospace;
             font-size: .84rem;
             letter-spacing: .5px;
             word-break: break-all;
         }
     </style>
</head>
<body style="background-image: url(plugins/images/bg1.jpg); background-size: cover; background-position: center; background-attachment: fixed; min-height: 100vh; display: flex; align-items: center;">

    <?php
    if ($erreur_activation) {
        echo "<script>
            Swal.fire({
                icon: 'error',
                title: 'Licence invalide',
                text: " . json_encode($message_activation) . ",
                confirmButtonColor: '#19784f'
            });
        </script>";
    } elseif (isset($_GET['motif'])) {
        $motif_texte = $_GET['motif'] === 'etab'
            ? activation_message_etab($nom_licence_liee, $nom_ecole)
            : licence_motif_message($_GET['motif']);
        echo "<script>
            Swal.fire({
                icon: 'warning',
                title: 'Licence requise',
                text: " . json_encode($motif_texte) . ",
                confirmButtonColor: '#19784f'
            });
        </script>";
    }
    ?>

    <div class="container py-5">
        <div class="row justify-content-center">
            <div class="col-md-7 col-lg-6">
                <div class="card glass-card p-4 mb-4">

                    <div class="text-center">
                        <img class="mb-3 mx-auto d-block" src="plugins/images/gescoapc.png" width="200" alt="Logo GESCO-APC">
                        <h4 class="fw-bold mb-1" style="color: #0764a8;">Validation de Licence</h4>
                        <p class="text-secondary small mb-3">Abonnement annuel et nominatif obligatoire</p>

                        <div class="p-3 mb-4 rounded" style="background: rgba(7, 100, 168, 0.08); border-left: 4px solid #0764a8;">
                            <p class="text-dark fw-bold mb-1 text-uppercase small" style="letter-spacing: 0.5px;">Structure locale détectée :</p>
                            <h6 class="text-primary fw-bolder mb-2"><?php echo htmlspecialchars($nom_ecole); ?></h6>
                            <span class="badge bg-success font-monospace px-3 py-2 fs-6" style="background-color: #19784f !important;">Session : <?php echo htmlspecialchars($annee_scolaire); ?></span>
                        </div>
                    </div>

                    <!-- ÉTAT ACTUEL -->
                    <?php if ($licence_active): ?>
                    <div class="p-3 mb-4 rounded" style="background: rgba(25, 120, 79, 0.10); border: 1px solid rgba(25, 120, 79, 0.35);">
                        <div class="d-flex align-items-center">
                            <i class="fa fa-circle-check text-success fa-2x me-3" style="color:#19784f !important;"></i>
                            <div>
                                <strong style="color:#19784f;" class="fw-bolder">Licence ACTIVE</strong>
                                <div class="small text-dark mt-1">
                                    Valable du <?php echo htmlspecialchars($etat['debut']); ?> au <strong><?php echo htmlspecialchars($etat['fin']); ?></strong>
                                    (<?php echo (int)$etat['jours_restants']; ?> jours restants) - Tarif <?php echo htmlspecialchars($etat['tarif']); ?>
                                    <?php if ($dernier_controle): ?> - Contrôle : <?php echo htmlspecialchars($dernier_controle); ?><?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php else: ?>
                    <div class="p-3 mb-4 rounded" style="background: rgba(220, 53, 69, 0.08); border: 1px solid rgba(220, 53, 69, 0.3);">
                        <i class="fa fa-circle-xmark text-danger me-2"></i>
                        <strong class="text-danger">Aucune licence active</strong>
                        <span class="small text-muted"> - effectuez le paiement puis collez la clé reçue ci-dessous.</span>
                    </div>
                    <?php endif; ?>

                    <?php if (!$licence_active && (stripos($nom_ecole, 'ETABLISSEMENT') !== false || stripos($nom_ecole, 'Établissement') !== false)): ?>
                    <div class="p-3 mb-4 rounded" style="background: rgba(255,193,7,0.12); border: 1px solid rgba(255,193,7,0.45);">
                        <i class="fa fa-triangle-exclamation text-warning me-2"></i>
                        <strong class="text-dark">Le nom « <?php echo htmlspecialchars($nom_ecole); ?> » est le nom par défaut.</strong>
                        <div class="small text-dark mt-1">
                            Corrigez-le <strong>ci-dessous</strong> (« Nom exact de l'établissement ») ou importez le fichier
                            .txt de votre licence : le nom sera mis à jour automatiquement. Si vous n'avez pas encore payé,
                            renseignez votre nom <strong>exact</strong> avant le paiement — la licence y est liée (ex. « Collège de la Perle »).
                        </div>
                    </div>
                    <?php elseif ($licence_active && $nom_licence_liee !== '' && $nom_licence_liee !== $nom_ecole): ?>
                    <div class="p-3 mb-4 rounded" style="background: rgba(255,193,7,0.12); border: 1px solid rgba(255,193,7,0.45);">
                        <i class="fa fa-triangle-exclamation text-warning me-2"></i>
                        <strong class="text-dark">Nom de l'établissement modifié après activation</strong>
                        <div class="small text-dark mt-1">
                            Votre licence est liée à « <?php echo htmlspecialchars($nom_licence_liee); ?> », le nom actuel est
                            « <?php echo htmlspecialchars($nom_ecole); ?> ». Importez le fichier .txt de votre licence ci-dessous :
                            le nom sera rétabli automatiquement à la validation. Sinon, activez une nouvelle licence pour le nom actuel.
                        </div>
                    </div>
                    <?php endif; ?>

                    <!-- ÉTAPE 1 : Paiement -->
                    <div class="mb-4">
                        <label class="form-label fw-bold text-dark mb-1" style="font-size: 0.9em;">Étape 1 : Renouvellement de l'abonnement</label>
                        <p class="text-muted" style="font-size: 0.8em; line-height: 1.3;">Réglez la licence annuelle sur le portail officiel (Assiin Pay), puis récupérez votre clé par email.</p>
                        <a href="<?php echo htmlspecialchars($lien_portail); ?>" target="_blank" class="btn btn-primary w-100 fw-bold py-2 shadow-sm" style="background-color: #0764a8; border: none;">
                            <i class="fa fa-credit-card me-2"></i>Payer la licence annuelle sur INOFIB
                        </a>
                    </div>

                    <div class="d-flex align-items-center my-3">
                        <hr class="flex-grow-1 text-muted">
                        <span class="mx-3 text-muted small fw-bold">OU</span>
                        <hr class="flex-grow-1 text-muted">
                    </div>

                    <!-- ÉTAPE 2 : Activation -->
                    <form action="activation.php" method="POST" onsubmit="if(this.dataset.actif){return false;}this.dataset.actif='1';window.setTimeout(function(){this.dataset.actif='';}.bind(this),5000);">

                        <div class="mb-4 p-3 rounded" style="background: rgba(7, 100, 168, 0.06); border: 1px dashed #0764a8;">
                            <label class="form-label fw-bold text-dark mb-1" style="font-size: 0.9em;"><i class="fa fa-file-import me-1"></i>Activation par fichier .txt (maintenancier)</label>
                            <input type="file" class="form-control key-input" id="fichier_licence" accept=".txt,text/plain" onchange="licence_import_txt(this)" style="background: rgba(255,255,255,0.7);">
                            <div class="form-text small text-muted">Choisissez le fichier « licence_GESCO-APC_….txt » reçu par email (ou via « Récupérer ma clé ») : la clé, la clé publique, l'install_id et le <strong>nom de l'établissement</strong> seront remplis automatiquement. La validation ci-dessous activera la licence et corrigera le nom dans le logiciel.</div>
                        </div>

                        <div class="mb-3">
                            <label for="nom_etb_fr" class="form-label fw-bold text-dark mb-1" style="font-size: 0.9em;">Nom exact de l'établissement</label>
                            <input type="text" class="form-control text-uppercase" id="nom_etb_fr" name="nom_etb_fr" maxlength="50" value="<?php echo htmlspecialchars($nom_ecole); ?>" style="font-weight:600; background: rgba(255,255,255,0.7); border: 2px solid rgba(255,255,255,0.5);">
                            <div class="form-text small text-muted">Rempli automatiquement à l'import du fichier .txt. Corrigez votre nom ici s'il est mal orthographié : il sera mis à jour dès la validation (adressez-vous au support pour corriger le nom côté portail).</div>
                        </div>

                        <div class="mb-3">
                            <label for="cle_licence" class="form-label fw-bold text-dark mb-1" style="font-size: 0.9em;">Étape 2 : Clé de licence</label>
                            <textarea class="form-control key-input" id="cle_licence" name="cle_licence" rows="3" placeholder="Collez ici la clé de licence complète reçue par email, ou le contenu complet du fichier .txt..." required style="letter-spacing:.5px; color:#19784f; background: rgba(255,255,255,0.7); border: 2px solid rgba(255,255,255,0.5);"></textarea>
                        </div>

                        <div class="mb-3">
                            <label for="install_id" class="form-label fw-bold text-dark mb-1" style="font-size: 0.9em;">Identifiant d'installation (install_id)</label>
                            <div class="d-flex align-items-stretch">
                                <input type="text" class="form-control key-input" id="install_id" name="install_id" value="<?php echo htmlspecialchars($install_id); ?>" required maxlength="64" pattern="[A-Za-z0-9\-_]{1,64}">
                                <button type="button" class="btn btn-outline-primary ms-2 d-flex align-items-center" style="min-width:48px;" onclick="licence_copier_install_id(this)" title="Copier l'identifiant d'installation"><i class="fa fa-copy"></i></button>
                            </div>
                            <div class="form-text small text-muted">À recopier lors de l'achat ou du renouvellement — votre licence est liée à cet identifiant. Ordinateur en panne ou remplacé ? Saisissez l'install_id d'origine (portail licences.inofib.com → « Récupérer ma clé »).</div>
                        </div>

                        <div class="mb-3">
                            <label for="cle_publique" class="form-label fw-bold text-dark mb-1" style="font-size: 0.9em;">Clé publique INOFIB <span class="text-muted">(facultatif, pré-remplie)</span></label>
                            <textarea class="form-control key-input" id="cle_publique" name="cle_publique" rows="3" placeholder="-----BEGIN PUBLIC KEY-----..." style="background: rgba(255,255,255,0.5); border: 1px solid rgba(255,255,255,0.5);"><?php echo htmlspecialchars(trim($licence['cle_publique'] ?? '') !== '' ? $licence['cle_publique'] : INOFIB_CLE_PUBLIQUE_DEFAUT); ?></textarea>
                            <div class="form-text small text-muted">Ne modifiez cette valeur que si INOFIB vous a communiqué une nouvelle clé publique.</div>
                        </div>

                        <div class="row g-2 mt-2">
                            <div class="col-8">
                                <button class="btn btn-success w-100 fw-bold py-2 shadow-sm" name="activer" type="submit" data-no-busy style="background-color: #19784f; border: none;">
                                    <i class="fa fa-check-circle me-2"></i>Valider l'activation
                                </button>
                            </div>
                            <div class="col-4">
                                <a href="exit.php" class="btn btn-outline-secondary w-100 py-2">Retour au login</a>
                            </div>
                        </div>
                    </form>

                </div>
            </div>
        </div>
    </div>

    <script>
        function licence_import_txt(input) {
            var f = input.files && input.files[0];
            if (!f) return;
            var reader = new FileReader();
            reader.onload = function (e) {
                var txt = e.target.result || '';
                var nom = '';
                var m = txt.replace(/\r\n/g, '\n').match(/^[^\n=]{1,255}/);
                if (m) { nom = m[0].trim(); }
                var m2 = txt.match(/Install\s*ID\s*:\s*([A-Za-z0-9\-_]{1,64})/i);
                if (m2) {
                    var champ_id = document.getElementById('install_id');
                    if (champ_id) { champ_id.value = m2[1]; }
                }
                document.getElementById('cle_licence').value = txt;
                if (nom) {
                    var champ_nom = document.getElementById('nom_etb_fr');
                    if (champ_nom) { champ_nom.value = nom; }
                }
                var msg = 'Fichier de licence importé.';
                if (nom) { msg += ' Nom détecté : « ' + nom + ' ».'; }
                msg += ' Vérifiez le nom ci-dessous puis cliquez sur « Valider l\'activation » : le nom et la licence seront enregistrés.';
                if (window.Swal) { Swal.fire({ icon: 'success', title: 'Licence importée', text: msg, confirmButtonColor: '#19784f' }); }
                else { alert(msg); }
            };
            reader.readAsText(f);
        }

        function licence_copier_install_id(btn) {
            var id = <?php echo json_encode($install_id); ?>;;
            function ok() {
                var icone = btn.querySelector('i');
                if (icone) { icone.className = 'fa fa-check'; }
                btn.classList.remove('btn-outline-primary');
                btn.classList.add('btn-success');
                window.setTimeout(function () {
                    if (icone) { icone.className = 'fa fa-copy'; }
                    btn.classList.add('btn-outline-primary');
                    btn.classList.remove('btn-success');
                }, 1800);
                if (window.GescoToast) { window.GescoToast("Identifiant d'installation copié.", 'success'); }
                else if (window.Swal) { Swal.fire({ icon: 'success', title: 'Copié !', text: "Identifiant d'installation copié dans le presse-papiers.", timer: 1800, showConfirmButton: false }); }
            }
            function fallback() {
                var ta = document.createElement('textarea');
                ta.value = id;
                ta.style.position = 'fixed';
                ta.style.top = '-9999px';
                document.body.appendChild(ta);
                ta.select();
                try { document.execCommand('copy'); ok(); } catch (e) {}
                document.body.removeChild(ta);
            }
            if (navigator.clipboard && window.isSecureContext) {
                navigator.clipboard.writeText(id).then(ok, fallback);
            } else {
                fallback();
            }
        }
    </script>

    <?php Config::scriptJs(); ?>
</body>
</html>