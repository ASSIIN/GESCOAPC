<?php 
/**
 * Classe de Gestion des Classes, Configurations et Calculs Statistiques
 * Projet: GESCO-APC
 * Optimisation Sécurité, Rapidité Laragon & Mode Sombre - INOFIB 2026
 */
class MyClasses
{
    private $nom_class, $ref_class_niveau, $class_session, $code_class;
    
    function __construct() {}

    public function setNom_class($value) { $this->nom_class = $value; }
    public function getNom_class() { return $this->nom_class; }

    public function setRef_class_niveau($value) { $this->ref_class_niveau = $value; }
    public function getRef_class_niveau() { return $this->ref_class_niveau; }

    public function setClass_session($value) { $this->class_session = $value; }
    public function getClass_session() { return $this->class_session; }

    public function setCode_class($value) { $this->code_class = $value; }
    public function getCode_class() { return $this->code_class; }

    public function AddClasses()
    {
        $bdd = $GLOBALS['bdd'];
        $req = "INSERT INTO classes (nom_class, ref_class_niveau, class_session, code_class) VALUES(?, ?, ?, ?)";
        $rep = $bdd->prepare($req);
        return $rep->execute(array($this->nom_class, $this->ref_class_niveau, $this->class_session, $this->code_class));
    }

    public function CkClasseByCode($code)
    {
        $bdd = $GLOBALS['bdd']; 
        $stmt = $bdd->prepare('SELECT id, nom_class, ref_class_niveau, class_session, code_class FROM classes WHERE code_class = ? LIMIT 1');
        $stmt->execute(array($code));
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        if ($row) {
            $_SESSION['id_cls'] = $row['id'];
            $_SESSION['nom_class'] = $row['nom_class'];
            $_SESSION['ref_class_niveau'] = $row['ref_class_niveau'];
            $_SESSION['class_session'] = $row['class_session'];
            $_SESSION['code_class'] = $row['code_class'];
        }
    }

    public function ShowClassInfos($code)
    {
        $this->CkClasseByCode($code);
    }

    public function SelectTeacherByRole($rl)
    {
        $bdd = $GLOBALS['bdd'];
        $stmt = $bdd->prepare('SELECT login, civilite, username, role FROM admins WHERE role = ? ORDER BY username ASC');
        $stmt->execute(array($rl));
        $i = 0;
        while($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            $i++;
            echo '<option value="' . $row['login'] . '" id="' . $row['login'] . '">' . $i . ' - ' . $row['civilite'] . ' ' . $row['username'] . ' - (' . $row['role'] . ')</option>';
        }
    }

    public function ShowAllClasses()
    {
        $bdd = $GLOBALS['bdd'];
        $reponse = $bdd->query('SELECT id, nom_class, ref_class_niveau, class_session, code_class FROM classes ORDER BY ref_class_niveau ASC, nom_class ASC');
        $i = 0;
        while($row = $reponse->fetch(PDO::FETCH_ASSOC)) 
        {
            $i++;
            $nbrstd = $this->NbrStudentByClass($row['code_class']);
            $nbmat = $this->NombreMatbyCls($row['code_class']);
            // CORRECTION : le professeur principal d'une classe est stocké dans classes.cls_master (login dans admins)
            $nomEns = $this->ShowNom_Cls_Master($row['code_class']);

            echo '
            <tr>
                <td>' . $i . '</td>
                <td class="text-start fw-bold" style="padding-left:15px;">' . $row['nom_class'] . ' <span class="badge bg-secondary-subtle text-secondary ms-2 small">Eff: ' . $nbrstd . '</span></td>
                <td>
                    <button type="button" class="btn btn-sm btn-outline-primary py-0 px-2" data-bs-toggle="modal" data-bs-target="#mod_edit' . $row['id'] . '"><i class="fa fa-edit"></i></button>
                </td>
                <td>
                    <a href="config_bull.php?id=' . $row['code_class'] . '" class="btn btn-sm btn-outline-info py-0 px-2 fw-bold"><i class="fa fa-cog me-1"></i> ' . $nbmat . ' matières</a>
                </td>
                <td>
                    <a href="fpdf185/listbycls.php?refcls=' . $row['code_class'] . '" class="btn btn-sm btn-outline-warning py-0 px-2"><i class="fa fa-print"></i></a>
                </td>
                <td>
                    <a href="excelReader/export_clslist.php?refcls=' . $row['code_class'] . '" class="btn btn-sm btn-outline-success py-0 px-2"><i class="fa fa-file-excel-o"></i></a>
                </td>
                <td>
                    <button type="button" class="btn btn-sm btn-outline-danger py-0 px-2" data-bs-toggle="modal" data-bs-target="#mod_del' . $row['id'] . '"><i class="fa fa-remove"></i></button>
                </td>
            </tr>';

            // Modal d'Édition Interne Harmonisé Mode Sombre & Bootstrap 5
            echo '
            <div class="modal fade" id="mod_edit' . $row['id'] . '" tabindex="-1" aria-hidden="true">
                <div class="modal-dialog modal-dialog-centered modal-lg">
                    <div class="modal-content border-0">
                        <div class="modal-header text-white" style="background-color: #0764a8;">
                            <h5 class="modal-title fw-bold"><i class="fa fa-edit me-2"></i>Modifier la Classe : ' . $row['code_class'] . '</h5>
                            <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                        </div>
                        <form action="Controler/classes/updcls.php" method="post">
                            <div class="modal-body p-4" style="background-color: var(--bg-main);">
                                <div class="container-fluid p-0">
                                    <div class="row g-3">
                                        <div class="col-12 col-md-4">
                                            <input type="hidden" name="id_cls" value="' . $row['id'] . '">
                                            <label class="form-label fw-bold text-secondary small">Intitulé de la classe : <i class="text-danger">(' . $row['nom_class'] . ')</i></label>
                                            <input type="text" class="form-control form-control-sm text-uppercase fw-bold" name="nom_cls" maxlength="100">
                                        </div>
                                        <div class="col-12 col-md-8">
                                            <label class="form-label fw-bold text-secondary small">Enseignant Responsable (PP) : <i class="text-danger">(' . $nomEns . ')</i></label>
                                            <select class="form-select form-select-sm" name="cls_master">
                                                <option value="">Choisir un nouveau titulaire...</option>';
                                                $this->SelectTeacherByRole('ens');
                                            echo '</select>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="modal-footer border-top-0 pt-0">
                                <button type="button" class="btn btn-sm btn-secondary px-3" data-bs-dismiss="modal">Annuler</button>
                                <button type="submit" class="btn btn-sm text-white fw-bold px-4" style="background-color: #19784f; border:none;"><i class="fa fa-save me-2"></i>Enregistrer</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>';

            // Modal de Suppression Interne Harmonisé Mode Sombre & Bootstrap 5
            echo '
            <div class="modal fade" id="mod_del' . $row['id'] . '" tabindex="-1" aria-hidden="true">
                <div class="modal-dialog modal-dialog-centered">
                    <div class="modal-content">
                        <div class="modal-header bg-danger text-white border-0 py-2">
                            <h5 class="modal-title fw-bold small"><i class="fa fa-warning me-2"></i>Supprimer la Structure</h5>
                            <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                        </div>
                        <div class="modal-body text-center p-4">
                            <p class="mb-1 text-muted small">Voulez-vous rayer de la structure pédagogique la classe :</p>
                            <h5 class="text-danger fw-bolder mb-2">' . $row['nom_class'] . '</h5>
                            <p class="text-secondary font-monospace bg-light p-2 rounded small" style="font-size:0.8em;"><i class="fa fa-info-circle me-1"></i>Cette action supprimera également la liste complète des élèves inclus ainsi que leurs configurations. Cette action est irréversible.</p>
                        </div>
                        <div class="modal-footer border-top-0 pt-0 justify-content-center">
                            <button type="button" class="btn btn-sm btn-secondary px-3" data-bs-dismiss="modal">Annuler</button>
                            <a href="Controler/classes/delclasse.php?id=' . $row['code_class'] . '" class="btn btn-sm btn-danger px-4 fw-bold">Confirmer la suppression</a>
                        </div>
                    </div>
                </div>
            </div>';
        }
    }


	    public function ShowUsernamebyID($id)
    {
        $bdd = $GLOBALS['bdd'];
        $stmt = $bdd->prepare('SELECT civilite, username FROM admins WHERE login = ? LIMIT 1');
        $stmt->execute(array($id));
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        return $row ? $row['civilite'] . ' ' . $row['username'] : 'Aucun enseignant';
    }

    public function ReturnID_ClsMaster($cls)
    {
        $bdd = $GLOBALS['bdd'];
        $stmt = $bdd->prepare('SELECT cls_master FROM classes WHERE code_class = ? LIMIT 1');
        $stmt->execute(array($cls));
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        return $row ? $row['cls_master'] : '';
    }

    public function ShowNom_Cls_Master($code)
    {
        $bdd = $GLOBALS['bdd'];
        $id = $this->ReturnID_ClsMaster($code);
        if (!empty($id)) {
            $stmt = $bdd->prepare('SELECT civilite, username FROM admins WHERE login = ? LIMIT 1');
            $stmt->execute(array($id));
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            if ($row) {
                return $row['civilite'] . ' ' . $row['username'];
            }
        }
        return 'Aucun enseignant';
    }

    public function ShowCls_namebyID($id)
    {
        $bdd = $GLOBALS['bdd'];
        $stmt = $bdd->prepare('SELECT nom_class FROM classes WHERE code_class = ? LIMIT 1');
        $stmt->execute(array($id));
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        return $row ? $row['nom_class'] : '';
    }

    public function ShowMat_namebyID($id)
    {
        $bdd = $GLOBALS['bdd'];
        $stmt = $bdd->prepare('SELECT nom_mat FROM matieres WHERE id = ? LIMIT 1');
        $stmt->execute(array($id));
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        return $row ? $row['nom_mat'] : '';
    }

    public function ShowRoleMasterCls_namebyID($id)
    {
        $bdd = $GLOBALS['bdd'];
        $stmt = $bdd->prepare('SELECT role FROM admins WHERE master_cls = ? LIMIT 1');
        $stmt->execute(array($id));
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        return $row ? $row['role'] : '';
    }

    public function ShowCls_Note_by_User($id)
    {
        $bdd = $GLOBALS['bdd'];
        $stmt = $bdd->prepare('SELECT distinct ref_class, ref_niveau_class, ref_mat FROM config_bull WHERE ref_ens = ? ORDER BY ref_niveau_class ASC');
        $stmt->execute(array($id));
        $i = 0;
        while($row = $stmt->fetch(PDO::FETCH_ASSOC)) 
        {
            $i++;
            $nom_cls = $this->ShowCls_namebyID($row['ref_class']);
            $nom_mat = $this->ShowMat_namebyID($row['ref_mat']);
            echo '
            <div class="col-md-6 my-2" tabindex="-1">
                <a class="btn w-100 text-start fw-bold shadow-sm" data-bs-toggle="collapse" href="#note_' . $row['ref_mat'] . $row['ref_class'] . '" role="button" style="background-color: var(--bg-card); color: var(--text-main); border: 1px solid var(--border-color);">
                    <i class="fa fa-folder-open text-primary me-2"></i>( ' . $i . ' ) &mdash; ' . $nom_cls . ' &bull; ' . $nom_mat . '
                </a>
            </div>';
        }
    }




		    public function SelectCls_Note_by_User($id)
    {
        $bdd = $GLOBALS['bdd'];
        $rep1 = $bdd->query('SELECT code_class FROM classes ORDER BY class_session ASC, ref_class_niveau ASC, nom_class ASC');
        $i = 0;
        
        $stmt = $bdd->prepare('SELECT ref_class FROM config_bull WHERE ref_ens = ? AND ref_class = ? ORDER BY group_mat ASC, nom_mat ASC LIMIT 1');
        
        while($row1 = $rep1->fetch(PDO::FETCH_ASSOC)) 
        {
            $stmt->execute(array($id, $row1['code_class']));
            while($row2 = $stmt->fetch(PDO::FETCH_ASSOC)) 
            {
                $nom_cls = $this->ShowCls_namebyID($row2['ref_class']);
                $i++;
                echo '<option value="' . $row2['ref_class'] . '" id="' . $row2['ref_class'] . '">' . $i . ' -- ' . $nom_cls . '</option>';
            }
        }
    }

    public function SelectClsList_byNote_by_User($id, $trim)
    {
        $bdd = $GLOBALS['bdd'];
        $role_user = isset($_SESSION['user_role']) ? $_SESSION['user_role'] : '';
        
        $rep1 = $bdd->query('SELECT code_class FROM classes ORDER BY class_session ASC, ref_class_niveau ASC, nom_class ASC');
        $i = 0;
        
        $stmt_admin = $bdd->prepare('SELECT ref_class FROM config_bull WHERE ref_class = ? ORDER BY group_mat ASC, nom_mat ASC LIMIT 1');
        $stmt_user = $bdd->prepare('SELECT ref_class FROM config_bull WHERE ref_ens = ? AND ref_class = ? ORDER BY group_mat ASC, nom_mat ASC LIMIT 1');
        
        while($row1 = $rep1->fetch(PDO::FETCH_ASSOC)) 
        {
            if ($role_user == "admin") {
                $stmt_admin->execute(array($row1['code_class']));
                $row2 = $stmt_admin->fetch(PDO::FETCH_ASSOC);
            } else {
                $stmt_user->execute(array($id, $row1['code_class']));
                $row2 = $stmt_user->fetch(PDO::FETCH_ASSOC);
            }
            
            if ($row2) {
                $nom_cls = $this->ShowCls_namebyID($row2['ref_class']);
                $i++;
                echo '<a href="poste_de_saisie.php?trim=' . $trim . '&ref_class=' . $row2['ref_class'] . '" class="list-group-item list-group-item-action py-2 fw-bold text-secondary"><i class="fa fa-chevron-right me-2 text-primary small"></i>' . $i . ' -- ' . $nom_cls . '</a>';
            }
        }
    }

    public function SelectClsList_byNote_by_User_AjoutPoint($id, $trim)
    {
        $bdd = $GLOBALS['bdd'];
        $role_user = isset($_SESSION['user_role']) ? $_SESSION['user_role'] : '';
        
        $rep1 = $bdd->query('SELECT code_class FROM classes ORDER BY class_session ASC, ref_class_niveau ASC, nom_class ASC');
        $i = 0;
        
        $stmt_admin = $bdd->prepare('SELECT ref_class FROM config_bull WHERE ref_class = ? ORDER BY group_mat ASC, nom_mat ASC LIMIT 1');
        $stmt_user = $bdd->prepare('SELECT ref_class FROM config_bull WHERE ref_ens = ? AND ref_class = ? ORDER BY group_mat ASC, nom_mat ASC LIMIT 1');
        
        while($row1 = $rep1->fetch(PDO::FETCH_ASSOC)) 
        {
            if ($role_user == "admin") {
                $stmt_admin->execute(array($row1['code_class']));
                $row2 = $stmt_admin->fetch(PDO::FETCH_ASSOC);
            } else {
                $stmt_user->execute(array($id, $row1['code_class']));
                $row2 = $stmt_user->fetch(PDO::FETCH_ASSOC);
            }
            
            if ($row2) {
                $nom_cls = $this->ShowCls_namebyID($row2['ref_class']);
                $i++;
                echo '<a href="interface_ajout_points.php?trim=' . $trim . '&ref_class=' . $row2['ref_class'] . '" class="list-group-item list-group-item-action py-2 fw-bold text-secondary"><i class="fa fa-plus-circle me-2 text-success small"></i>' . $i . ' -- ' . $nom_cls . '</a>';
            }
        }
    }


		    public function SelectClsList_byNote_by_User_std($id, $trim)
    {
        $bdd = $GLOBALS['bdd'];
        $role_user = isset($_SESSION['user_role']) ? $_SESSION['user_role'] : '';
        
        $rep1 = $bdd->query('SELECT code_class FROM classes ORDER BY class_session ASC, ref_class_niveau ASC, nom_class ASC');
        $i = 0;
        
        $stmt_admin = $bdd->prepare('SELECT ref_class FROM config_bull WHERE ref_class = ? ORDER BY group_mat ASC, nom_mat ASC LIMIT 1');
        $stmt_user = $bdd->prepare('SELECT ref_class FROM config_bull WHERE ref_ens = ? AND ref_class = ? ORDER BY group_mat ASC, nom_mat ASC LIMIT 1');
        
        while($row1 = $rep1->fetch(PDO::FETCH_ASSOC)) 
        {
            if ($role_user == "admin") {
                $stmt_admin->execute(array($row1['code_class']));
                $row2 = $stmt_admin->fetch(PDO::FETCH_ASSOC);
            } else {
                $stmt_user->execute(array($id, $row1['code_class']));
                $row2 = $stmt_user->fetch(PDO::FETCH_ASSOC);
            }
            
            if ($row2) {
                $nom_cls = $this->ShowCls_namebyID($row2['ref_class']);
                $i++;
                echo '<a href="poste_de_saisie_std.php?trim=' . $trim . '&ref_class=' . $row2['ref_class'] . '" class="list-group-item list-group-item-action py-2 fw-bold text-secondary"><i class="fa fa-user me-2 text-info small"></i>' . $i . ' -- ' . $nom_cls . '</a>';
            }
        }
    }

    public function SelectMatCls_Note_by_User($id)
    {
        $bdd = $GLOBALS['bdd'];
        $rep1 = $bdd->query('SELECT code_class FROM classes ORDER BY class_session ASC, ref_class_niveau ASC, nom_class ASC');
        $i = 0;
        
        $stmt = $bdd->prepare('SELECT ref_class FROM config_bull WHERE ref_ens = ? AND ref_class = ? ORDER BY group_mat ASC, nom_mat ASC LIMIT 1');
        
        while($row1 = $rep1->fetch(PDO::FETCH_ASSOC)) 
        {
            $stmt->execute(array($id, $row1['code_class']));
            if($row2 = $stmt->fetch(PDO::FETCH_ASSOC)) 
            {
                $nom_cls = $this->ShowCls_namebyID($row2['ref_class']);
                $i++;
                echo '<option value="' . $row2['ref_class'] . '" id="' . $row2['ref_class'] . '">' . $i . ' -- ' . $nom_cls . '</option>';
            }
        }
    }

    public function SelectMatCls_Note_by_User_by_trim($id, $trim, $cls)
    {
        $bdd = $GLOBALS['bdd'];
        $role_user = isset($_SESSION['user_role']) ? $_SESSION['user_role'] : '';
        
        $rep1 = $bdd->query('SELECT code_class FROM classes ORDER BY class_session ASC, ref_class_niveau ASC, nom_class ASC');
        
        $stmt_admin = $bdd->prepare('SELECT ref_class, ref_mat FROM config_bull WHERE ref_class = ? ORDER BY group_mat ASC, nom_mat ASC');
        $stmt_user = $bdd->prepare('SELECT ref_class, ref_mat FROM config_bull WHERE ref_ens = ? AND ref_class = ? ORDER BY group_mat ASC, nom_mat ASC');
        
        while($row1 = $rep1->fetch(PDO::FETCH_ASSOC)) 
        {
            if ($role_user == "admin") {
                $stmt_admin->execute(array($row1['code_class']));
                $stmt_actual = $stmt_admin;
            } else {
                $stmt_user->execute(array($id, $row1['code_class']));
                $stmt_actual = $stmt_user;
            }
            
            while($row2 = $stmt_actual->fetch(PDO::FETCH_ASSOC)) 
            {
                if ($row2['ref_class'] == $cls) {
                    $nom_mat = $this->ShowMat_namebyID($row2['ref_mat']);
                    echo '<a href="gestion_notes_by_mat.php?trim=' . $trim . '&ref_class=' . $cls . '&ref_mat=' . $row2['ref_mat'] . '" class="list-group-item list-group-item-action py-2 fw-bold text-secondary"><i class="fa fa-book me-2 text-warning small"></i>' . $nom_mat . '</a>';
                }
            }
        }
    }

    public function SelectMatCls_Note_by_User_by_trim_AjoutPoint($id, $trim, $cls)
    {
        $bdd = $GLOBALS['bdd'];
        $role_user = isset($_SESSION['user_role']) ? $_SESSION['user_role'] : '';
        
        $rep1 = $bdd->query('SELECT code_class FROM classes ORDER BY class_session ASC, ref_class_niveau ASC, nom_class ASC');
        
        $stmt_admin = $bdd->prepare('SELECT ref_class, ref_mat FROM config_bull WHERE ref_class = ? ORDER BY group_mat ASC, nom_mat ASC');
        $stmt_user = $bdd->prepare('SELECT ref_class, ref_mat FROM config_bull WHERE ref_ens = ? AND ref_class = ? ORDER BY group_mat ASC, nom_mat ASC');
        
        while($row1 = $rep1->fetch(PDO::FETCH_ASSOC)) 
        {
            if ($role_user == "admin") {
                $stmt_admin->execute(array($row1['code_class']));
                $stmt_actual = $stmt_admin;
            } else {
                $stmt_user->execute(array($id, $row1['code_class']));
                $stmt_actual = $stmt_user;
            }
            
            while($row2 = $stmt_actual->fetch(PDO::FETCH_ASSOC)) 
            {
                if ($row2['ref_class'] == $cls) {
                    $nom_mat = $this->ShowMat_namebyID($row2['ref_mat']);
                    echo '<a href="interface_ajout_points.php?trim=' . $trim . '&ref_class=' . $cls . '&ref_mat=' . $row2['ref_mat'] . '" class="list-group-item list-group-item-action py-2 fw-bold text-secondary"><i class="fa fa-plus me-2 text-success small"></i>' . $nom_mat . '</a>';
                }
            }
        }
    }

        public function SelectMatCls_Note_by_User_by_trim_std($id, $trim, $cls)
    {
        $bdd = $GLOBALS['bdd'];
        $role_user = isset($_SESSION['user_role']) ? $_SESSION['user_role'] : '';
        
        $rep1 = $bdd->query('SELECT code_class FROM classes ORDER BY class_session ASC, ref_class_niveau ASC, nom_class ASC');
        
        $stmt_admin = $bdd->prepare('SELECT ref_class, ref_mat FROM config_bull WHERE ref_class = ? ORDER BY group_mat ASC, nom_mat ASC');
        $stmt_user = $bdd->prepare('SELECT ref_class, ref_mat FROM config_bull WHERE ref_ens = ? AND ref_class = ? ORDER BY group_mat ASC, nom_mat ASC');
        
        while($row1 = $rep1->fetch(PDO::FETCH_ASSOC)) 
        {
            if ($role_user == "admin") {
                $stmt_admin->execute(array($row1['code_class']));
                $stmt_actual = $stmt_admin;
            } else {
                $stmt_user->execute(array($id, $row1['code_class']));
                $stmt_actual = $stmt_user;
            }
            
            while($row2 = $stmt_actual->fetch(PDO::FETCH_ASSOC)) 
            {
                if ($row2['ref_class'] == $cls) {
                    $nom_mat = $this->ShowMat_namebyID($row2['ref_mat']);
                    echo '<a href="poste_de_saisie_std.php?trim=' . $trim . '&ref_class=' . $cls . '&ref_mat=' . $row2['ref_mat'] . '" class="list-group-item list-group-item-action py-2 fw-bold text-secondary"><i class="fa fa-user me-2 text-info small"></i>' . $nom_mat . '</a>';
                }
            }
        }
    }

    public function SelectStd_byMatCls_Note_by_User_by_trim($id, $trim, $cls, $mat)
    {
        $bdd = $GLOBALS['bdd'];
        $stmt = $bdd->prepare('SELECT mat_std, nom_std FROM eleves WHERE ref_class = ? ORDER BY nom_std ASC');
        $stmt->execute(array($cls));
        $i = 0;
        while($row1 = $stmt->fetch(PDO::FETCH_ASSOC)) 
        {
            $i++;
            echo '<a href="gestion_notes_by_mat_std.php?trim=' . $trim . '&ref_class=' . $cls . '&ref_mat=' . $mat . '&ref_std=' . $row1['mat_std'] . '" class="list-group-item list-group-item-action py-1 small text-secondary fw-bold" style="line-height:1.2em;"><i class="fa fa-chevron-right me-2 text-muted small"></i>' . $i . ' - ' . $row1['nom_std'] . '</a>';
        }
    }

    public function SelectStd_byCls_by_trim($trim, $cls)
    {
        $bdd = $GLOBALS['bdd'];
        $stmt = $bdd->prepare('SELECT mat_std, nom_std FROM eleves WHERE ref_class = ? ORDER BY nom_std ASC');
        $stmt->execute(array($cls));
        $i = 0;

        while($row1 = $stmt->fetch(PDO::FETCH_ASSOC)) 
        {
            $i++;
            if ($trim != "an") {
                echo '<a href="fpdf185/bul_cls_ind.php?trim=' . $trim . '&refcls=' . $cls . '&ref_std=' . $row1['mat_std'] . '" class="list-group-item list-group-item-action py-1 small text-secondary fw-bold" style="line-height:1.2em;"><i class="fa fa-file-pdf-o me-2 text-danger small"></i>' . $i . ' - ' . $row1['nom_std'] . '</a>';
            } else {
                echo '<a href="fpdf185/bul_an_ind.php?cls=' . $cls . '&std=' . $row1['mat_std'] . '" class="list-group-item list-group-item-action py-1 small text-secondary fw-bold" style="line-height:1.2em;"><i class="fa fa-file-pdf-o me-2 text-danger small"></i>' . $i . ' - ' . $row1['nom_std'] . '</a>';
            }
        }
    }

    public function SelectNiveauCls()
    {
        $bdd = $GLOBALS['bdd'];
        $reponse = $bdd->query('SELECT ref_niveau, nom_niveau FROM niveaux WHERE id >= 0 ORDER BY ref_niveau ASC');
        $i = 0;
        while($row = $reponse->fetch(PDO::FETCH_ASSOC)) 
        {
            $i++;
            echo '<option value="' . $row['ref_niveau'] . '">' . $i . ' -- ' . $row['nom_niveau'] . '</option>';
        }
    }

    public function SelectSessCls()
    {
        $bdd = $GLOBALS['bdd'];
        $reponse = $bdd->query('SELECT abr_sess, nom_sess FROM sess WHERE id >= 0 ORDER BY id ASC');
        $i = 0;
        while($row = $reponse->fetch(PDO::FETCH_ASSOC)) 
        {
            $i++;
            echo '<option value="' . $row['abr_sess'] . '">' . $i . ' -- ' . $row['nom_sess'] . '</option>';
        }
    }

    public function SelectCls_by_Sess($sess)
    {
        $bdd = $GLOBALS['bdd'];
        $stmt = $bdd->prepare('SELECT code_class, nom_class FROM classes WHERE class_session = ? ORDER BY ref_class_niveau ASC');
        $stmt->execute(array($sess));
        $i = 0;
        while($row = $stmt->fetch(PDO::FETCH_ASSOC)) 
        {
            $i++;
            echo '<option value="' . $row['code_class'] . '">' . $i . ' -- ' . $row['nom_class'] . '</option>';
        }
    }

    public function SelectModelCls()
    {
        $bdd = $GLOBALS['bdd'];
        $reponse = $bdd->query('SELECT code_class, nom_class, ref_class_niveau, class_session FROM classes ORDER BY ref_class_niveau ASC, class_session ASC, nom_class ASC');
        $i = 0;
        while($row = $reponse->fetch(PDO::FETCH_ASSOC)) 
        {
            $i++;
            echo '<option value="' . $row['code_class'] . '">' . $i . ' -- ' . $row['nom_class'] . ' (N' . $row['ref_class_niveau'] . ' - ' . $row['class_session'] . ')</option>';
        }
    }

    public function SelectMat_Note_by_User($id)
    {
        $bdd = $GLOBALS['bdd'];
        $stmt = $bdd->prepare('SELECT ref_mat, ref_class FROM config_bull WHERE ref_ens = ? ORDER BY ref_niveau_class ASC');
        $stmt->execute(array($id));
        $i = 0;
        while($row = $stmt->fetch(PDO::FETCH_ASSOC)) 
        {
            $nom_mat = $this->ShowMat_namebyID($row['ref_mat']);
            $nom_cls = $this->ShowCls_namebyID($row['ref_class']);
            $i++;
            echo '<option value="' . $row['ref_mat'] . '">' . $i . ' (' . $nom_cls . ') &mdash; ' . $nom_mat . '</option>';
        }
    }


 	

	
		
		    public function ShowCls_Note_by_admin()
    {
        $bdd = $GLOBALS['bdd'];
        $reponse = $bdd->query('SELECT distinct ref_class, ref_niveau_class, ref_mat FROM config_bull WHERE id >= 0 ORDER BY ref_niveau_class ASC');
        $i = 0;
        while($row = $reponse->fetch(PDO::FETCH_ASSOC)) 
        {
            $i++;
            $nom_cls = $this->ShowCls_namebyID($row['ref_class']);
            $nom_mat = $this->ShowMat_namebyID($row['ref_mat']);
            echo '
            <div class="col-12 col-sm-6 col-md-4 mb-2">
                <a class="btn w-100 text-start fw-bold shadow-sm py-2" data-bs-toggle="collapse" href="#note_' . $row['ref_mat'] . $row['ref_class'] . '" role="button" style="background-color: var(--bg-card); color: var(--text-main); border: 1px solid var(--border-color); font-size: 0.88em;">
                    <i class="fa fa-book text-primary me-2"></i>( ' . $i . ' ) - ' . $nom_mat . ' <span class="badge bg-secondary-subtle text-secondary float-end">' . $nom_cls . '</span>
                </a>
            </div>';
        }
    }

    public function ShowCls_Note_by_admin2($cls)
    {
        $bdd = $GLOBALS['bdd'];
        $stmt = $bdd->prepare('SELECT ref_class, ref_mat FROM config_bull WHERE ref_class = ? ORDER BY ref_niveau_class ASC');
        $stmt->execute(array($cls));
        $i = 0;
        while($row = $stmt->fetch(PDO::FETCH_ASSOC)) 
        {
            $i++;
            $nom_mat = $this->ShowMat_namebyID($row['ref_mat']);
            echo '
            <div class="col-6 col-sm-4 col-md-3 my-1">
                <a class="btn btn-sm w-100 fw-bold shadow-sm text-truncate" data-bs-toggle="collapse" data-bs-target="#note_' . $row['ref_mat'] . $row['ref_class'] . '" href="#note_' . $row['ref_mat'] . $row['ref_class'] . '" role="button" style="background-color: var(--bg-card); color: var(--text-main); border: 1px solid var(--border-color); font-size:0.8em;">
                    <i class="fa fa-folder-open text-info me-1"></i>( ' . $i . ' ) - ' . $nom_mat . '
                </a>
            </div>';
        }
    }

    public function ShowMat_Note_and_Eval($id)
    {
        $bdd = $GLOBALS['bdd'];
        $stmt = $bdd->prepare('SELECT ref_class, ref_mat FROM config_bull WHERE ref_ens = ? ORDER BY ref_niveau_class ASC');
        $stmt->execute(array($id));
        while($row = $stmt->fetch(PDO::FETCH_ASSOC)) 
        {
            $nom_cls = $this->ShowCls_namebyID($row['ref_class']);
            $nom_mat = $this->ShowMat_namebyID($row['ref_mat']);
            echo '
            <div class="dropdown d-inline-block m-1">
              <button class="btn btn-sm dropdown-toggle fw-bold" type="button" data-bs-toggle="dropdown" aria-expanded="false" style="background-color: var(--bg-card); color: var(--text-main); border: 1px solid var(--border-color);">
                <i class="fa fa-tasks text-secondary me-1"></i>Évaluation : ' . $nom_cls . ' &bull; ' . $nom_mat . '
              </button>
              <ul class="dropdown-menu shadow">
                <li><a class="dropdown-item fw-bold text-secondary" href="gestion_notes_by_mat.php?cls=' . $row['ref_class'] . '&mat=' . $row['ref_mat'] . '&seq=1">Séquence 1 (EVAL 1)</a></li>
                <li><a class="dropdown-item fw-bold text-secondary" href="gestion_notes_by_mat.php?cls=' . $row['ref_class'] . '&mat=' . $row['ref_mat'] . '&seq=2">Séquence 2 (EVAL 2)</a></li>
                <li><a class="dropdown-item fw-bold text-secondary" href="gestion_notes_by_mat.php?cls=' . $row['ref_class'] . '&mat=' . $row['ref_mat'] . '&seq=3">Séquence 3 (EVAL 3)</a></li>
                <li><a class="dropdown-item fw-bold text-secondary" href="gestion_notes_by_mat.php?cls=' . $row['ref_class'] . '&mat=' . $row['ref_mat'] . '&seq=4">Séquence 4 (EVAL 4)</a></li>
                <li><a class="dropdown-item fw-bold text-secondary" href="gestion_notes_by_mat.php?cls=' . $row['ref_class'] . '&mat=' . $row['ref_mat'] . '&seq=5">Séquence 5 (EVAL 5)</a></li>
                <li><a class="dropdown-item fw-bold text-secondary" href="gestion_notes_by_mat.php?cls=' . $row['ref_class'] . '&mat=' . $row['ref_mat'] . '&seq=6">Séquence 6 (EVAL 6)</a></li>
              </ul>
            </div>';
        }
    }

    public function ExportSheetNotes_admin()
    {
        $bdd = $GLOBALS['bdd'];
        $reponse = $bdd->query('SELECT code_class, nom_class FROM classes ORDER BY ref_class_niveau ASC, nom_class ASC');
        while($row = $reponse->fetch(PDO::FETCH_ASSOC)) 
        {
            echo '<li><a class="dropdown-item fw-bold text-secondary py-2" href="Controler/notes/exportnotes.php?cls=' . $row['code_class'] . '"><i class="fa fa-file-excel-o text-success me-2"></i>' . $row['nom_class'] . '</a></li>';
        }
    }

    public function ExportSheetNotes_Ens($ens)
    {
        $bdd = $GLOBALS['bdd'];
        $stmt = $bdd->prepare('SELECT distinct ref_class FROM config_bull WHERE ref_ens = ?');
        $stmt->execute(array($ens));
        while($row = $stmt->fetch(PDO::FETCH_ASSOC)) 
        {
            $nom_cls = $this->ShowCls_namebyID($row['ref_class']);
            echo '<li><a class="dropdown-item fw-bold text-secondary py-2" href="Controler/notes/exportnotes.php?cls=' . $row['ref_class'] . '"><i class="fa fa-file-excel-o text-success me-2"></i>' . $nom_cls . '</a></li>';
        }
    }

    public function SelectDropActiveEval($cls, $mat)
    {
        $bdd = $GLOBALS['bdd'];
        $i = 0;
        $nt = 0;
        $reponse = $bdd->query('SELECT id, statut, nom_seq FROM evaluations WHERE id >= 0 ORDER BY nom_seq ASC');
        while($row = $reponse->fetch(PDO::FETCH_ASSOC)) 
        {
            if ($row['statut'] == "O" && $row['id'] == '1') $i = 1;
            elseif ($row['statut'] == "O" && $row['id'] == '3') $i = 3;
            elseif ($row['statut'] == "O" && $row['id'] == '5') $i = 0;
            
            if ($row['statut'] == "O")
            {
                $i++;
                $ev = $row['id'];
                $nt += (int)$row['id'];
                echo '<li><a class="dropdown-item fw-bold text-secondary py-1" href="gestion_notes_by_mat.php?cls=' . $cls . '&mat=' . $mat . '&seq=' . $ev . '"><i class="fa fa-check text-success me-2 small"></i>' . $row['nom_seq'] . '</a></li>';    
            }
            
            if ($nt == 3 && $i == 1) {
                echo '<li><a class="dropdown-item fw-bold text-dark py-1" href="gestion_notes_by_mat.php?cls=' . $cls . '&mat=' . $mat . '&seq=12" style="background-color:rgba(38,189,237,0.15);"><i class="fa fa-compress me-2 small text-primary"></i>ÉVAL 1 & 2 (Trim 1)</a></li>';
                $nt = 0;    
            }
            if ($nt == 7 && $i == 1) {
                echo '<li><a class="dropdown-item fw-bold text-dark py-1" href="gestion_notes_by_mat.php?cls=' . $cls . '&mat=' . $mat . '&seq=34" style="background-color:rgba(38,189,237,0.15);"><i class="fa fa-compress me-2 small text-primary"></i>ÉVAL 3 & 4 (Trim 2)</a></li>';
                $nt = 0;    
            }
            if ($nt == 11 && $i == 1) {
                echo '<li><a class="dropdown-item fw-bold text-dark py-1" href="gestion_notes_by_mat.php?cls=' . $cls . '&mat=' . $mat . '&seq=56" style="background-color:rgba(38,189,237,0.15);"><i class="fa fa-compress me-2 small text-primary"></i>ÉVAL 5 & 6 (Trim 3)</a></li>';
                $nt = 0;    
            }
        }
    }

		

		    public function SelectDropActiveEval_Ens($cls, $mat)
    {
        $bdd = $GLOBALS['bdd'];
        $i = 0;
        $nt = 0;
        $reponse = $bdd->query('SELECT id, statut, nom_seq FROM evaluations WHERE id >= 0 ORDER BY nom_seq ASC');
        while($row = $reponse->fetch(PDO::FETCH_ASSOC)) 
        {
            if ($row['statut'] == "O" && $row['id'] == '1') $i = 1;
            elseif ($row['statut'] == "O" && $row['id'] == '3') $i = 3;
            elseif ($row['statut'] == "O" && $row['id'] == '5') $i = 5;
            
            if ($row['statut'] == "O")
            {
                $i++;
                $ev = $row['id'];
                $nt += (int)$row['id'];
                echo '<li><a class="dropdown-item fw-bold text-secondary py-1" href="espace_notes.php?cls=' . $cls . '&mat=' . $mat . '&seq=' . $ev . '"><i class="fa fa-check text-success me-2 small"></i>' . $row['nom_seq'] . '</a></li>';    
            }
            
            if ($nt == 3 && $i == 1) {
                echo '<li><a class="dropdown-item fw-bold text-dark py-1" href="espace_notes.php?cls=' . $cls . '&mat=' . $mat . '&seq=12" style="background-color:rgba(38,189,237,0.15);"><i class="fa fa-compress me-2 small text-primary"></i>ÉVAL 1 & 2 (Trim 1)</a></li>';
                $nt = 0;    
            }
            if ($nt == 7 && $i == 1) {
                echo '<li><a class="dropdown-item fw-bold text-dark py-1" href="espace_notes.php?cls=' . $cls . '&mat=' . $mat . '&seq=34" style="background-color:rgba(38,189,237,0.15);"><i class="fa fa-compress me-2 small text-primary"></i>ÉVAL 3 & 4 (Trim 2)</a></li>';
                $nt = 0;    
            }
            if ($nt == 11 && $i == 1) {
                echo '<li><a class="dropdown-item fw-bold text-dark py-1" href="espace_notes.php?cls=' . $cls . '&mat=' . $mat . '&seq=56" style="background-color:rgba(38,189,237,0.15);"><i class="fa fa-compress me-2 small text-primary"></i>ÉVAL 5 & 6 (Trim 3)</a></li>';
                $nt = 0;    
            }
        }
    }


    public function ShowMat_Note_and_Eval_admin($cls)
    {
        $bdd = $GLOBALS['bdd'];
        $stmt = $bdd->prepare('SELECT ref_class, ref_mat FROM config_bull WHERE ref_class = ? ORDER BY group_mat ASC');
        $stmt->execute(array($cls));
        while($row = $stmt->fetch(PDO::FETCH_ASSOC)) 
        {
            $nom_mat = $this->ShowMat_namebyID($row['ref_mat']);
            echo '
            <div class="dropdown d-inline-block m-1" id="note_' . $row['ref_mat'] . $row['ref_class'] . '">
              <button class="btn btn-sm btn-secondary dropdown-toggle fw-bold" type="button" data-bs-toggle="dropdown" aria-expanded="false" style="background-color: var(--bg-card); color: var(--text-main); border: 1px solid var(--border-color); font-size: 0.88em;">
                <i class="fa fa-book me-1 text-primary"></i>' . $nom_mat . '
              </button>
              <ul class="dropdown-menu shadow" style="font-size:0.9em;">';
                $this->SelectDropActiveEval($row['ref_class'], $row['ref_mat']);
              echo '</ul>
            </div>';
        }
    }

    public function ShowMat_Note_and_Eval_Ens($cls, $ens)
    {
        $bdd = $GLOBALS['bdd'];
        $stmt = $bdd->prepare('SELECT ref_class, ref_mat FROM config_bull WHERE ref_class = ? AND ref_ens = ? ORDER BY group_mat ASC');
        $stmt->execute(array($cls, $ens));
        while($row = $stmt->fetch(PDO::FETCH_ASSOC)) 
        {
            $nom_mat = $this->ShowMat_namebyID($row['ref_mat']);
            echo '
            <div class="dropdown d-inline-block m-1" id="note_' . $row['ref_mat'] . $row['ref_class'] . '">
              <button class="btn btn-sm btn-secondary dropdown-toggle fw-bold" type="button" data-bs-toggle="dropdown" aria-expanded="false" style="background-color: var(--bg-card); color: var(--text-main); border: 1px solid var(--border-color); font-size: 0.88em;">
                <i class="fa fa-graduation-cap me-1 text-info"></i>' . $nom_mat . '
              </button>
              <ul class="dropdown-menu shadow" style="font-size:0.9em;">';
                $this->SelectDropActiveEval_Ens($row['ref_class'], $row['ref_mat']);
              echo '</ul>
            </div>';
        }
    }



    public function ShowMat_Note_and_Eval_user($cls, $ens)
    {
        $bdd = $GLOBALS['bdd'];
        $stmt = $bdd->prepare('SELECT ref_class, ref_mat FROM config_bull WHERE ref_class = ? AND ref_ens = ? ORDER BY group_mat ASC');
        $stmt->execute(array($cls, $ens));
        while($row = $stmt->fetch(PDO::FETCH_ASSOC)) 
        {
            $nom_mat = $this->ShowMat_namebyID($row['ref_mat']);
            echo '
            <div class="dropdown d-inline-block m-1" id="note_' . $row['ref_mat'] . $row['ref_class'] . '">
              <button class="btn btn-sm btn-secondary dropdown-toggle fw-bold" type="button" data-bs-toggle="dropdown" aria-expanded="false" style="background-color: var(--bg-card); color: var(--text-main); border: 1px solid var(--border-color); font-size: 0.88em;">
                <i class="fa fa-book me-1 text-primary"></i>' . $nom_mat . '
              </button>
              <ul class="dropdown-menu shadow" style="font-size:0.9em;">';
                $this->SelectDropActiveEval($row['ref_class'], $row['ref_mat']);
              echo '</ul>
            </div>';
        }
    }



    public function ShowStd_for_Note_by_Mat($cls, $mat, $seq)
    {
        $bdd = $GLOBALS['bdd'];
        $stmt = $bdd->prepare('SELECT mat_std, nom_prenom_std FROM eleves WHERE ref_class = ? ORDER BY nom_prenom_std ASC');
        $stmt->execute(array($cls));
        $i = 0;
        $pre_matr = isset($_SESSION['pre_matr']) ? $_SESSION['pre_matr'] : '';
        
        while($row = $stmt->fetch(PDO::FETCH_ASSOC)) 
        {
            $note = $this->ShowNoteStd_by_MatCls($cls, $mat, $seq, $row['mat_std']);
            $i++;
            echo '
            <tr>
                <td>' . $i . '</td>
                <td class="font-monospace text-primary fw-bold">' . $pre_matr . $row['mat_std'] . '</td>
                <td class="text-start fw-bold" style="padding-left:15px;">' . $row['nom_prenom_std'] . '</td>
                <td>
                    <input type="hidden" name="ref_cls" value="' . $cls . '">
                    <input type="hidden" name="ref_mat" value="' . $mat . '">
                    <input type="hidden" name="ref_seq" value="' . $seq . '">
                    <input type="number" class="form-control form-control-sm mx-auto text-center font-weight-bold" name="' . $row['mat_std'] . '" placeholder="' . (!empty($note) || $note === 0 || $note === '0' ? $note : '--') . '" min="-1" max="20" step="0.25" style="max-width: 90px; height:28px; color: var(--text-main);">
                </td>
            </tr>';
        }
    }

    public function ShowStd_for_Notes_by_Mat($cls, $mat, $seq)
    {
        $bdd = $GLOBALS['bdd'];
        $stmt = $bdd->prepare('SELECT mat_std, nom_prenom_std FROM eleves WHERE ref_class = ? ORDER BY nom_prenom_std ASC');
        $stmt->execute(array($cls));
        $i = 0;
        $pre_matr = isset($_SESSION['pre_matr']) ? $_SESSION['pre_matr'] : '';
        
        $e1 = "1"; $e2 = "2";
        if ($seq == '34') { $e1 = "3"; $e2 = "4"; }
        if ($seq == '56') { $e1 = "5"; $e2 = "6"; }
        
        while($row = $stmt->fetch(PDO::FETCH_ASSOC)) 
        {
            $note1 = $this->ShowNoteStd_by_MatCls($cls, $mat, $e1, $row['mat_std']);
            $note2 = $this->ShowNoteStd_by_MatCls($cls, $mat, $e2, $row['mat_std']);
            $i++;
            echo '
            <tr>
                <td>' . $i . '</td>
                <td class="font-monospace text-primary fw-bold">' . $pre_matr . $row['mat_std'] . '</td>
                <td class="text-start fw-bold" style="padding-left:15px;">' . $row['nom_prenom_std'] . '</td>
                <td>
                    <input type="hidden" name="ref_cls" value="' . $cls . '">
                    <input type="hidden" name="ref_mat" value="' . $mat . '">
                    <input type="hidden" name="ref_seq' . $e1 . '" value="' . $e1 . '">
                    <input type="number" class="form-control form-control-sm mx-auto text-center font-weight-bold" name="e' . $e1 . $row['mat_std'] . '" placeholder="' . (!empty($note1) || $note1 === 0 || $note1 === '0' ? $note1 : '--') . '" min="-1" max="20" step="0.25" style="max-width: 85px; height:28px; color: var(--text-main);">
                </td>
                <td>
                    <input type="hidden" name="ref_seq' . $e2 . '" value="' . $e2 . '">
                    <input type="number" class="form-control form-control-sm mx-auto text-center font-weight-bold" name="e' . $e2 . $row['mat_std'] . '" placeholder="' . (!empty($note2) || $note2 === 0 || $note2 === '0' ? $note2 : '--') . '" min="-1" max="20" step="0.25" style="max-width: 85px; height:28px; color: var(--text-main);">
                </td>
            </tr>';
        }
    }


		    public function SelectCoef_by_MatCls($cls, $mat)
    {
        $bdd = $GLOBALS['bdd'];
        $stmt = $bdd->prepare('SELECT coeff_mat FROM config_bull WHERE ref_class = ? AND ref_mat = ? LIMIT 1');
        $stmt->execute(array($cls, $mat));
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        return $row ? (float)$row['coeff_mat'] : 1.0;
    }

    public function ShowStd_for_Notes_by_Mat_by_Trim($cls, $mat, $trim)
    {
        $bdd = $GLOBALS['bdd'];
        $stmt = $bdd->prepare('SELECT mat_std, cni_std, nom_std, sexe_std FROM eleves WHERE ref_class = ? ORDER BY nom_std ASC');
        $stmt->execute(array($cls));
        $i = 0;
        $pre_matr = isset($_SESSION['pre_matr']) ? $_SESSION['pre_matr'] : '';
        
        $e1 = "1"; $e2 = "2";
        if ($trim == 't2') { $e1 = "3"; $e2 = "4"; }
        elseif ($trim == 't3') { $e1 = "5"; $e2 = "6"; }
        
        $coef = $this->SelectCoef_by_MatCls($cls, $mat);
        
        while($row = $stmt->fetch(PDO::FETCH_ASSOC)) 
        {
            $note1 = $this->ShowNoteStd_by_MatCls($cls, $mat, $e1, $row['mat_std']);
            $note2 = $this->ShowNoteStd_by_MatCls($cls, $mat, $e2, $row['mat_std']);
            $i++;
            
            // Les valeurs nulles ou vides sont converties proprement pour l'affichage dans l'attribut 'value'
            $v_note1 = ($note1 === null || $note1 === '') ? '' : $note1;
            $v_note2 = ($note2 === null || $note2 === '') ? '' : $note2;

            echo '
            <tr data-id-eleve="' . $row['mat_std'] . '">
                <td>' . $i . '</td>
                <td class="col-mat font-monospace fw-bold text-primary">' . $pre_matr . $row['mat_std'] . '</td>
                <td class="col-mat font-monospace mobile-hide">' . $row['cni_std'] . '</td>
                <td class="col-eleve text-start fw-bold" style="padding-left:15px;">' . $row['nom_std'] . '</td>
                <td class="mobile-hide">' . $row['sexe_std'] . '</td>
                <td class="col-eval">
                    <input type="number" class="form-control form-control-sm text-center mx-auto note-input note1 font-weight-bold" 
                           data-id-eleve="' . $row['mat_std'] . '" 
                           data-ref-eval="' . $e1 . '" 
                           data-ref-clas="' . $cls . '" 
                           data-ref-mat="' . $mat . '" 
                           value="' . $v_note1 . '" step="0.01" min="-1" max="20" required style="max-width:90px; color: var(--text-main);">
                    <input type="hidden" class="coef-input" value="' . $coef . '">
                </td>
                <td class="col-eval">
                    <input type="number" class="form-control form-control-sm text-center mx-auto note-input note2 font-weight-bold"  
                           data-id-eleve="' . $row['mat_std'] . '" 
                           data-ref-eval="' . $e2 . '" 
                           data-ref-clas="' . $cls . '" 
                           data-ref-mat="' . $mat . '" 
                           value="' . $v_note2 . '" step="0.01" min="-1" max="20" required style="max-width:90px; color: var(--text-main);">
                    <input type="hidden" class="coef-input" value="' . $coef . '">
                </td>
            </tr>';
        }
    }

    public function ShowStd_for_Notes_by_Mat_by_Trim_std($cls, $mat, $trim, $std)
    {
        $bdd = $GLOBALS['bdd'];
        $stmt = $bdd->prepare('SELECT mat_std, cni_std, nom_std, sexe_std FROM eleves WHERE ref_class = ? AND mat_std = ? LIMIT 1');
        $stmt->execute(array($cls, $std));
        $i = 0;
        $pre_matr = isset($_SESSION['pre_matr']) ? $_SESSION['pre_matr'] : '';
        
        $e1 = "1"; $e2 = "2";
        if ($trim == 't2') { $e1 = "3"; $e2 = "4"; }
        elseif ($trim == 't3') { $e1 = "5"; $e2 = "6"; }
        
        $coef = $this->SelectCoef_by_MatCls($cls, $mat);
        
        if($row = $stmt->fetch(PDO::FETCH_ASSOC)) 
        {
            $note1 = $this->ShowNoteStd_by_MatCls($cls, $mat, $e1, $row['mat_std']);
            $note2 = $this->ShowNoteStd_by_MatCls($cls, $mat, $e2, $row['mat_std']);
            $i++;
            
            $v_note1 = ($note1 === null || $note1 === '') ? '' : $note1;
            $v_note2 = ($note2 === null || $note2 === '') ? '' : $note2;

            echo '
            <tr data-id-eleve="' . $row['mat_std'] . '">
                <td>' . $i . '</td>
                <td class="col-mat font-monospace fw-bold text-primary">' . $pre_matr . $row['mat_std'] . '</td>
                <td class="col-mat font-monospace mobile-hide">' . $row['cni_std'] . '</td>
                <td class="col-eleve text-start fw-bold" style="padding-left:15px;">' . $row['nom_std'] . '</td>
                <td class="mobile-hide">' . $row['sexe_std'] . '</td>
                <td class="col-eval">
                    <input type="number" class="form-control form-control-sm text-center mx-auto note-input note1 font-weight-bold" 
                           data-id-eleve="' . $row['mat_std'] . '" 
                           data-ref-eval="' . $e1 . '" 
                           data-ref-clas="' . $cls . '" 
                           data-ref-mat="' . $mat . '" 
                           value="' . $v_note1 . '" step="0.01" min="-1" max="20" required style="max-width:90px; color: var(--text-main);">
                    <input type="hidden" class="coef-input" value="' . $coef . '">
                </td>
                <td class="col-eval">
                    <input type="number" class="form-control form-control-sm text-center mx-auto note-input note2 font-weight-bold"  
                           data-id-eleve="' . $row['mat_std'] . '" 
                           data-ref-eval="' . $e2 . '" 
                           data-ref-clas="' . $cls . '" 
                           data-ref-mat="' . $mat . '" 
                           value="' . $v_note2 . '" step="0.01" min="-1" max="20" required style="max-width:90px; color: var(--text-main);">
                    <input type="hidden" class="coef-input" value="' . $coef . '">
                </td>
            </tr>';
        }
    }


		    public function ShowInfosStd_for_Note_by_Mat($cls, $mat, $seq)
    {
        $nom_cls = $this->ShowCls_namebyID($cls);
        $nom_mat = $this->ShowMat_namebyID($mat);

        echo '</tbody>
                </table>
                     </div>
                    </div>
             <div class="col-12 col-md-4 mt-4 py-3 px-3 rounded shadow-sm border" style="background-color: var(--bg-card); height: fit-content;">
                <h5 class="fw-bold mb-3" style="color: var(--primary-color);"><i class="fa fa-info-circle me-2"></i>Informations de saisie</h5>
                <ul class="list-group list-group-flush mb-3 small">
                    <li class="list-group-item bg-transparent px-0 d-flex justify-content-between"><span>Classe :</span> <span class="fw-bold text-primary">' . $nom_cls . '</span></li>
                    <li class="list-group-item bg-transparent px-0 d-flex justify-content-between"><span>Matière :</span> <span class="fw-bold text-success">' . $nom_mat . '</span></li>
                    <li class="list-group-item bg-transparent px-0 d-flex justify-content-between"><span>Évaluation :</span> <span class="badge bg-info px-2">EVAL ' . $seq . '</span></li>
                </ul>
                <button type="submit" class="btn text-white fw-bold w-100 shadow-sm" style="background-color: #19784f;"><i class="fa fa-save me-2"></i>Enregistrer les notes</button>
            </form>
            </div>';
    }

    public function ShowInfosStd_for_Notes_by_Mat($cls, $mat, $seq)
    {
        $e1 = "1"; $e2 = "2";
        if ($seq == '34') { $e1 = "3"; $e2 = "4"; }
        elseif ($seq == '56') { $e1 = "5"; $e2 = "6"; }

        $nom_cls = $this->ShowCls_namebyID($cls);
        $nom_mat = $this->ShowMat_namebyID($mat);

        echo '</tbody>
                </table>
                     </div>
                    </div>
             <div class="col-12 col-md-4 mt-4 py-3 px-3 rounded shadow-sm border" style="background-color: var(--bg-card); height: fit-content;">
                <h5 class="fw-bold mb-3" style="color: var(--primary-color);"><i class="fa fa-info-circle me-2"></i>Informations de saisie</h5>
                <ul class="list-group list-group-flush mb-3 small">
                    <li class="list-group-item bg-transparent px-0 d-flex justify-content-between"><span>Classe :</span> <span class="fw-bold text-primary">' . $nom_cls . '</span></li>
                    <li class="list-group-item bg-transparent px-0 d-flex justify-content-between"><span>Matière :</span> <span class="fw-bold text-success">' . $nom_mat . '</span></li>
                    <li class="list-group-item bg-transparent px-0 d-flex justify-content-between"><span>Séquences :</span> <span class="fw-bold text-info">EVAL ' . $e1 . ' & ' . $e2 . '</span></li>
                </ul>
                <button type="submit" class="btn text-white fw-bold w-100 shadow-sm" style="background-color: #19784f;"><i class="fa fa-save me-2"></i>Enregistrer les notes</button>
            </form>
            </div>';
    }

    public function ShowInfosStd_for_Note_by_Mat_Import($cls, $mat, $seq)
    {
        $nom_cls = $this->ShowCls_namebyID($cls);
        $nom_mat = $this->ShowMat_namebyID($mat);

        echo '
             <div class="col-12 col-md-6 mt-3">
                <nav aria-label="breadcrumb">
                  <ol class="breadcrumb p-3 rounded shadow-sm border mb-3" style="background-color: var(--bg-card);">
                    <li class="breadcrumb-item text-primary fw-bold">Classe : ' . $nom_cls . '</li>
                    <li class="breadcrumb-item text-success fw-bold">Matière : ' . $nom_mat . '</li>
                    <li class="breadcrumb-item active fw-bold text-secondary">Éval : ' . htmlspecialchars((string)$seq) . '</li>
                  </ol>
                </nav>
                <button type="submit" class="btn text-white fw-bold px-4 shadow-sm" style="background-color: #0764a8;"><i class="fa fa-upload me-2"></i>Lancer l\'importation</button>         
            </div>
             </form>';
    }

    public function ShowAbs_std_by_Cls_by_Trim($cls, $std, $trim)
    {
        $bdd = $GLOBALS['bdd'];
        $stmt = $bdd->prepare('SELECT heure FROM absences WHERE ref_cls = ? AND ref_std = ? AND ref_trim = ? LIMIT 1');
        $stmt->execute(array($cls, $std, $trim));
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        return $row ? $row['heure'] : '';
    }

    public function ShowAbsStd_by_Cls($cls, $std, $trim)
    {
        return $this->ShowAbs_std_by_Cls_by_Trim($cls, $std, $trim);
    }

    public function ShowInfosAbs_by_Class($cls, $trim)
    {
        $nom_cls = $this->ShowCls_namebyID($cls);

        echo '</tbody>
                </table>
                     </div>
                    </div>
             <div class="col-12 col-md-3 mt-4 py-3 px-3 rounded shadow-sm border" style="background-color: var(--bg-card); height: fit-content;">
                <h5 class="fw-bold mb-2 text-uppercase" style="color: var(--primary-color); font-size: 0.9em;"><i class="fa fa-gavel me-2"></i>Poste de Saisie</h5>
                <p class="text-muted small mb-3">Registre des absences</p>
                <ul class="list-group list-group-flush mb-3 small">
                    <li class="list-group-item bg-transparent px-0 d-flex justify-content-between"><span>Classe Target :</span> <span class="fw-bold text-primary">' . $nom_cls . '</span></li>
                    <li class="list-group-item bg-transparent px-0 d-flex justify-content-between"><span>Trimestre :</span> <span class="badge bg-danger px-2">TRIM ' . $trim . '</span></li>
                </ul>
                <button type="submit" class="btn text-white fw-bold w-100 shadow-sm" style="background-color: #19784f;"><i class="fa fa-save me-2"></i>Enregistrer le registre</button>
            </form>
            </div>';
    }

    public function ShowAbsence_Cls($cls, $trim)
    {
        $bdd = $GLOBALS['bdd'];
        $stmt = $bdd->prepare('SELECT mat_std, cni_std, nom_std FROM eleves WHERE ref_class = ? ORDER BY nom_std ASC');
        $stmt->execute(array($cls));
        $i = 0;
        $pre_matr = isset($_SESSION['pre_matr']) ? $_SESSION['pre_matr'] : '';
        
        while($row = $stmt->fetch(PDO::FETCH_ASSOC)) 
        {
            $abs = $this->ShowAbsStd_by_Cls($cls, $row['mat_std'], $trim);
            $i++;

            echo '
            <tr>
                <td>' . $i . '</td>
                <td class="font-monospace text-primary fw-bold">' . $pre_matr . $row['mat_std'] . '</td>
                <td class="font-monospace mobile-hide">' . $row['cni_std'] . '</td>
                <td class="text-start fw-bold" style="padding-left:15px;">' . $row['nom_std'] . '</td>
                <td>
                    <input type="hidden" name="cls" value="' . $cls . '">
                    <input type="hidden" name="trim" value="' . $trim . '">
                    <input type="text" class="form-control form-control-sm text-center mx-auto" name="' . $row['mat_std'] . '" placeholder="' . (!empty($abs) || $abs === 0 || $abs === '0' ? $abs : '0') . '" pattern="[0-9]{1,3}" style="max-width: 80px; height: 26px; color: var(--text-main);">
                </td>
            </tr>';
        }
    }


		    public function ShowNoteStd_by_MatCls($cls, $mat, $seq, $std)
    {
        $bdd = $GLOBALS['bdd'];
        $table = 'table_note_par_mat_eval' . preg_replace('/[^0-9]/', '', $seq);
        try {
            $stmt = $bdd->prepare("SELECT note FROM $table WHERE ref_cls = ? AND ref_mat = ? AND ref_eval = ? AND ref_std = ? LIMIT 1");
            $stmt->execute(array($cls, $mat, $seq, $std));
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            return $row ? $row['note'] : null;
        } catch (Exception $e) { return null; }
    }

    public function ShowNoteStd_by_MatCls_OK($cls, $mat, $seq, $std)
    {
        $bdd = $GLOBALS['bdd'];
        $table = 'table_note_par_mat_eval' . preg_replace('/[^0-9]/', '', $seq);
        try {
            $stmt = $bdd->prepare("SELECT note FROM $table WHERE ref_cls = ? AND ref_mat = ? AND ref_eval = ? AND ref_std = ? LIMIT 1");
            $stmt->execute(array($cls, $mat, $seq, $std));
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if (!$row || $row['note'] === null || $row['note'] === '') {
                return null;
            }
            return (float)$row['note'] === 0.0 ? 0 : $row['note'];
        } catch (Exception $e) { return null; }
    }

    public function CheckNoteStd_by_MatCls($cls, $mat, $seq, $std)
    {
        $bdd = $GLOBALS['bdd'];
        $table = 'table_note_par_mat_eval' . preg_replace('/[^0-9]/', '', $seq);
        try {
            $stmt = $bdd->prepare("SELECT id FROM $table WHERE ref_cls = ? AND ref_mat = ? AND ref_eval = ? AND ref_std = ? LIMIT 1");
            $stmt->execute(array($cls, $mat, $seq, $std));
            return (bool)$stmt->fetch();
        } catch (Exception $e) { return false; }
    }

    public function CheckNote_Tranfert_Std_by_Cls($cls, $seq, $std)
    {
        $bdd = $GLOBALS['bdd'];
        $table = 'table_note_par_mat_eval' . preg_replace('/[^0-9]/', '', $seq);
        try {
            $stmt = $bdd->prepare("SELECT id FROM $table WHERE ref_cls = ? AND ref_std = ? AND ref_eval = ? LIMIT 1");
            $stmt->execute(array($cls, $std, $seq));
            return (bool)$stmt->fetch();
        } catch (Exception $e) { return false; }
    }

    public function DelMatieresObsoletes($cls, $seq)
    {
        $bdd = $GLOBALS['bdd'];
        $table = 'table_note_par_mat_eval' . preg_replace('/[^0-9]/', '', $seq);
        
        try {
            $sql_notes = "SELECT id, ref_mat FROM $table WHERE ref_cls = ?";
            $stmt_notes = $bdd->prepare($sql_notes);
            $stmt_notes->execute(array($cls));
            
            $stmt_config = $bdd->prepare('SELECT COUNT(id) AS count FROM config_bull WHERE ref_class = ? AND ref_mat = ?');
            $stmt_delete = $bdd->prepare("DELETE FROM $table WHERE id = ?");
            
            while ($row_note = $stmt_notes->fetch(PDO::FETCH_ASSOC)) 
            {
                $stmt_config->execute(array($cls, $row_note['ref_mat']));
                $row_config = $stmt_config->fetch(PDO::FETCH_ASSOC);
                
                if ((int)$row_config['count'] === 0) {
                    $stmt_delete->execute(array($row_note['id']));
                }
            }
        } catch (Exception $e) {
            error_log("Erreur DelMatieresObsoletes : " . $e->getMessage());
        }
    }

    public function SelectNoteStd_by_MatCls($cls, $mat, $seq, $std)
    {
        $bdd = $GLOBALS['bdd'];
        $table = 'table_note_par_mat_eval' . preg_replace('/[^0-9]/', '', $seq);
        
        try {
            $stmt = $bdd->prepare("SELECT note FROM $table WHERE ref_cls = ? AND ref_mat = ? AND ref_eval = ? AND ref_std = ? LIMIT 1");
            $stmt->execute([$cls, $mat, $seq, $std]);
            $row = $stmt->fetch(PDO::FETCH_ASSOC);

            if (!$row || $row['note'] === null || !is_numeric($row['note'])) {
                return '--';
            }
            return (float)$row['note'];
        } catch (PDOException $e) {
            return '--'; 
        }
    }

    public function SelectNoteStd_by_MatCls_an($cls, $mat, $trim, $std)
    {
        $s1 = '1'; $s2 = '2';
        if ($trim == '2') { $s1 = '3'; $s2 = '4'; }
        elseif ($trim == '3') { $s1 = '5'; $s2 = '6'; }

        $bdd = $GLOBALS['bdd'];
        $notes_trim = [];

        foreach ([$s1, $s2] as $seq) {
            $table = 'table_note_par_mat_eval' . $seq;
            try {
                $stmt = $bdd->prepare("SELECT note FROM $table WHERE ref_cls = ? AND ref_mat = ? AND ref_std = ? LIMIT 1");
                $stmt->execute([$cls, $mat, $std]);
                $row = $stmt->fetch(PDO::FETCH_ASSOC);

                if ($row && is_numeric($row['note'])) {
                    $notes_trim[] = (float)$row['note'];
                }
            } catch (PDOException $e) {
                error_log("Erreur PDO Séquence $seq : " . $e->getMessage());
            }
        }

        $nb = count($notes_trim);
        return $nb > 0 ? array_sum($notes_trim) / $nb : '--';
    }




		    public function SelectMINNoteby_MatClsbyEval($cls, $mat, $seq)
    {
        $bdd = $GLOBALS['bdd'];
        $tab_notes = array();
        $table = 'table_note_par_mat_eval' . preg_replace('/[^0-9]/', '', $seq);
        
        try {
            $stmt = $bdd->prepare("SELECT note FROM $table WHERE ref_cls = :cls AND ref_mat = :mat AND ref_eval = :seq");
            $stmt->bindParam(':cls', $cls);
            $stmt->bindParam(':mat', $mat);
            $stmt->bindParam(':seq', $seq);
            $stmt->execute();

            while($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
                if (is_numeric($row['note'])) {
                    $tab_notes[] = (float)$row['note'];
                }
            }
        } catch (Exception $e) { return null; }
        
        return empty($tab_notes) ? null : min($tab_notes);
    }

    public function SelectMINNoteby_MatCls_an($cls, $mat, $trim)
    {
        $bdd = $GLOBALS['bdd'];
        $tab_notes = array();
        
        // CORRECTION DE SÉCURITÉ : Détermination automatique des séquences pour éliminer la variable $seq indéfinie
        $s1 = '1'; $s2 = '2';
        if ($trim == '2') { $s1 = '3'; $s2 = '4'; }
        elseif ($trim == '3') { $s1 = '5'; $s2 = '6'; }
        
        foreach ([$s1, $s2] as $seqId) {
            $table = 'table_note_par_mat_eval' . $seqId;
            try {
                $stmt = $bdd->prepare("SELECT note FROM $table WHERE ref_cls = :cls AND ref_mat = :mat AND ref_eval = :seq");
                $stmt->bindParam(':cls', $cls);
                $stmt->bindParam(':mat', $mat);
                $stmt->bindParam(':seq', $seqId);
                $stmt->execute();

                while($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
                    if (is_numeric($row['note'])) {
                        $tab_notes[] = (float)$row['note'];
                    }
                }
            } catch (Exception $e) { continue; }
        }
        
        return empty($tab_notes) ? null : min($tab_notes);
    }

    public function SelectMinMaxAnnuel($cls, $mat) 
    {
        $bdd = $GLOBALS['bdd'];
        $moyennes_an_classe = [];

        try {
            $stds = $bdd->prepare("SELECT DISTINCT ref_std FROM table_note_par_mat_eval1 WHERE ref_cls = ?");
            $stds->execute([$cls]);
            
            while($s = $stds->fetch()) {
                $notes = [];
                for($t = 1; $t <= 3; $t++) {
                    $m = $this->SelectNoteStd_by_MatCls_an($cls, $mat, $t, $s['ref_std']);
                    if(is_numeric($m)) {
                        $notes[] = $m;
                    }
                }
                if(count($notes) > 0) {
                    $moyennes_an_classe[] = array_sum($notes) / count($notes);
                }
            }
        } catch (Exception $e) { return ['min' => '--', 'max' => '--']; }

        if(empty($moyennes_an_classe)) return ['min' => '--', 'max' => '--'];

        return [
            'min' => number_format(min($moyennes_an_classe), 2),
            'max' => number_format(max($moyennes_an_classe), 2)
        ];
    }

    public function SelectMAXNoteby_MatClsbyEval($cls, $mat, $seq)
    {
        $bdd = $GLOBALS['bdd'];
        $tab_notes = array();
        $table = 'table_note_par_mat_eval' . preg_replace('/[^0-9]/', '', $seq);
        
        try {
            $stmt = $bdd->prepare("SELECT note FROM $table WHERE ref_cls = :cls AND ref_mat = :mat AND ref_eval = :seq");
            $stmt->bindParam(':cls', $cls);
            $stmt->bindParam(':mat', $mat);
            $stmt->bindParam(':seq', $seq);
            $stmt->execute();

            while($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
                if (is_numeric($row['note'])) {
                    $tab_notes[] = (float)$row['note'];
                }
            }
        } catch (Exception $e) { return null; }

        return empty($tab_notes) ? null : max($tab_notes);
    }

    public function calculerMoyenneSimple($noteA, $noteB) 
    {
        $notes_valides = array_filter([$noteA, $noteB], fn($v) => is_numeric($v));
        $nombre = count($notes_valides);

        if ($nombre === 0) {
            return ''; 
        }
        
        return round(array_sum($notes_valides) / $nombre, 2);
    }




// Conservez votre fonction existante pour récupérer le nom de la classe par son code
public function ReturnNomCls_by_Code_stat($code)
{
    $bdd = $GLOBALS['bdd'];
    // Simplification de la fonction existante pour être plus propre et sécurisée
    $stmt = $bdd->prepare('SELECT nom_class FROM classes WHERE code_class = :code LIMIT 1');
    $stmt->bindParam(':code', $code);
    $stmt->execute();
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
    return $row ? $row['nom_class'] : 'Classe inconnue';
}


/**
 * Récupère les N meilleurs ou N derniers élèves pour un trimestre, optionnellement par classe.
 * Utilise une double requête ET la fonction ReturnNomCls_by_Code pour gérer les collations.
 */
public function getStudentsByRank($limit = 5, $cls = NULL, $trim = '1', $orderByAsc = false) {
    $bdd = $GLOBALS['bdd'];
    
    // --- Requête 1: Récupère les données de notation et l'ID de classe (sans jointure problématique) ---
    $sql_notes = "SELECT t.ref_std, t.moy, t.rang, t.ref_cls 
                  FROM table_note_par_trim" . $trim . " t";

    if ($cls !== NULL) {
        $sql_notes .= " WHERE t.ref_cls = :cls";
    }
    
    $sortOrder = $orderByAsc ? 'ASC' : 'DESC';
    $sql_notes .= " ORDER BY CAST(t.moy AS DECIMAL(10,2)) " . $sortOrder . " LIMIT :limit";

    $stmt_notes = $bdd->prepare($sql_notes);
    if ($cls !== NULL) {
        $stmt_notes->bindParam(':cls', $cls);
    }
    $stmt_notes->bindParam(':limit', $limit, PDO::PARAM_INT);
    $stmt_notes->execute();
    $results = $stmt_notes->fetchAll(PDO::FETCH_ASSOC);

    if (empty($results)) {
        return [];
    }

    $studentIds = array_column($results, 'ref_std');

    // --- Requête 2: Récupère les noms des élèves séparément ---
    $placeholdersStudents = implode(',', array_fill(0, count($studentIds), '?'));
    $sql_names = "SELECT mat_std, nom_std FROM eleves WHERE mat_std IN ($placeholdersStudents)";
    $stmt_names = $bdd->prepare($sql_names);
    $stmt_names->execute($studentIds);
    $nameMap = array_column($stmt_names->fetchAll(PDO::FETCH_ASSOC), 'nom_std', 'mat_std');

    // --- Fusionne les données en PHP et utilise la fonction existante pour le nom de la classe ---
    $finalResults = [];
    foreach ($results as $row) {
        $row['nom'] = $nameMap[$row['ref_std']] ?? 'Nom inconnu';
        $row['mat_std'] = $row['ref_std']; // Ajoute explicitement la clé "mat_std"
        
        // Utilisation de la fonction existante pour obtenir le nom de la classe (ajoute la clé "nom_class")
        $row['nom_class'] = $this->ReturnNomCls_by_Code($row['ref_cls']); 
        
        $finalResults[] = $row;
    }

    return $finalResults;
}

// Fonction utilitaire pour appeler getStudentsByRank pour les meilleurs élèves (tri DESC)
public function getTopStudents($limit = 5, $cls = NULL, $trim = '1') {
    // Cette fonction retourne maintenant le tableau avec 'mat_std' et 'nom_class'
    return $this->getStudentsByRank($limit, $cls, $trim, false);
}

// Fonction utilitaire pour appeler getStudentsByRank pour les derniers élèves (tri ASC)
public function getBottomStudents($limit = 5, $cls = NULL, $trim = '1') {
    // Cette fonction retourne maintenant le tableau avec 'mat_std' et 'nom_class'
    return $this->getStudentsByRank($limit, $cls, $trim, true);
}


// Récupère le taux de réussite global par classe ou établissement
public function getSuccessRatesByCls($trim = '1') {
    $bdd = $GLOBALS['bdd'];
    
    // 1. Récupère les taux de réussite par classe (sans jointure)
    $sql_rates = "SELECT t.ref_cls,
                         AVG(CASE WHEN CAST(t.moy AS DECIMAL(10,2)) >= 10 THEN 100 ELSE 0 END) as taux_reussite
                  FROM table_note_par_trim" . $trim . " t
                  GROUP BY t.ref_cls";
            
    $stmt_rates = $bdd->query($sql_rates);
    $rates = $stmt_rates->fetchAll(PDO::FETCH_ASSOC);

    if (empty($rates)) {
        return [];
    }

    // 2. Utilise la fonction existante pour fusionner les noms de classe
    $finalResults = [];
    foreach ($rates as $row) {
        $row['nom_class'] = $this->ReturnNomCls_by_Code($row['ref_cls']);
        $finalResults[] = $row;
    }

    return $finalResults;
}

public function getGlobalSuccessRate($trim = '1') {
    $bdd = $GLOBALS['bdd'];
    $sql = "SELECT AVG(CASE WHEN CAST(moy AS DECIMAL(10,2)) >= 10 THEN 100 ELSE 0 END) as taux_reussite
            FROM table_note_par_trim" . $trim;
    $stmt = $bdd->query($sql);
    $result = $stmt->fetch(PDO::FETCH_ASSOC);
    return $result['taux_reussite'];
}


// Fonction pour récupérer la liste de toutes les classes actives
public function getAllClasses() {
    $bdd = $GLOBALS['bdd'];
    // Assurez-vous que cette requête ne pose pas de problème de collation si la table 'classes' est mixte
    $sql = "SELECT code_class, nom_class FROM classes ORDER BY nom_class ASC";
    $stmt = $bdd->query($sql);
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}


// Récupère les statistiques détaillées pour une classe donnée et un trimestre
public function getDetailedClassStats($classCode, $trim = '1') {
    $bdd = $GLOBALS['bdd'];
    $tableName = "table_note_par_trim" . $trim;

    // --- Requête 1: Obtenir le nombre total d'élèves inscrits dans la classe ---
    $sql_inscrits = "SELECT COUNT(mat_std) as total_inscrits FROM eleves WHERE ref_class = :classCode";
    $stmt_inscrits = $bdd->prepare($sql_inscrits);
    $stmt_inscrits->bindParam(':classCode', $classCode);
    $stmt_inscrits->execute();
    $inscrits_count_result = $stmt_inscrits->fetch(PDO::FETCH_ASSOC);
    $total_inscrits = $inscrits_count_result['total_inscrits'];

    // --- Requête 2: Obtenir les statistiques de notation pour ce trimestre ---
    $sql = "
        SELECT 
            COUNT(t.ref_std) as inscrits_composant, -- Ceux qui ont composé (ont une ligne dans la table de notes)
            SUM(CASE WHEN t.moy IS NOT NULL THEN 1 ELSE 0 END) as nombre_de_moyennes_valides, -- Le nombre de moyennes tout court (votre ancien 'Nb Moy')
            SUM(CASE WHEN CAST(t.moy AS DECIMAL(10,2)) >= 10 THEN 1 ELSE 0 END) as nbre_reussite, -- NOUVEAU: Le nombre d'élèves ayant >= 10
            AVG(CAST(t.moy AS DECIMAL(10,2))) as moyenne_generale_classe,
            MAX(CAST(t.moy AS DECIMAL(10,2))) as moyenne_premier,
            MIN(CAST(t.moy AS DECIMAL(10,2))) as moyenne_dernier,
            AVG(CASE WHEN CAST(t.moy AS DECIMAL(10,2)) >= 10 THEN 100 ELSE 0 END) as taux_reussite,
            SUM(CASE WHEN t.rang = 1 THEN 1 ELSE 0 END) as nbre_premier_classe,
            SUM(CASE WHEN CAST(t.moy AS DECIMAL(10,2)) >= 12 THEN 1 ELSE 0 END) as nbre_tableau_honneur
        FROM 
            $tableName t
        WHERE 
            t.ref_cls = :classCode
    ";

    $stmt = $bdd->prepare($sql);
    $stmt->bindParam(':classCode', $classCode);
    $stmt->execute();
    $stats = $stmt->fetch(PDO::FETCH_ASSOC);

    $stats['total_inscrits'] = $total_inscrits;
    
    return $stats;
}


    public function ReturnCNI_by_matr($code)
    {
        $bdd = $GLOBALS['bdd']; 
        $stmt = $bdd->prepare('SELECT cni_std FROM eleves WHERE mat_std = ? LIMIT 1');
        $stmt->execute(array($code));
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        return $row ? $row['cni_std'] : '';
    }

    public function getNextClasseCode($active_id) 
    {
        $bdd = $GLOBALS['bdd'];
        $tab_code = array();
        $i = 0;
        $nextcls = null;
        
        $reponse = $bdd->query('SELECT code_class FROM classes ORDER BY class_session ASC, ref_class_niveau ASC, nom_class ASC');
        while($row = $reponse->fetch(PDO::FETCH_ASSOC)) {
            $i++;
            $tab_code[$i] = $row['code_class'];
        }
     
        foreach ($tab_code as $index => $classe) {
            if ($classe == $active_id) {
                if ($index < count($tab_code)) {
                    $nextcls = $tab_code[$index + 1];
                }
                break;
            }
        }
        return $nextcls;
    }

    public function getNextMatCode($c_cls, $c_mat) 
    {
        $bdd = $GLOBALS['bdd'];
        $tab_code = array();
        $i = 0;
        $nextmat = null;
        
        $stmt = $bdd->prepare('SELECT ref_mat FROM config_bull WHERE ref_class = ? ORDER BY group_mat ASC, nom_mat ASC');
        $stmt->execute(array($c_cls));
        while($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            $i++;
            $tab_code[$i] = $row['ref_mat'];
        }
     
        foreach ($tab_code as $index => $mat) {
            if ($mat == $c_mat) {
                if ($index < count($tab_code)) {
                    $nextmat = $tab_code[$index + 1];
                }
                break;
            }
        }
        return $nextmat;
    }

    public function getPreClasseCode($active_id) 
    {
        $bdd = $GLOBALS['bdd'];
        $tab_code = array();
        $i = 0;
        $precls = null;
        
        $reponse = $bdd->query('SELECT code_class FROM classes ORDER BY class_session ASC, ref_class_niveau ASC, nom_class ASC');
        while($row = $reponse->fetch(PDO::FETCH_ASSOC)) {
            $i++;
            $tab_code[$i] = $row['code_class'];
        }
     
        foreach ($tab_code as $index => $classe) {
            if ($classe == $active_id) {
                if ($index > 1) {
                    $precls = $tab_code[$index - 1];
                }
                break;
            }
        }
        return $precls;
    }

    public function getPreMatCode($c_cls, $c_mat) 
    {
        $bdd = $GLOBALS['bdd'];
        $tab_code = array();
        $i = 0;
        $premat = null;
        
        $stmt = $bdd->prepare('SELECT ref_mat FROM config_bull WHERE ref_class = ? ORDER BY group_mat ASC, nom_mat ASC');
        $stmt->execute(array($c_cls));
        while($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            $i++;
            $tab_code[$i] = $row['ref_mat'];
        }
     
        foreach ($tab_code as $index => $mat) {
            if ($mat == $c_mat) {
                if ($index > 1) {
                    $premat = $tab_code[$index - 1];
                }
                break;
            }
        }
        return $premat;
    }

    public function getStartClasseCode() 
    {
        $bdd = $GLOBALS['bdd'];
        $reponse = $bdd->query('SELECT code_class FROM classes ORDER BY class_session ASC, ref_class_niveau ASC, nom_class ASC LIMIT 1');
        $row = $reponse->fetch(PDO::FETCH_ASSOC);
        return $row ? $row['code_class'] : null;
    }

    public function getStartConfigMatBull() 
    {
        $bdd = $GLOBALS['bdd'];
        $startmat = null;

        $reponse = $bdd->query('SELECT code_class FROM classes ORDER BY class_session ASC, ref_class_niveau ASC, nom_class ASC LIMIT 1');
        if($row = $reponse->fetch(PDO::FETCH_ASSOC)) {
            $stmt = $bdd->prepare('SELECT ref_mat FROM config_bull WHERE ref_class = ? ORDER BY group_mat ASC, nom_mat ASC LIMIT 1');
            $stmt->execute(array($row['code_class']));
            if($row2 = $stmt->fetch(PDO::FETCH_ASSOC)) {
                $startmat = $row2['ref_mat'];
            }
        }
        return $startmat;
    }

    public function getStartConfigMatBull_by_cls($cls) 
    {
        $bdd = $GLOBALS['bdd'];
        $startmat = null;

        $stmt = $bdd->prepare('SELECT ref_mat FROM config_bull WHERE ref_class = ? ORDER BY group_mat ASC, nom_mat ASC LIMIT 1');
        $stmt->execute(array($cls));
        $row2 = $stmt->fetch(PDO::FETCH_ASSOC);
        if($row2) {
            $startmat = $row2['ref_mat'];
        }
        return $startmat;
    }



		    public function ShowEdit_Bul($code)
    {
        $bdd = $GLOBALS['bdd'];
        $stmt = $bdd->prepare('SELECT id, ref_class, ref_mat, coeff_mat, group_mat, ref_ens FROM config_bull WHERE ref_class = ? ORDER BY group_mat ASC');
        $stmt->execute(array($code));
        $i = 0;
        
        while($row = $stmt->fetch(PDO::FETCH_ASSOC)) 
        {
            $i++;
            $nom_ens = $this->ShowUsernamebyID($row['ref_ens']);
            $nom_mat = $this->ReturnNomMatbyId($row['ref_mat']);
            
            echo '
            <tr style="font-size:0.9em;">
                <td>' . $i . '</td>
                <td class="fw-bold">' . $nom_mat . '</td>
                <td class="font-monospace">' . $row['coeff_mat'] . '</td>
                <td><span class="badge bg-secondary">Groupe ' . $row['group_mat'] . '</span></td>
                <td class="small text-secondary">' . $nom_ens . '</td>
                <td>
                    <div class="btn-group btn-group-sm">
                        <button type="button" class="btn btn-outline-primary px-2" data-bs-toggle="modal" data-bs-target="#mod_edit' . $row['id'] . '"><i class="fa fa-edit"></i></button>
                        <button type="button" class="btn btn-outline-danger px-2" data-bs-toggle="modal" data-bs-target="#mod_del' . $row['id'] . '"><i class="fa fa-times"></i></button>
                    </div>

                    <!-- Modal Suppression de matière associée -->
                    <div class="modal fade" id="mod_del' . $row['id'] . '" tabindex="-1" aria-hidden="true">
                        <div class="modal-dialog modal-dialog-centered">
                            <div class="modal-content border-0">
                                <div class="modal-header bg-danger text-white border-0 py-2">
                                    <h5 class="modal-title fw-bold small"><i class="fa fa-warning me-2"></i>Retirer la matière</h5>
                                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                                </div>
                                <div class="modal-body text-center p-4">
                                    <p class="mb-1 text-muted small">Voulez-vous dissocier de la classe la matière :</p>
                                    <h5 class="text-danger fw-bolder mb-2">' . $nom_mat . '</h5>
                                    <p class="text-secondary font-monospace bg-light p-2 rounded small" style="font-size:0.8em;"><i class="fa fa-info-circle me-1"></i>Cette action supprimera les configurations de coefficients associées. Cette action est irréversible.</p>
                                </div>
                                <div class="modal-footer border-top-0 pt-0 justify-content-center">
                                    <button type="button" class="btn btn-sm btn-secondary px-3" data-bs-dismiss="modal">Annuler</button>
                                    <a href="Controler/classes/del_mat_classe.php?id=' . $row['id'] . '&refcls=' . $code . '" class="btn btn-sm btn-danger px-4 fw-bold">Confirmer le retrait</a>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Modal Modification Coeff / Groupe / Enseignant -->
                    <div class="modal fade" id="mod_edit' . $row['id'] . '" tabindex="-1" aria-hidden="true">
                        <div class="modal-dialog modal-dialog-centered modal-lg">
                            <div class="modal-content border-0">
                                <div class="modal-header text-white border-0 py-2" style="background-color: #0764a8;">
                                    <h5 class="modal-title fw-bold"><i class="fa fa-edit me-2"></i>Ajustement : ' . $nom_mat . '</h5>
                                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                                </div>
                                <form action="Controler/classes/upd_mat_classe.php" method="post">
                                    <div class="modal-body p-4" style="background-color: var(--bg-main);">
                                        <div class="container-fluid p-0">
                                            <div class="row g-2 mb-2">
                                                <input type="hidden" name="ref_class" value="' . $row['ref_class'] . '">
                                                <input type="hidden" name="ref_mat" value="' . $row['ref_mat'] . '"> 
                                                
                                                <div class="col-6 col-md-2">
                                                    <label class="form-label fw-bold text-secondary small">Coeff (<i class="text-primary">' . $row['coeff_mat'] . '</i>)</label>
                                                    <input type="number" class="form-control form-control-sm text-center" name="coeff" min="1" max="20" step="0.5">
                                                </div>
                                                <div class="col-6 col-md-2">
                                                    <label class="form-label fw-bold text-secondary small">Groupe (<i class="text-primary">' . $row['group_mat'] . '</i>)</label>
                                                    <input type="number" class="form-control form-control-sm text-center" name="groupe" min="1" max="3">
                                                </div>
                                                <div class="col-12 col-md-8">
                                                    <label class="form-label fw-bold text-secondary small">Enseignant affecté : (<i class="text-danger">' . $nom_ens . '</i>)</label>
                                                    <select class="form-select form-select-sm" name="ens">
                                                        <option value="">Conserver le titulaire actuel...</option>';
                                                        $this->SelectTeacher();
                                                    echo '</select>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="modal-footer border-top-0 pt-0">
                                        <button type="button" class="btn btn-sm btn-secondary px-3" data-bs-dismiss="modal">Annuler</button>
                                        <button type="submit" class="btn btn-sm text-white fw-bold px-4" style="background-color: #19784f; border:none;"><i class="fa fa-save me-2"></i>Sauvegarder</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>

                </td>
            </tr>';
        }
    }

    public function Show_Ens_Class_and_Mat($code)
    {
        $bdd = $GLOBALS['bdd'];
        $stmt = $bdd->prepare('SELECT id, ref_class, ref_mat, group_mat FROM config_bull WHERE ref_ens = ? ORDER BY group_mat ASC');
        $stmt->execute(array($code));
        
        while($row = $stmt->fetch(PDO::FETCH_ASSOC)) 
        {
            $nom_cls = $this->ShowCls_namebyID($row['ref_class']);
            $nom_mat = $this->ShowMat_namebyID($row['ref_mat']);

            echo '
            <div class="d-inline-block m-1">
                <button type="button" class="btn btn-sm btn-outline-danger fw-bold" data-bs-toggle="modal" data-bs-target="#mod_del_ens' . $row['id'] . '">
                    <i class="fa fa-unlink me-1"></i>' . $nom_cls . ' &mdash; ' . $nom_mat . '
                </button>
            </div>

            <div class="modal fade" id="mod_del_ens' . $row['id'] . '" tabindex="-1" aria-hidden="true">
                <div class="modal-dialog modal-dialog-centered">
                    <div class="modal-content border-0">
                        <div class="modal-header bg-danger text-white border-0 py-2">
                            <h5 class="modal-title fw-bold small"><i class="fa fa-warning me-2"></i>Retirer l\'affectation</h5>
                            <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                        </div>
                        <div class="modal-body text-center p-4">
                            <p class="mb-1 text-muted small">Voulez-vous délier l\'enseignant de la matière :</p>
                            <h5 class="text-danger fw-bolder mb-2">' . $nom_mat . ' (' . $nom_cls . ')</h5>
                            <p class="text-secondary font-monospace bg-light p-2 rounded small" style="font-size:0.8em;"><i class="fa fa-info-circle me-1"></i>Cette action réinitialisera la liaison d\'attribution de notes. Cette action est irréversible.</p>
                        </div>
                        <div class="modal-footer border-top-0 pt-0 justify-content-center">
                            <button type="button" class="btn btn-sm btn-secondary px-3" data-bs-dismiss="modal">Annuler</button>
                            <a href="Controler/classes/del_mat_classe.php?id=' . $row['id'] . '&refcls=' . $code . '" class="btn btn-sm btn-danger px-4 fw-bold">Confirmer le retrait</a>
                        </div>
                    </div>
                </div>
            </div>';
        }
    }

	
		    public function SelectTeacher()
    {
        $bdd = $GLOBALS['bdd'];
        $reponse = $bdd->query('SELECT login, civilite, username FROM admins ORDER BY username ASC');
        $i = 0;
        while($row = $reponse->fetch(PDO::FETCH_ASSOC)) 
        {
            $i++;
            echo '<option value="' . $row['login'] . '" id="' . $row['login'] . '">' . $i . ' - ' . $row['civilite'] . ' ' . $row['username'] . '</option>';
        }
    }

    public function NombreMatbyCls($cls)
    {
        $bdd = $GLOBALS['bdd'];
        $stmt = $bdd->prepare('SELECT COUNT(id) AS total FROM config_bull WHERE ref_class = ?');
        $stmt->execute(array($cls));
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        return $row ? (int)$row['total'] : 0;
    }

    public function NbrStudentByClass($code)
    {
        $bdd = $GLOBALS['bdd']; 
        $stmt = $bdd->prepare('SELECT COUNT(id) AS total FROM eleves WHERE ref_class = ?');
        $stmt->execute(array($code));
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        return $row ? (int)$row['total'] : 0;
    }

    public function NbrStudentByAll()
    {
        $bdd = $GLOBALS['bdd']; 
        $res = $bdd->query('SELECT COUNT(id) AS total FROM eleves');
        $row = $res->fetch(PDO::FETCH_ASSOC);
        return $row ? (int)$row['total'] : 0;
    }

    public function NbrStudentBySess($s)
    {
        $bdd = $GLOBALS['bdd']; 
        $reponse = $bdd->query('SELECT ref_class FROM eleves');
        $i = 0;
        while (($row = $reponse->fetch(PDO::FETCH_ASSOC))) 
        {
            $sess = $this->ReturnClasseSessionByCode($row['ref_class']);
            if ($sess == $s) {
                $i++;
            }
        }
        return $i;
    }

    public function NbrStudentByNv($nv)
    {
        $bdd = $GLOBALS['bdd']; 
        $reponse = $bdd->query('SELECT ref_class FROM eleves');
        $i = 0;
        while (($row = $reponse->fetch(PDO::FETCH_ASSOC))) 
        {
            $thisnv = $this->ReturnClasseNvByCode($row['ref_class']);
            if ($thisnv == $nv) {
                $i++;
            }
        }
        return $i;
    }

    public function RetrunStd_ClasserbyTrim($trim, $std)
    {
        $bdd = $GLOBALS['bdd'];
        $table = 'table_note_par_trim' . preg_replace('/[^0-9]/', '', $trim);
        try {
            $stmt = $bdd->prepare("SELECT classer FROM $table WHERE ref_trim = ? AND ref_std = ? LIMIT 1");
            $stmt->execute(array($trim, $std));
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            return $row ? $row['classer'] : null;
        } catch (Exception $e) { return null; }
    }

    public function ReturnNomNiveau_by_Ref($code)
    {
        $bdd = $GLOBALS['bdd'];
        $stmt = $bdd->prepare('SELECT nom_niveau FROM niveaux WHERE ref_niveau = ? LIMIT 1');
        $stmt->execute(array($code));
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        return $row ? $row['nom_niveau'] : '';
    }

    public function ReturnClasseNvByCode($code)
    {
        $bdd = $GLOBALS['bdd'];
        $stmt = $bdd->prepare('SELECT ref_class_niveau FROM classes WHERE code_class = ? LIMIT 1');
        $stmt->execute(array($code));
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        return $row ? $row['ref_class_niveau'] : 0;
    }

    public function ReturnNomCls_by_Code($code)
    {
        $bdd = $GLOBALS['bdd'];
        $stmt = $bdd->prepare('SELECT nom_class FROM classes WHERE code_class = ? LIMIT 1');
        $stmt->execute(array($code));
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        return $row ? $row['nom_class'] : '';
    }

    public function ReturnNomMatbyId($code)
    {
        $bdd = $GLOBALS['bdd'];
        $stmt = $bdd->prepare('SELECT nom_mat FROM matieres WHERE id = ? LIMIT 1');
        $stmt->execute(array($code));
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        return $row ? $row['nom_mat'] : '';
    }

    public function ReturnNomMatbyRef($code)
    {
        return $this->ReturnNomMatbyId($code);
    }

    public function ReturnNomSess_by_Code($code)
    {
        $bdd = $GLOBALS['bdd'];
        $stmt = $bdd->prepare('SELECT nom_sess FROM sess WHERE abr_sess = ? LIMIT 1');
        $stmt->execute(array($code));
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        return $row ? $row['nom_sess'] : '';
    }

    public function ReturnClasseSessionByCode($code)
    {
        $bdd = $GLOBALS['bdd'];
        $stmt = $bdd->prepare('SELECT class_session FROM classes WHERE code_class = ? LIMIT 1');
        $stmt->execute(array($code));
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        return $row ? $row['class_session'] : '';
    }


		    public function CkNbClsbySess($ss)
    {
        $bdd = $GLOBALS['bdd']; 
        $stmt = $bdd->prepare('SELECT nb_class_par_sess FROM sess WHERE abr_sess = ? LIMIT 1');
        $stmt->execute(array($ss));
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        return $row ? (int)$row['nb_class_par_sess'] : 0;
    }

    public function Return_MaxNVCls_Sess($ss)
    {
        $bdd = $GLOBALS['bdd'];
        $stmt = $bdd->prepare('SELECT MAX(ref_class_niveau) AS max_nv FROM classes WHERE class_session = ?');
        $stmt->execute(array($ss));
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        return $row ? (int)$row['max_nv'] : 0;
    }

    public function ReturnNvCls_by_Sess($ss)
    {
        $bdd = $GLOBALS['bdd'];
        $stmt = $bdd->prepare('SELECT COUNT(id) AS total FROM classes WHERE class_session = ?');
        $stmt->execute(array($ss));
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        return $row ? (int)$row['total'] : 0;
    }

    public function NbrBySexeBySess($s, $sexe)
    {
        $bdd = $GLOBALS['bdd']; 
        $reponse = $bdd->query('SELECT ref_class, sexe_std FROM eleves');
        $i = 0;
        while ($row = $reponse->fetch(PDO::FETCH_ASSOC)) 
        {
            if ($row['sexe_std'] === $sexe) {
                $sess = $this->ReturnClasseSessionByCode($row['ref_class']);
                if ($sess == $s) {
                    $i++;
                }           
            }
        }
        return $i;
    }

    public function NombreCoeffbyCls($cls)
    {
        $bdd = $GLOBALS['bdd'];
        $stmt = $bdd->prepare('SELECT SUM(coeff_mat) AS total_coeff FROM config_bull WHERE ref_class = ?');
        $stmt->execute(array($cls));
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        return $row ? (int)$row['total_coeff'] : 0;
    }

    public function NombreClasses()
    {
        $bdd = $GLOBALS['bdd'];
        $res = $bdd->query('SELECT COUNT(id) AS total FROM classes');
        $row = $res->fetch(PDO::FETCH_ASSOC);
        return $row ? (int)$row['total'] : 0;
    }


	    public function NumStudentByClass($cls, $code)
    {
        $bdd = $GLOBALS['bdd']; 
        $stmt = $bdd->prepare('SELECT mat_std FROM eleves WHERE ref_class = ? ORDER BY nom_std ASC');
        $stmt->execute(array($cls));
        $i = 0;
        $n = 0;
        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            $i++;
            if ($row['mat_std'] == $code) {
                $n = $i;
                break;
            }
        }
        return $n;
    }

    public function NbrBySexeByClass($code, $sexe)
    {
        $bdd = $GLOBALS['bdd']; 
        $stmt = $bdd->prepare('SELECT COUNT(id) AS total FROM eleves WHERE ref_class = ? AND sexe_std = ?');
        $stmt->execute(array($code, $sexe));
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        return $row ? (int)$row['total'] : 0;
    }

    public function NbrBySexeByAll($sexe)
    {
        $bdd = $GLOBALS['bdd']; 
        $stmt = $bdd->prepare('SELECT COUNT(id) AS total FROM eleves WHERE sexe_std = ?');
        $stmt->execute(array($sexe));
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        return $row ? (int)$row['total'] : 0;
    }

    public function NbrBySexeByNv($nv, $sexe)
    {
        $bdd = $GLOBALS['bdd']; 
        $stmt = $bdd->prepare('SELECT ref_class FROM eleves WHERE sexe_std = ?');
        $stmt->execute(array($sexe));
        $i = 0;
        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            $thisnv = $this->ReturnClasseNvByCode($row['ref_class']);
            if ($thisnv == $nv) {
                $i++;
            }           
        }
        return $i;
    }

    public function CkExistingCode($code)
    {
        $bdd = $GLOBALS['bdd']; 
        $stmt = $bdd->prepare('SELECT id FROM classes WHERE code_class = ? LIMIT 1');
        $stmt->execute(array($code));
        return (bool)$stmt->fetch();
    }

    public function CkExistingMat($code)
    {
        $bdd = $GLOBALS['bdd']; 
        $stmt = $bdd->prepare('SELECT id FROM matieres WHERE id = ? LIMIT 1');
        $stmt->execute(array($code));
        return (bool)$stmt->fetch();
    }

    public function CkMatbyCls($cls, $mat)
    {
        $bdd = $GLOBALS['bdd'];
        $stmt = $bdd->prepare('SELECT id FROM config_bull WHERE ref_class = ? AND ref_mat = ? LIMIT 1');
        $stmt->execute(array($cls, $mat));
        return (bool)$stmt->fetch();
    }

    public function SelectActiveEval()
    {
        $bdd = $GLOBALS['bdd'];
        $reponse = $bdd->query('SELECT id, nom_seq FROM evaluations WHERE statut = "O" ORDER BY nom_seq ASC');
        while($row = $reponse->fetch(PDO::FETCH_ASSOC)) {
            echo '<option value="' . $row['id'] . '" id="' . $row['id'] . '">' . $row['nom_seq'] . '</option>';
        }
    }

    public function CkIsClsStd($mat, $cls)
    {
        $bdd = $GLOBALS['bdd']; 
        $stmt = $bdd->prepare('SELECT id FROM eleves WHERE mat_std = ? AND ref_class = ? LIMIT 1');
        $stmt->execute(array($mat, $cls));
        return (bool)$stmt->fetch();
    }

    public function delClasse($code)
    {
        $bdd = $GLOBALS['bdd'];
        $stmt = $bdd->prepare('DELETE FROM classes WHERE code_class = ?');
        return $stmt->execute(array($code));
    }

    public function delMatbyClasse($id, $cls)
    {
        $bdd = $GLOBALS['bdd'];
        $id_mat = (string)$id;
        
        // Nettoyage sécurisé de la table des compétences associées
        $reqi = 'DELETE FROM competences_matieres WHERE ref_class = ? AND ref_mat = ?';
        $repi = $bdd->prepare($reqi);
        $repi->execute(array($cls, $id_mat));

        // Nettoyage de la configuration d'affichage du bulletin
        $req = 'DELETE FROM config_bull WHERE id = ?';
        $rep = $bdd->prepare($req);
        return $rep->execute(array($id));
    }
}

// Initialisation de la variable globale requise par le système GescoAPC
$class = new MyClasses();
?>
