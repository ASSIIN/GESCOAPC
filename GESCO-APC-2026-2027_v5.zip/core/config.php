<?php
/**
 * Ressources partagées GESCOAPC : fonctionnement local/offline, thème et notifications.
 */
class Config
{
    public static function head(): void
    {
        echo <<<HTML
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<meta name="theme-color" content="#0764a8">
<link rel="icon" href="images/favicon.png" type="image/png">
<link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
<link rel="stylesheet" href="assets/fontawesome/css/all.min.css">
      <link rel="stylesheet" href="css/dashboard.css">
     <style>
         @media print {
             .no-print, .no-Imprimer, .sidebar, .navbar, .navbar-expand, header, footer,
             .sidebar-menu, .sidenav, .menu-bar, .btn, .btn-print, .fa-print-btn { display:none !important; }
             body { background:#fff !important; }
             body > .page-content, body > .main-panel, body > .main-content-wrapper,
             .container, .container-fluid, .content, .card-body, .main-container { margin:0 !important; padding:0 !important; width:100% !important; max-width:100% !important; }
             a[href^="http"]:after { content: none !important; }
             .install-box, .key-input { -webkit-print-color-adjust: exact; print-color-adjust: exact; }
         }
         .gesco-print-fab {
             position: fixed; right: 18px; bottom: 18px; z-index: 1050;
             width: 54px; height: 54px; border-radius: 50%;
             display: flex; align-items: center; justify-content: center;
             box-shadow: 0 6px 18px rgba(0,0,0,.28);
         }
         @media (max-width: 767.98px) {
             .gesco-print-fab { right: 13px; bottom: 13px; width: 50px; height: 50px; }
         }
     </style>
HTML;
    }

    public static function head_b462(): void
    {
        self::head();
    }

    public static function scriptJs(): void
    {
        echo <<<HTML
<script src="assets/js/core/jquery-3.7.1.min.js"></script>
<script src="assets/bootstrap/js/bootstrap.bundle.min.js"></script>
<script>
(function () {
  'use strict';
  var root = document.documentElement;
  var savedTheme = localStorage.getItem('gescoapc-theme') || localStorage.getItem('theme') || 'light';
  root.setAttribute('data-theme', savedTheme);
  function updateThemeButton() {
    var dark = root.getAttribute('data-theme') === 'dark';
    document.querySelectorAll('[data-theme-toggle], #toggleTheme').forEach(function (button) {
      var icon = button.querySelector('[data-theme-icon], #themeIcon');
      var text = button.querySelector('[data-theme-text], #themeText');
      if (icon) icon.className = dark ? 'fa-solid fa-sun me-1' : 'fa-solid fa-moon me-1';
      if (text) text.textContent = dark ? ' Mode clair' : ' Mode sombre';
      button.setAttribute('aria-label', dark ? 'Activer le mode clair' : 'Activer le mode sombre');
    });
  }
  function toast(message, type) {
    type = ['success','danger','warning','info'].indexOf(type) >= 0 ? type : 'info';
    var icons = {success:'circle-check', danger:'circle-exclamation', warning:'triangle-exclamation', info:'circle-info'};
    var host = document.getElementById('gesco-toast-host');
    if (!host) { host = document.createElement('div'); host.id = 'gesco-toast-host'; host.className = 'toast-container position-fixed top-0 end-0 p-3'; host.style.zIndex = '1080'; document.body.appendChild(host); }
    var el = document.createElement('div');
    el.className = 'toast show text-bg-' + type + ' border-0 shadow';
    el.setAttribute('role', 'status');
    el.innerHTML = '<div class="d-flex"><div class="toast-body"><i class="fa-solid fa-' + icons[type] + ' me-2"></i>' + String(message).replace(/[&<>"']/g, function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[c];}) + '</div><button type="button" class="btn-close btn-close-white me-2 m-auto" aria-label="Fermer"></button></div>';
    host.appendChild(el);
    el.querySelector('button').addEventListener('click', function(){ el.remove(); });
    window.setTimeout(function(){ el.classList.remove('show'); window.setTimeout(function(){el.remove();}, 250); }, 5200);
  }
  window.GescoToast = toast;
  document.addEventListener('DOMContentLoaded', function () {
    document.querySelectorAll('[data-toggle="modal"],[data-toggle="collapse"],[data-toggle="dropdown"]').forEach(function (el) {
      el.setAttribute('data-bs-toggle', el.getAttribute('data-toggle'));
      if (el.hasAttribute('data-target')) el.setAttribute('data-bs-target', el.getAttribute('data-target'));
      if (el.hasAttribute('data-parent')) el.setAttribute('data-bs-parent', el.getAttribute('data-parent'));
      if (el.hasAttribute('data-dismiss')) el.setAttribute('data-bs-dismiss', el.getAttribute('data-dismiss'));
    });
    updateThemeButton();
    document.addEventListener('click', function (event) {
      var toggle = event.target.closest('[data-theme-toggle], #toggleTheme');
      if (toggle) {
        event.preventDefault();
        var next = root.getAttribute('data-theme') === 'dark' ? 'light' : 'dark';
        root.setAttribute('data-theme', next);
        localStorage.setItem('gescoapc-theme', next);
        localStorage.setItem('theme', next);
        updateThemeButton();
        toast(next === 'dark' ? 'Mode sombre activé.' : 'Mode clair activé.', 'info');
      }
      var menuButton = event.target.closest('[data-sidebar-toggle], #toggleMobileMenu, .toggle-sidebar, .sidenav-toggler');
      if (menuButton) { event.preventDefault(); event.stopPropagation(); document.body.classList.toggle('sidebar-open'); var side = document.getElementById('sidebarMenu'); if (side) side.classList.toggle('active'); }
      if (event.target.matches('.sidebar-backdrop')) { document.body.classList.remove('sidebar-open'); var side = document.getElementById('sidebarMenu'); if (side) side.classList.remove('active'); }
      if (event.target.closest('#sidebarMenu a')) { document.body.classList.remove('sidebar-open'); var side = document.getElementById('sidebarMenu'); if (side) side.classList.remove('active'); }
    });
    document.querySelectorAll('form').forEach(function(form){
      form.addEventListener('submit', function(){
        var submit = form.querySelector('button[type="submit"]');
        if (!submit || submit.dataset.noBusy) { return; }
        if (submit.disabled) { return false; } // bloque le double envoi
        submit.dataset.originalText = submit.innerHTML;
        submit.disabled = true;
        submit.innerHTML = '<span class="spinner-border spinner-border-sm me-1" role="status"></span>Traitement…';
        // Sécurité : on réactive le bouton après 15 s même si la page ne navigue pas
        // (formulaires AJAX) pour ne plus rester bloqué sur « Traitement… ».
        window.setTimeout(function(){
          if (submit && submit.dataset.originalText !== undefined) {
            submit.disabled = false;
            submit.innerHTML = submit.dataset.originalText;
          }
        }, 15000);
      });
    });
    document.querySelectorAll('[data-auto-dismiss]').forEach(function(el){ window.setTimeout(function(){ if (window.bootstrap && bootstrap.Alert) bootstrap.Alert.getOrCreateInstance(el).close(); }, Number(el.dataset.autoDismiss) || 5000); });
      document.querySelectorAll('.page-content, .main-panel, .main-content-wrapper, .card, .white-box').forEach(function(el){ el.classList.add('ui-reveal'); });
      document.body.hasAttribute && document.body.hasAttribute('data-imprimable') && (function () {
        var fab = document.createElement('button');
        fab.type = 'button';
        fab.className = 'gesco-print-fab btn btn-primary no-print';
        fab.setAttribute('aria-label', "Imprimer ou capturer cette page");
        fab.setAttribute('title', "Imprimer / Capturer (PDF)");
        fab.innerHTML = '<i class="fa-solid fa-print"></i>';
        fab.onclick = function () { document.body.classList.add('gesco-printing'); window.print(); };
        document.body.appendChild(fab);
      })();
    document.addEventListener('show.bs.modal', function (event) {
      var modal = event.target;
      if (modal && modal.classList && modal.classList.contains('modal') && modal.parentElement !== document.body) {
        document.body.appendChild(modal);
        if (typeof bootstrap !== 'undefined' && bootstrap.Modal) {
          var mI = bootstrap.Modal.getInstance(modal);
          if (mI && typeof mI.handleUpdate === 'function') { mI.handleUpdate(); }
        }
      }
    }, true);
  });
})();
</script>
HTML;
    }

    public static function scriptJ_b462(): void
    {
        self::scriptJs();
    }

    public static function toast(string $message, string $type = 'warning'): void
    {
        $allowed = ['success', 'danger', 'warning', 'info'];
        $type = in_array($type, $allowed, true) ? $type : 'info';
        $icons = ['success'=>'circle-check', 'danger'=>'circle-exclamation', 'warning'=>'triangle-exclamation', 'info'=>'circle-info'];
        echo '<div class="toast-container position-fixed top-0 end-0 p-3" style="z-index:1080"><div class="toast show text-bg-'. $type .' border-0 shadow" role="alert" aria-live="assertive" aria-atomic="true" data-auto-dismiss="6000"><div class="d-flex"><div class="toast-body"><i class="fa-solid fa-'. $icons[$type] .' me-2"></i>'. htmlspecialchars($message, ENT_QUOTES, 'UTF-8') .'</div><button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast" aria-label="Fermer"></button></div></div></div>';
    }
}
?>
