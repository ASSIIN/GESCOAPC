<?php
    session_start();   
	require_once 'core/require.php'; 
	require_once 'Model/connexion.php';
     if (!isset($_SESSION['user'])) 
     {
      session_unset();
      session_destroy();
      header('location: index.php');
    }
    if (($_SESSION['user_role']!="admin") and ($_SESSION['user_role']!="pcpl")) {
       header('location: poste_de_saisie.php?trim=t1');    
    }
    $etb->ShowEtb();
    $etb->CkLE();
    $etb->ckexneE();
?>
<!DOCTYPE html>
<html>
  <head>
   <?php Config::head(); ?>
    <title>GESCOAPC| PARAMATRE GLOBAL</title>
    <style>
        .field-current { color: #e63f32; font-style: italic; }
    </style>
  </head>

<body>
    <div class="wrapper">
      <!-- Sidebar -->

      <!-- Inclusion du menu de navigation externe réutilisable -->
      <?php include 'core/sidebar.php'; ?>  

<div class="main-content-wrapper">
        <!-- Barre supérieure de navigation adaptative -->
        <div class="mobile-navbar-fixed p-3 mb-4 rounded shadow-sm border">
            <div class="row align-items-center g-2">
                <div class="col-auto d-md-none">
                    <button class="btn btn-outline-dark btn-sm" id="toggleMobileMenu"><i class="fa fa-bars fa-lg"></i></button>
                </div>
                <div class="col-12 col-md">
                    <h4 class="m-0 fw-bold text-primary text-uppercase">Gestion générale des paramètres de l'établissement</h4>
                </div>
            </div>
        </div>
        <!-- End Sidebar -->

        <div class="container-fluid mt-3">
            <div class="row">
                <div class="col-12">
                    <div class="accordion" id="accordionExample">

                        <!-- ===== ENTETE ===== -->
                        <div class="accordion-item">
                            <h2 class="accordion-header">
                                <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                                    <h4 class="fw-bolder m-0">PARAMETRE DE L'ENTETE</h4>
                                </button>
                            </h2>
                            <div id="collapseOne" class="accordion-collapse collapse show" data-bs-parent="#accordionExample">
                                <div class="accordion-body">
                                    <form action="Controler/school/updetb.php" method="post" enctype="multipart/form-data">
                                        <div class="container-fluid">
                                            <div class="row">
                                                <div class="col-md-4"><h5 class="fw-bolder">NOM DE L'ETABLISSEMENT</h5></div>
                                                <div class="col-md-4">
                                                    <label class="form-label">Nom (FR) : <span class="field-current"><?php echo $_SESSION['nom_etb_fr']; ?></span></label>
                                                    <input type="text" class="form-control text-uppercase" id="nom_etb_fr" name="nom_etb_fr" maxlength="50" disabled="true">
                                                </div>
                                                <div class="col-md-4">
                                                    <label class="form-label">Nom (EN) : <span class="field-current"><?php echo $_SESSION['nom_etb_en']; ?></span></label>
                                                    <input type="text" class="form-control text-uppercase" id="nom_etb_en" name="nom_etb_en" maxlength="50">
                                                </div>
                                            </div>

                                            <div class="row">
                                                <div class="col-md-4"><h5 class="fw-bolder">MINISTERE</h5></div>
                                                <div class="col-md-4">
                                                    <label class="form-label">Ministère (FR) : <span class="field-current"><?php echo $_SESSION['minist_etb_fr']; ?></span></label>
                                                    <input type="text" class="form-control text-uppercase" id="minist_etb_fr" name="minist_etb_fr" maxlength="50">
                                                </div>
                                                <div class="col-md-4">
                                                    <label class="form-label">Ministère (EN) : <span class="field-current"><?php echo $_SESSION['minist_etb_en']; ?></span></label>
                                                    <input type="text" class="form-control text-uppercase" id="minist_etb_en" name="minist_etb_en" maxlength="50">
                                                </div>
                                            </div>

                                            <div class="row">
                                                <div class="col-md-4"><h5 class="fw-bolder">REGION</h5></div>
                                                <div class="col-md-4">
                                                    <label class="form-label">Région (FR) : <span class="field-current"><?php echo $_SESSION['region_etb_fr']; ?></span></label>
                                                    <input type="text" class="form-control" id="region_etb_fr" name="region_etb_fr">
                                                </div>
                                                <div class="col-md-4">
                                                    <label class="form-label">Région (EN) : <span class="field-current"><?php echo $_SESSION['region_etb_en']; ?></span></label>
                                                    <input type="text" class="form-control text-uppercase" id="region_etb_en" name="region_etb_en" maxlength="50">
                                                </div>
                                            </div>

                                            <div class="row">
                                                <div class="col-md-4"><h5 class="fw-bolder">DEPARTEMENT</h5></div>
                                                <div class="col-md-4">
                                                    <label class="form-label">Département (FR) : <span class="field-current"><?php echo $_SESSION['depart_etb_fr']; ?></span></label>
                                                    <input type="text" class="form-control" id="depart_etb_fr" name="depart_etb_fr">
                                                </div>
                                                <div class="col-md-4">
                                                    <label class="form-label">Département (EN) : <span class="field-current"><?php echo $_SESSION['depart_etb_en']; ?></span></label>
                                                    <input type="text" class="form-control text-uppercase" id="depart_etb_en" name="depart_etb_en" maxlength="50">
                                                </div>
                                            </div>

                                            <div class="row">
                                                <div class="col-md-4"><h5 class="fw-bolder">BOITE POSTALE / TELEPHONE</h5></div>
                                                <div class="col-md-4">
                                                    <label class="form-label">Boîte postale : <span class="field-current"><?php echo $_SESSION['code_pste_etb']; ?></span></label>
                                                    <input type="text" class="form-control" id="code_pste_etb" name="code_pste_etb">
                                                </div>
                                                <div class="col-md-4">
                                                    <label class="form-label">Téléphone : <span class="field-current"><?php echo $_SESSION['tel_etb']; ?></span></label>
                                                    <input type="text" class="form-control text-uppercase" id="tel_etb" name="tel_etb" maxlength="50">
                                                </div>
                                            </div>

                                            <div class="row mb-2">
                                                <div class="col-md-4"><h5 class="fw-bolder">MATRICULE / EMAIL</h5></div>
                                                <div class="col-md-4">
                                                    <label class="form-label">Matricule : <span class="field-current"><?php echo $_SESSION['code_im_etb']; ?></span></label>
                                                    <input type="text" class="form-control" id="code_im_etb" name="code_im_etb">
                                                </div>
                                                <div class="col-md-4">
                                                    <label class="form-label">Email : <span class="field-current"><?php echo $_SESSION['email_etb']; ?></span></label>
                                                    <input type="text" class="form-control" id="email_etb" name="email_etb" maxlength="50">
                                                </div>
                                            </div>

                                            <div class="row mb-2">
                                                <div class="col-md-4"><h5 class="fw-bolder">PRE-MATRICULE / SLOGAN (DEVISE)</h5></div>
                                                <div class="col-md-4">
                                                    <label class="form-label">Pré-matricule : <span class="field-current"><?php echo $_SESSION['pre_matr']; ?></span> (la valeur OFF pour désactiver)</label>
                                                    <input type="text" class="form-control" id="pre_matr" name="pre_matr" maxlength="4" placeholder="4 caractères maxi">
                                                </div>
                                                <div class="col-md-4">
                                                    <label class="form-label">Slogan : <span class="field-current"><?php echo $_SESSION['slogan_etb']; ?></span></label>
                                                    <input type="text" class="form-control" id="slg" name="slg" maxlength="50">
                                                </div>
                                            </div>

                                            <div class="row mb-2">
                                                <div class="col-md-4"><h5 class="fw-bolder">LOCALITE / RESPONSABLE</h5></div>
                                                <div class="col-md-4">
                                                    <label class="form-label">Localité : <span class="field-current"><?php echo $_SESSION['ville_etb']; ?></span></label>
                                                    <input type="text" class="form-control" id="ville_etb" name="ville_etb" placeholder="Ville ou village">
                                                </div>
                                                <div class="col-md-4">
                                                    <label class="form-label">Responsable : <span class="field-current"><?php echo $_SESSION['nom_respo_etb']; ?></span></label>
                                                    <input type="text" class="form-control" id="nom_respo_etb" name="nom_respo_etb" maxlength="100" placeholder="nom du répondant">
                                                </div>
                                            </div>

                                            <div class="row mb-4">
                                                <div class="col-md-4"><h5 class="fw-bolder">LOGO + SIGNATURE DU PRINCIPAL (PNG ou JPG 128x128)</h5></div>
                                                <div class="col-md-4">
                                                    <div class="card w-100" style="max-width: 27rem;">
                                                        <div class="card-body">
                                                            <label class="form-label">LOGO</label>
                                                            <img src="plugins/images/<?php echo $_SESSION['logo_etb']; ?>" class="d-block mx-auto mb-2" alt="photo" width="135px" height="120px">
                                                            <input type="file" class="form-control" id="support1" name="support1">
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-md-4">
                                                    <div class="card w-100" style="max-width: 27rem;">
                                                        <div class="card-body">
                                                            <label class="form-label">SIGNATURE</label>
                                                            <img src="plugins/images/<?php echo $_SESSION['sign_respo_etb']; ?>" class="d-block mx-auto mb-2" alt="photo" width="135px" height="120px">
                                                            <input type="file" class="form-control" id="support2" name="support2">
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="row mb-2 align-items-center">
                                                <div class="col-md-4"><h5 class="fw-bolder">CACHET SUR LES BULLETINS</h5></div>
                                                <div class="col-md-4">
                                                    <label class="form-label">Cachet : <span class="field-current"><?php echo ($_SESSION['p_ch'] ?? 'N') === 'O' ? 'Afficher le cachet' : 'Ne pas afficher le cachet'; ?></span></label>
                                                    <select class="form-select" id="p_ch" name="p_ch">
                                                        <option value="N" <?php echo ($_SESSION['p_ch'] ?? 'N') === 'O' ? '' : 'selected'; ?>>NON — masquer le cachet</option>
                                                        <option value="O" <?php echo ($_SESSION['p_ch'] ?? 'N') === 'O' ? 'selected' : ''; ?>>OUI — imprimer le cachet de l'établissement</option>
                                                    </select>
                                                </div>
                                            </div>

                                            <div class="row">
                                                <div class="col-12 text-end">
                                                    <button type="submit" class="btn btn-primary">Enrégistrer</button>
                                                </div>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>

                        <!-- ===== DROITS ===== -->
                        <div class="accordion-item">
                            <h2 class="accordion-header">
                                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
                                    <h4 class="fw-bolder m-0">PARAMETRE DES DROITS</h4>
                                </button>
                            </h2>
                            <div id="collapseTwo" class="accordion-collapse collapse" data-bs-parent="#accordionExample">
                                <div class="accordion-body">
                                    <p class="text-muted small">Définir les droits aux utilisateurs</p>
                                    <form action="Controler/admins/updroleuser.php" method="post" enctype="multipart/form-data">
                                        <div class="row">
                                            <div class="col-10 col-sm-6">
                                                <label for="user" class="form-label">Utilisateur</label>
                                                <select id="user" class="form-select mb-2" name="user">
                                                    <option value="">Choisir...</option>
                                                    <?php $user->SelectTeacherAndRole(); ?>
                                                </select>
                                            </div>
                                            <div class="col-10 col-sm-4">
                                                <label for="user_role" class="form-label">Rôle</label>
                                                <select id="user_role" class="form-select" name="user_role" required>
                                                    <option value="">Choisir...</option>
                                                    <option value="ens">Enseignant</option>
                                                    <option value="pcpl">Principal</option>
                                                    <option value="admin">Administrateur</option>
                                                    <option value="caisse">Caissier</option>
                                                </select>
                                            </div>
                                            <div class="col-10 col-sm-2">
                                                <label class="form-label">Opération</label>
                                                <button class="btn btn-primary" type="submit">Enregistrer</button>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>

                        <!-- ===== COMPETENCES ===== -->
                        <div class="accordion-item">
                            <h2 class="accordion-header">
                                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
                                    <h4 class="fw-bolder m-0">ACTIVER LES COMPETENCES</h4>
                                </button>
                            </h2>
                            <div id="collapseThree" class="accordion-collapse collapse" data-bs-parent="#accordionExample">
                                <div class="accordion-body">
                                    <div class="row">
                                        <div class="col-6 col-sm-4">
                                            <form action="Controler/notes/updprd.php" method="post" enctype="multipart/form-data">
                                                <fieldset>
                                                    <legend class="fs-6 fw-bold">Activer/Désactiver les périodes des évaluations</legend>
                                                    <?php $opt->ShowPeriodesEval(); ?>
                                                    <button type="submit" class="btn btn-primary mt-2">Enregistrer les modifications</button>
                                                </fieldset>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>

        <!-- ============================================================== -->
        <!-- End Page Content -->
        <!-- ============================================================== -->
    </div>
</div>

		<?php 
		 	Config::scriptJs();
		?>
	</body>
</html>
