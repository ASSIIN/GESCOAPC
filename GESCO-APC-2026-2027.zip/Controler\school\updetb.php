<?php
	session_start();
	require_once '../../Model/connexion.php';
	require_once '../../core/require.php'; 

	// Sécurité : page réservée aux rôles autorisés sur general_setting.php (admin / pcpl)
	if (!isset($_SESSION['user']) || !in_array($_SESSION['user_role'] ?? '', array('admin', 'pcpl'))) {
		header('location: ../../index.php');
		exit;
	}

	$nom_etb_fr= htmlspecialchars($_POST['nom_etb_fr']);
	$nom_etb_en= htmlspecialchars($_POST['nom_etb_en']);
	$minist_etb_fr= htmlspecialchars($_POST['minist_etb_fr']);
	$minist_etb_en= htmlspecialchars($_POST['minist_etb_en']);
	$region_etb_fr= htmlspecialchars($_POST['region_etb_fr']);
	$region_etb_en= htmlspecialchars($_POST['region_etb_en']);
	$depart_etb_fr= htmlspecialchars($_POST['depart_etb_fr']);
	$depart_etb_en= htmlspecialchars($_POST['depart_etb_en']);
	$tel_etb= htmlspecialchars($_POST['tel_etb']);
	$email_etb= htmlspecialchars($_POST['email_etb']);
	$code_pste_etb= htmlspecialchars($_POST['code_pste_etb']);
	$code_im_etb= htmlspecialchars($_POST['code_im_etb']);
	$ville_etb= htmlspecialchars($_POST['ville_etb']);
	$slogan_etb= htmlspecialchars($_POST['slg']);
	$pre_matr= htmlspecialchars($_POST['pre_matr']);
	$nom_respo_etb= htmlspecialchars($_POST['nom_respo_etb']);

	// CORRECTION : paramètre « cachet sur bulletin » (p_ch) — valeur O / N uniquement
	$p_ch = (($_POST['p_ch'] ?? '') === 'O') ? 'O' : 'N';

	$support1 = $_FILES['support1'];
	$support2 = $_FILES['support2'];
	

	
		/* conversion*/
		$minist_etb_fr=str_replace("&#039;", "'", $minist_etb_fr);
		$minist_etb_en=str_replace("&#039;", "'", $minist_etb_en);
		$region_etb_fr=str_replace("&#039;", "'", $region_etb_fr);
		$region_etb_en=str_replace("&#039;", "'", $region_etb_en);
		$depart_etb_fr=str_replace("&#039;", "'", $depart_etb_fr);
		$depart_etb_en=str_replace("&#039;", "'", $depart_etb_en);
		$nom_etb_fr=str_replace("&#039;", "'", $nom_etb_fr);
		$nom_etb_en=str_replace("&#039;", "'", $nom_etb_en);
		$ville_etb=str_replace("&#039;", "'", $ville_etb);
		$slogan_etb=str_replace("&#039;", "'", $slogan_etb);
		

			
		$minist_etb_fr= mb_strtoupper($minist_etb_fr);
		$minist_etb_en= mb_strtoupper($minist_etb_en);
		$region_etb_fr= mb_strtoupper($region_etb_fr);
		$region_etb_en= mb_strtoupper($region_etb_en);
		$depart_etb_fr= mb_strtoupper($depart_etb_fr);
		$depart_etb_en= mb_strtoupper($depart_etb_en);
		$nom_etb_fr= mb_strtoupper($nom_etb_fr);
		$nom_etb_en= mb_strtoupper($nom_etb_en);
		$ville_etb= mb_strtoupper($ville_etb);
		$pre_matr= mb_strtoupper($pre_matr);

		

		$elt= array('
			nom_etb_fr' =>$nom_etb_fr, 
			'nom_etb_en' =>$nom_etb_en, 
			'minist_etb_fr' =>$minist_etb_fr, 
			'minist_etb_en' =>$minist_etb_en, 
			'region_etb_fr' =>$region_etb_fr, 
			'region_etb_en' =>$region_etb_en, 
			'depart_etb_fr' =>$depart_etb_fr, 
			'depart_etb_en' =>$depart_etb_en, 
			'tel_etb' =>$tel_etb, 
			'email_etb' =>$email_etb, 
			'logo_etb' =>$support1,
			'sign_respo_etb' =>$support2,
			'code_im_etb' =>$code_im_etb,
			'code_pste_etb' =>$code_pste_etb,
			'ville_etb' =>$ville_etb,
			'slogan_etb' =>$slogan_etb,
			'pre_matr' =>$pre_matr,
			'nom_respo_etb' =>$nom_respo_etb,
			'p_ch' =>$p_ch
		
		);
		
		foreach ($elt as $key => $value) 
		{
			if ($value!="") 
			{

				if ($key=='logo_etb') 
				{
					$file_nom = basename($support1['name']);
					$file_ext = strrchr($file_nom, '.');
					$tab_ext = array('.jpg', '.png');
					$file_exten='.png';
					if($file_nom!="")
					{
						if (!in_array($file_ext, $tab_ext))
						{
							$erreur = "Format image non pris en charge";
							echo $erreur;
						}
						else
						{
							$fichier ='logo'.$file_ext;	
						
							// CORRECTION : chemin absolu (indépendant du répertoire de travail)
							$dossier = __DIR__ . "/../../plugins/images/";

							$file=$dossier.$fichier;
							if (file_exists($file))
							{
								if (is_file($file)) {
									unlink($file);
								}
							}
							$file=$dossier.$fichier;
							if (move_uploaded_file($support1['tmp_name'], $file)) 
							{
								$bdd = $GLOBALS['bdd'];	
									$req ='UPDATE etablissement SET logo_etb= ? where id>=0';
									$rep =$bdd->prepare($req);
									$rep->execute(array($fichier));
									
							}

						}
						
						
					}
				
				}

				elseif($key=='sign_respo_etb') 
				{
					$file_nom = basename($support2['name']);
					$file_ext = strrchr($file_nom, '.');
					$tab_ext = array('.jpg', '.png');
					$file_exten='.png';
					if($file_nom!="")
					{
						if (!in_array($file_ext, $tab_ext))
						{
							$erreur = "Format image non pris en charge";
							echo $erreur;
						}
						else
						{
							$fichier ='signature'.$file_ext;	
						
							// CORRECTION : chemin absolu (indépendant du répertoire de travail)
							$dossier = __DIR__ . "/../../plugins/images/";

							$file=$dossier.$fichier;
							if (file_exists($file))
							{
								if (is_file($file)) {
									unlink($file);
								}
							}
							$file=$dossier.$fichier;
							if (move_uploaded_file($support2['tmp_name'], $file)) 
							{
								$bdd = $GLOBALS['bdd'];	
									$req ='UPDATE etablissement SET sign_respo_etb= ? where id>=0';
									$rep =$bdd->prepare($req);
									$rep->execute(array($fichier));
								
							}
						
				
						}
					}

				}
				elseif($key=='pre_matr')
				{
					if ($value=='OFF') 
					{
						$value_ok=NULL;
						$bdd = $GLOBALS['bdd'];	
						$req ='UPDATE etablissement SET '.$key.'= ? where id>=0';
						$rep = $bdd->prepare($req);
						$rep->execute(array($value_ok));
					}
				

					else
					{
						$bdd = $GLOBALS['bdd'];	
						$req ='UPDATE etablissement SET '.$key.'= ? where id>=0';
						$rep = $bdd->prepare($req);
						$rep->execute(array($value));

					}

				}
					
				else
				{
					$bdd = $GLOBALS['bdd'];	
					$req ='UPDATE etablissement SET '.$key.'= ? where id>=0';
					$rep = $bdd->prepare($req);
					$rep->execute(array($value));


				}

				
			}
			
		}
		header('location: ../../general_setting.php');
		exit;
?>