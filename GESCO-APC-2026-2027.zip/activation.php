<?php
session_start();
require_once 'core/require.php';
require_once 'Model/checkdb.php';

// Sécurité : Si l'année de connexion n'est pas définie, on redirige vers l'index
if (!isset($_SESSION['con_year']) || empty($_SESSION['con_year'])) {
    header('location: index.php');
    exit();
}

require_once 'Model/connexion.php';
require_once 'less/licence_service.php';
$bdd = $GLOBALS['bdd'];

licence_creer_table();

// 1. Informations d'identité de l'établissement local
$stmt_info = $bdd->query("SELECT nom_etb_fr, school_year FROM etablissement LIMIT 1");
$info_etb = $stmt_info->fetch(PDO::FETCH_ASSOC);
$nom_ecole = $info_etb ? $info_etb['nom_etb_fr'] : 'Établissement non configuré';
$annee_scolaire = $info_etb ? $info_etb['school_year'] : 'Non définie';

// 2. Identifiant d'installation stable (généré une seule fois, communiqué pour l'achat)
//    Pré-remplissage possible depuis ?iid=... (récupération en cas de panne / changement d'ordinateur)
$licence = licence_lire();
$install_id = $licence ? trim($licence['install_id'] ?? '') : '';
$iid_get = trim($_GET['iid'] ?? '');
if ($install_id === '' && $iid_get !== '' && preg_match('/^[A-Za-z0-9\-_]{1,64}$/', $iid_get)) {
    $install_id = $iid_get;
}
if ($install_id === '') {
    $install_id = licence_uuid_v4();
    if ($licence) {
        $bdd->prepare("UPDATE config_licence SET install_id = ? WHERE id = ?")
            ->execute([$install_id, (int)$licence['id']]);
    } else {
        $bdd->prepare("INSERT INTO config_licence (cle_licence, statut_activation, install_id) VALUES ('', 'inactif', ?)")
            ->execute([$install_id]);
        $licence = licence_lire();
    }
}

// 3. État actuel de la licence
$etat = licence_verifier();
$licence_active = $etat['valide'];

// 4. Lien d'achat / renouvellement vers le portail INOFIB avec pré-remplissage
//    L'année scolaire locale est transmise : la licence est liée au nom de
//    l'établissement ET à l'année scolaire (toute modification manuelle verrouille).
$lien_portail = 'https://licences.inofib.com/service_gescoapc.php?install_id=' . urlencode($install_id)
    . '&nom_etab=' . urlencode($nom_ecole)
    . '&annee_scolaire=' . urlencode($annee_scolaire);

// 5. Traitement de l'activation / remplacement
$erreur_activation = false;
$message_activation = '';

if (isset($_POST['activer'])) {
    $cle = trim($_POST['cle_licence'] ?? '');
    $cle_publique_post = trim($_POST['cle_publique'] ?? '');
    $install_id_post = trim($_POST['install_id'] ?? '');

    if ($install_id_post !== '') {
        $bdd->prepare("UPDATE config_licence SET install_id = ? WHERE id = ?")
            ->execute([$install_id_post, (int)$licence['id']]);
        $install_id = $install_id_post;
    }

    if ($cle === '') {
        $erreur_activation = true;
        $message_activation = 'Veuillez coller la clé de licence reçue par email.';
    } else {
        $controle = licence_verifier_cle_saisie($cle, $cle_publique_post);
        if ($controle['valide']) {
            licence_enregistrer($cle, $cle_publique_post, $install_id);
            unset($_SESSION['licence_verifiee']);
            $_SESSION['activation_ok'] = true;
            header('Location: index.php?lk=1');
            exit();
        } else {
            $erreur_activation = true;
            $message_activation = licence_motif_message($controle['motif']);
        }
    }
}

$licence = licence_lire();
$dernier_controle = $licence ? $licence['dernier_controle'] : null;
?>
<!DOCTYPE html>
<html lang="fr">
<head>
     <?php Config::head(); ?>
     <title>GESCO-APC | Activation Annuelle</title>

     <style>
         .glass-card {
             background: rgba(255, 255, 255, 0.9);
             backdrop-filter: blur(12px);
             -webkit-backdrop-filter: blur(12px);
             border-radius: 16px;
             box-shadow: 0 8px 32px 0 rgba(0, 0, 0, 0.2);
             border: 1px solid rgba(255, 255, 255, 0.25);
         }
         .install-box {
             background: #f0f7ff;
             border: 2px dashed #0764a8;
             border-radius: 10px;
             padding: 14px 16px;
             font-family: Consolas, monospace;
             letter-spacing: 1px;
             color: #0764a8;
             word-break: break-all;
         }
         .key-input {
             font-family: Consolas, monospace;
             font-size: .84rem;
             letter-spacing: .5px;
             word-break: break-all;
         }
     </style>
</head>
<body style="background-image: url(plugins/images/bg1.jpg); background-size: cover; background-position: center; background-attachment: fixed; min-height: 100vh; display: flex; align-items: center;">

    <?php
    if ($erreur_activation) {
        echo "<script>
            Swal.fire({
                icon: 'error',
                title: 'Licence invalide',
                text: " . json_encode($message_activation) . ",
                confirmButtonColor: '#19784f'
            });
        </script>";
    } elseif (isset($_GET['motif'])) {
        echo "<script>
            Swal.fire({
                icon: 'warning',
                title: 'Licence requise',
                text: " . json_encode(licence_motif_message($_GET['motif'])) . ",
                confirmButtonColor: '#19784f'
            });
        </script>";
    }
    ?>

    <div class="container py-5">
        <div class="row justify-content-center">
            <div class="col-md-7 col-lg-6">
                <div class="card glass-card p-4 mb-4">

                    <div class="text-center">
                        <img class="mb-3 mx-auto d-block" src="plugins/images/gescoapc.png" width="200" alt="Logo GESCO-APC">
                        <h4 class="fw-bold mb-1" style="color: #0764a8;">Validation de Licence</h4>
                        <p class="text-secondary small mb-3">Abonnement annuel et nominatif obligatoire</p>

                        <div class="p-3 mb-4 rounded" style="background: rgba(7, 100, 168, 0.08); border-left: 4px solid #0764a8;">
                            <p class="text-dark fw-bold mb-1 text-uppercase small" style="letter-spacing: 0.5px;">Structure locale détectée :</p>
                            <h6 class="text-primary fw-bolder mb-2"><?php echo htmlspecialchars($nom_ecole); ?></h6>
                            <span class="badge bg-success font-monospace px-3 py-2 fs-6" style="background-color: #19784f !important;">Session : <?php echo htmlspecialchars($annee_scolaire); ?></span>
                        </div>
                    </div>

                    <!-- ÉTAT ACTUEL -->
                    <?php if ($licence_active): ?>
                    <div class="p-3 mb-4 rounded" style="background: rgba(25, 120, 79, 0.10); border: 1px solid rgba(25, 120, 79, 0.35);">
                        <div class="d-flex align-items-center">
                            <i class="fa fa-circle-check text-success fa-2x me-3" style="color:#19784f !important;"></i>
                            <div>
                                <strong style="color:#19784f;" class="fw-bolder">Licence ACTIVE</strong>
                                <div class="small text-dark mt-1">
                                    Valable du <?php echo htmlspecialchars($etat['debut']); ?> au <strong><?php echo htmlspecialchars($etat['fin']); ?></strong>
                                    (<?php echo (int)$etat['jours_restants']; ?> jours restants) - Tarif <?php echo htmlspecialchars($etat['tarif']); ?>
                                    <?php if ($dernier_controle): ?> - Contrôle : <?php echo htmlspecialchars($dernier_controle); ?><?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php else: ?>
                    <div class="p-3 mb-4 rounded" style="background: rgba(220, 53, 69, 0.08); border: 1px solid rgba(220, 53, 69, 0.3);">
                        <i class="fa fa-circle-xmark text-danger me-2"></i>
                        <strong class="text-danger">Aucune licence active</strong>
                        <span class="small text-muted"> - effectuez le paiement puis collez la clé reçue ci-dessous.</span>
                    </div>
                    <?php endif; ?>

                    <!-- IDENTIFIANT D'INSTALLATION -->
                    <div class="mb-4">
                        <label class="form-label fw-bold text-dark mb-1" style="font-size: 0.9em;">Identifiant d'installation (install_id)</label>
                        <p class="text-muted" style="font-size: 0.78em; line-height: 1.3;">À recopier lors de l'achat ou du renouvellement. Votre licence est liée à cet identifiant unique.</p>
                        <div class="install-box"><?php echo htmlspecialchars($install_id); ?></div>
                    </div>

                    <!-- ÉTAPE 1 : Paiement -->
                    <div class="mb-4">
                        <label class="form-label fw-bold text-dark mb-1" style="font-size: 0.9em;">Étape 1 : Renouvellement de l'abonnement</label>
                        <p class="text-muted" style="font-size: 0.8em; line-height: 1.3;">Réglez la licence annuelle sur le portail officiel (Assiin Pay), puis récupérez votre clé par email.</p>
                        <a href="<?php echo htmlspecialchars($lien_portail); ?>" target="_blank" class="btn btn-primary w-100 fw-bold py-2 shadow-sm" style="background-color: #0764a8; border: none;">
                            <i class="fa fa-credit-card me-2"></i>Payer la licence annuelle sur INOFIB
                        </a>
                    </div>

                    <div class="d-flex align-items-center my-3">
                        <hr class="flex-grow-1 text-muted">
                        <span class="mx-3 text-muted small fw-bold">OU</span>
                        <hr class="flex-grow-1 text-muted">
                    </div>

                    <!-- ÉTAPE 2 : Activation -->
                    <form action="activation.php" method="POST">
                        <div class="mb-3">
                            <label for="cle_licence" class="form-label fw-bold text-dark mb-1" style="font-size: 0.9em;">Étape 2 : Clé de licence</label>
                            <textarea class="form-control key-input" id="cle_licence" name="cle_licence" rows="3" placeholder="Collez ici la clé de licence complète reçue par email..." required style="letter-spacing:.5px; color:#19784f; background: rgba(255,255,255,0.7); border: 2px solid rgba(255,255,255,0.5);"></textarea>
                        </div>

                        <div class="mb-3">
                            <label for="install_id" class="form-label fw-bold text-dark mb-1" style="font-size: 0.9em;">Identifiant d'installation (install_id)</label>
                            <input type="text" class="form-control key-input" id="install_id" name="install_id" value="<?php echo htmlspecialchars($install_id); ?>" required maxlength="64" pattern="[A-Za-z0-9\-_]{1,64}">
                            <div class="form-text small text-muted">Ordinateur en panne ou remplacé en cours d'année ? Saisissez ici l'install_id d'origine fourni dans l'email de récupération (portail licences.inofib.com → « Récupérer ma clé »), puis collez la clé ci-dessus.</div>
                        </div>

                        <div class="mb-3">
                            <label for="cle_publique" class="form-label fw-bold text-dark mb-1" style="font-size: 0.9em;">Clé publique INOFIB <span class="text-muted">(facultatif, pré-remplie)</span></label>
                            <textarea class="form-control key-input" id="cle_publique" name="cle_publique" rows="3" placeholder="-----BEGIN PUBLIC KEY-----..." style="background: rgba(255,255,255,0.5); border: 1px solid rgba(255,255,255,0.5);"><?php echo htmlspecialchars(trim($licence['cle_publique'] ?? '') !== '' ? $licence['cle_publique'] : INOFIB_CLE_PUBLIQUE_DEFAUT); ?></textarea>
                            <div class="form-text small text-muted">Ne modifiez cette valeur que si INOFIB vous a communiqué une nouvelle clé publique.</div>
                        </div>

                        <div class="row g-2 mt-2">
                            <div class="col-8">
                                <button class="btn btn-success w-100 fw-bold py-2 shadow-sm" name="activer" type="submit" style="background-color: #19784f; border: none;">
                                    <i class="fa fa-check-circle me-2"></i>Valider l'activation
                                </button>
                            </div>
                            <div class="col-4">
                                <a href="index.php" class="btn btn-outline-secondary w-100 py-2">Retour</a>
                            </div>
                        </div>
                    </form>

                </div>
            </div>
        </div>
    </div>

    <?php Config::scriptJs(); ?>
</body>
</html>